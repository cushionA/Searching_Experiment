import ast
import base64
import gzip
import hashlib
import json
import os
import pathlib
import resource
import subprocess
import sys
import time

os.environ["HF_HOME"] = "/tmp/qwen-html-hf"
os.environ["TRANSFORMERS_VERBOSITY"] = "error"
os.environ["USE_TF"] = "0"
os.environ["USE_FLAX"] = "0"
MODEL_ID = "Ambition0303/Qwen-HTML"
MODEL_REVISION = "b1b061d3f708807534d3796414e0c882ac46e883"
COSCRAPER_REVISION = "a83a1b9740b8883c25365316728c890d4ff68c0e"
INPUT_GZIP_B64 = "H4sIAIM5+WoC/+29+27jRvIv/io93i9OJsBQ4v0y6xVgzyXOYm4bOwmCJCCazabEMUVqebGj3SxwXuP39+9NzqOcJzlVTYoiZcm2ZuiFRXM2S4u36urq6vpU9aX476OcZpdHL4/OecRZTqIwvsxInpAw9sOr0C9oRBZp4hdwz+c5DeGUTnlGgjSZE1rfi8IsD+PpiLz5g0WFzwmjOZ8m6fIFielVOKV5mMQvCGUsKeKc0NhHOmEsrpeljsg5veJAMy0iTvIZzYFITDxOUl5k3CfwII2TfMbTurijF0cZ575bpFF29PLXo1meL7KX47GXJEAwTzKW0gUfsWQ+hkdvuQvs0iiZFny8Yrx8ylXGIAn+x2iWz6MvIzHOU6hX5KpNSr8jKfgLPB8/e/3x1cUvn94QvDI5xiOJaDz9229HPJaK7LcjwiKaZXAeJ9JnOJ8cP5Ok42e/cmik4HdJgpc49Se/xaT6d5yHecSrCydR3YYZ+ZOcIlPYxOeCdyKB3GPfS/74LT4er95rkJpDsxOst8T/WYRXwAVL4pzHuZQvFxyZK0/hRs7/yMfI/18Jm9E04/nffrx4K9nA8SbBmM45kko5CMtvUVH1fEb+XsRElRWTyM5L1dlNwOfQBOEC1ahFZPcbVyG/XiRp3nr8OvTz2d98fhUyLomT3QTSxEvyrPX6h48nP7w6+/6nNy8+fHx18ursjXi78T60F3nHydnF+3cGyWbh/AUJkpR8/8aUbJIVC2SIJIF4gEBXnAPdjEDLtmn8GgYkyuE14vzevFXKgGQpA2bGogkMLGU0TZIpdOzEL3U0u4pBHYv4snxkVCrTuHy9VdZat5r1WP8ST2G/hd4ZQaHZDGrAipyETLTELOUBXs6hh7Mx9BOajgOwBHB3BIeWdLeXUP5qHm+UmS8jns04x7ZEZVypIMuyHSzAnXH52kg8NGnS30l7G6XPGXbvPIPevZB8UOI8nPNFyC55uvNGq8wOarKD+i553iXxbWebzx2PK1NTnXqJvyShL3piQIsob1ir+srkfu0rrBhY99X7q1PoZjSMeSoFURH67Y4JKFU/j8jkhjE82XrmxnNpcn3jgRsPsSSSsjn0zpmCfYSuGmFtxOHyhi09HtPJcTanUTQhP3MSJYBnHgegIiVO+M+gr4nbaGuhtFbn2tHJque2nZeNwdOazOq4UZOW/ASAr7XwHgKsniyi+kEPzLbP0mLutVsjCjflvl1uZ8lcCKtZrda7QKkujLI8vEKOm0DWeP54XERta7utsTf5ykL0UqqH8MSjqGqi0XXxY+5L2lY92aE5ohcAf/ME0ShzIx7kW9/fQWOjoW+3gztqixVxK/8j5NnNftBoRHDM0DmT0Jm6Zz23N/L2Br+XS7VTPrfz0Pwn+uCXEimV8Jb7QrXuT/dhRLbNhexAcheC6oOJbnxrrf9rspsvs5ynS1frVnjvS7J9l94MjAOYEkYjKQgZGjZX71aQZ3UJ5G1ZQt9lmkEgBf59CDKlae4a3crzvKZOTiDK6bksBZiFLHPNbqX4qqLbd/ktZmGUZMlitnStbiX4qabcdxmCy0djxl27WwH+UJLtu/SuIRaIsxpdnG6F+LOg/lSQZSVERe5Wik9EfAxMlp+CvrhKx0HKqxXl3ttCHoVToYIdBys/VIT7LsA4iete3HHI8qEm3fuYrwDfzVU6jlTeI9W+i64atHWVjsOS19VgcN9jOxZycNpqd0bpOC45L+k/mVAZJ8Yyica+NKVzDsDccZRyLgoQE9LfYQF9Fyj1fYlKLJnjDKOrdByynPg+oaSi3ntnm8Y5zZau0nHI8rak23tHh19L1EeoUTuOVj7wa9DEJwA2y6SIpyshdhyx/IK0n4YYK8x2VfVBsLr3Q4gJz9Olq3YcrXwSZHsvPJrSOEnnNHLVjsOVTzXp3js1Kdi/juOVJzB3ssiWbJbALei8HYcpn2rSvde9Ik+8MJmmFOdQ1I7Dk5Mm9SdgC3HiMp66qt25KSwp9z+8A3+tHnxQna7DO6D+VIYeZsU8SV2t49jkDKn2XnRJmqLsOg5JzgTZp7HiZulq6kOss+k9iARJ4ovxQj8N40tX6zgqeQvkxWjhayTf/wnRFHfa0LiGFE3vemK0KuGpwIpXZGHMs8zVOg5YTivCvRdg7WxrHQctp0/F0c6h00URB4TuOFy5qAj33i7izq/5IkkpAnXHwcqrBvH+z++FaZgXNApzEKTT9dzemnjvAz9GfT4Pmat3HLCcVIT7vyg7CqQZjxaurnS9IDsKyBlQfjp7BVxdfahNAk/G5XZ17YFc7d535SJb8Djjrt5xsHJeEe69AHEztyR6HM9cvesNKkidnJfU+7+c84pHIEOz66WcSLb3gMJplM9cveMo5UyQ7f+0PPi9uDNK73oypSLceyQuorxI0ZnpOC55VRHuuwB5moCeUNfoOCR5U9Ltvf6l4Zy7Rtc7UZDqoxFd++Uimnyl8KtcEOvTdU6F1XHzBZEJ4maCiK25QKq0EM4+aSGayTWkKqUJLYe6d7Xm8UzZSHYBF/bJGLH9Gv5vnalizrMMU3lV2THW+Ujul97iCzJb7BLZcZCkczLn+SzBMqa8mUQG70ngMYb/wjQm0Y5kMoJDkUUH886E2SKiy5dxEvMbbO46u8nkbe/d0u2zPE3i6USRZfl4XJ2QlGdg9DMiEfCtrzEjTP3c+qE8qa+q63dHd5W862yVHQUlOLmRRynjQgdvy5NDIw6OujhK1zSNcf3EEUkTIWRxGTPjVGz+XD7wbF2di1mYEfiPEp/PE3LNvSzMuch7Bb/LlDgoiUWRLpKMZyPyCSJ8Xi7GTyku18jIjKccHodDCpeTebQkuDF7GvNyGm6GOePiBARMI1AhijyMtivc8fbecpxEd2YGusMqNpLVoIX4I5PMm6lkxI9oWuWUaf6vxIMUMC1ap6Sp+r67SPwdOn+jvcI55u+p0/3skdNlhypvwSgqReF0lkthLOUzLtE8x41WoOttlDoO59MqHdmc+yEFbGMzPlbZ2Kdw9KlvWkzXPVlWuQU2UWZMM0xHYzK3vdHnBSoaOOnw+gl5hwWSMCZQIDnBAhvmIZ8Vcy+moSi0lVFoP9ho68Y+ZuB4sc6+k9NUKjUXp0I4323h1xqDKdEkfFPUIOzpC8fjxWS3odqp3jNt8uVaSEQ2w506NNm4PBqNRAKvMRR6L+Za6L7qrmjCdvS8zT7fsMaLBiEgAJ04SlCY/+f/N5SRZa2lJ6B6/XQYZ3nCLgm9gi5AvVBMddS5vTYaKLlsNc+6+O9jIsjU6cNEcfc3HtsrdtwAHnHuFXmexKv8dlnhzcMm0nt5TOD/EkhgTtOl+O1FyNYR8aHppSihPnQtCTPjYav6eAathk3p+wifHs0ueX48LkuabCDg/snWVgQq41w5Sjs91AEisHPm4WIhmgl65hWPrnjuOo5zP3wwxzKDo8xMyhXTY1xTmB3YzDEAMnzfCXSqsBY+XJSliR78kyjtENDhYzxgwwNhwz3UrwaGbcozuXnxMcKCNrL0ARYGWDgYWMiSYh5C6IY5fhz7XnCg8TEP4MgDx2GO71CfB5puak5gKLJpqrKq2prcgoPzupQBBp40DNyibrX5byrLZH3yGM29PFLkwdwP5v5wzP2Mpgsp8T5zlmfQBa37WXx1bChwNBQWaFTTFTUwtEDTHK6r8ISqaLrsaG2LjwWRj2VBh2D03yZFOlj9B7L6t2rd2vC3dWbSOn+E5l+3RrY6mP/B/B+O+aeLENN6UslLQx5I1a42KYGfxZzGl9AvoX+a90IFj4+pAUdqmI4VqIamUzWwTarxQLU8g9pMUanZRoWy/JfkhJwiA6vtb+IjKysGDgItym8fDGjxEGjxJUq6BpH7qdhk53OPdMJBH6nagDUD1hzOhMOMSyl+nIzP4S/2WONesGLaY02DI4QXns4cj8marpoWV3xqKgr1NE/TA7s92zDj5IeyKPjrD2NMT3uq4Q7FW88zbKrNZOPKI8QBVR2ZxoADAw4cFA74YZovJdBG6HhSxlnK8wz9uSnP0RpKy6RIJT/ldC59Tjzosfq9oMJRx6oFR9XSqWN4FlMNJYB4xKGqZ1PLVi2DevoNqHiN3JB3ghtyXnKD7uF3JTeYZDElr5Eb8vfEGwavBjj5Sv1tIc6+2jfZ+dLjjFQ0baQNc+ADQh0WQrFkji11jV/3kagkNghK0Drcl5JyOWMUBhz7PP4O44DOkyKTAg6vhVkuXYUMt05SoJD4syKKwAho95tc8ceGDkdDd3SZGxY3TZXpvq8EWhDIMrNsxsybIPZKMIxf0qExDmKIvYfklFbf5MZlMu+AY7Qs+Pv7imPytuL4BfmpYhlolCwPC3gHqPsvdIQWGj6IGk+2UX6caKlYI2cY1xvQ8rDQ0kuW2WqZv5fQXIqhOInOOSYDicsvg8C9MJXwK+jSPwsOlgGaSZomkS/B8/ii4mim5PE0AkJJtJwvcFu046j3GyU0x7YNR9vWPEcJTFvWPVVTNWZrpqNpCvMsgNAbqHkKjK92FpwC4y/JB+CcnKw4F7uXLpBz8gb4If9AzsXmqO+Ac0Jz8SZyTk4F5+RjxfkQJg7Y+d/rFi0MfUilnmwW8DhhFIdFh5V4A4weGIxGlF1K0IwhhR6u3Av4DHusm3DUTRliRdWWVVU1bcXQPB4Epq8Zqieb7CbwYVHkPRY1TI8NQHWL4rWhpak2k40rj3GZhDpShumxAQcOaEke9PwrbKcZp/hRxRw6VjwtIrCFeUp9jhfwiy2SAj1Vvu/CvECHY6DrPlVt5tiBIxtU4x5nsmdbHreNzQ06FReYhQu/vPj8omaDXCAbcBRsvCB/Ub49iIHC62RAkAdaoPflKrteprenwk3ufuGRDvBpI8cZEGlApEPaI3TJswV0M55JWRLHHDdt2PfLFaDIY92Go24HpuZrniGbCvPVQFd1X5U9LXA80zQ3twqtyvsmI+dlgcNw2pPfMnS3EjZ3Dm1TocnW649x+EoemeYAEgNIHA5I8FyacylIOYdueb/EAYaHczaGZ9vMUE1NCwwNbgSKqTLFCPTAVjXF2NhGynPynpO3YtJ/2Bb0pBHhFo1bA0FTXyaNs8c59a8PRn8w+gdk9FmS59IijKbQkBk0J2chLv6pFsaKhUGtZ3AEwL5fjgFHH3sKHD3Fsz1V1z3GHdOymBqoDmPMdmQfIog2OGBR5FNZFPh3nyp+VutkxcKh562nDmX0agCSBwSSDrR4DThfqoOTu958pPtQ1ZE6DGcNoHU4oJWGCynMpWIhlt+gncklOoXyoFPfL9GBrYyZDkemU8fSNFPniuXLSqAqFlcU21YNzTd4C5p+CBckzMmPC7H2Bseuc3KChQ7g87TB5/7aWEPMLbo0ad97pBuCjJE8pMkZIONwIAN383nYP1lSRL7k8XKDX+UZ8phnUpAm8zLLebXKUoK+G3KpgB6cTtME/kqKYytwcNB9vF/uA0MfmzIcTdkKuO3ohu1YzGeM+7Ks64qseYrstWdPPhYpOcXO/wp5Jae83ECIfudLci6YJchsmWO9Yhb6CzBLflwz+4LU3A7bgJ44Rj24+tfQ9hDKO7lJ9JGGUtZIHdaqDbh4QLgYhQl05vslZzAMzONjGJqmyNRSTNUPPKYy01ccaus+lf3A4e0dOh+B/rA6+WljzzYVW+OFUJAJ/nmMs/jayLYHgz4Y9IMx6HOeUXCqqo3dHm5Hy1jIY8alIBRfolt9b1pSbFmGg+5A77xfYgPZGVMNjlSjPNBtw7AMy+QKtQ2PWjzg1ObMs1oA8H7Fz0si9hrgPrXzkiHytmRo9YlqUjM0IMaTRoxOdLhGmC/UwMlt7z3SYTlrZAwzOQNaHQ5aRaHH0xx3nsUhVA83Tnt8GsZQHq4NvV/iANkbewyOHvNlagY6/LUVxjxF1h1qqJZm6rLZnsx51ypXbJw+XZU7bIV50uCzl0rWIHO7Qk1uu/04v4WpDSlsBiA5HCAJMXtjHC2FxziDEiO6pNhf77cFX7XwwweqRQ3NByBxDM/3bVu1bU4D02SOqsm+1YaQ7/NvMggCoqUYyT5bFTmgx5NGj3vqYY0bO7VosuPOY/xojjFShi8nHypaHI+T6BZdWKlRU0pFtNYFMO03LfoGy00cKtKUx/kdb+C/T0CZKJgl0JBvpX6zslsq2WAhhrZBLdvSe7E2krrCCnyw7G63lHA8LqK6FUs5bTbiZpMdjzMuhh0aHWb7G8138MrxM0ki4zS5JpLUKrS8gey7wqks7zfv1fArBVER+uUD694APSHJ4b2VkFan7bfqZtvUPyyrfGWj/u1fG7VExj7/o+DQk+r61DczloaLvMLqWZ4vXo7H9DP9YzRNkmnE6SLMRiyZi2votGfjz/9EUmNl5IyU6mQ0D+PR50wYlZLg9mIm12Cdk+tRxc2ffxI/YcUcNHV0nYY5f/5Nmx9AFOhu4yRjNB1/rosu/0iCg0bRv/22Kvybb2s+vobgzbqU0t0t+ZvnQvoX12GO7XwKbZflKV00FKvir7KFaNHGn8GIl5fB4G1n3FtR0tY/d3IuePiIr94sdzv58kcRCnK7eWMzmmYcTXCRB5LdLvk+5dS8S2DXeR7OMb3bJU933vgahr6CHQAfGvHdD4xoFH2drG7TqG32q2Gz7tCgja74P8+DIhZ28fm35N+7cLB5FOIZhXGYP//2ryseyosZpymbbd5b/fsPXmqY47ZmbNQCdfQniNPFSPCH8UnbVjV8HmgEf4nOGcDH5OjF0fGz1x9fXfzy6Q0RV47xSCIaT0EYPJaKZqwQJ1LZQaC042e/8tgPg9+hoOMZp34TO4TjWF2AXnuZkT9XzJan4GOcM1AETiRyTmPfS/4ouVu92SA25zmgINhWCb+QciXixDgHqydhmyF75emq9bAGf60V5seLt0JdNgnGdI7tzVIOqui3qKh6PiN/L2KiyopJZOel6uwm4POyYapvTNdEapHvfPMq5NeLJM1br12Hfj77m8+vwHuVxMluAmniJWXGgvr1Dx9Pfnh19v1Pb158+Pjq5NXZmypebunJO/DUL96/M0gGvv8LMc7z/RtTsklWLJAh8ckyeIDwiCO6ZG1lQhq/hgGJcniNOL9Pbnam0j6MRVMYWEqFhyzxucDD7Coe52kRX5aP7ESMppbdEkFEYXxJUh6hUZpBDViRE3TVQTaV+zQajcv/WkYroFf42AgOG+MEd0FUg8Vm4fkS7NyM83zDlrEsu4sXeGRcvj8ST7ecmJ2F3EryiyCiWXiXddtRzC5R7z+WcPM5sHKlYapO0fSR0Be9NqBF1Iya6iuT+zW9sHkNX3R1usMXvRno1m7wDYxpPQd+9NYwuPVQNV5mk5nSChrq1mgNL22YYBE9ZBC5RxPyMydRcsWJx3EIJhP3/WfQMcXtlbO+fwDYPC9bpXLCW955u0rtUADltdbLe0iyerIRBnpg632WFnOv3Sw3Aqe7BHiWzHl7rGwj+moRr8un4DeIHS6iARqvVOHZDk1ZacAmj1nor0c88cSj6c2R03sOZIoSRddYpMk8QTjL3IgH+c4xuG1BervRb7ebO2qLFXEh2OVTMdl9s3M0GjSmV4CFV1IUZvkeA7bHOwce2o3favPdL9w+vr2GxjxN4umq7auzL6Vaat8t94voFtpdCwr6h4fVAkinVzxyN2ZEv1Z0F4Lqg4lqfGstH0xW82UGQe3S1boV1vuSbN+kVX6MN4Q4crW6xtW7FdxZXcJqwU3fZJhB/ATufAgypGnuGt3K77ymTk4gqOmZ7ATkYEZ8s1upvaro9k1ei1kYJVmymC1dq1uJfaop901mKX4yiHHX7lZgP5Rk+yata3DC46xGA6dbof0sqPcVCVZCU+RupdZTcTEwOX4K+uAqSsfmf0W5d7aMR+FUqFjHwcAPFeG+CSxO4rpXdhwSfKhJ9y6GKsB3cpWOI4H3SLVvoqrGN12lY7f/dTVu2rdYqb2Vw1U69vs39nb0Tnw4j1R+eGxK5xyAs+Mo4FwUILLPfIcF9E2A1Pclih9FxQk4V+k4JMBlXpRU1Hvn3NI4p9nSVToOCd6WdHvnePBrifoIDWrH0cAHfg2a1kNwWCZFPF0JreOI4Bek3U+xVZjqquqDYGnvhtASnqdLV+04GvgkyPZOWDSlcZLOaeSqHYcDn2rSvXMyUrBfHccDPRz7X2RLNkvwo1Cu2nEY8Kkm3TvdKvLEC5NpSnEOQO3Y/T9pUu+hLcOJtHjqqnbnpqyk3L9wCfylOlhXna7DJaDe11B9VsyT1NU69v3PkGrvRJWkKcqqY5f/TJDt54qNpaupD7FOo3dGP0gSX4yX+WkYX7pax17/WyAvRsteI/n+TdCloBUhjWsI0PSuJ+qqEvoKA16RhTHPMlfrOCA4rQj3TmC1c6t1HBSc9tWxzaETRREHBO04HLioCPfOruHGnvkiSSkCacfBwKsG8f7NP4VpmBcU9/G7mtP13NOaeO8CKUZ9Pg+Zq3ccEJxUhPu3qDYKpBmPFq6udL2gNgrIGVDu71puV1cfahF3b11cV9ceyLXtXdcssgWPM+7qHQcD5xXh3gkM986uspa6etcbBJD6Kolp/5bvXfEIZGZ2vXQPyfYOADiN8pmrdxwFnAmy/ZsGBj8Td57oXU8GVIR7h5RFlBcpOhcd+/2vKsJ9ExhPE9AD6hodu/xvSrq90680nHPX6HonAFJ9NKJqv1xEk68UdiMBWXm63ineTtPTqBHuBL+57X1r2oNqs7uzz2b3ZvoAqcreQMuh3Z1pJ2fKav82/NpnA/zu1HXrjfdznmXAyyotxq5EbXUFNnbrf8FG/fts1RfZB8mc57MEy5vyZtIMvCeBWxf+C7M1RDuSZwhuRfoQzLMRZouILl/GyZZPE+zOX7fJ8F259HY0YLXtXpFlud6DT1KegWXPiETAAb7GxBf1c+uH8qS+qq7fHd1V8u6knWW9Grkdm2l0Wqn3tqotjTh40+IoXdM0xkn9I5ImQsjiMmYCqdj8uXzg2bo6FxCEE/iPEp/PE3LNvSzMucgFBL/LzB8oiUWRLpKMZyPyCRNqliuuywytGZnxlMPjcEjhcjKPlgR3s05jXs41zegVJ3ECAqYRqBBFHkbble94e885TqI7M6HcYRp7n1+4TFBCpSicznIpLL9HQfMcd8aAnu9MLVznNmnlGGZjn8LRp75pMV33ZFnlFlhHmTHNMB2Nydz2WjmGT8g7LJmEcfm5PCx5+Jbjk0wxvI8q1tmFt+vPZOPyI/2WojKyhqzCQw76w8CIPFwsRBNBr7zi0RXPXcdx9gQIcywzOMrMpFwxPcY1hdmBzRwDMMP3nUCnCmsBxEVZrOjGP4lih09nPVlwuIcO1siwTXEmNy8+RlzQRpY+4MKACweBC1lSzMMsE2lUHHs/PND4mAdw5IHjMMd3qM8DTTc1JzAU2TRVWVVtTW7hwXld3IADTxYHbtG52v43FWWyPnmM9l4eKfJg7wd7fxj2fkbThZR4nznLM+h+1p4mXx0bChwNhQUa1XRFDQwt0DSH6yo8oSqaLjta2+RjieRjWeIhWP23SZEOZv8BzP6tqre2/G19mbTOH+PXpayRrQ72f7D/h2H/6SLE3IlU8tKQB1K1VUtK4Gcxp/El9Enom+Z+sOBx/Dyhx6lhOlagGppO1cA2qcYD1fIMajNFpWYbFkpGXpITcoqcrDZ3iS9QrDg5CLgoE7sPcNE1XHyJpq5R5H7qNdn53COddNBH6vDh2wFsDmTSYcalFL/cxOfwF3ursR+umPZY0+AIAYanM8djsqarpsUVn5qKQj3N0/TAbs84zDj5oSwT/vrDMNPTnW64Q/vWcw2bKjPZuPIIgUBVR6YxAMEABAcDBH6Y5ksJNBE6nZRxlnL8FHUgTXmOVlBaJkUq+Smnc+lz4kFv1ffDCkfFr6Q7qmrp1DE8i6mGEkBE4lDVs6llq5ZBPf0GVrxGtsg7wRY5L9lCJ/G7ki1MypeS18gW+XviDeNXTxtPvlKJW5Czr+ZNdr70OGMVTRtpw0T4AFGHA1EsmWMrXeNXUyQqiY19ErQM96WkXNAYhQHH/o6/wzig86TIpIDDa2GWS1chwy2OFCgk/qyIIjAA2p4TLP7Y0OFo6I4uc8Pipqky3feVQAsCWWaWzZh5E8VeCc7x0yU0xrEMsXmQnCLrJClXUb4D1tG84O/vK9bJ24r1F+SninegUfI+rON94lj38L2hBYcPosKTbZQfJ1wq1sgZhvYGuDwcuPSSZbZa6e8lNJdiKEqic45ZOOLyExBwL0wl/PKz9M+Cg1WAJpKmSeRL8Dy+qDiaKXk8jYBQEi3nC9zv7DjqngOF5ti24WjbmucogWnLuqdqqsZszXQ0TWGeBRh6AzZPoQarXQanUIOX5ANUgZysqiC2Ml1gFcgbYIz8A6sgdkp9B1UgNBdvYhXIqagC+VhVYQgUnzZ4/vf6RgtEH1KhJ5sFPE4cxZHRYT3egKMHhKMRZZcSNGFIoXcr+yGfYY91E466KUO0qNqyqqqmrRiax4PA9DVD9WST3UQ+LJO8xzKHKbKnjVS3aF8bW5oqM9m48hjXSqgjZZgiG4DgQBbmQY+/wjaacYrfz8uhU8XTIgIbmKfU53gBPxYiKdBL5b2X5wU6HANd96lqM8cOHNmgGvc4kz3b8rhtbG7UqdjBzFr4tb3nFzU/5AL5gaPg5wX5i/LtQYwVXicDhDzAMr0v19v1Yr09lW1y9wuPdIxPGznOAEkDJB3KXqFLni2gi/FMypI45rhvw94za4Aij3UbjrodmJqveYZsKsxXA13VfVX2tMDxTNPc3DK0KvibjJyXJQ8jak9669DdmtjcQbRNfSZbrz/GESx5ZJoDSgwocRgowXNpzqUg5Ry65J4pBAwP520Mz7aZoZqaFhga3AgUU2WKEeiBrWqKsbGflOfkPSdvxcz/sD3oyULCLWq3RoKmrkwaZ49z/l8frP5g9Q/E6rMkz6VFGE2hETNoSs5CXP1TLY0VK4Naz2D8b++ZbcDRx54CR0/xbE/VdY9xx7QspgaqwxizHdmHGKKNDlgm+VSWCV7ep4qx1ZJZsYToeeupQxnAGpDkgZCkA1VeI86X6t/krjcf6YZUdaQOI1oDah0GaqXhQgpzqViI9TdoX3KJTqEs6NB7pjywlTHT4ch06liaZupcsXxZCVTF4opi26qh+QZvYdMP4YKEOflxIVbh4Bh2Tk6w9AF9ni763F8la4y5RY8m7XuPdGOQMZKHjDkDZhwGZuCOPg/7JkuKyJc8Xm7yq9xCHvNMCtJkXuY7r9ZZStBvQy4V0HvTaZrAX0lxbAUODvqOe2ZBMPSxKcPRlK2A245u2I7FfMa4L8u6rsiap8heewblY5GSU7QAr5BpcsrL3YTofb4k54JrglyXadcrrqHTANfkxzXXL0jN9rAd6AmD1IP3gRrbHkJxJzeJPtJgyhqpw4q1ARgPBBijMIGOvGeaBsPAlD6GoWmKTC3FVP3AYyozfcWhtu5T2Q8c3t6p8xEKGhYpP13w2aZna8AQyjHBP49xKl8b2fZg0QeLfhAWfc4zCh5Vtbvbwy1pGQt5zLgUhOKzdKsvREuKLctw0B3omXumOJCdMdXgSDXKA902DMuwTK5Q2/CoxQNObc48q4UA71eMvSRi3wFuWjsvOSNvS85WX5cmNWcDZDxZyOhEkWuI+ULtm9z23iMdmbNGxjCbM8DVYcBVFHo8zXH3WRxC1XD3tMenYQxl4erQPVMIyN7YY3D0mC9TM9Dhr60w5imy7lBDtTRTl832hM67FgNiG/XpioFhS8yTRZ+99LJGmduVaXLb7cf5dUxtyGYzIMlhIEmIWRzjaCncxRmUFtElxb6652Z81cLvIKgWNTQfkMQxPN+3bdW2OQ1MkzmqJvtWG0O+z7/JIAyIlmJE+2xV9gAfTxY+7qmMNXDs1KDJjjuP8SM6xkgZPqZ8qHBxPE6iW3RhpUZNKRXRWhfAtt806RssN4GoSFMe53e8gf8+AWWiYMZAQ76V+s3Kbqlkg4UY2ga1rO65WAdJXcEE3i472S10j8dFVLddKZ3NpttsqONxxsVwQ6Ob7Hqn+RZeOX4mSWScJtdEklrFljewAq7wJsv7zXs17kpBVIR++cC6F0APSHJ4byWc1Wn7rbq5NvUOyypf2ZBA+9dGLZGxz/8oOPSguj71zYyl4SKvgHqW54uX4zH9TP8YTZNkGnG6CLMRS+biGnrr2fjzP5HUWBk5I6U6Gc3DePQ5E8akJLi9mMk1WOXkelRx8+efxE9YMQcNHV2nYc6ff9Pmp3YcAE6gv42TjNF0/LnmofwjCVYaPPz224qLb76tGeqE8s3alfLe3RY3z0V7XFyHObb8KbRmlqd00VC1itHKKqJtG38Gc15eBtN3Rw28FUlt/XNnFQQzH/HVmwzcUU75owgF3d3cshlNM47mucgDyW6zsFeBdW0kMP48D+eYDu6SpztvfA1nXfAFUEUjvvuBEY2ir5PebVrXtHtbTOodWrbRgf/neVDEwp4+/5b8exdqNo9CPKMwDvPn3/51xUN5MeM0ZbPNe6t//8FLDTPe1pWNWqD6/gRhvRg5/jA+aVu4hocEjeAv0ZUD2JkcvTg6fvb646uLXz69IeLKMR5JROMpCIPHUtGMKuJEKvsOlHb87Fce+2HwOxR0POPUb2KOcDOrCxcpxaS8f664hZ5+maFLcs5AEziRyDmNfS/5o2Rv9WqD2pznAJpgkiX8vMqViCvjHIylhI2G/JWnq+bDKvy11pgfL94KfdkkGNM5NjhLOeii36Ki6vmM/L2IiSorJpGdl6qzm4DPy5apvk9dE6llvvPNq5BfL5I0b712Hfr57G8+vwJnVxInuwmkiZeUSQ7q1z98PPnh1dn3P7158eHjq5NXZ2+q+LqlKO/Asb94/84gGYQKL8S40PdvTMkmWbFAhsQHz+ABwiOOoJS1tQlp/BoGJMrhNeL8PrnZm0pLMRZNYWApFYyyxOcCRrOreJynRXxZPrITVppqdkvAEYXxJUl5hN7zDGrAipygZw+yacVJWwxXQK/wyREcNoYW7oKyBpfN8vMl2LoZ5/mGPWNZdg924KlxSWIkXmh5QDvLuYvqF6FGs/yOa7ijpF0y338I4uZzYPJKK1Wdoh0koS96cECLqBlw1Vcm99MBYQAb7uzqdIc7ezNGrj3pG4DTeg5c8a0RdOuhaqzNJjOlFW80G6Q1QrVhkUUUkkHcH03Iz5xEyRUnHsfBm0zc959BPxW3Vy7//uFj87xsmMqVb/n47Vq1AwoU2Vo77yHM6slGEOmB6fdZWsy9dsvcCMDuIcOzZM7bA20bgdwNg7WtGTfK8bBhXGVLa90c09tZXDMGpeC5iC05JSg33qkiyx36udK7TbFkob8eo8UTj6Y3x3rvOfQqShQdcpEm8wQBNXMjHuQ7Bwy3jSq09ex2s72jtlgRl4GFmor5+ZtdsqFDMb0CNL6SojDL9xhiPt45UnJvPdj9+u3j86t/Qo++lEipf7fcL6JbGOxaSp3K5RiwMImndRepTh9MUuNbK/kACjVfZhBxL12tW316X5Ltj5zKjweHELquFgC5erciO6tLWK0J6o/0MojVIHQIQXo0zV2jW8md19TJCQRQvZGagBXM2G92K69XFd3+SGoxC6MkSxazpWt1K6tPNeX+SCvF7xgx7trdiuqHkmx/5HQNbnyc1fbe6VZcPwvq/bP1K3Epcrfy6p2gGJgWPwUdcJWOvflXK8o9slk8CqdCrdSOrVZFuD+iipO47oMdu/UfatI9ioAK8IVcpWNv/j1S7Y+QqjFQV+nYdX9dja32J9Jp7xJxlY59941tIz0SHM41lZ81m9I5B1Ds2JM/FwWIrDbfYQH9ER31fYni11Zxes5VOnbrcc0YJRX1HrmpNM5ptnSVjt36tyXdHrkT/FqiPhp/tWOP/gO/Bu3qlflfJkU8XYmrY6/+F6TdN4FVeOmq6oPgZI+GuBKep0tX7dij/yTI9khMNKVxks5p5Kodu/SfatI9ch1SsFMd+/S9GoNfZEs2S/DTUa7asSv/qSbdI30q8sQLk2lKcSxe7diFP2lS75XNwumreOqqducmq6Tcp2AH/J86vFadroMdoN6/4HpWzJPU1Tr238+Qao+ElKQpSqljt/1MkO3bSoilq6kPsf6hR2Y9SBJfjGf5aRhfulrHnvtbIC9Gs14j+T5Ni6WgCSGNayOv6V1Pj1Ul9M/Qe0UWxjzLXK1jp/60ItwjUdVuqtaxY3/aPxc1hy4TRRzQsWOX/qIi3CP7hdtv5oskpQiSHTv0rxrE+zT3E6ZhXlDclu9qTtfzPmviPQqDGPX5PGSu3rFTf1IR7tPi0yiQZjxauLrS9cLTKCBnQLmP65xdXX2oBc49dFZdXXsgJ7VHHbHIFjzOuKt37NCfV4R7JCrct7pKMerqXS+YR+qrjKN9Wvh2xSOQltn1ojck2yMTz2mUz1y9Y0/+TJDt04QreIy4+0LvelC+ItwjFCyivEjRZejYd39VEe6PqHiaQNtT1+jYbX9T0u2RTqXhnLtG1yvjkeqjEVL75SKafKWYGxnBytP1/ud2/ptGjXB/883N3FtTCFRbuJ19tnA39+FLVSYEWg667sz8OFPq/bbwc5993btTyK33k895lgEzqxwTu1Kn1TXY2IT+BfvP77MDXWQBJHOezxIsb8qbGSjwngQ+W/gvzHsQ7chEIbgV6TgwaUWYLSK6fBknWz4QsDuj3CbDd+W029GC1TZpRal3TJOUZ2DMs9FdNHanwCw5bGRLbGaaaaW126qBNOLg9IqjdE3TGGfFj0iaCHGJy5ggo2L35/KBZ2v+LyAyJvAfJT6fJ+Sae1mYc5EuB36X2TAwLcaiSBdJxrMR+YQpKssFx2W+04zMeMrhcTikcDmZR0uCWzGnMS+ncmag9SROQFg0AmWgyMNouxodb+8Dx0l0Z4KQO6zcE0nZ+5VZe4fEvUPi3pV8u0rcO+TuXVEZcvcOqd4fL24ERQS1SVDfrngqxQmdZRJNLyUKV/xllnHovwk8UcQ5XIf/5WIhiMeXSey7trI/vhjW2LLgaFkyXFBM1Q50XbZMzTQ1I9A92+C2zVr48ha4JO+BS4Jckg/A5f/93/9fRk7Sy5fkJCYfS05Rqd4jp3ADORWOyKng9CA+K58U6YBFD4JFHat5jVldKOZkF5HH+V0s3Rnpw9dMBog7GIjLeP0hbtxbyiPuocFF/Qsk/HR3LM5oJC3AImRSDiFrVqTclzAszlxLU/fGOIeOLTxa3NQCRbVVxwdk0zVPU3xFkb1A85najqHOef0RbzAd5NWaT0xbi5/t/lDxiWvhLzPyv+h88VdyseKWnCO3w6fpnzbQda3sNdJ1pZ6TWwg9UsCzR/YQ0w2AdzCAd0Wn1APXElsK/NsixowHoH3TIvQ5urk4IANVQZMQJaI507l0naSRD/YAZytcw9gf83xj7AVw9AJZdmTdkj3ZsznVTd+BKM8MLNsxKG1h3k9rToW7/GPFKvkOWUV9wgGfkzJz+ztk9QJYJT8jq1UC/mGM8SnD3QOoeo14nSjn5A4qj/Tbx+bI0QfIGyDvUCCvgA6cis6eFxkDS5AVsWvI+v6Bmz1mKhwhOnMMZgS+QnVuMd8IVM/UmAGhnMm8Foj9iGULW3AhyibnRTyEYU8bl+6ljzXSbNegybbLjxEsrOHzxgNYHBBYUOiN8zn0zzCWeJEmC+7qhr03VOh8rBhwVAzFkDXbtmSVe4yqzKCGqlGmWrKhOS2oOIEujCWjPr8RJQ/hy1OGiXtoYg0S23RncvPiYxxA00faEE0MAHEwAIF+2xS/nwgWMIyu6VLy6L8oTV19c0POPWDCMsc+Hn2uK7ZpBZqq+VagBHrgcTXwA6Z4qtceFrsAl+87LJ/8UJZPTkX5hwAWH+MhpngYsLi3VtaQsVuPJrtuPcb4Qh4ZA3wM8HFA8cWSU+HTAX9XIod6/UNxdXX/JXO+N4Y+7nu6qRiOJxsBpYbvGKqpKorqBQ5THd/3N0KNX4AJEsbkU1U2eV7/+ovy7bAg7olHHvvoaCMIuUurJlseeZyTHIY5su0BVwZcOaSwJIWWwnlNUEfokZiPz/MiMfvpQ1/Li5RnONdJ49UqoBj7uJeGyJYUJzncD9JkLlFJfOtYCrMIF7qqrmpZe+MSl8d6AEc9sLlPVaoG1NEtyplimbqsyqrvUE++Edv8AJVApXonKoFZ/8pKvCQndS1wUpXGq5VCMdqT07IW5PkHrAZ5C9UglJxjNcj3ohrkL+q3Q5D01IOk/14faUVaD6zVky1lPE5gVbWRqgzAOgDroQBrzEOwG6mEe5qh/4uJW/hVLhDKGoPzirP/NJFsjm0FjrZiaDK1PKbJCqOBwTTVsLjiyYFsGW2M/FDyQ85wezXwQy6Qn5fVoqIMrcYBzR4NywweDO2+WHFr4NpD1Sa7nn2ka9jskWMMKDSg0KGgkCLLsrSIKAP3E7xX3MnhcWgBLi2TQvJD6MX7DxxaYzmAoxxY3PcdXJLAdIPaqqLYTAsCk6mO0x44VF4AH+ST4ANVA/drnAo+8LNd5HV4EKjzNrwaQOdhQGdfPa2x5j6aNdn20CMNc8yRPIwfHirAHI+T6FZduK3043E7S9Nt72zmpDp+JklknCbXRJJqOaxvYHYxN4wBY8r7zXs1/EhBVIR++cC6aaFZkxzeW+faKk/bb9VKuClMLKt8ZaNF2r82aomMff5HwUEt6vrUNzOWhou8wqhZni9ejsf0M/1jNE2SacTpIsxGLJmLa9B4Xjb+/E8kNVZGzkipTkbzMB59zkQPKQluL2ZyDVYnuR5V3Pz5J/ETVuCnXkfXaZjz59+0+WliJlhP0KNxkjGajj/XbJR/JMFNg43fflsx8s23NU9dEb9Zx1Lqu1tkS24xbJWL6zDH9j+FNs0gJFg0FK7iterw2G3Hn8FSlZehV99dCW9FVVv/3FkLwc9HfPUmD3cXVf4oQkF6N89sRtOMo/0p8kCy21zsW2ZdJwkMHM/DOV+E7JKnO298DXMdsQYWmUZ89wMjGkVfJ8PbNLBpCW8+dZfGbXTp/3keFLGwsM+/Jf++T9ZBIZ5RGIf582//uuKhvJhxmrLZ5r3Vv//gpYZhb2vMRi1Qj3/iaQaMvSQfxidtm9dwBKAR/CV6LOACTY5+fwH+wKJAJwSnRGnM+NHLX/99BL6Tf/RSeXGUJUWK146q/Wvi6WwsK7ih2wcb4Sdz4U4dvTgSbXT00gA/TIc3Z1Q1THjTMJ3AMDTDp4qlGaZGfW4yTzc8XwscVVZsX6Wmo+iqEti2w21uBabpeKasq5qhyc7Rf16sGFLvZEjdxpCsqU2GLNMLfMu2VV/RLFthuu+bzNYDxdRl26SeEXDdlh3TDxxN1h1ZNWzTtxWbUxYoMjUaDGl3MqRtYUgzLcNsMOTZjqkzRQm4zD3dtnUtMLhugEAYsz2DyZzJsgVyCjh3ZNtiTsANW/NVU/OCwFOO/vP7f/4fJ5fY+hxCAgA="
OUT = pathlib.Path("/kaggle/working/qwen-html-result.json")


def save(value):
    OUT.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_inputs():
    return json.loads(gzip.decompress(base64.b64decode(INPUT_GZIP_B64)))


def parse_rule(output):
    decoder = json.JSONDecoder()
    for index, char in enumerate(output):
        if char != "{":
            continue
        try:
            value, _ = decoder.raw_decode(output[index:])
        except json.JSONDecodeError:
            continue
        selector = value.get("selector") if isinstance(value, dict) else None
        selector_type = value.get("selector_type") if isinstance(value, dict) else None
        if isinstance(selector, str) and selector.strip() and selector_type in {"css", "xpath"}:
            return {
                "kind": "selector",
                "selector": selector.strip(),
                "selector_type": selector_type,
                "attribute": "href",
            }
    return None


def apply_rule(rule, html_text):
    if rule["selector_type"] == "css":
        from bs4 import BeautifulSoup

        nodes = BeautifulSoup(html_text, "html.parser").select(rule["selector"])
    else:
        from lxml import html as lxml_html

        nodes = lxml_html.fromstring(html_text).xpath(rule["selector"])
    return [node.get("href") for node in nodes if getattr(node, "get", None) and node.get("href")]


def inspect_generated_code(code):
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return {"safe": False, "reason": f"SyntaxError: {exc}"}
    allowed = {"json", "re", "lxml"}
    imports = []
    rejected = []
    blocked_calls = {
        "open", "eval", "exec", "compile", "input", "__import__", "getattr", "hasattr",
        "setattr", "delattr",
    }
    blocked_attributes = {
        "open", "read_text", "write_text", "read_bytes", "write_bytes", "read", "write",
        "unlink", "remove", "mkdir", "rmdir", "exists", "is_file", "is_dir", "connect",
        "send", "request", "post", "put", "delete", "urlopen", "system", "popen", "Popen",
        "run", "check_call", "check_output",
    }
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.append(node.module)
        elif isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            rejected.append(f"dunder attribute: {node.attr}")
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in blocked_calls:
                rejected.append(f"call: {node.func.id}")
            if isinstance(node.func, ast.Attribute):
                name = node.func.attr
                receiver = node.func.value
                if name in blocked_attributes:
                    rejected.append(f"attribute call: {name}")
                if name == "parse" and not (
                    isinstance(receiver, ast.Name) and receiver.id == "parser"
                ):
                    rejected.append("non-parser parse call")
    blocked_modules = sorted({name.split(".")[0] for name in imports} - allowed)
    return {
        "safe": not blocked_modules and not rejected,
        "imports": imports,
        "blocked_modules": blocked_modules,
        "rejected_operations": sorted(set(rejected)),
    }


def execute_parser(code, html_pages):
    allowed = {"json", "re", "lxml"}

    def safe_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name.split(".")[0] not in allowed:
            raise ImportError(f"blocked import: {name}")
        return __import__(name, globals, locals, fromlist, level)

    safe_builtins = {
        "__build_class__": __build_class__, "__import__": safe_import,
        "object": object, "str": str, "int": int, "float": float, "bool": bool,
        "list": list, "dict": dict, "tuple": tuple, "set": set, "len": len,
        "enumerate": enumerate, "zip": zip, "range": range, "isinstance": isinstance,
        "ValueError": ValueError, "TypeError": TypeError, "Exception": Exception,
        "RuntimeError": RuntimeError, "any": any, "all": all, "sorted": sorted,
        "min": min, "max": max, "sum": sum,
    }
    namespace = {"__builtins__": safe_builtins, "__name__": "generated_parser"}
    exec(compile(code, "<generated-parser>", "exec"), namespace)
    parser_type = namespace.get("WebPageParser")
    if parser_type is None:
        raise ValueError("generated code does not define WebPageParser")
    parser = parser_type()
    return [parser.parse(page) for page in html_pages]


def main():
    import torch
    import transformers
    from huggingface_hub import HfApi, snapshot_download
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    total_started = time.perf_counter()
    inputs = read_inputs()
    html_pages = inputs["html"]
    seed_urls = inputs["seed_urls"]
    sources = []
    started = time.perf_counter()
    source = snapshot_download(
        MODEL_ID,
        revision=MODEL_REVISION,
        allow_patterns=[
            "config.json", "generation_config.json", "model.safetensors.index.json",
            "model-*.safetensors", "tokenizer.json", "tokenizer_config.json",
            "special_tokens_map.json", "added_tokens.json", "chat_template.jinja",
            "merges.txt", "vocab.json",
        ],
    )
    download_seconds = round(time.perf_counter() - started, 3)
    weight_files = sorted(pathlib.Path(source).glob("model-*.safetensors"))
    weight_bytes = sum(path.stat().st_size for path in weight_files)
    hub = HfApi().model_info(MODEL_ID, revision=MODEL_REVISION, files_metadata=True)
    weight_provenance = [
        {
            "file": item.rfilename,
            "size_bytes": item.size,
            "hub_lfs_sha256": item.lfs.sha256 if item.lfs else None,
        }
        for item in hub.siblings
        if item.rfilename.endswith(".safetensors")
    ]
    weight_hash_started = time.perf_counter()
    for item in weight_provenance:
        item["local_sha256"] = sha256_file(pathlib.Path(source) / item["file"])
        item["sha256_matches_hub"] = item["local_sha256"] == item["hub_lfs_sha256"]
        if not item["sha256_matches_hub"]:
            raise ValueError(f"downloaded weight SHA-256 mismatch: {item['file']}")
    weight_hash_seconds = round(time.perf_counter() - weight_hash_started, 3)
    hardware = {
        "gpu_name": torch.cuda.get_device_name(0),
        "gpu_total_bytes": torch.cuda.get_device_properties(0).total_memory,
        "torch_version": torch.__version__,
        "transformers_version": transformers.__version__,
    }
    quantization = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=torch.float16,
    )
    tokenizer = AutoTokenizer.from_pretrained(source, local_files_only=True, trust_remote_code=False)
    memory_mib = int(hardware["gpu_total_bytes"] / (1024 * 1024))
    load_started = time.perf_counter()
    model = AutoModelForCausalLM.from_pretrained(
        source,
        local_files_only=True,
        trust_remote_code=False,
        dtype=torch.float16,
        quantization_config=quantization,
        attn_implementation="sdpa",
        device_map="auto",
        max_memory={0: f"{memory_mib - 1024}MiB", "cpu": "24GiB"},
        low_cpu_mem_usage=True,
    )
    model.eval()
    model_load_seconds = round(time.perf_counter() - load_started, 3)
    calls = []

    def generate(system, user, max_new_tokens):
        message = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        encoded = tokenizer.apply_chat_template(
            message,
            add_generation_prompt=True,
            tokenize=True,
            return_dict=True,
            return_tensors="pt",
            enable_thinking=False,
        )
        input_ids = encoded["input_ids"].to(model.get_input_embeddings().weight.device)
        started_call = time.perf_counter()
        try:
            with torch.inference_mode():
                output = model.generate(
                    input_ids=input_ids,
                    attention_mask=encoded["attention_mask"].to(input_ids.device),
                    max_new_tokens=max_new_tokens,
                    do_sample=False,
                    use_cache=True,
                )
            new = output[0, input_ids.shape[-1]:]
            text = tokenizer.decode(new, skip_special_tokens=True)
            metric = {
                "input_tokens": int(input_ids.shape[-1]),
                "output_tokens": int(new.numel()),
                "elapsed_seconds": round(time.perf_counter() - started_call, 3),
            }
        except Exception as exc:
            metric = {
                "input_tokens": int(input_ids.shape[-1]),
                "output_tokens": 0,
                "elapsed_seconds": round(time.perf_counter() - started_call, 3),
                "error": f"{type(exc).__name__}: {exc}",
            }
            calls.append(metric)
            torch.cuda.empty_cache()
            raise RuntimeError(metric["error"]) from exc
        calls.append(metric)
        return text, metric

    torch.cuda.reset_peak_memory_stats()
    direct_query = inputs["task"]
    direct_system = (
        "Inspect only the supplied representative HTML. Return one JSON object with fields "
        "kind='selector', selector, selector_type='css' or 'xpath', and attribute='href'. "
        "Select repeated individual product detail links; exclude category, navigation, account, and pagination links. "
        "Use a rule reusable on structurally similar listing pages."
    )
    try:
        direct_text, direct_metric = generate(
            direct_system,
            f"Task: {direct_query}\nRepresentative HTML:\n{html_pages[0]}",
            512,
        )
        direct_rule = parse_rule(direct_text)
    except Exception as exc:
        direct_text, direct_rule = "", None
        direct_metric = calls[-1] if calls else {
            "input_tokens": None,
            "output_tokens": 0,
            "elapsed_seconds": None,
            "error": f"{type(exc).__name__}: {exc}",
        }
    direct = {
        "input_mode": "raw representative seed HTML; no truncation",
        "input_chars": len(html_pages[0]),
        "input_sha256": hashlib.sha256(html_pages[0].encode()).hexdigest(),
        "metrics": direct_metric,
        "gpu_peak_bytes": torch.cuda.max_memory_allocated(),
        "generated_text": direct_text,
        "rule": direct_rule,
        "tests": [],
    }
    if direct_rule:
        for index, page in enumerate(html_pages, 1):
            try:
                values = apply_rule(direct_rule, page)
                direct["tests"].append({"seed": index, "count": len(values), "values": values})
            except Exception as exc:
                direct["tests"].append({"seed": index, "error": f"{type(exc).__name__}: {exc}"})
    direct["status"] = "error" if direct_metric.get("error") else "rule_created" if direct_rule else "no_rule"
    save({
        "stage": "direct_selector_complete",
        "model_id": MODEL_ID,
        "model_revision": MODEL_REVISION,
        "direct_selector": direct,
    })
    co = {"input_mode": "Co-Scraper native simplification and query-aware DOM pruning"}
    torch.cuda.reset_peak_memory_stats()
    responses = []
    try:
        source_dir = pathlib.Path("/tmp/co-scraper")
        subprocess.run(
            ["git", "clone", "https://github.com/Ambition-0303/Co-Scraper.git", str(source_dir)],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
        subprocess.run(
            ["git", "-C", str(source_dir), "checkout", COSCRAPER_REVISION],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
        sys.path.insert(0, str(source_dir / "src"))
        from coscraper import pipeline

        def local_inference(system, user, *, max_tokens, **kwargs):
            output, _ = generate(system, user, min(max_tokens, 1024))
            responses.append(output)
            return "", output

        pipeline.inference = local_inference
        schema = {
            "type": "object",
            "properties": {"product_urls": {"type": "array", "items": {"type": "string"}}},
            "required": ["product_urls"],
        }
        result = pipeline.run(
            "Extract the href URLs for individual product detail pages in a product listing.",
            schema,
            html_pages,
            sources=seed_urls,
            id_max_tokens=512,
            code_max_tokens=1024,
            max_attempts=1,
            execute=False,
            output_dir=None,
        )
        code = result["generated_code"]
        (pathlib.Path("/kaggle/working") / "generated_parser.py").write_text(code, encoding="utf-8")
        safety = inspect_generated_code(code)
        co.update(
            {
                "source_revision": COSCRAPER_REVISION,
                "truncation_cutoff_chars": 500,
                "id_max_tokens": 512,
                "code_max_tokens": 1024,
                "pruned_seed_chars": [len(page["extracted_html"]) for page in result["pages"]],
                "simplified_seed_chars": [len(page["simplified_html"]) for page in result["pages"]],
                "model_calls": calls[1:],
                "gpu_peak_bytes": torch.cuda.max_memory_allocated(),
                "process_peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                "generated_code_safety": safety,
                "generated_code_sha256": hashlib.sha256(code.encode()).hexdigest(),
                "executed": False,
            }
        )
        if safety["safe"]:
            try:
                co["execution_results"] = execute_parser(code, html_pages)
                co["executed"] = True
            except Exception as exc:
                co["execution_error"] = f"{type(exc).__name__}: {exc}"
    except Exception as exc:
        co["error"] = f"{type(exc).__name__}: {exc}"
        co["model_calls"] = calls[1:]
        co["model_outputs"] = responses
        co["gpu_peak_bytes"] = torch.cuda.max_memory_allocated()
        co["process_peak_rss_bytes"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    result = {
        "case_id": "01",
        "other_case_ids_not_run": ["08"],
        "model": {
            "id": MODEL_ID,
            "revision": MODEL_REVISION,
            "license": "Apache-2.0; Qwen/Qwen3-4B base terms separately apply",
            "weight_bytes": weight_bytes,
            "weight_files": weight_provenance,
            "download_seconds": download_seconds,
            "weight_hash_seconds": weight_hash_seconds,
            "load_seconds": model_load_seconds,
            "quantization": "bitsandbytes NF4 4-bit, double quantization, float16 compute",
            "trust_remote_code": False,
        },
        "hardware": hardware,
        "direct_selector": direct,
        "coscraper": co,
        "input_provenance": inputs["input_provenance"],
        "model_calls": calls,
        "gpu_peak_bytes": torch.cuda.max_memory_allocated(),
        "process_peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        "total_elapsed_seconds": round(time.perf_counter() - total_started, 3),
    }
    result["direct_selector_status"] = direct.get("status")
    result["coscraper_status"] = "error" if co.get("error") else "generated_code_ready"
    save(result)
    output_files = [OUT]
    generated_path = pathlib.Path("/kaggle/working/generated_parser.py")
    if generated_path.exists():
        output_files.append(generated_path)
    continuation = {
        "ready_for_verification": True,
        "model_revision": MODEL_REVISION,
        "direct_selector_status": result["direct_selector_status"],
        "coscraper_status": result["coscraper_status"],
        "coscraper_executed": bool(co.get("executed", False)),
        "outputs": [
            {
                "path": str(path),
                "size_bytes": path.stat().st_size,
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
            for path in output_files
        ],
    }
    pathlib.Path("/kaggle/working/continuation.json").write_text(
        json.dumps(continuation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        OUT.parent.mkdir(parents=True, exist_ok=True)
        previous = {}
        if OUT.exists():
            try:
                previous = json.loads(OUT.read_text(encoding="utf-8"))
            except Exception:
                previous = {}
        previous.update({
            "model_id": MODEL_ID,
            "model_revision": MODEL_REVISION,
            "fatal_error": f"{type(exc).__name__}: {exc}",
        })
        save(previous)
        raise
