import json
from pathlib import Path
from lxml import html as lxml_html

class WebPageParser:
    def parse(self, html_text: str) -> dict:
        tree = lxml_html.fromstring(html_text)

        product_urls = tree.xpath("//article[@class='product_pod']//h3/a/@href")

        return {
            "product_urls": [url.strip() for url in product_urls if url.strip()],
        }

def main():
    input_source = 'sample.html'

    try:
        html_file = Path(input_source)
        if not html_file.exists():
            print(json.dumps({'error': f'File not found: {html_file}'}))
        html_content = html_file.read_text(encoding='utf-8')

        parser = WebPageParser()
        result = parser.parse(html_content)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        print(json.dumps({'error': str(e)}))

if __name__ == '__main__':
    main()