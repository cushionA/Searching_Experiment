# blocking-triage on Cloud Run Job

blocking-triage を GCP の Cloud Run Job で動かし、GCP から見た結果を返すための一式。

```
skills/
  blocking-triage/        パッチ適用済みのスキル(下の環境変数を付けないときは元と同じ動き)
  blocking-triage-gcp/    Job を起動し、完了を待ち、結果を読む skill(呼び出しは専用 SA で行う)
cloudrun-job/
  container/              Job のイメージ(Dockerfile・job.py・server.py・patch.py・cloudbuild.yaml)
  terraform/              Job・結果用バケット・Job の SA・呼び出し用 SA・プロキシ用 Secret・IAM
```

## blocking-triage へのパッチ(すべて環境変数で切り替わる)

| 環境変数 | 効果 |
|---|---|
| `BT_DC_DIRECT=1` | CLIENT_PROXY がないとき、この環境の出口(Cloud Run)をデータセンターの回線として使う |
| `BT_KEEP_BODY=1` | ladder.py の JSON に本文の先頭を残す |
| `BT_BODY_BYTES=N` | 本文の先頭を N 文字まで残す(既定 2048) |
| `BT_MATCH_LINE=1` | ブラウザのタイムゾーン・言語・Accept-Language を、その回線の出口(ipinfo.io の国・タイムゾーン)に合わせる。取れなければ既定(ja・Asia/Tokyo) |
| `BT_ONLY_BROWSER=1` | ブラウザの確認だけを回す(Chrome が動くかの確認用。読みは診断にならない)。Job では `--browser-smoke` |

`patch.py` は何度当てても同じ結果になる(当たっていれば飛ばす)。元のスキルにも、パッチ済みのスキルにも使える。

## 作り方

```bash
# 1. イメージ: スキルを container/skill にコピーしてからビルド
cp -r skills/blocking-triage cloudrun-job/container/skill
gcloud builds submit cloudrun-job/container --config=cloudrun-job/container/cloudbuild.yaml \
  --substitutions=_TAG=v4 --region=us-central1
#    cloudbuild.yaml の serviceAccount は、ビルド専用 SA(バケットの読み取り・リポジトリへの書き込み・ログ)

# 2. インフラ: variables.tf の project・image・invoker_sa_id・operators を合わせる
cd cloudrun-job/terraform && terraform init && terraform plan -out=tfplan && terraform apply tfplan
```

## 呼び方

```bash
cd skills/blocking-triage-gcp/scripts
export CLIENT_PROXY=...        # 任意。なければ Cloud Run の出口(Google の IP)
export RESIDENTIAL_PROXY=...   # 任意。あればレジデンシャルの回線での確認まで進む
uv run gcp_triage.py --url https://example.com/
```

## IAM の設計

| 主体 | 権限 | 範囲 |
|---|---|---|
| Job の SA(lab-bt-job-sa) | storage.objectCreator | 結果用バケット(作成のみ。読み取り・上書き・削除は不可) |
| | secretmanager.secretAccessor | プロキシ用 Secret 2 つ |
| 呼び出し用 SA(lab-bt-invoker) | run.jobsExecutorWithOverrides・run.viewer | この Job のみ |
| | カスタムロール(run.operations.get のみ) | プロジェクト(このロールはプロジェクト単位でしか付けられない) |
| | secretmanager.secretVersionManager | プロキシ用 Secret 2 つ(追加・破棄のみ。中身は読めない) |
| | storage.objectViewer | 結果用バケット |
| 操作する人(operators) | iam.serviceAccountTokenCreator | 呼び出し用 SA のみ |

プロキシの URL は Job の引数に入れない。呼び出し側が Secret に 1 バージョン足し、Job にはバージョン名だけを渡し、終わったら破棄する。Job の引数は実行の記録に残るため。

## 守りの考え方

- 起動できるのは呼び出し用 SA だけ(になりすませる人を operators で決める)。環境変数は実行時に上書きできるので、ホストの許可リストは置いていない(`ALLOWED_HOSTS=*`)
- 入口の検査: http/https・ポート 80/443・URL 内の認証情報なし・名前解決した先が公開 IP
- Job の SA が乗っ取られても、できるのは結果用バケットへの作成と、プロキシ用 Secret の読み取りまで
- Chrome は `--no-sandbox` で動く(Cloud Run の制約)。実行ごとにコンテナは使い捨て
