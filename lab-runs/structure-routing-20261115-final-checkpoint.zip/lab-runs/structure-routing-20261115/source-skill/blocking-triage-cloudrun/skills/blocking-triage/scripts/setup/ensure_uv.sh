#!/usr/bin/env bash
# uv が使えるようにする。無ければ公式インストーラで、スキルの中の .tools/bin に入れる。
# リポジトリ・イメージ・シェルの設定ファイルは変更しない(UV_NO_MODIFY_PATH=1)。
# 何度実行しても同じ結果になる。バージョンを固定するときは UV_VERSION=0.x.y を付ける。
set -euo pipefail

skill="$(cd "$(dirname "$0")/../.." && pwd)"
tools="$skill/.tools/bin"
export PATH="$tools:$HOME/.local/bin:$PATH"

if command -v uv >/dev/null 2>&1; then
  echo "uv: $(uv --version) ($(command -v uv))"
  exit 0
fi

url="https://astral.sh/uv/install.sh"
if [ -n "${UV_VERSION:-}" ]; then
  url="https://astral.sh/uv/${UV_VERSION}/install.sh"
fi

echo "uv が見つからないため ${url} から導入する" >&2
curl -LsSf "$url" | UV_UNMANAGED_INSTALL="$tools" UV_NO_MODIFY_PATH=1 sh >&2

echo "uv: $(uv --version) ($(command -v uv))"
echo "このシェルで使うには: export PATH=\"$tools:\$PATH\"" >&2
