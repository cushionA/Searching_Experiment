# 補助: ABORTED の Job の URL から調査を始める

基本の入口は、ユーザーから受け取った URL。実行結果の ABORTED から調べたいと言われたときだけ、ここを使う。

## 手順

1. DB へ接続する。接続手順と注意(読み取り専用、認証情報をチャットから写さない、接続先が正しい DB かの確認)は、`qcv3-execute-quality-report` skill の「DB へ接続する」に従う。
2. 対象の Execute の ABORTED の Job から、URL とエラー文を取る。

```sql
select j.kind, j.url, j."tryCount", j.result->>'error' as error, j.crawled
from "Job" j
where j."executeId" = '<Execute の id>'
  and j.status = 'ABORTED'
order by j.kind, j.url
limit 50;
```

3. kind ごとに URL を数件選び、`ladder.py` に渡す。全件を渡さない(相手への負荷を避ける。1 URL あたりの上限は SKILL.md の「守ること」)。

## 読むときの注意(qcv3 の仕様)

- `result->>'error'` が残るのは ABORTED の Job だけ。リトライの末に成功した Job には残らない。
- `crawled is null or crawled < pulled` の ABORTED は、エラーではなく timeout(pod の停止やフリーズ)の可能性がある。このときの `result` は前の試行のエラー文のことがある。ブロックと決めつけず、timeout の可能性も並べて書く。
- 親の Job(LIST など)が ABORTED だと、その子の Job は DB に現れない。ABORTED の件数は、データが欠けた件数の下限。
- worker は 3 回続けて Job に失敗するとプロセスを終了し、k8s が再起動する。ブロックされ続けている間は、worker の再起動の繰り返しとして見える。
- worker の回線は、`references/environment.md` の「回線」のとおり。開発環境から診断するときは、同じプロキシを渡すと、worker に近い経路で確認できる(`ladder.py`・`probe.py` は `--client-proxy` か `.env`・環境変数の `CLIENT_PROXY`、ブラウザの確認 `run_browser_probe.sh` は `--line=client_proxy`)。
