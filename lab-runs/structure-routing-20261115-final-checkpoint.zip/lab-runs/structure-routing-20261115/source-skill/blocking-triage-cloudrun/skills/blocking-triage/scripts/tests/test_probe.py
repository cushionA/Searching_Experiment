"""probe.py のリクエストの組み立てのテスト。外への通信はしない(curl のテストは localhost のサーバーだけを使う)。実行: uv run --with pytest pytest .claude/skills/blocking-triage/scripts/tests"""

import gzip
import http.server
import threading

import pytest

import probe
from probe import plan_requests

TWO_EGRESSES = [("direct", None), ("client_proxy", "http://gke.example.com:57884")]
URL = "https://jp.indeed.com/jobs?q=engineer"


def shape(plan):
    return [(r["egress"], r["client"]) for r in plan]


def test_by_default_plain_curl_and_curl_cffi_are_compared_on_each_egress():
    # 基準線は素の curl(OpenSSL)。qcv3 や Node がない環境でも動く
    assert shape(plan_requests(TWO_EGRESSES)) == [
        ("direct", "curl"),
        ("direct", "curl_cffi"),
        ("client_proxy", "curl"),
        ("client_proxy", "curl_cffi"),
    ]


def test_when_axios_is_chosen_qcv3_axios_takes_the_place_of_curl():
    # プロキシ経由では、サイトとの TLS をプロキシが作るので、Basic の代わりにならない
    assert shape(plan_requests(TWO_EGRESSES, node_client="axios")) == [
        ("direct", "axios"),
        ("direct", "curl_cffi"),
        ("client_proxy", "axios"),
        ("client_proxy", "curl_cffi"),
    ]


def test_when_basic_is_chosen_qcv3_basic_takes_the_place_of_curl():
    assert shape(plan_requests(TWO_EGRESSES, node_client="basic")) == [
        ("direct", "basic"),
        ("direct", "curl_cffi"),
        ("client_proxy", "basic"),
        ("client_proxy", "curl_cffi"),
    ]


def test_the_table_has_two_rows_per_egress():
    assert shape(plan_requests([("direct", None)])) == [("direct", "curl"), ("direct", "curl_cffi")]


def test_table_shows_the_previous_kind_with_its_date():
    rows = [{"egress": "direct", "client": "curl_cffi", "ok": True, "status": 403, "http_version": "h2",
             "kind": "blocked", "vendors": ["cloudflare"], "title": "Blocked",
             "previous": {"at": "2026-10-15T10:00:00+09:00", "status": 200, "kind": "ok"}, "changed": True}]
    table = probe._table(URL, rows)
    assert "前回" in table.splitlines()[2]
    assert "ok(10-15)→変化" in table


def _capture(monkeypatch):
    sent = []

    def fake_curl(url, proxy, ua):
        sent.append(("curl", ua))
        return {"status": 200, "http_version": "http/1.1", "final_url": url, "elapsed_ms": 1,
                "headers": {}, "cookie_names": [], "body": "<title>ok</title>"}

    def fake_cffi(url, proxy, headers=None, default_headers=True, impersonate="chrome"):
        sent.append(("curl_cffi", headers))
        return {"status": 200, "http_version": "h2", "final_url": url, "elapsed_ms": 1,
                "headers": {}, "cookie_names": [], "body": "<title>ok</title>"}

    monkeypatch.setattr(probe, "fetch_curl", fake_curl)
    monkeypatch.setattr(probe, "fetch_cffi", fake_cffi)
    return sent


def test_chrome_ua_changes_only_the_version_that_curl_cffi_claims_and_leaves_curl_alone(monkeypatch):
    # zozo.jp は、TLS が同じでも UA の版が古いと拒否した。TLS と UA の版を分けて確かめる
    sent = _capture(monkeypatch)

    probe.probe(URL, plan_requests([("direct", None)]), ua="qcv3-ua", interval=0, chrome_ua=155)

    assert sent[0] == ("curl", "qcv3-ua")
    headers = sent[1][1]
    assert "Chrome/155.0.0.0" in headers["User-Agent"]
    assert '"Google Chrome";v="155"' in headers["sec-ch-ua"] and '"Chromium";v="155"' in headers["sec-ch-ua"]


def test_without_chrome_ua_curl_cffi_keeps_its_own_headers(monkeypatch):
    sent = _capture(monkeypatch)

    probe.probe(URL, plan_requests([("direct", None)]), ua="qcv3-ua", interval=0)

    assert sent[1] == ("curl_cffi", None)


def test_table_shows_the_deny_page_signature_and_whether_akamai_bot_manager_ran():
    base = {"egress": "direct", "ok": True, "status": 403, "http_version": "h2", "kind": "blocked",
            "vendors": ["akamai"], "title": "Access Denied"}
    rows = [{**base, "client": "axios", "deny_signature": "#3fa2", "akamai_bot_manager": False},
            {**base, "client": "curl_cffi", "deny_signature": "#91c0", "akamai_bot_manager": True}]
    table = probe._table(URL, rows)
    assert "拒否ページ" in table.splitlines()[2]
    assert "akamai(BM なし)" in table and "#3fa2" in table
    assert "akamai(BM あり)" in table and "#91c0" in table


AMAZON_503_SJIS = bytes.fromhex(
    "3c68746d6c3e3c686561643e3c4d45544120485454502d45515549563d22436f6e74656e742d547970652220636f6e74656e743d22746578742f"
    "68746d6c3b20636861727365743d53686966745f4a4953223e3c7469746c653e82b296c0986682f082a882a982af82b582c482a282dc82b781"
    "493c2f7469746c653e3c2f686561643e3c2f68746d6c3e"
)


def test_body_without_charset_in_the_header_is_read_with_the_charset_of_its_meta():
    # Amazon の 503 は、ヘッダーが text/html だけで、Shift_JIS は本文の meta にしかない
    assert "<title>ご迷惑をおかけしています！</title>" in probe.decode_body(AMAZON_503_SJIS, "text/html")


def test_charset_in_the_header_takes_precedence_over_the_meta():
    assert probe.decode_body(b"<title>ok</title>", "text/html; charset=utf-8") == "<title>ok</title>"


def test_table_shows_the_challenge_type_next_to_the_kind():
    rows = [{"egress": "direct", "client": "curl_cffi", "ok": True, "status": 403, "http_version": "h2",
             "kind": "turnstile", "challenge_type": "button", "vendors": ["cloudflare"], "title": "Just a moment..."}]
    assert "turnstile(button)" in probe._table(URL, rows)


def test_axios_with_the_chrome_header_set_passes_the_13_headers_to_node_without_zstd(monkeypatch):
    # Node 20 は zstd を展開できないので、zstd で返されると本文が読めず、判定を誤る
    import json
    import subprocess

    payloads = []

    def fake_run(cmd, input, **kwargs):
        payloads.append(json.loads(input))
        out = {"status": 200, "http_version": "http/1.1", "final_url": URL, "elapsed_ms": 1, "headers": {}, "cookie_names": [],
               "body": "<title>求人</title>"}  # fmt: skip
        return subprocess.CompletedProcess(cmd, 0, stdout=json.dumps(out), stderr="")

    monkeypatch.setattr(probe.subprocess, "run", fake_run)
    plan = [{"egress": "direct", "proxy": None, "client": "axios_chrome_headers"}]

    [row] = probe.probe(URL, plan, probe.CHROME_UA, interval=0)

    headers = payloads[0]["headers"]
    assert [name for name, _ in headers] == [name for name, _ in probe.CHROME_HEADERS]
    assert dict(headers)["accept-encoding"] == "gzip, deflate, br"
    assert (row["client"], row["kind"]) == ("axios_chrome_headers", "ok")


@pytest.fixture
def local_server():
    """localhost で、受け取ったヘッダーを届いた順に残し、gzip を受け付けるときは gzip で返すサーバー。"""
    received: list[list[tuple[str, str]]] = []

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            received.append([(name.lower(), value) for name, value in self.headers.items()])
            body = "<title>求人</title>".encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            if "gzip" in self.headers.get("accept-encoding", ""):
                body = gzip.compress(body)
                self.send_header("Content-Encoding", "gzip")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{server.server_port}/", received
    server.shutdown()


def test_curl_with_the_chrome_header_set_sends_the_13_headers_in_chrome_order_without_zstd(local_server):
    # 資料では、curl に Chrome と同じヘッダー 13 個を同じ順序で付けても 403 だった。順序が崩れると、この確認の意味がなくなる
    url, received = local_server
    plan = [{"egress": "direct", "proxy": None, "client": "curl_chrome_headers"}]

    probe.probe(url, plan, probe.CHROME_UA, interval=0)

    chrome_names = [name for name, _ in probe.CHROME_HEADERS]
    sent = [(name, value) for name, value in received[0] if name in chrome_names]
    assert [name for name, _ in sent] == chrome_names
    assert dict(sent)["accept-encoding"] == "gzip, deflate, br"


def test_curl_with_the_chrome_header_set_reads_a_gzip_compressed_body(local_server):
    # 圧縮された本文を展開しないと、タイトルが取れず、判定を誤る
    url, _ = local_server
    plan = [{"egress": "direct", "proxy": None, "client": "curl_chrome_headers"}]

    [row] = probe.probe(url, plan, probe.CHROME_UA, interval=0)

    assert (row["status"], row["title"], row["kind"]) == (200, "求人", "ok")
