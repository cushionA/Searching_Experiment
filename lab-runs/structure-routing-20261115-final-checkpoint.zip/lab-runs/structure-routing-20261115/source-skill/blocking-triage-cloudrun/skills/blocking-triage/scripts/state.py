"""実行をまたいで残す状態。サイトごとの結果の履歴(history.jsonl)と、ホストごとの直前のリクエストの時刻(last/<host>)。

置き場所は、リポジトリの temp/blocking-triage/(gitignore 済み)。BLOCKING_TRIAGE_STATE_DIR で変えられる。
browser_run.py も同じ last/<host> の更新時刻を見て、probe の直後にブラウザを起動しないよう待つ。
本文と cookie は残さない。サイト側の設定は変わるので、前回との差を見るためだけに使う。
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from urllib.parse import urlsplit

_KEEP = ("status", "kind", "vendors", "title")


def state_dir() -> Path:
    env = os.environ.get("BLOCKING_TRIAGE_STATE_DIR")
    return Path(env) if env else Path(__file__).resolve().parents[4] / "temp" / "blocking-triage"


def history_records(url: str, rows: list[dict], at: str, asn: str | None = None) -> list[dict]:
    """probe の行を、履歴の 1 行ずつにする。送らなかった行とエラーの行は、種別を skipped / error にして残す。

    asn は、その回線の ASN(ipinfo.io の org の先頭)。手元の回線は日によって違う回線になるので、前回と比べるときに使う。
    """
    out = []
    for r in rows:
        base = {"at": at, "url": url, "egress": r["egress"], "asn": asn, "client": r["client"]}
        if r.get("ok"):
            out.append({**base, **{k: r.get(k) for k in _KEEP}})
        else:
            out.append({**base, "status": None, "kind": "skipped" if r.get("skipped") else "error", "vendors": [], "title": None})
    return out


def load_history(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def append_history(path: Path, records: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def _same_slot(h: dict, url: str, egress: str, client: str, browser: str | None = None, asn: str | None = None) -> bool:
    # 違う ASN の回線、違う種類のブラウザ(Chromium / Chrome)は、別の条件なので比べない。
    # ASN とブラウザの種類を残していない以前の結果(2026-10-22 まで)は、どの条件だったか分からないので比べない
    return (h["url"] == url and h["egress"] == egress and h["client"] == client
            and h.get("browser") == browser and h.get("asn") == asn)  # fmt: skip


def _previous(
    history: list[dict], url: str, egress: str, client: str,
    before: str | None = None, browser: str | None = None, asn: str | None = None,
) -> dict | None:  # fmt: skip
    hits = [h for h in history if _same_slot(h, url, egress, client, browser, asn) and (before is None or h["at"] < before)]
    if not hits:
        return None
    h = hits[-1]
    return {"at": h["at"], "status": h["status"], "kind": h["kind"]}


def attach_previous(rows: list[dict], url: str, history: list[dict], asn: str | None = None) -> list[dict]:
    """各行に、同じ URL・回線(ASN まで)・クライアントの前回の結果(previous)と、種別が変わったか(changed)を付ける。"""
    out = []
    for r in rows:
        prev = _previous(history, url, r["egress"], r["client"], asn=asn)
        kind = r.get("kind") if r.get("ok") else ("skipped" if r.get("skipped") else "error")
        out.append({**r, "previous": prev, "changed": None if prev is None else prev["kind"] != kind})
    return out


def record_browser(path: Path, d: dict, summary: dict, asn: str | None = None) -> dict | None:
    """③のブラウザの結果を履歴に足し、同じ条件の前回の結果を返す。

    同じ実行(started_at が同じ)の結果は 1 回しか足さない。--classify-json を同じ JSON に何度かけてもよい。
    回線は、結果に記録した line(browser_run.py の --line)で決める。line のない以前の結果は、
    プロキシを渡したかで決める(当時の --proxy は、ふつう CLIENT_PROXY)。ブラウザの種類(applied.browser。chromium / chrome)と
    回線の ASN も残し、同じ条件の前回とだけ比べる。
    """
    egress = d.get("line") or ("client_proxy" if (d.get("applied") or {}).get("proxy") else "direct")
    client = d.get("engine") or "nodriver"
    browser = (d.get("applied") or {}).get("browser")
    at = d.get("started_at")
    history = load_history(path)
    prev = _previous(history, d["url"], egress, client, before=at, browser=browser, asn=asn)
    if at and not any(_same_slot(h, d["url"], egress, client, browser, asn) and h["at"] == at for h in history):
        if summary.get("ok"):
            rec = {k: summary.get(k) for k in _KEEP}
        else:
            rec = {"status": None, "kind": "error", "vendors": [], "title": None}
        append_history(path, [{"at": at, "url": d["url"], "egress": egress, "asn": asn, "client": client, "browser": browser,
                               **rec}])  # fmt: skip
    return prev


def _host(url: str) -> str:
    return (urlsplit(url).hostname or "unknown").lower()


def touch_last_request(directory: Path, url: str, now: float | None = None) -> None:
    """このホストへ最後にリクエストを送った時刻を、ファイルの更新時刻として残す(シェルからも stat で読める)。"""
    p = directory / "last" / _host(url)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.touch()
    t = time.time() if now is None else now
    os.utime(p, (t, t))


def since_last_request(directory: Path, url: str, now: float | None = None) -> float | None:
    """このホストへ最後にリクエストを送ってから何秒か。送ったことがなければ None。"""
    p = directory / "last" / _host(url)
    if not p.exists():
        return None
    return (time.time() if now is None else now) - p.stat().st_mtime
