"""route_summary.py のテスト。実行: uv run --with pytest pytest .claude/skills/blocking-triage/scripts/tests"""

from route_summary import summarize_browser_probe, summarize_route


def pg(kind="target", status=200, title="商品", body="<title>商品</title>", **extra):
    return {"kind": kind, "status": status, "title": title, "body_head": body, "headers": {}, "cookie_names": [],
            "abck_state": None, "url": "https://shop.example.com/x", **extra}


def denied(kind="target"):
    return pg(kind, status=403, title="Access Denied", body="<H1>Access Denied</H1> errors.edgesuite.net")


def trial(pages):
    return {"pages": pages}


def mode(name, trials, humanize="none"):
    return {"name": name, "humanize": humanize, "label": name, "trials": trials}


def run(modes, **top):
    return summarize_route({"target_url": "https://shop.example.com/dp/1.html", "steps": ["https://shop.example.com/", "https://shop.example.com/dp/1.html"],
                            "modes": modes, **top})


def test_trial_is_judged_again_with_classify():
    # ブラウザ側では通過に見えても、本文がチャレンジのページなら通過にしない
    challenge = pg(status=200, title="商品", body="<title>Just a moment...</title><script>window._cf_chl_opt={}</script>")
    s = run([mode("direct", [trial([challenge])])])
    assert s["modes"][0]["outcome"] == "fail"
    assert s["first_passing_mode"] is None



def test_click_passes_when_location_does_not():
    s = run([
        mode("direct", [trial([denied()])]),
        mode("location", [trial([pg("route"), denied()])]),
        mode("click", [trial([pg("route"), pg()])]),
    ])
    assert s["first_passing_mode"] == "click"
    assert "クリック" in s["reading"]
    assert "操作" not in s["reading"]


def test_click_with_humanize_after_plain_click_failed_points_to_operation_data():
    s = run([
        mode("click", [trial([pg("route"), denied()])]),
        mode("click", [trial([pg("route"), pg()])], humanize="scroll"),
    ])
    assert s["first_passing_mode"] == "click"
    assert s["first_passing_humanize"] == "scroll"
    assert "操作データ" in s["reading"] and "scroll" in s["reading"]


def test_click_that_fell_back_to_direct_navigation_is_not_a_pass_and_the_reading_says_so():
    # リンクが見つからず直接遷移に切り替わった試行は、拒否されていなくても、クリックで通ったことにしない
    fell_back = trial([pg("route", how="click"), pg("target", how="goto(リンクなし)")])
    s = run([mode("click", [fell_back, fell_back], humanize="mouse")])
    assert s["modes"][0]["outcome"] == "fail"
    assert s["first_passing_mode"] is None
    assert "リンクが見つからず" in s["reading"] and "クリックで辿る移り方" in s["reading"]


def test_click_with_humanize_only_says_plain_click_was_not_tried():
    # 操作つきのクリックだけを試して通ったとき、操作を足したことと、操作なしが未確認であることを伝える
    s = run([mode("click", [trial([pg("route", how="click"), pg(how="click")])], humanize="mouse")])
    assert s["first_passing_mode"] == "click"
    assert "mouse" in s["reading"] and "試していない" in s["reading"]
    assert "操作データの採点が候補" not in s["reading"]


def test_split_results_are_flagged_and_do_not_count_as_passing():
    s = run([mode("direct", [trial([pg()]), trial([denied()])])])
    assert s["modes"][0]["outcome"] == "split"
    assert s["modes"][0]["passes"] == 1 and s["modes"][0]["total"] == 2
    assert s["first_passing_mode"] is None
    assert "割れ" in s["reading"]


def test_direct_passes_means_the_block_was_not_reproduced():
    s = run([mode("direct", [trial([pg()]), trial([pg()])])])
    assert s["first_passing_mode"] == "direct"
    assert "再現しなかった" in s["reading"]


def test_route_entry_blocked_means_going_back_to_earlier_layers():
    s = run([mode("location", [trial([denied("route")])])], stopped="route_blocked")
    assert s["first_passing_mode"] is None
    assert "入口" in s["reading"] and "ブラウザで直接開けるか" in s["reading"] and "③" not in s["reading"]


def test_nothing_passes():
    s = run([mode("direct", [trial([denied()])]), mode("location", [trial([pg("route"), denied()])]),
             mode("click", [trial([pg("route"), denied()])])], stopped="exhausted")
    assert s["first_passing_mode"] is None
    assert "通らない" in s["reading"]


def test_pages_carry_class_and_vendors_but_not_the_body():
    s = run([mode("direct", [trial([denied()])])])
    p = s["modes"][0]["trials"][0]["pages"][0]
    assert p["class"] == "blocked" and p["vendors"] == ["akamai"]
    assert "body_head" not in p


def test_route_and_seed_are_kept_for_reproduction():
    s = run([mode("direct", [trial([pg()])])], seed=5, request_count=3)
    assert s["steps"] == ["https://shop.example.com/", "https://shop.example.com/dp/1.html"]
    assert s["seed"] == 5 and s["request_count"] == 3


def test_resolve_failed_points_at_the_selector_of_the_failed_hop():
    d = {"target_url": None, "steps": [], "modes": [], "stopped": "resolve_failed",
         "plan": {"description": "kakakucom", "source": "src/example/kakakucom.ts", "steps": []},
         "resolution": {"ok": False, "failed_at": 1, "reason": "selector_not_found",
                        "hops": [{"index": 0, "type": "url", "status": 200}, {"index": 1, "type": "link", "selector": "td.mark a", "matched_links": 0}]}}
    s = summarize_route(d)
    assert s["first_passing_mode"] is None
    assert "セレクタ" in s["reading"] and "1" in s["reading"]
    assert s["resolution"]["failed_at"] == 1
    assert s["plan"]["source"] == "src/example/kakakucom.ts"


def test_resolve_blocked_means_the_route_page_itself_was_refused():
    d = {"target_url": None, "steps": [], "modes": [], "stopped": "resolve_blocked",
         "resolution": {"ok": False, "failed_at": 0, "reason": "blocked", "hops": [{"index": 0, "type": "url", "status": 403, "blocked": True}]}}
    s = summarize_route(d)
    assert "拒否" in s["reading"] and "ブラウザで直接開けるか" in s["reading"] and "③" not in s["reading"]


def test_resolved_hops_are_reported_without_page_bodies():
    d = {"target_url": "https://shop.example.com/dp/1.html", "steps": ["https://shop.example.com/", "https://shop.example.com/dp/1.html"],
         "modes": [mode("direct", [trial([pg()])])], "stopped": "passed",
         "resolution": {"ok": True, "failed_at": None, "reason": None, "resolved_urls": ["https://shop.example.com/", "https://shop.example.com/dp/1.html"],
                        "hops": [{"index": 0, "type": "url", "status": 200}, {"index": 1, "type": "link", "selector": "a", "matched_links": 12, "link_text": "商品"}]}}
    s = summarize_route(d)
    assert s["resolution"]["resolved_urls"][-1].endswith("/dp/1.html")
    assert s["resolution"]["hops"][1]["matched_links"] == 12


# Indeed のチャレンジのページは先頭に長い <style> があり、body_head にタイトルも手がかりも入らない
INDEED_HEAD = "<!DOCTYPE html><html lang=en><style>:root{--primary-1000:#0d2d5e;--primary-900:#164081}</style>"


def test_challenge_title_is_not_a_pass_even_when_the_body_head_has_no_marker():
    page = pg(status=200, title="Security Check - Indeed.com", body=INDEED_HEAD, blocked=True)
    s = run([mode("direct", [trial([page])])])
    assert s["modes"][0]["outcome"] == "fail"
    assert s["first_passing_mode"] is None


def test_when_rejudging_overturns_the_pass_the_browser_stopped_on_the_reading_says_the_rest_was_not_tried():
    challenge = pg(status=200, title="商品", body="<title>商品</title><script>window._cf_chl_opt={}</script>")
    s = run([mode("direct", [trial([challenge]), trial([challenge])])], stopped="passed", params={"all_modes": False})
    assert s["first_passing_mode"] is None
    assert "試していない" in s["reading"] and "--all-modes" in s["reading"] and "残りの移り方" in s["reading"]


def test_browser_probe_result_keeps_whether_the_challenge_was_resolved():
    d = {"ok": True, "url": "https://jp.indeed.com/jobs?q=engineer", "first_status": 403, "status": 403,
         "challenge_unresolved": True, "final_url": "https://jp.indeed.com/jobs?q=engineer",
         "title": "Security Check - Indeed.com", "headers": {"server": "cloudflare", "cf-ray": "x"},
         "cookie_names": ["__cf_bm"], "body_head": INDEED_HEAD}
    s = summarize_browser_probe(d)
    assert s["kind"] == "challenge" and s["vendors"] == ["cloudflare"]
    assert s["first_status"] == 403 and s["challenge_unresolved"] is True
    assert "body_head" not in s


def test_browser_probe_result_carries_readings_of_the_fingerprint_and_page_js_values():
    d = {"ok": True, "url": "https://jp.indeed.com/jobs?q=engineer", "engine": "nodriver", "first_status": 403, "status": 403,
         "challenge_unresolved": True, "title": "Security Check - Indeed.com", "headers": {"server": "cloudflare"},
         "cookie_names": [], "body_head": INDEED_HEAD, "since_last_request_sec": 12, "cooldown_waited_sec": 48,
         "user_agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
         "webdriver": False,
         "js_env": {"webgl_renderer": "ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero)), SwiftShader driver)",
                    "plugins": 5, "platform": "Linux x86_64", "ua_brands": ["Chromium 132"]},
         "fingerprint": {"ja4": "t13d1516h2_8daaf6152771_02713d6af862", "akamai_h2": "1:65536;2:0;4:6291456;6:262144|15663105|0|m,a,s,p"}}
    s = summarize_browser_probe(d)
    assert s["engine"] == "nodriver"
    assert s["fingerprint"]["ja4_ciphers_match_chrome"] is True and s["fingerprint"]["ua_major"] == 132
    assert s["connection_layer"] == "Chrome と同じ"
    assert any("ソフトウェア描画" in f for f in s["env_flags"])
    assert any("Chromium" in f for f in s["env_flags"])
    assert (s["since_last_request_sec"], s["cooldown_waited_sec"]) == (12, 48)


def test_location_pass_means_a_click_is_not_needed_and_says_nothing_about_goto():
    s = run([
        mode("direct", [trial([denied()])]),
        mode("location", [trial([pg("route"), pg()])]),
    ])
    assert s["first_passing_mode"] == "location"
    assert "location.href" in s["reading"] and "クリックは要らない" in s["reading"]
    assert "goto" not in s["reading"]



def test_skipped_warmup_is_reported_with_the_reason_rather_than_as_a_failure():
    s = run([
        mode("click", [trial([pg("route"), denied()])]),
        {**mode("warmup_location", []), "skipped": "no_abck"},
    ])
    assert s["modes"][1]["outcome"] == "skipped"
    assert "_abck" in s["reading"] and "warmup" not in s["reading"]



def test_warmup_location_pass_without_abck_accepted_does_not_point_to_abck_or_claim_location_failed():
    warm = {"pages": [pg("route", abck_state="pending"), pg(abck_state="pending")],
            "warmup": {"accepted": False, "waited_ms": 47000, "rounds": 20}}
    s = run([mode("warmup_location", [warm])])
    assert s["first_passing_mode"] == "warmup_location"
    assert "合格しなかった" in s["reading"]
    assert "通らなかった" not in s["reading"]


def test_warmup_then_location_pass_after_plain_location_failed_points_to_operation_data_without_internal_names():
    # 資料の調査(joshin_scrape.py・zozo_scrape.py)と同じ移り方。トップで _abck が合格するまで操作してから location.href で移る
    warm = {"pages": [pg("route", abck_state="accepted"), pg("target", how="location")],
            "warmup": {"accepted": True, "waited_ms": 8200, "rounds": 4}}
    s = run([
        mode("location", [trial([pg("route"), {**denied(), "how": "location"}])]),
        mode("warmup_location", [warm]),
    ])
    assert s["first_passing_mode"] == "warmup_location"
    assert "location.href" in s["reading"] and "操作データ" in s["reading"]
    assert "warmup" not in s["reading"]


def test_the_user_agent_of_the_browser_is_passed_through_so_that_the_chrome_version_can_be_reported():
    ua = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"

    assert run([], params={"user_agent": ua})["user_agent"] == ua
    assert run([])["user_agent"] is None


def not_found(kind="route"):
    return pg(kind, status=404, title="ページが見つかりません", body="<title>ページが見つかりません</title><h1>お探しのページは見つかりません</h1>")


def test_when_the_page_in_the_middle_of_the_route_is_404_it_is_not_counted_as_a_block_and_the_route_is_read_as_outdated():
    # joshinweb.jp: トップは開けたが、保存した経路の 2 ページ目がサイトの「ページが見つかりません」(404)だった
    s = run([
        mode("location", [trial([pg("route"), not_found()]), trial([pg("route"), not_found()])]),
        mode("click", [trial([pg("route"), not_found()])]),
    ])

    trials = [t for m in s["modes"] for t in m["trials"]]
    assert [t["blocked_at"] for t in trials] == [None, None, None]
    assert [t["passed"] for t in trials] == [False, False, False]
    assert s["route_outdated"] is True
    assert "古い" in s["reading"]
    assert "操作データ" not in s["reading"]
