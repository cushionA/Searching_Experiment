// parser_flow.mjs のテスト。実行: node --test .claude/skills/blocking-triage/scripts/tests/
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { test } from 'node:test';

import { analyzeParser } from '../parser_flow.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const kakaku = path.resolve(here, '../../../../../src/example/kakakucom.ts');

test('kakakucom.ts: 起点は LIST(URL の式つき)', { skip: !fs.existsSync(kakaku) }, () => {
  const flow = analyzeParser(fs.readFileSync(kakaku, 'utf8'), kakaku);
  assert.equal(flow.start.length, 1);
  assert.equal(flow.start[0].kind, 'LIST');
  assert.equal(flow.start[0].url_expr, '`https://kakaku.com/shopitem/${shopId}/`');
  assert.deepEqual(flow.start[0].meta_keys.sort(), ['shop', 'shopId']);
});

test('kakakucom.ts: LIST → ITEMS の遷移と、リンクを見つけるセレクタ・絞り込みの語', { skip: !fs.existsSync(kakaku) }, () => {
  const flow = analyzeParser(fs.readFileSync(kakaku, 'utf8'), kakaku);
  const edge = flow.edges.find((e) => e.from === 'LIST' && e.to === 'ITEMS');
  assert.ok(edge, 'LIST → ITEMS がある');
  assert.equal(edge.url_expr, 'a.href');
  assert.ok(edge.selectors.includes('#tabContents > div > div'));
  assert.ok(edge.selectors.includes('td.mark a'));
  assert.ok(edge.text_filters.includes('パソコン本体'));
  assert.ok(edge.meta_keys.includes('itemPage'));
});

test('kakakucom.ts: ITEMS はコメントアウトされた次ページを遷移として数えない。レコードは数える', { skip: !fs.existsSync(kakaku) }, () => {
  const flow = analyzeParser(fs.readFileSync(kakaku, 'utf8'), kakaku);
  assert.equal(flow.edges.filter((e) => e.from === 'ITEMS').length, 0);
  assert.deepEqual(flow.kinds.sort(), ['ITEMS', 'LIST']);
  assert.equal(flow.cases.find((c) => c.kind === 'ITEMS').records, 1);
});

test('if (job.kind === ...) の形でも、遷移を拾う', () => {
  const src = `
    import { launch } from '@keywalker/queueing-crawler-v3';
    await launch({
      initializer: async ({ createExecute }) => {
        const execute = createExecute({});
        const jobs = [execute.childJob({ kind: 'TOP', url: 'https://shop.example.com/' })];
        return { execute, jobs };
      },
      worker: async (job, { utils }) => {
        const document = new utils.JSDOM('').window.document;
        if (job.kind === 'TOP') {
          return { jobs: [...document.querySelectorAll('nav a.category')].map((a) => job.childJob({ kind: 'CAT', url: a.href })) };
        } else if (job.kind === 'CAT') {
          return { jobs: [...document.querySelectorAll('ul.items li a')].map((a) => job.childJob({ kind: 'ITEM', url: a.href })) };
        }
        return {};
      },
    });
  `;
  const flow = analyzeParser(src, 'x.ts');
  assert.equal(flow.start[0].url_expr, "'https://shop.example.com/'");
  assert.deepEqual(
    flow.edges.map((e) => `${e.from}>${e.to}`),
    ['TOP>CAT', 'CAT>ITEM'],
  );
  assert.deepEqual(flow.edges[0].selectors, ['nav a.category']);
  assert.deepEqual(flow.edges[1].selectors, ['ul.items li a']);
});

test('launch が見つからないときは、警告を返す(例外にしない)', () => {
  const flow = analyzeParser('export const x = 1;', 'x.ts');
  assert.deepEqual(flow.start, []);
  assert.deepEqual(flow.edges, []);
  assert.ok(flow.warnings.some((w) => w.includes('launch')));
});

test('JavaScript のソースも解析できる', () => {
  const src = `
    await launch({
      initializer: async ({ createExecute }) => {
        const execute = createExecute({});
        return { execute, jobs: [execute.childJob({ kind: 'A', url: 'https://a.example.com/' })] };
      },
      worker: async (job) => {
        switch (job.kind) {
          case 'A':
            return { jobs: [job.childJob({ kind: 'B', url: 'x' })] };
        }
      },
    });
  `;
  const flow = analyzeParser(src, 'x.js');
  assert.deepEqual(flow.edges.map((e) => `${e.from}>${e.to}`), ['A>B']);
});
