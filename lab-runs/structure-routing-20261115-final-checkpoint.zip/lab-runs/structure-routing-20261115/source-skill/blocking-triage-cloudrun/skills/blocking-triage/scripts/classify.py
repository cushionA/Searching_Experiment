"""応答からボット対策のベンダーとブロックの種類を推定する(純関数)。

ここで分かるのは「応答に残った手がかり」までで、判定ロジックの中身は分からない。
ベンダーの手がかりは CDN として前に立っているだけでも付くので、
「ベンダーが出た = ボット対策が効いている」とは限らない。kind とあわせて読む。
"""

from __future__ import annotations

import hashlib
import html
import re

# Akamai の bm-verify。200・タイトルが空白だけで返り、meta refresh で数秒後に再読み込みされる(www.amazon.co.jp、2026-10-19)
_BM_VERIFY_REFRESH = re.compile(r"""http-equiv=["']?refresh["']?[^>]*bm-verify=""")

# ベンダーごとの手がかり。(種類, 照合する値, 説明) の並び。
# header: ヘッダー名の存在、header_value: ヘッダー名=部分一致、
# cookie: cookie 名の前方一致、body: 本文の部分一致(大文字小文字を区別せず、文字参照は解いてから照合する)、
# body_regex: 本文の正規表現(body と同じ前処理)
_AMAZON_REFUSAL = "to discuss automated access to amazon data"
# Amazon の「ショッピングを続ける」確認画面。ボタンが validateCaptcha へ送るフォームを持つ(www.amazon.co.jp では 200・約 3.7KB・title は「Amazon.co.jp」。2026-10-22)
_AMAZON_CONTINUE_FORM = re.compile(r"""<form[^>]*action=["']?[^"'>\s]*validatecaptcha""")

_VENDOR_SIGNALS: dict[str, list[tuple[str, tuple[str, ...], str]]] = {
    "cloudflare": [
        ("header", ("cf-ray",), "header cf-ray"),
        ("header_value", ("server", "cloudflare"), "header server=cloudflare"),
        ("cookie", ("cf_clearance",), "cookie cf_clearance"),
        ("cookie", ("__cf_bm",), "cookie __cf_bm"),
        ("body", ("cdn-cgi/challenge-platform",), "body cdn-cgi/challenge-platform"),
        ("body", ("just a moment",), "body 'Just a moment'"),
    ],
    "akamai": [
        ("header_value", ("server", "akamaighost"), "header server=AkamaiGHost"),
        ("cookie", ("_abck",), "cookie _abck"),
        ("cookie", ("bm_sz",), "cookie bm_sz"),
        ("cookie", ("ak_bmsc",), "cookie ak_bmsc"),
        ("body", ("errors.edgesuite.net",), "body errors.edgesuite.net"),
        ("body", ("sec-if-cpt-container",), "body sec-if-cpt-container"),
        ("body_regex", (_BM_VERIFY_REFRESH.pattern,), "body meta refresh bm-verify"),
    ],
    "aws_waf": [
        ("header", ("x-amzn-waf-action",), "header x-amzn-waf-action"),
        ("cookie", ("aws-waf-token",), "cookie aws-waf-token"),
        ("body", ("token.awswaf.com",), "body token.awswaf.com"),
        ("body", ("gokuprops",), "body gokuProps"),
    ],
    "datadome": [
        ("header", ("x-datadome",), "header x-datadome"),
        ("cookie", ("datadome",), "cookie datadome"),
        ("body", ("captcha-delivery.com",), "body captcha-delivery.com"),
    ],
    "perimeterx": [
        ("cookie", ("_px",), "cookie _px*"),
        ("body", ("px-captcha",), "body px-captcha"),
    ],
    "imperva": [
        ("header", ("x-iinfo",), "header x-iinfo"),
        ("cookie", ("incap_ses_",), "cookie incap_ses_*"),
        ("cookie", ("visid_incap_",), "cookie visid_incap_*"),
        ("body", ("incapsula incident",), "body Incapsula incident"),
    ],
    # Amazon 自身の、自動アクセスを断るページ(503・ご迷惑をおかけしています！。www.amazon.co.jp、2026-10-20)
    "amazon": [
        ("body", (_AMAZON_REFUSAL,), "body automated access to Amazon data"),
        ("body_regex", (_AMAZON_CONTINUE_FORM.pattern,), "body validateCaptcha form"),
    ],
}

# 人の操作や JS の確認を求めるページの手がかり。
# 通常のページにも Cloudflare の検知スクリプト(cdn-cgi/challenge-platform/scripts/jsd/)や
# Turnstile のウィジェットは入るので、これらは status が 400 以上のときだけ根拠にする。
_TURNSTILE_MARKERS = ("challenges.cloudflare.com/cdn-cgi/challenge-platform/turnstile", "cf-turnstile")
_WEAK_CHALLENGE_MARKERS = (
    "cdn-cgi/challenge-platform",
    "captcha-delivery.com",
    "px-captcha",
    "press & hold",
    "hcaptcha.com",
    "google.com/recaptcha",
    "g-recaptcha",
)
# 拒否のページにしか出ない手がかり。status が 503 などでも、拒否として扱う
_BLOCK_BODY_MARKERS = (_AMAZON_REFUSAL,)
# チャレンジページ自身にしか出ない手がかり。status が 200 でも根拠にする。
# sec-if-cpt-container は Akamai のチャレンジ画面(zozo.jp では 200・タイトル空で返った)。
# gokuProps は AWS WAF のチャレンジ画面が持つ設定(www.amazon.co.jp では 202・タイトル空)。
# AWS WAF の JS を読み込むだけの通常ページには入らない。
# validateCaptcha へ送るフォームは Amazon の「ショッピングを続ける」確認画面(200・タイトルは通常ページと同じ「Amazon.co.jp」)
_STRONG_CHALLENGE = re.compile(
    r"_cf_chl_opt|checking your browser|sec-if-cpt-container|gokuprops|"
    + _BM_VERIFY_REFRESH.pattern
    + "|"
    + _AMAZON_CONTINUE_FORM.pattern,
    re.IGNORECASE,
)
_CHALLENGE_TITLE = re.compile(r"^\s*just a moment|checking your browser|security check", re.IGNORECASE)
# ステータスが 200 でも、タイトルでブロックと分かるページ
_BLOCK_TITLE = re.compile(r"blocked|access denied|forbidden|attention required", re.IGNORECASE)


def extract_title(body: str) -> str:
    m = re.search(r"<title[^>]*>(.*?)</title>", body, re.IGNORECASE | re.DOTALL)
    return re.sub(r"\s+", " ", html.unescape(m.group(1))).strip()[:200] if m else ""


def classify(
    status: int,
    headers: dict[str, str],
    cookie_names: list[str],
    body: str,
    title: str | None = None,
) -> dict:
    """vendors(検出したベンダー)・kind・signals(根拠)を返す。

    kind: ok / blocked / challenge / turnstile / rate_limited / error
    title: ブラウザで取ったタイトル。本文の先頭しかないときに渡す(省略すると本文から取る)
    """
    h = {k.lower(): v for k, v in headers.items()}
    cookies = [c.lower() for c in cookie_names]
    text = html.unescape(body).lower()
    page_title = extract_title(body) if title is None else title

    vendors: list[str] = []
    signals: list[str] = []
    for vendor, rules in _VENDOR_SIGNALS.items():
        hit = False
        for rtype, args, label in rules:
            matched = (
                (rtype == "header" and args[0] in h)
                or (rtype == "header_value" and args[1] in h.get(args[0], "").lower())
                or (rtype == "cookie" and any(c.startswith(args[0]) for c in cookies))
                or (rtype == "body" and args[0] in text)
                or (rtype == "body_regex" and re.search(args[0], text) is not None)
            )
            if matched:
                hit = True
                signals.append(label)
        if hit:
            vendors.append(vendor)

    kind = _kind(status, h, text, page_title)
    denied = kind not in ("ok", "rate_limited", "error")
    return {
        "vendors": vendors,
        "kind": kind,
        "signals": signals,
        "deny_signature": _deny_signature(text) if denied else None,
        "challenge_type": _challenge_type(h, text) if kind in ("challenge", "turnstile") else None,
        # Akamai の拒否で Bot Manager の cookie が発行されていなければ、Bot Manager より前のルール(IP・地域・ヘッダー)で止まった可能性が高い
        "akamai_bot_manager": any(c in cookies for c in _AKAMAI_BM_COOKIES) if denied and "akamai" in vendors else None,
    }


_AKAMAI_BM_COOKIES = ("ak_bmsc", "bm_sz")
# DataDome の dd オブジェクトの rt。c は CAPTCHA(スライダー)、i は自動の確認(interstitial)
_DATADOME_RT = re.compile(r"""['"]rt['"]\s*:\s*['"]([a-z])['"]""")


def _challenge_type(h: dict[str, str], text: str) -> str:
    """チャレンジ画面で、人が何をすれば通るか。auto(JS が自動で確かめる) / button(1 回押す) / press_hold(押し続ける) /
    puzzle(画像やスライダー) / unknown。button は最初に見える形で、押したあとにパズルに切り替わることがある
    """
    datadome = _DATADOME_RT.search(text) if "captcha-delivery.com" in text else None
    if "px-captcha" in text or "press & hold" in text:
        return "press_hold"
    if h.get("x-amzn-waf-action", "").lower() == "captcha" or "hcaptcha.com" in text or (datadome and datadome.group(1) == "c"):
        return "puzzle"
    if (
        any(m in text for m in _TURNSTILE_MARKERS)
        or "google.com/recaptcha" in text
        or "g-recaptcha" in text
        or _AMAZON_CONTINUE_FORM.search(text)
    ):
        return "button"
    if (
        h.get("cf-mitigated", "").lower() == "challenge"
        or h.get("x-amzn-waf-action", "").lower() == "challenge"
        or "cdn-cgi/challenge-platform" in text
        or "sec-if-cpt-container" in text
        or "gokuprops" in text
        or _BM_VERIFY_REFRESH.search(text)
        or (datadome and datadome.group(1) == "i")
    ):
        return "auto"
    return "unknown"


def _deny_signature(text: str) -> str:
    """拒否・チャレンジ画面の本文の「型」を表す短い記号。同じ記号なら、同じ拒否ページ(同じルール)と読める。

    Akamai の Reference 番号や Cloudflare の Ray ID のように、リクエストごとに変わる数字・英数字の並びは、ならしてから比べる
    """
    normalized = re.sub(r"[0-9a-f]{6,}|\d+", "#", re.sub(r"\s+", " ", text)).strip()
    return "#" + hashlib.sha1(normalized.encode()).hexdigest()[:4]


def _kind(status: int, headers: dict[str, str], text: str, title: str) -> str:
    if status == 429:
        return "rate_limited"
    # AWS WAF の CAPTCHA は、人の操作を求める画面
    if headers.get("x-amzn-waf-action", "").lower() == "captcha":
        return "turnstile"
    strong = (
        headers.get("cf-mitigated", "").lower() == "challenge"
        or headers.get("x-amzn-waf-action", "").lower() == "challenge"
        or bool(_STRONG_CHALLENGE.search(text))
        or bool(_CHALLENGE_TITLE.search(title))
    )
    if (strong or status >= 400) and any(m in text for m in _TURNSTILE_MARKERS):
        return "turnstile"
    if strong or (status >= 400 and any(m in text for m in _WEAK_CHALLENGE_MARKERS)):
        return "challenge"
    if status in (401, 403, 451) or _BLOCK_TITLE.search(title) or (status >= 400 and any(m in text for m in _BLOCK_BODY_MARKERS)):
        return "blocked"
    if status >= 400:
        return "error"
    return "ok"
