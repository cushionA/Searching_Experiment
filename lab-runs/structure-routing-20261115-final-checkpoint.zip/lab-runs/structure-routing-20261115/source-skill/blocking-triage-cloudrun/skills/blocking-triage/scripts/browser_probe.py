# /// script
# requires-python = ">=3.10,<3.14"
# dependencies = ["nodriver"]
# ///
"""1 つの URL を、nodriver で開いた Google Chrome の安定版で開き、結果を JSON で標準出力に出す(③のブラウザでの確認)。

使い方: browser_probe.py <URL> [--headless] [--proxy=URL] [--body-bytes=N] [--no-fingerprint] [--chrome=PATH]
                              [--line=client_proxy|residential|direct] [--since-last-request=SEC] [--cooldown-waited=SEC]

- ブラウザは、スキルの中の .tools/ に取った Chrome(setup/ensure_chrome.sh)。--chrome で別のものも指せる
- プロキシの認証情報は、出力にも記録にも残さない(applied.proxy にはホストだけを入れる)。cookie は名前だけ出す
- 結果の形は、以前の Node 版(browser_probe.mjs)と同じ。route_summary.py・classify.py・ladder.py が読む
"""

from __future__ import annotations

import asyncio
import os
import json
import shutil
import sys
import time
from datetime import datetime, timezone

import browser_common as bc

NAV_TIMEOUT_SEC = 30
CHALLENGE_WAIT_SEC = 20


def opt(args: list[str], name: str) -> str | None:
    return next((a[len(name) + 3 :] for a in args if a.startswith(f"--{name}=")), None)


def num_or_none(v: str | None) -> float | None:
    return None if v in (None, "") else float(v)


async def run(url: str, args: list[str]) -> dict:
    import nodriver as uc
    from nodriver import cdp

    headless = "--headless" in args
    proxy = opt(args, "proxy")
    body_bytes = int(opt(args, "body-bytes") or os.environ.get("BT_BODY_BYTES", 2048))
    result: dict = {
        "url": url,
        "engine": "nodriver",
        "headless": headless,
        "started_at": datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
        "line": opt(args, "line"),
        "since_last_request_sec": num_or_none(opt(args, "since-last-request")),
        "cooldown_waited_sec": num_or_none(opt(args, "cooldown-waited")),
    }
    profile = bc.new_profile_dir()
    browser = None
    try:
        chrome = opt(args, "chrome") or bc.setup_chrome()
        browser, via_forwarder = await bc.start_browser(chrome, headless, proxy, profile)
        result["applied"] = {"locale": bc.LOCALE, "timezone": bc.TIMEZONE, "proxy": bc.proxy_option(proxy)["label"], "browser": "chrome"}

        # 最初の応答(多くは 403)と最後の応答を分けて残す。チャレンジを通ると、同じ URL への再読み込みで本物のページが返る
        documents: list = []

        def on_response(ev: cdp.network.ResponseReceived) -> None:
            if ev.type_ == cdp.network.ResourceType.DOCUMENT:
                documents.append(ev)

        started = time.monotonic()
        tab = await (browser.create_context(url, proxy_server=proxy) if via_forwarder else browser.get("about:blank"))
        tab.add_handler(cdp.network.ResponseReceived, on_response)
        await tab.send(cdp.network.enable())
        await tab.send(cdp.emulation.set_timezone_override(bc.TIMEZONE))
        if not via_forwarder:
            await asyncio.wait_for(tab.get(url), NAV_TIMEOUT_SEC)
        await tab.sleep(1)
        await bc.settle(tab, CHALLENGE_WAIT_SEC)

        first, last = (documents[0], documents[-1]) if documents else (None, None)
        cookies = await browser.cookies.get_all()
        result.update(
            ok=True,
            first_status=first.response.status if first else None,
            status=last.response.status if last else None,
            challenge_unresolved=await bc.page_in_challenge(tab),
            final_url=tab.url,
            elapsed_ms=int((time.monotonic() - started) * 1000),
            title=await tab.evaluate("document.title"),
            user_agent=await tab.evaluate("navigator.userAgent"),
            webdriver=await tab.evaluate("navigator.webdriver"),
            language=await tab.evaluate("navigator.language"),
            languages=await bc.eval_json(tab, "Array.from(navigator.languages)"),
            timezone=await tab.evaluate("Intl.DateTimeFormat().resolvedOptions().timeZone"),
            headers={k.lower(): v for k, v in (last.response.headers or {}).items()} if last else {},
            cookie_names=bc.cookie_names([{"name": c.name} for c in cookies]),
            body_head=bc.body_head(await tab.get_content(), body_bytes),
            js_env=await bc.eval_json(tab, bc.JS_ENV),
        )
        # 目的のページを見終えてから測る(目的のページへのリクエストには影響しない)
        if "--no-fingerprint" not in args:
            result["fingerprint"] = await bc.measure_fingerprint(browser)
    except Exception as e:  # noqa: BLE001
        result["ok"] = False
        result["error"] = bc.error_text(e)
    finally:
        if browser is not None:
            browser.stop()
            await asyncio.sleep(0.5)  # 後始末が終わる前にループが閉じると、警告が出る
        shutil.rmtree(profile, ignore_errors=True)
    return result


def main() -> int:
    args = sys.argv[1:]
    url = next((a for a in args if not a.startswith("--")), None)
    if not url:
        print("使い方: browser_probe.py <URL> [--headless] [--proxy=URL] [--body-bytes=N] [--no-fingerprint] [--chrome=PATH]", file=sys.stderr)
        return 2
    result = bc.run_until_terminated(run(url, args))
    if isinstance(result, int):  # SIGTERM で止められた
        return result
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
