"""routes_store.py のテスト。保存先は tmp_path に作る。通信はしない。"""

import pytest

from routes_store import RoutesFileError, find_saved_route, load_routes, record_route, route_to, saved_route_notes, saved_route_pages

PAGES = ["https://shop.example.com/", "https://shop.example.com/list", "https://shop.example.com/item/1"]


@pytest.mark.parametrize(
    "outcome, how",
    [("pass", "手前のページから location.href で移る"), ("fail", None)],
)
def test_a_route_recorded_for_the_first_time_is_saved_with_its_date_line_move_and_outcome(tmp_path, outcome, how):
    path = tmp_path / "routes.json"

    record_route(path, PAGES, line="residential", outcome=outcome, how=how, at="2026-10-27")

    routes = load_routes(path)["sites"]["shop.example.com"]["routes"]
    assert routes == [{"pages": PAGES, "results": [{"at": "2026-10-27", "line": "residential", "outcome": outcome, "how": how, "url": PAGES[-1]}]}]


def test_the_same_route_recorded_again_gets_its_result_appended_and_keeps_only_the_latest_ten(tmp_path):
    path = tmp_path / "routes.json"

    for day in range(1, 13):
        record_route(path, PAGES, line="residential", outcome="fail", how=None, at=f"2026-10-{day:02d}")

    routes = load_routes(path)["sites"]["shop.example.com"]["routes"]
    assert len(routes) == 1
    assert [r["at"] for r in routes[0]["results"]] == [f"2026-10-{day:02d}" for day in range(3, 13)]


def test_the_same_route_to_another_target_page_adds_a_result_with_its_url_instead_of_a_new_route(tmp_path):
    path = tmp_path / "routes.json"
    second = [*PAGES[:-1], "https://shop.example.com/item/2"]

    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")
    record_route(path, second, line="residential", outcome="fail", how=None, at="2026-10-28")

    routes = load_routes(path)["sites"]["shop.example.com"]["routes"]
    assert len(routes) == 1 and routes[0]["pages"] == PAGES
    assert [(r["url"], r["outcome"]) for r in routes[0]["results"]] == [(PAGES[-1], "pass"), (second[-1], "fail")]


def test_another_route_of_the_same_site_is_saved_next_to_the_existing_one(tmp_path):
    path = tmp_path / "routes.json"
    other = ["https://shop.example.com/", "https://shop.example.com/sale/9"]

    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")
    record_route(path, other, line="residential", outcome="fail", how=None, at="2026-10-27")

    routes = load_routes(path)["sites"]["shop.example.com"]["routes"]
    assert [r["pages"] for r in routes] == [PAGES, other]


@pytest.mark.parametrize("outcome", ["unavailable", "skipped"])
def test_a_route_that_was_not_tried_because_the_browser_or_the_line_was_missing_is_not_recorded(tmp_path, outcome):
    path = tmp_path / "routes.json"

    record_route(path, PAGES, line="residential", outcome=outcome, how=None, at="2026-10-27")

    assert not path.exists()


def test_a_broken_routes_file_is_reported_and_left_as_it_is_instead_of_being_overwritten(tmp_path):
    path = tmp_path / "routes.json"
    path.write_text('{"sites": {"shop.example.com": ', encoding="utf-8")

    with pytest.raises(RoutesFileError):
        record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")

    assert path.read_text(encoding="utf-8") == '{"sites": {"shop.example.com": '


def test_the_saved_route_for_the_same_target_comes_first_then_another_route_of_the_site_and_never_another_site(tmp_path):
    path = tmp_path / "routes.json"
    other = ["https://shop.example.com/", "https://shop.example.com/sale/9"]
    elsewhere = ["https://other.example.org/", "https://other.example.org/x"]
    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")
    record_route(path, other, line="residential", outcome="fail", how=None, at="2026-10-27")
    record_route(path, elsewhere, line="residential", outcome="pass", how="x", at="2026-10-27")
    data = load_routes(path)

    assert find_saved_route(data, other[-1])["pages"] == other  # 目的ページが同じ経路は、保存順に関わらず優先
    assert find_saved_route(data, "https://shop.example.com/item/77")["pages"] == PAGES  # なければ、同じサイトで、ページの形が同じ経路
    assert find_saved_route(data, "https://unknown.example.net/item/1") is None


def test_a_route_is_found_by_any_target_page_it_was_tried_with_not_only_the_first(tmp_path):
    path = tmp_path / "routes.json"
    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")
    record_route(path, [*PAGES[:-1], "https://shop.example.com/item/2"], line="residential", outcome="pass", how="x", at="2026-10-28")

    assert find_saved_route(load_routes(path), "https://shop.example.com/item/2")["pages"] == PAGES


@pytest.mark.parametrize(
    "target, expected",
    [("https://shop.example.com/item/77", "list"), ("https://shop.example.com/sale/55", "sale"), ("https://shop.example.com/search?q=x", None), ("https://shop.example.com/a/b/c", None)],
    ids=["同じ形(item)", "同じ形(sale)", "区切りの数が違う", "最初の区切りが違う"],
)
def test_without_a_route_for_the_target_only_a_route_whose_pages_have_the_same_shape_is_used(tmp_path, target, expected):
    path = tmp_path / "routes.json"
    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")
    record_route(path, ["https://shop.example.com/", "https://shop.example.com/sale/9"], line="residential", outcome="pass", how="x", at="2026-10-27")

    found = find_saved_route(load_routes(path), target)

    assert (found and ("list" if found["pages"] == PAGES else "sale")) == expected


def test_a_saved_route_used_for_another_target_ends_at_the_given_target_instead_of_the_old_one(tmp_path):
    path = tmp_path / "routes.json"
    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")
    saved = find_saved_route(load_routes(path), "https://shop.example.com/item/77")

    assert route_to(saved, "https://shop.example.com/item/77") == [PAGES[0], PAGES[1], "https://shop.example.com/item/77"]


def saved_data(tmp_path):
    path = tmp_path / "routes.json"
    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")
    return load_routes(path)


def test_when_no_route_was_given_the_saved_route_of_the_site_is_used_as_the_route_pages_without_the_target(tmp_path):
    pages = saved_route_pages(saved_data(tmp_path), PAGES[-1], route_given=False, use_saved=True)

    assert pages == PAGES[:-1]


def test_when_a_route_was_given_the_saved_route_is_not_used_so_the_given_route_wins(tmp_path):
    assert saved_route_pages(saved_data(tmp_path), PAGES[-1], route_given=True, use_saved=True) is None


def test_when_saved_routes_are_switched_off_the_saved_route_is_not_used(tmp_path):
    assert saved_route_pages(saved_data(tmp_path), PAGES[-1], route_given=False, use_saved=False) is None


def test_when_the_saved_route_passed_the_reading_says_so_with_the_date_of_the_previous_result(tmp_path):
    saved = find_saved_route(saved_data(tmp_path), PAGES[-1])

    notes = saved_route_notes(saved, passed=True, line="residential")

    assert notes == ["保存済みの経路で通った(前回の結果は 2026-10-27 に通った)"]


def test_when_the_saved_route_failed_the_reading_says_the_route_may_be_out_of_date_with_the_previous_result(tmp_path):
    saved = find_saved_route(saved_data(tmp_path), PAGES[-1])

    notes = saved_route_notes(saved, passed=False, line="residential")

    assert notes == ["保存済みの経路で通らなかった(前回の結果は 2026-10-27 に通った)。サイトの構成が変わって、経路が古い可能性がある"]


def test_the_reading_of_a_saved_route_does_not_use_names_known_only_inside_the_skill(tmp_path):
    # チャットにそのまま写される文に、ステップの番号や手の名前を出さない(test_ladder.py の INTERNAL_TERMS と同じ)
    import re

    internal = re.compile(r"ステップ ?[0-9]|手 ?[A-F]|warmup|all_failed|not_reproduced|no_residential|[①②③④]")
    saved = find_saved_route(saved_data(tmp_path), PAGES[-1])

    notes = [*saved_route_notes(saved, passed=True, line="residential"), *saved_route_notes(saved, passed=False, line="residential")]

    assert [n for n in notes if internal.search(n)] == []


def test_the_previous_result_in_the_reading_is_the_latest_one_on_the_same_line(tmp_path):
    path = tmp_path / "routes.json"
    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-20")
    record_route(path, PAGES, line="client_proxy", outcome="fail", how=None, at="2026-10-27")
    saved = find_saved_route(load_routes(path), PAGES[-1])

    assert saved_route_notes(saved, passed=True, line="residential") == ["保存済みの経路で通った(前回の結果は 2026-10-20 に通った)"]
    assert saved_route_notes(saved, passed=False, line="client_proxy") == ["保存済みの経路で通らなかった(前回の結果は 2026-10-27 に全滅だった)。サイトの構成が変わって、経路が古い可能性がある"]


def test_the_reading_has_no_previous_result_when_the_route_was_never_tried_on_that_line(tmp_path):
    path = tmp_path / "routes.json"
    record_route(path, PAGES, line="client_proxy", outcome="fail", how=None, at="2026-10-27")
    saved = find_saved_route(load_routes(path), PAGES[-1])

    assert saved_route_notes(saved, passed=True, line="residential") == ["保存済みの経路で通った"]


# ---- www の有無


def www(pages):
    return [p.replace("://shop.", "://www.shop.") for p in pages]


def test_a_route_saved_with_www_is_found_without_it_and_the_other_way_round(tmp_path):
    path = tmp_path / "routes.json"
    record_route(path, www(PAGES), line="residential", outcome="pass", how="x", at="2026-10-27")
    data = load_routes(path)

    assert list(data["sites"]) == ["shop.example.com"]
    assert find_saved_route(data, PAGES[-1])["pages"] == www(PAGES)
    assert find_saved_route(data, www(PAGES)[-1])["pages"] == www(PAGES)


def test_results_go_to_the_existing_site_entry_even_when_its_key_was_written_with_www(tmp_path):
    path = tmp_path / "routes.json"
    path.write_text('{"sites": {"www.shop.example.com": {"routes": [{"pages": %s, "results": []}]}}}' % str(www(PAGES)).replace("'", '"'), encoding="utf-8")

    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")

    data = load_routes(path)
    assert list(data["sites"]) == ["www.shop.example.com"]
    assert len(data["sites"]["www.shop.example.com"]["routes"][0]["results"]) == 1


# ---- 書き込み


def record_many(args):
    path, i = args
    for j in range(5):
        pages = ["https://s.example.com/", f"https://s.example.com/p{i}/", f"https://s.example.com/p{i}/x{j}"]
        record_route(path, pages, line="residential", outcome="pass", how="x", at="2026-10-27")


def test_results_recorded_at_the_same_time_by_several_runs_are_all_kept(tmp_path):
    import multiprocessing

    path = tmp_path / "routes.json"
    with multiprocessing.get_context("fork").Pool(6) as pool:
        pool.map(record_many, [(path, i) for i in range(6)])

    routes = load_routes(path)["sites"]["s.example.com"]["routes"]
    assert sorted(len(r["results"]) for r in routes) == [5] * 6


def test_when_writing_fails_the_saved_file_stays_as_it_was_and_no_temporary_file_is_left(tmp_path, monkeypatch):
    path = tmp_path / "routes.json"
    record_route(path, PAGES, line="residential", outcome="pass", how="x", at="2026-10-27")
    before = path.read_text(encoding="utf-8")

    def boom(*a, **k):
        raise OSError("disk full")

    monkeypatch.setattr("routes_store.os.replace", boom)
    with pytest.raises(OSError):
        record_route(path, PAGES, line="residential", outcome="fail", how=None, at="2026-10-28")

    assert path.read_text(encoding="utf-8") == before
    assert sorted(p.name for p in tmp_path.iterdir() if p.name != "routes.json.lock") == ["routes.json"]
