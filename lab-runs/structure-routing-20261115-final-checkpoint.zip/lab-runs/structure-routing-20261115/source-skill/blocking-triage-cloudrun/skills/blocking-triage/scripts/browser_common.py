"""nodriver でブラウザを開く診断(browser_probe.py・browser_route.py)の、ブラウザに依存しない部品。

結果の JSON は、以前の Node 版(browser_probe.mjs)と同じ形にする(route_summary.py・classify.py・ladder.py が読むため)。
"""

from __future__ import annotations

import json
import re
from urllib.parse import unquote, urlsplit

# チャレンジ中のページのタイトル。要素のほうは、タイトルでは分からないもの(CHALLENGE_SELECTOR)をページ側で調べる
CHALLENGE_TITLE = re.compile(r"just a moment|checking your browser|security check", re.IGNORECASE)
# チャレンジ中のページにある要素(終わるまで待つ対象)。Akamai の画面は 200・タイトル空で返ることがある
CHALLENGE_SELECTOR = ",".join(
    [
        "#sec-if-cpt-container",
        'meta[http-equiv="refresh" i][content*="bm-verify"]',
        'html:has(#challenge-container):has(script[src*=".awswaf.com/"])',
    ]
)


def proxy_option(url: str | None) -> dict:
    """プロキシ URL を、サーバーと認証情報に分け、表示用のラベルを付ける。

    認証情報(user:pass@)は username / password に分け、ラベルには出さない。出力・記録にはラベルだけを使う。
    """
    if not url:
        return {"option": None, "label": None}
    u = urlsplit(url)
    server = f"{u.scheme}://{u.netloc.rsplit('@', 1)[-1]}"
    option = {"server": server}
    if u.username:
        option["username"] = unquote(u.username)
        option["password"] = unquote(u.password or "")
    return {"option": option, "label": server}


def launch_args(browser: str, env_args: str | None = None) -> list[str]:
    """Chrome の起動の引数。環境変数の引数(空白区切り)に、Chrome のときは WebGL のフラグを足す。

    空文字の要素が混ざると、ヘッドレスで起動に失敗するので、除く。
    """
    args = (env_args or "").split()
    if browser == "chrome" and "--enable-unsafe-swiftshader" not in args:
        args.append("--enable-unsafe-swiftshader")
    # --lang だけでは、LANG のない環境で navigator.language が en-US のままになる。Accept-Language は ja,en-US;q=0.9,en;q=0.8 で送る
    if browser == "chrome" and not any(a.startswith("--accept-lang") for a in args):
        args.append("--accept-lang=" + (os.environ.get("BT_BROWSER_ACCEPT_LANG") or "ja,en-US,en"))
    return args


def in_challenge(title: str | None, has_challenge_element: bool) -> bool:
    """チャレンジの確認中か(タイトル、またはチャレンジの要素)。"""
    return bool(CHALLENGE_TITLE.search(title or "")) or has_challenge_element


def error_text(exc: BaseException, limit: int = 300) -> str:
    """結果に残すエラー文。1 行目だけを limit 文字までに切る(スタックトレースを混ぜない)。"""
    first = (str(exc).split("\n")[0] if str(exc) else "")[:limit]
    return f"{type(exc).__name__}: {first}"


def parse_fingerprint(text: str) -> dict:
    """tls.peet.ws の JSON から、接続の層の判定に使う値を取る。読めないときは error を返す。"""
    try:
        d = json.loads(text)
        extensions = (d.get("tls") or {}).get("extensions")
        return {
            "ja4": (d.get("tls") or {}).get("ja4"),
            "akamai_h2": (d.get("http2") or {}).get("akamai_fingerprint"),
            "http_version": d.get("http_version"),
            "extensions": [e["name"] for e in extensions if "GREASE" not in e["name"]] if extensions else None,
            **({"user_agent": d["user_agent"]} if d.get("user_agent") else {}),
        }
    except (ValueError, TypeError, KeyError, AttributeError) as e:
        return {"error": error_text(e, 200)}


def cookie_names(cookies: list[dict]) -> list[str]:
    """cookie は名前だけ返す(値は、出力にも記録にも残さない)。重複を除き、名前順に並べる。"""
    return sorted({c["name"] for c in cookies})


def body_head(body: str, size: int) -> str:
    """結果に残す本文の先頭。巨大な本文で出力が膨らまないように切る。"""
    return body[:size]


# ---- ここから下は、実際にブラウザを動かす部分(単体テストの対象外。実行して確かめる)

import asyncio  # noqa: E402
import os  # noqa: E402
import signal  # noqa: E402
import subprocess  # noqa: E402
import tempfile  # noqa: E402
import time  # noqa: E402
from pathlib import Path  # noqa: E402

SETUP_DIR = Path(__file__).with_name("setup")
FINGERPRINT_URL = "https://tls.peet.ws/api/all"
LOCALE = os.environ.get("BT_BROWSER_LOCALE") or "ja-JP"
TIMEZONE = os.environ.get("BT_BROWSER_TZ") or "Asia/Tokyo"

# ページの JS から見える値のうち、ボット対策が自動化やヘッドレスの手がかりにしうるもの。読みは browser_env.py(env_flags)が行う
JS_ENV = """
(() => {
  const out = {};
  try {
    const gl = document.createElement('canvas').getContext('webgl');
    const ext = gl && gl.getExtension('WEBGL_debug_renderer_info');
    out.webgl_vendor = gl ? gl.getParameter(ext ? ext.UNMASKED_VENDOR_WEBGL : gl.VENDOR) : null;
    out.webgl_renderer = gl ? gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER) : null;
  } catch (e) { out.webgl_renderer = null; }
  out.screen = { width: screen.width, height: screen.height, avail_width: screen.availWidth, avail_height: screen.availHeight };
  out.window = { inner_width: innerWidth, inner_height: innerHeight, outer_width: outerWidth, outer_height: outerHeight };
  out.device_pixel_ratio = devicePixelRatio;
  out.plugins = navigator.plugins ? navigator.plugins.length : null;
  out.hardware_concurrency = navigator.hardwareConcurrency ?? null;
  out.device_memory = navigator.deviceMemory ?? null;
  out.platform = navigator.platform ?? null;
  out.ua_brands = navigator.userAgentData ? navigator.userAgentData.brands.map((b) => b.brand + ' ' + b.version) : null;
  return out;
})()
"""


def setup_chrome() -> str:
    """Chrome の実行ファイルのパスを返す。無ければ取得し(ensure_chrome.sh)、足りない共有ライブラリを補う(ensure_chrome_libs.sh)。

    取ったものは、スキルの中(.tools/)に収まる。補った共有ライブラリは、このプロセスの LD_LIBRARY_PATH に足す。
    """
    chrome = subprocess.run(["bash", str(SETUP_DIR / "ensure_chrome.sh")], check=True, capture_output=True, text=True).stdout.strip()
    libs = subprocess.run(["bash", str(SETUP_DIR / "ensure_chrome_libs.sh"), chrome], check=True, capture_output=True, text=True).stdout.strip()
    if libs:
        os.environ["LD_LIBRARY_PATH"] = f"{libs}:{os.environ['LD_LIBRARY_PATH']}" if os.environ.get("LD_LIBRARY_PATH") else libs
    return chrome


async def start_browser(chrome: str, headless: bool, proxy: str | None, profile_dir: str):
    """nodriver で Chrome を起動する。認証のないプロキシは --proxy-server で、認証つきは nodriver の中継(create_context)で渡す。"""
    import nodriver as uc

    os.environ["TZ"] = TIMEZONE
    opt = proxy_option(proxy)["option"]
    args = launch_args("chrome", os.environ.get("CLIENT_PUPPETEER_CHROMIUM_ARGS"))
    if opt and "username" not in opt:
        args.append(f"--proxy-server={opt['server']}")
    browser = await uc.start(
        browser_executable_path=chrome, headless=headless, user_data_dir=profile_dir, lang=LOCALE, browser_args=args
    )
    return browser, bool(opt and "username" in opt)


async def eval_json(tab, expression: str):
    """ページ内の式を評価して、Python の値で返す。nodriver は配列・オブジェクトを内部表現で返すので、JSON 文字列で受け取る。"""
    return json.loads(await tab.evaluate(f"JSON.stringify({expression})"))


async def page_in_challenge(tab) -> bool:
    """チャレンジの確認中か。遷移の途中で調べられないときも、確認中とみなす。"""
    try:
        title, has_element = await eval_json(tab, f"[document.title, document.querySelector({json.dumps(CHALLENGE_SELECTOR)}) !== null]")
        return in_challenge(title, bool(has_element))
    except Exception:  # noqa: BLE001
        return True


async def settle(tab, wait_sec: float) -> None:
    """チャレンジの確認が終わるのを待つ(最大 wait_sec)。通ると同じ URL を読み込み直すことがあるので、間隔をおいて調べ直す。"""
    deadline = time.monotonic() + wait_sec
    while await page_in_challenge(tab) and time.monotonic() < deadline:
        await asyncio.sleep(0.5)


async def measure_fingerprint(browser) -> dict:
    """同じブラウザから tls.peet.ws を別のタブで開き、相手に届いた TLS と HTTP/2 の指紋を取る(外部サービスへ送る)。"""
    tab = None
    try:
        tab = await browser.get(FINGERPRINT_URL, new_tab=True)
        await tab.sleep(1.5)
        return parse_fingerprint(await tab.evaluate("document.body.innerText"))
    except Exception as e:  # noqa: BLE001
        return {"error": error_text(e, 200)}
    finally:
        if tab is not None:
            try:
                await tab.close()
            except Exception:  # noqa: BLE001
                pass


def new_profile_dir() -> str:
    return tempfile.mkdtemp(prefix="blocking-triage-")


def run_until_terminated(coro) -> int | object:
    """コルーチンを実行する。SIGTERM(browser_run.py の時間切れ・中断)を受けたら、ブラウザとプロファイルを片付けてから 143 で終わる。"""

    async def wrapper():
        asyncio.get_running_loop().add_signal_handler(signal.SIGTERM, asyncio.current_task().cancel)
        return await coro

    try:
        return asyncio.run(wrapper())
    except asyncio.CancelledError:
        return 128 + signal.SIGTERM


def opt(args: list[str], name: str) -> str | None:
    """--name=値 の値。なければ None。"""
    return next((a[len(name) + 3 :] for a in args if a.startswith(f"--{name}=")), None)


async def open_tab(browser, via_forwarder: bool, proxy: str | None):
    """最初のタブを開き、ページの遷移の応答を追う。戻りは (タブ, nav)。nav["last"] は、メインのフレームの最後の応答。"""
    from nodriver import cdp

    tab = await (browser.create_context("about:blank", proxy_server=proxy) if via_forwarder else browser.get("about:blank"))
    nav: dict = {"last": None, "frame_id": None}

    def on_response(ev: cdp.network.ResponseReceived) -> None:
        if ev.type_ == cdp.network.ResourceType.DOCUMENT and ev.frame_id == nav["frame_id"]:
            nav["last"] = ev.response

    tab.add_handler(cdp.network.ResponseReceived, on_response)
    await tab.send(cdp.network.enable())
    await tab.send(cdp.emulation.set_timezone_override(TIMEZONE))
    nav["frame_id"] = (await tab.send(cdp.page.get_frame_tree())).frame.id_
    return tab, nav
