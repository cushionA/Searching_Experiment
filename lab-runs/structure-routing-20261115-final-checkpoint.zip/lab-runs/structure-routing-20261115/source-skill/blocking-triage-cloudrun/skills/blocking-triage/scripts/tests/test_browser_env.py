"""browser_env.py のテスト。③のブラウザの指紋と、JS から見える値の読み。実行: uv run --with pytest pytest .claude/skills/blocking-triage/scripts/tests"""

import pytest

from browser_env import compare_browsers, env_flags, read_fingerprint

CHROME_H2 = "1:65536;2:0;4:6291456;6:262144|15663105|0|m,a,s,p"
UA_132 = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"
CLEAN_ENV = {
    "webgl_renderer": "ANGLE (Intel, Mesa Intel(R) UHD Graphics 620 (KBL GT2), OpenGL 4.6)",
    "screen": {"width": 1920, "height": 1080},
    "window": {"outer_width": 1280, "outer_height": 900},
    "plugins": 5,
    "platform": "Linux x86_64",
    "ua_brands": ["Google Chrome 132", "Chromium 132", "Not A(Brand 24"],
}


def test_browser_matching_chrome_tls_and_h2_is_read_as_the_same_connection_as_chrome():
    r = read_fingerprint({"ja4": "t13d1517h2_8daaf6152771_cb7bf5808d99", "akamai_h2": CHROME_H2, "user_agent": UA_132})
    assert r["ja4_ciphers_match_chrome"] is True
    assert r["h2_matches_chrome"] is True
    assert r["ua_major"] == 132
    assert any("23 版古い" in n for n in r["notes"])


def test_cipher_part_of_ja4_different_from_chrome_is_reported_as_not_matching():
    r = read_fingerprint({"ja4": "t13d3112h2_e8f1e7e78f70_b26ce05bbdd6", "akamai_h2": "3:100;4:33554432;2:0|33488897|0|m,p,s,a",
                          "user_agent": UA_132})
    assert r["ja4_ciphers_match_chrome"] is False
    assert r["h2_matches_chrome"] is False


def test_missing_fingerprint_is_reported_as_not_measured():
    r = read_fingerprint({"error": "TimeoutError: page.goto: Timeout 30000ms exceeded"})
    assert r["ja4_ciphers_match_chrome"] is None
    assert any("取れなかった" in n for n in r["notes"])


def test_clean_headful_environment_has_no_flags():
    assert env_flags(UA_132, False, CLEAN_ENV) == []


@pytest.mark.parametrize(
    ("ua", "webdriver", "change", "expected"),
    [
        (UA_132, True, {}, "webdriver"),
        (UA_132.replace("Chrome/", "HeadlessChrome/"), False, {}, "HeadlessChrome"),
        (UA_132, False, {"webgl_renderer": "ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero)), SwiftShader driver)"}, "ソフトウェア描画"),
        (UA_132, False, {"webgl_renderer": "llvmpipe (LLVM 15.0.6, 256 bits)"}, "ソフトウェア描画"),
        (UA_132, False, {"webgl_renderer": None}, "WebGL"),
        (UA_132, False, {"plugins": 0}, "plugins"),
        (UA_132, False, {"window": {"outer_width": 0, "outer_height": 0}}, "outerWidth"),
        (UA_132, False, {"ua_brands": ["Chromium 132", "Not A(Brand 24"]}, "Chromium"),
        (UA_132.replace("X11; Linux x86_64", "Windows NT 10.0; Win64; x64"), False, {}, "OS"),
    ],
)
def test_traces_visible_to_page_js_are_flagged(ua, webdriver, change, expected):
    flags = env_flags(ua, webdriver, {**CLEAN_ENV, **change})
    assert any(expected in f for f in flags), flags


def test_firefox_is_not_flagged_for_missing_brands_or_plugins_of_chrome():
    ua = "Mozilla/5.0 (X11; Linux x86_64; rv:135.0) Gecko/20100101 Firefox/135.0"
    assert env_flags(ua, False, {**CLEAN_ENV, "ua_brands": None, "plugins": 5}) == []


def browser(ja4, h2, ua, **env):
    return {"user_agent": ua, "webdriver": False, "fingerprint": {"ja4": ja4, "akamai_h2": h2}, "js_env": {**CLEAN_ENV, **env}}


def test_same_connection_but_different_js_values_points_to_the_js_layer_or_version():
    human = browser("t13d1517h2_8daaf6152771_cb7bf5808d99", CHROME_H2, UA_132.replace("132", "155"))
    probed = browser("t13d1516h2_8daaf6152771_02713d6af862", CHROME_H2, UA_132,
                         webgl_renderer="ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero)), SwiftShader driver)",
                         ua_brands=["Chromium 132"])
    c = compare_browsers(human, probed)
    rows = {r["item"]: r for r in c["rows"]}
    assert rows["JA4 の暗号スイートの部分"]["same"] is True
    assert rows["HTTP/2 の指紋"]["same"] is True
    assert rows["JA4 の拡張の部分"]["same"] is False
    assert rows["UA の版"]["same"] is False
    assert c["only_in_browser_probe"] and not c["only_in_human"]
    # 実際の利用者にまれな違い(版・brands・ソフトウェア描画)だけを候補にする。JA4 の拡張の部分は候補にしない
    assert set(c["candidates"]) == {"UA の版", "brands に Google Chrome があるか", "WebGL がソフトウェア描画か"}
    # 切り分けとして返すのは層だけ。どの項目が違ったかは JSON(candidates)に残し、読みには出さない
    assert c["layer"] == "JS の層かブラウザの版"
    assert "UA の版" not in c["reading"] and "WebGL" not in c["reading"]


def test_differences_real_users_also_have_are_not_counted_as_causes():
    # セッションの再開で増える拡張、OS、画面などは、実際の利用者のあいだでも違う(個体差)
    human = browser("t13d1518h2_8daaf6152771_e2d80978ab2e", CHROME_H2, UA_132, platform="Win32")
    human["user_agent"] = UA_132.replace("X11; Linux x86_64", "Windows NT 10.0; Win64; x64")
    probe_ = browser("t13d1516h2_8daaf6152771_02713d6af862", CHROME_H2, UA_132)
    c = compare_browsers(human, probe_)
    roles = {r["item"]: r["role"] for r in c["rows"]}
    assert roles["JA4 の拡張の部分"] == roles["navigator.platform"] == "個体差"
    assert c["candidates"] == []
    assert c["layer"] == "比べた層に違いなし"


def test_different_connection_is_read_as_a_connection_layer_difference():
    human = browser("t13d1517h2_8daaf6152771_cb7bf5808d99", CHROME_H2, UA_132)
    other = browser("t13d3112h2_e8f1e7e78f70_b26ce05bbdd6", "3:100;4:33554432;2:0|33488897|0|m,p,s,a", UA_132)
    c = compare_browsers(human, other)
    assert c["layer"] == "接続の層"


def test_identical_browsers_point_outside_the_compared_items():
    same = browser("t13d1516h2_8daaf6152771_02713d6af862", CHROME_H2, UA_132)
    c = compare_browsers(same, same)
    assert c["layer"] == "比べた層に違いなし"


def test_resumed_tls_session_is_named_as_the_cause_of_a_different_extension_part():
    fp = {"ja4": "t13d1518h2_8daaf6152771_e2d80978ab2e", "akamai_h2": CHROME_H2, "user_agent": UA_132.replace("132", "155"),
          "extensions": ["server_name (0)", "pre_shared_key (41)", "key_share (51)"]}
    notes = read_fingerprint(fp)["notes"]
    assert any("pre_shared_key" in n and "再開" in n for n in notes)


def test_extension_names_present_on_only_one_side_are_listed():
    human = browser("t13d1518h2_8daaf6152771_e2d80978ab2e", CHROME_H2, UA_132)
    probe_ = browser("t13d1516h2_8daaf6152771_02713d6af862", CHROME_H2, UA_132)
    human["fingerprint"]["extensions"] = ["server_name (0)", "pre_shared_key (41)", "application_settings (17613)"]
    probe_["fingerprint"]["extensions"] = ["server_name (0)", "application_settings_old (17513)"]
    rows = {r["item"]: r for r in compare_browsers(human, probe_)["rows"]}
    diff = rows["片方だけにある拡張"]
    assert diff["human"] == ["pre_shared_key (41)", "application_settings (17613)"]
    assert diff["browser_probe"] == ["application_settings_old (17513)"]
    assert diff["same"] is False
