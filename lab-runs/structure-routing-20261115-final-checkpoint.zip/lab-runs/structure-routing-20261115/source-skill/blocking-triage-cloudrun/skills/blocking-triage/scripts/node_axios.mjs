// qcv3 の Axios クライアント(getAxiosClient の AxiosClient)そのもので 1 URL を取得し、結果を JSON で標準出力に出す。
// probe.py の axios の行に使う。直接の接続は Node の TLS(OpenSSL)と HTTP/1.1 で、Basic と同じ ClientHello になる。
// プロキシ経由では CONNECT を使わず、プロキシに絶対 URL を平文で渡すので、サイトとの TLS はプロキシが作る。
// 使い方: echo '{"url":"https://example.com/","userAgent":"...","proxy":null}' | node node_axios.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { decode } from './body_decode.mjs';

// AxiosClient は exports に出ていないので、qcv3 の実体の場所から読む
const QCV3_ROOT = path.dirname(fs.realpathSync('/app/node_modules/@keywalker/queueing-crawler-v3/package.json'));
const { AxiosClient } = await import(path.join(QCV3_ROOT, 'dist/src/crawler/context/webClient/axios.js'));

const MAX_REDIRECTS = 5;

function setCookieNames(headers) {
  return [headers?.['set-cookie'] ?? []].flat().map((c) => c.split('=', 1)[0].trim());
}

/**
 * 本番の AxiosClient は、プロキシの host・port・protocol だけを渡し、認証情報(user:pass)を捨てる。
 * そのままでは認証つきのプロキシ(レジデンシャルに多い)が 407 を返し、サイトの判定を見られないので、
 * 診断では認証を足して送る。本番と違う送り方なので、結果に proxy_auth_added を残す
 */
function proxyWithAuth(proxy) {
  const u = proxy ? new URL(proxy) : null;
  if (!u?.username) return null;
  const auth = { username: decodeURIComponent(u.username), password: decodeURIComponent(u.password) };
  return { host: u.hostname, port: Number(u.port), protocol: u.protocol, auth };
}

/**
 * AxiosClient の既定の設定(cookie の jar、user-agent だけ)で取得する。cookie は名前だけ返す。
 * headers([名前, 値] の並び)を渡すと、パーサーが axiosOptions.headers で付けるのと同じ形で足す(user-agent も上書きする)
 */
export async function fetchAxios({ url, proxy = null, userAgent, headers = null, timeoutMs = 20000 }) {
  const started = Date.now();
  const cookieNames = [];
  let finalUrl = url;
  const authProxy = proxyWithAuth(proxy);
  // CLIENT_PROXY を空で渡さないと、AxiosClient が /app/.env の CLIENT_PROXY を読んでしまう
  const client = new AxiosClient({
    envs: { CLIENT_USER_AGENT: userAgent, CLIENT_PROXY: proxy || '' },
    ...(authProxy ? { options: { proxy: authProxy } } : {}),
  });
  try {
    const res = await client.fetchResponse({
      url,
      axiosOptions: {
        ...(headers ? { headers: Object.fromEntries(headers) } : {}),
        timeout: timeoutMs,
        maxRedirects: MAX_REDIRECTS,
        validateStatus: () => true, // 403 なども応答として受け取る
        beforeRedirect: (options, { headers }) => {
          cookieNames.push(...setCookieNames(headers)); // 途中の応答の cookie も拾う
          finalUrl = options.href;
        },
      },
    });
    cookieNames.push(...setCookieNames(res.headers));
    return {
      status: res.status,
      http_version: `http/${res.request?.res?.httpVersion ?? '1.1'}`,
      final_url: finalUrl,
      elapsed_ms: Date.now() - started,
      headers: Object.fromEntries(
        Object.entries(res.headers)
          .filter(([k]) => k !== 'set-cookie') // cookie の値は出さない
          .map(([k, v]) => [k, [v].flat().join(', ')]),
      ),
      cookie_names: [...new Set(cookieNames)].sort(),
      body: decode(Buffer.from(res.data ?? []), res.headers['content-type']),
      ...(authProxy ? { proxy_auth_added: true } : {}),
    };
  } catch (err) {
    return { error: `${err.code ?? err.name}: ${String(err.message).slice(0, 200)}` };
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const input = JSON.parse(fs.readFileSync(0, 'utf8'));
  process.stdout.write(JSON.stringify(await fetchAxios(input)));
}
