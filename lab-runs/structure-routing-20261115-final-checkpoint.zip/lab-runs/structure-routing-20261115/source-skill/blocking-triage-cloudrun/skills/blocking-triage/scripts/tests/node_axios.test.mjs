// node_axios.mjs のテスト。ローカルのサーバーだけを使い、外へは送らない。実行: node --test .claude/skills/blocking-triage/scripts/tests/
import assert from 'node:assert/strict';
import http from 'node:http';
import { test } from 'node:test';

import { fetchAxios } from '../node_axios.mjs';

async function serve(handler) {
  const server = http.createServer(handler);
  server.on('connect', (req, socket) => {
    server.emit('tunnel', req.url);
    socket.destroy();
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  return { server, origin: `http://127.0.0.1:${port}` };
}

test('リダイレクトを辿って 403 が返ったとき、例外にせず、最終 URL・HTTP/1.1・途中の応答も含めた cookie の名前と、Axios が足すヘッダーを返すこと', async (t) => {
  let received;
  const { server, origin } = await serve((req, res) => {
    if (req.url === '/start') {
      res.writeHead(302, { location: '/end', 'set-cookie': '__cf_bm=secret-1; Path=/' });
      return res.end();
    }
    received = req.headers;
    res.writeHead(403, { 'content-type': 'text/html; charset=utf-8', 'set-cookie': 'cf_clearance=secret-2; Path=/' });
    res.end('<title>Attention Required!</title>');
  });
  t.after(() => server.close());

  const out = await fetchAxios({ url: `${origin}/start`, userAgent: 'UA-for-test' });

  assert.equal(out.status, 403);
  assert.equal(out.http_version, 'http/1.1');
  assert.equal(out.final_url, `${origin}/end`);
  assert.deepEqual(out.cookie_names, ['__cf_bm', 'cf_clearance']);
  assert.equal(out.body, '<title>Attention Required!</title>');
  assert.ok(!JSON.stringify(out).includes('secret-'), 'cookie の値を出さない');
  // Axios は UA に加えて、accept と accept-encoding を自分で付ける(本番と同じ)
  assert.equal(received['user-agent'], 'UA-for-test');
  assert.equal(received.accept, 'application/json, text/plain, */*');
  assert.match(received['accept-encoding'], /gzip/);
});

test('ヘッダーを渡したとき、その名前と値で送り、UA も AxiosClient の既定ではなく渡した値になること', async (t) => {
  let received;
  const { server, origin } = await serve((req, res) => {
    received = req.headers;
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end('<title>ok</title>');
  });
  t.after(() => server.close());

  await fetchAxios({
    url: `${origin}/`,
    userAgent: 'UA-default',
    headers: [
      ['sec-ch-ua-platform', '"Linux"'],
      ['user-agent', 'UA-from-headers'],
      ['accept', 'text/html'],
    ],
  });

  assert.equal(received['sec-ch-ua-platform'], '"Linux"');
  assert.equal(received['user-agent'], 'UA-from-headers');
  assert.equal(received.accept, 'text/html');
});

test('https の URL をプロキシ経由で取るとき、CONNECT を使わず、プロキシに絶対 URL を平文で渡すこと', async (t) => {
  let seen;
  let tunneled = false;
  const { server, origin } = await serve((req, res) => {
    seen = req.url;
    res.writeHead(200, { 'content-type': 'text/html' });
    res.end('<title>ok</title>');
  });
  server.on('tunnel', () => {
    tunneled = true;
  });
  t.after(() => server.close());

  const out = await fetchAxios({ url: 'https://target.example/page', proxy: origin, userAgent: 'UA' });

  // サイトとの TLS は、Node ではなくプロキシが作ることになる
  assert.equal(out.status, 200);
  assert.equal(seen, 'https://target.example/page');
  assert.equal(tunneled, false);
});

test('認証情報つきのプロキシを渡したとき、Proxy-Authorization を付けて送り、本番の AxiosClient と違う送り方をしたことを結果に残すこと', async (t) => {
  let auth;
  const { server, origin } = await serve((req, res) => {
    auth = req.headers['proxy-authorization'];
    res.writeHead(200, { 'content-type': 'text/html' });
    res.end('<title>ok</title>');
  });
  t.after(() => server.close());
  const proxy = origin.replace('http://', 'http://us%40er:p%3Ass@');

  const out = await fetchAxios({ url: 'https://target.example/page', proxy, userAgent: 'UA' });

  // 本番の AxiosClient は host・port・protocol だけを渡すので、認証つきのプロキシでは 407 になる
  assert.equal(out.status, 200);
  assert.equal(auth, `Basic ${Buffer.from('us@er:p:ss').toString('base64')}`);
  assert.equal(out.proxy_auth_added, true);
  assert.ok(!JSON.stringify(out).includes('p:ss') && !JSON.stringify(out).includes('p%3Ass'), '認証情報を出さない');
});

test('接続できないとき、例外を投げずに error を返すこと', async () => {
  const { server, origin } = await serve(() => {});
  await new Promise((resolve) => server.close(resolve)); // 閉じたポートに送る

  const out = await fetchAxios({ url: `${origin}/`, userAgent: 'UA', timeoutMs: 3000 });

  assert.match(out.error, /ECONNREFUSED/);
});
