#!/usr/bin/env bash
# Chrome が起動に使う共有ライブラリのうち、この環境に無いものを、root なしで補う。
# apt-get download で .deb を取り(root は要らない)、dpkg-deb -x でユーザー領域に展開するだけで、
# システムのパッケージ・リポジトリ・シェルの設定は変更しない。
# システムの apt に索引が無い(root でなく apt-get update が打てない)ときは、索引をスキルの中(.tools/apt)に作って使う。
# 展開先に、この環境の glibc では読めないライブラリ(別の環境で作ったもの)が残っていれば、<展開先>.stale へ退避して取り直す。
# 使い方: ensure_chrome_libs.sh <chrome の実行ファイル> [展開先]
# 標準出力に、LD_LIBRARY_PATH に足すディレクトリを出す(補う必要がなければ空)。何度実行しても同じ結果になる。
# 展開先の既定は、スキルの中の .tools/libs。Debian 系(apt-get がある環境)だけで動く。
set -euo pipefail

bin="${1:?使い方: ensure_chrome_libs.sh <chrome の実行ファイル> [展開先]}"
skill="$(cd "$(dirname "$0")/../.." && pwd)"  # 取ったものはスキルの中(.tools/)に収める
dir="${2:-$skill/.tools/libs}"
lib="$dir/usr/lib/x86_64-linux-gnu"
apt_dir="$skill/.tools/apt"
apt_opts=()  # システムの索引を使えないときだけ、ユーザー領域の索引を指す

# lib を足した状態で、まだ見つからない共有ライブラリの名前を出す
missing() {
  LD_LIBRARY_PATH="$lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ldd "$bin" 2>&1 | awk '/=> not found/ {print $1}'
}

# 展開先のライブラリが、この環境の glibc では読めないか(別の環境で作ったものが残っている)
stale() {
  [ -d "$lib" ] &&
    LD_LIBRARY_PATH="$lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ldd "$bin" 2>&1 | grep -qF "not found (required by $dir"
}

# 64 ビットの time_t に移行した版(名前が t64 で終わる)があれば、そちらの名前を出す
t64_name() {
  apt-cache "${apt_opts[@]}" show "${1}t64" >/dev/null 2>&1 && echo "${1}t64" || echo "$1"
}

# 共有ライブラリの名前 → それを含むパッケージ名(Chrome と、その依存が要るもの)
package_for() {
  case "$1" in
    libnspr4.so*) echo libnspr4 ;;
    libnss3.so* | libnssutil3.so* | libsmime3.so*) echo libnss3 ;;
    libasound.so*) t64_name libasound2 ;;
    libatk-1.0.so*) t64_name libatk1.0-0 ;;
    libatk-bridge-2.0.so*) t64_name libatk-bridge2.0-0 ;;
    libatspi.so*) t64_name libatspi2.0-0 ;;
    libcups.so*) t64_name libcups2 ;;
    libavahi-common.so*) t64_name libavahi-common3 ;;
    libavahi-client.so*) t64_name libavahi-client3 ;;
    libxkbcommon.so*) echo libxkbcommon0 ;;
    libgbm.so*) echo libgbm1 ;;
    libXcomposite.so*) echo libxcomposite1 ;;
    libXdamage.so*) echo libxdamage1 ;;
    libXrandr.so*) echo libxrandr2 ;;
    libXfixes.so*) echo libxfixes3 ;;
    libXi.so*) echo libxi6 ;;
    libXrender.so*) echo libxrender1 ;;
    libwayland-server.so*) echo libwayland-server0 ;;
    libdrm.so*) echo libdrm2 ;;
    *) return 1 ;;
  esac
}

# root なしで索引を作る: 置き場と状態の参照先だけを、書き込めるユーザー領域に替える
update_user_index() {
  mkdir -p "$apt_dir/lists/partial" "$apt_dir/cache"
  echo "apt の索引をユーザー領域に作る: $apt_dir" >&2
  apt-get "${apt_opts[@]}" update >&2
}

if stale; then
  echo "展開先に、この環境の glibc では読めないライブラリがある。$dir.stale へ退避して取り直す" >&2
  rm -rf "$dir.stale"
  mv "$dir" "$dir.stale"
fi

if [ -z "$(missing)" ]; then
  [ -d "$lib" ] && echo "$lib"
  exit 0
fi
if ! command -v apt-get >/dev/null 2>&1; then
  echo "足りない共有ライブラリを補えない(apt-get がない): $(missing | tr '\n' ' ')" >&2
  exit 4
fi

# システムの索引で取れないなら(索引が空で、root でなく更新できない)、ユーザー領域の索引に切り替える
if ! apt-get download --print-uris libnspr4 >/dev/null 2>&1; then
  apt_opts=(-o "Dir::State::Lists=$apt_dir/lists" -o "Dir::Cache=$apt_dir/cache" -o "Dir::State::status=/var/lib/dpkg/status")
  [ -n "$(ls -A "$apt_dir/lists" 2>/dev/null | grep -v -e '^lock$' -e '^partial$')" ] || update_user_index
fi

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

# 補ったパッケージの依存先(ライブラリ)が、さらに足りないことがあるので、足りなくなくなるまで繰り返す
for round in 1 2 3; do
  need="$(missing)"
  [ -z "$need" ] && break
  packages=""
  for so in $need; do
    if ! pkg="$(package_for "$so")"; then
      echo "このスクリプトが対応していない共有ライブラリ: $so。root で入れるか、スクリプトに対応を足す" >&2
      exit 4
    fi
    case " $packages " in *" $pkg "*) ;; *) packages="$packages $pkg" ;; esac
  done
  echo "足りない共有ライブラリを補う($round 回目):$packages" >&2
  # 索引が古くて取れないときは、ユーザー領域の索引だけ、1 回作り直して取り直す
  if ! (cd "$tmp" && apt-get "${apt_opts[@]}" download $packages >&2); then
    [ "${#apt_opts[@]}" -gt 0 ] || { echo "取得に失敗した(システムの索引で取れない)" >&2; exit 4; }
    update_user_index
    (cd "$tmp" && apt-get "${apt_opts[@]}" download $packages >&2)
  fi
  mkdir -p "$dir"
  for deb in "$tmp"/*.deb; do dpkg-deb -x "$deb" "$dir"; done
  rm -f "$tmp"/*.deb
done

still="$(missing)"
if [ -n "$still" ]; then
  echo "補っても見つからない共有ライブラリ: $(echo "$still" | tr '\n' ' ')" >&2
  exit 4
fi
echo "$lib"
