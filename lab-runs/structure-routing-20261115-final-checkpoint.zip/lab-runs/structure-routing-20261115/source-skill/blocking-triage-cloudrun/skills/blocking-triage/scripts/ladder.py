# /// script
# requires-python = ">=3.10,<3.14"
# dependencies = ["curl_cffi"]
# ///
"""拒否された URL を、弱い条件から順に試し、最初に通ったステップで止める。

資料の切り分けの番号(① 回線、② curl_cffi、③ ブラウザ、④ 遷移)を、導入コストの低い順に並べ直したもの。
クライアントを替える(②③)のが先で、回線を替える(①)のはその後。④は、ステップ 5 まで全部通らなかったときに、
経路をもらって試す(任意)。

  ステップ 0  拒否の確認  client_proxy  素の curl(--client axios なら Axios、--client basic なら Basic。qcv3 のある環境だけ)
  ステップ 1  ②          client_proxy  curl_cffi
  ステップ 2  ③          client_proxy  nodriver で開いた Google Chrome(ヘッドフル)。開けなければ、トップページを経由して同じように試す
  ステップ 3  ①          residential   素の curl(ステップ 0 と同じクライアント)
  ステップ 4  ②          residential   curl_cffi
  ステップ 5  ③          residential   nodriver で開いた Google Chrome。開けなければ、トップページを経由して同じように試す
  ステップ 6  ④(任意)    residential   経路を辿る(手 A〜C)。--route-pages か --route-file のとき。
                                 --with-client-proxy なら、先に client_proxy でも試す(ユーザーに聞いて、やるときだけ)

経路を渡しても、先にステップ 0〜5 を回し、全部通らなかったときだけステップ 6 で経路を辿る(run_with_route)。
ステップ 0〜5 を済ませたあとで経路をもらったときは、--route-only でステップ 6 だけを行う。

- どのステップも、2 回続けて拒否されたら次のステップへ進む。一度でも通ったら計 3 回まで試し、全部通れば「一貫」、割れたら「ばらつく」
  (どちらもそのステップで止める)
- 回線につながらない(接続エラーで、ipinfo.io にも届かない)か 429 なら、そのステップで止める
- レジデンシャルの回線がなければ(egress.py の choose_residential)、ステップ 2 で止めて手配を依頼する
- ブラウザを起動できなかった(画面がない、コンテナがない)ステップは、未確認として次のステップへ進む

ステップの実行は probe.py(ステップ 0・1・3・4)と browser_run.py(ステップ 2・5・6)をそのまま使う。結果は probe.py と同じ
temp/blocking-triage/history.jsonl に残り、「前回」の列に出る。

使い方:
  uv run ladder.py --url https://example.com/x                  # ステップ 0〜5(数分かかる。ブラウザのステップは直前のアクセスから 60 秒待つ)
  uv run ladder.py --url https://example.com/x --client axios   # ステップ 0・3 を qcv3 の Axios にする(本番のクライアントで確かめる。qcv3 のある環境だけ)
  uv run ladder.py --url https://example.com/x --client basic   # ステップ 0・3 を qcv3 の Basic にする
  uv run ladder.py --url https://example.com/x --route-pages=https://example.com/,https://example.com/list   # ステップ 0〜5、全滅ならステップ 6
  uv run ladder.py --url https://example.com/x --route-file=../../../../temp/route-<サイト名>.json   # 同上(パーサーから作った経路)
  uv run ladder.py --url https://example.com/x --route-pages=https://example.com/ --route-only   # ステップ 0〜5 を済ませたあとのステップ 6
"""

from __future__ import annotations

import argparse
import os
import json
import re
import subprocess
import sys
from collections.abc import Callable, Mapping
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

import probe
from egress import asn_of, mask_proxy
from route_summary import summarize_browser_probe, summarize_route
from routes_store import (
    RoutesFileError,
    find_saved_route,
    load_routes,
    record_route,
    routes_path,
    saved_route_notes,
    saved_route_pages,
)
from state import (
    append_history,
    attach_previous,
    history_records,
    load_history,
    record_browser,
    state_dir,
    touch_last_request,
)

STEPS = (
    {"n": 0, "doc": "拒否の確認", "line": "client_proxy", "client": "axios"},
    {"n": 1, "doc": "②", "line": "client_proxy", "client": "curl_cffi"},
    {"n": 2, "doc": "③", "line": "client_proxy", "client": "browser"},
    {"n": 3, "doc": "①", "line": "residential", "client": "axios"},
    {"n": 4, "doc": "②", "line": "residential", "client": "curl_cffi"},
    {"n": 5, "doc": "③", "line": "residential", "client": "browser"},
)
PASS_TRIES = 3  # 通過と判定するまでの回数(割れたら、そのステップで止める)
FAIL_TRIES = 2  # 拒否と判定するまでの、続けて拒否された回数
RUN_BROWSER = Path(__file__).with_name("browser_run.py")
ROUTE_MODES = "location,click,warmup_location"  # 目的ページを直接開く手(direct)は、ステップ 2・5 で済んでいる


def run_ladder(lines: Mapping[str, dict | None], run_step: Callable[[dict, dict], dict], via_top: bool = True) -> dict:
    """ステップ 0〜5 を順に試し、最初に通ったステップで止める(純関数。ステップの実行は run_step に任せる)。

    run_step(step, line) は {"result": "pass" | "fail" | "error" | "rate_limited" | "unavailable", ...} を返す。
    どのステップも、2 回続けて拒否されたら拒否、3 回とも通れば通過、割れたらそのステップで止める(_try_until_judged)。
    ブラウザのステップは、直接開いて拒否されたら、step に "via_top": True を付けて同じように試す。トップページを開いてから
    目的ページへ移らせる(Referer やトップで得る cookie を見るサイトがある)。目的ページがトップなら(via_top=False)、
    直接開くだけにする。
    """
    records: list[dict] = []
    unchecked: list[int] = []
    for step in [s for s in STEPS if s["client"] == "browser"] if os.environ.get("BT_ONLY_BROWSER") else STEPS:
        line = lines[step["line"]]
        if line is None:
            return _ladder(records, unchecked, "no_residential", stopped_at=step["n"])
        variants = [step, {**step, "via_top": True}] if step["client"] == "browser" and via_top else [step]
        outcomes: list[dict] = []
        for variant in variants:
            tried = [{**o, "via_top": bool(variant.get("via_top"))} for o in _try_until_judged(run_step, variant, line)]
            outcomes += tried
            if any(o["result"] == "pass" for o in tried) or tried[-1]["result"] != "fail":
                break
        first = next((i for i, o in enumerate(outcomes) if o["result"] == "pass"), None)
        cut = len(outcomes) if first is None else first + 1
        records.append({"step": step, "line": line, "outcomes": outcomes[:cut], "confirm": outcomes[cut:]})
        if first is not None:
            # 確かめは、通ったときと同じ条件(トップページを経由したか)で行う。条件の違う試行は、割合に数えない
            passed_via_top = outcomes[first]["via_top"]
            tried = [o["result"] for o in outcomes if o["result"] in ("pass", "fail") and o["via_top"] == passed_via_top]
            passes = tried.count("pass")
            stopped = "not_reproduced" if step["n"] == 0 else "passed"
            return {
                **_ladder(records, unchecked, stopped, stopped_at=step["n"]),
                "first_pass": None if step["n"] == 0 else step["n"],
                "passes": passes,
                "tries": len(tried),
                "consistent": passes == len(tried) == PASS_TRIES,
                "via_top": passed_via_top,
                "headers_check": _check_chrome_headers(step, line, run_step) if step["client"] == "curl_cffi" else None,
            }
        last = outcomes[-1]["result"]
        if last in ("error", "rate_limited"):
            return _ladder(records, unchecked, last, stopped_at=step["n"])
        if last == "unavailable":
            unchecked.append(step["n"])
    return _ladder(records, unchecked, "all_failed", stopped_at=None)


def _try_until_judged(run_step: Callable[[dict, dict], dict], step: dict, line: dict) -> list[dict]:
    """1 つの条件を、判定がつくまで試す。2 回続けて拒否されたら拒否。一度でも通ったら、計 3 回まで試す(割れを拾う)。

    回線の障害・429・ブラウザを起動できなかったときは、そこで止める。
    """
    outcomes: list[dict] = []
    while True:
        outcomes.append(run_step(step, line))
        results = [o["result"] for o in outcomes]
        if results[-1] not in ("pass", "fail"):
            return outcomes
        if len(results) >= (PASS_TRIES if "pass" in results else FAIL_TRIES):
            return outcomes


def _check_chrome_headers(step: dict, line: dict, run_step: Callable[[dict, dict], dict]) -> dict:
    """Chrome をまねた接続で通ったとき、同じ回線で、Chrome のヘッダー一式を付けた Axios を試す。

    通れば、ヘッダーをそろえるだけで、ブラウザなしで通る(qcv3 の AxiosClient は axiosOptions.headers で付けられる)。
    """
    outcomes = _try_until_judged(run_step, {**step, "client": "axios", "chrome_headers": True}, line)
    tried = [o["result"] for o in outcomes if o["result"] in ("pass", "fail")]
    passes = tried.count("pass")
    if passes == len(tried) == PASS_TRIES:
        result = "pass"
    elif passes == 0 and len(tried) >= FAIL_TRIES:
        result = "fail"
    elif len(tried) == PASS_TRIES:
        result = "split"
    else:
        result = "unchecked"  # 送れなかったか、判定がつく前に止まった
    return {"outcomes": outcomes, "result": result, "passes": passes, "tries": len(tried)}


def _ladder(records: list[dict], unchecked: list[int], stopped: str, stopped_at: int | None) -> dict:
    return {"records": records, "unchecked": unchecked, "stopped": stopped, "stopped_at": stopped_at,
            "first_pass": None, "passes": None, "tries": None, "consistent": None, "via_top": False, "headers_check": None}  # fmt: skip


# 最初に通ったステップ → 原因の層と、診断が求めるもの(クライアントと回線)。求めるものは環境に依存しない書き方にする。
# 環境にあるどのクライアント・ブラウザ・ベースイメージで満たすか(推奨構成)は、references/environment.md から選ぶ(SKILL.md の手順 6)
_CHROME_LIKE = "Chrome と同じ接続の作り方(ブラウザ系。ブラウザで通るかは未確認)"
_BROWSER = "JS を実行するブラウザ"
# ブラウザの要否は、環境の構成ファイルがなくても書く。通ったのは、診断で使った Google Chrome の安定版。
# 最新版とは限らないので、版は結果の user_agent から取って書き(chrome_need)、これより古い版と Chromium で通るかは未確認とする
_BROWSER_CHROME = "__chrome__"
_BROWSER_NONE = "不要(ブラウザなしで通った)"
_BROWSER_MAYBE = "ブラウザ系が要る見込み(ブラウザで通るかは未確認)"
_READINGS = {
    1: ("接続の作り方(TLS/HTTP2)か、ヘッダー一式", _CHROME_LIKE, _BROWSER_MAYBE, "client_proxy"),
    2: ("JS の判定", _BROWSER, _BROWSER_CHROME, "client_proxy"),
    3: ("回線(IP/ASN)", None, _BROWSER_NONE, "residential"),
    4: ("回線(IP/ASN)と、接続の作り方(TLS/HTTP2)かヘッダー一式", _CHROME_LIKE, _BROWSER_MAYBE, "residential"),
    5: ("回線(IP/ASN)と JS の判定", _BROWSER, _BROWSER_CHROME, "residential"),
}
# ステップ 1・4 で、Chrome のヘッダー一式を付けた Axios が通った / 通らなかったときの原因の層
_HEADERS_LAYERS = {
    1: {"pass": "ヘッダー一式(接続の作り方は Chrome でなくても通る)", "fail": "接続の作り方(TLS/HTTP2)。ヘッダー一式をそろえるだけでは通らない"},
    4: {"pass": "回線(IP/ASN)と、ヘッダー一式", "fail": "回線(IP/ASN)と、接続の作り方(TLS/HTTP2)。ヘッダー一式をそろえるだけでは通らない"},
}
_HEADERS_NOTE = (
    "Chrome のヘッダー一式は、Chrome 155 が送る 13 個を同じ順序で付けたもの。accept-encoding だけは zstd を外している。"
    "一覧は references/environment.md"
)
# ステップ 2・5 で、トップページを経由したときだけ開けた。経由すると Referer・トップの cookie・ページ内からの遷移がそろうので、
# どれが効いたかは分からない。curl_cffi に Referer を付けて試していないので、JS の判定が要るかも分からない
_VIA_TOP_READINGS = {
    2: "遷移の条件(トップページを経由すること)。JS の判定も要るかは未確認",
    5: "回線(IP/ASN)と、遷移の条件(トップページを経由すること)。JS の判定も要るかは未確認",
}
# ブラウザで開けたときの確認の限界。診断のブラウザは、本番のブラウザと起動条件が違う(本番の既定は references/environment.md)
_BROWSER_NOTE = (
    "診断のブラウザは Google Chrome の安定版で、WebGL を有効にして開いた(--enable-unsafe-swiftshader)。"
    "本番のブラウザは起動条件が違うので、同じ結果になるとは限らない(違いは references/environment.md)"
)
_ROUTE_REQUEST = (
    "サイト内の経路を辿って開けるかを確かめる。人が目的ページに着くまでに通るページの URL(例: トップ → 一覧)か、"
    "パーサーのパスと、データセンターの回線でも試すかを、ユーザーに教えてもらう"
)


# 読みの文はチャットにそのまま写されるので、ステップの番号や手の名前ではなく、回線とクライアントで書く(SKILL.md の手順 6 の対応表)
LINE_LABELS = {"client_proxy": "データセンターの回線", "residential": "レジデンシャルの回線"}
CLIENT_LABELS = {"curl": "素の curl", "axios": "Axios と同じ接続", "basic": "Basic と同じ接続", "curl_cffi": "Chrome をまねた接続", "browser": "ブラウザ(nodriver)"}
# ヘッダー一式を付けた確認の、読みに書くクライアント名(Basic のときも Axios で送る)
_HEADERS_CLIENT_NAMES = {"curl": "curl", "axios": "Axios", "basic": "Axios"}
# 診断が求めるクライアント(環境に依存しない書き方)。既定の基準は素の curl で、本番の Axios・Basic とは接続の作り方が違う
_PLAIN = "Chrome をまねない素のクライアント"
_PLAIN_WITH_HEADERS = "素のクライアント(Chrome のヘッダー一式を付ける)"
_PRODUCTION_UNCONFIRMED_NOTE = (
    "基準は素の curl(HTTP/2、TLS は OpenSSL)。本番のクライアントは HTTP/1.1 で、TLS は Node が作る。同じ結果になるかは未確認。"
    "本番への当てはめは references/environment.md"
)
_CHECK_WITH_AXIOS = "本番のクライアントで確かめる: qcv3 のある環境で --client axios を付けて、同じ確認をやり直す"


def step_label(n: int, node_client: str = "curl") -> str:
    step = STEPS[n]
    client = node_client if step["client"] == "axios" else step["client"]
    return f"{LINE_LABELS[step['line']]}・{CLIENT_LABELS[client]}"


def _line_config(name: str, lines: Mapping[str, dict | None]) -> str:
    # どの回線で確かめたか(プロキシの host、手元の回線で代用したこと)は、出力の「診断の条件」に 1 回だけ書く
    if name == "client_proxy":
        return "今のデータセンターの回線のまま"
    if lines["residential"]["substitute"]:
        return "レジデンシャルのプロキシ(手配を依頼する)"
    return "レジデンシャルのプロキシ(診断で使った RESIDENTIAL_PROXY)"


def _auth_notes(lines: Mapping[str, dict | None], used: set[str]) -> list[str]:
    """認証つきのプロキシを、本番のクライアントが通せるかは references/environment.md。診断では認証を足して送っている(node_axios.mjs)"""
    notes = []
    for name in sorted(used):
        line = lines.get(name)
        if line and line["proxy"] and urlsplit(line["proxy"]).username:
            notes.append(
                f"{LINE_LABELS[name]}のプロキシは認証つき。診断では認証を足して送った。"
                "本番のクライアントが認証を通せるかは、references/environment.md を確かめる"
            )
    return notes


def _substitute_note(lines: Mapping[str, dict | None], used: set[str]) -> list[str]:
    if "residential" in used and (lines.get("residential") or {}).get("substitute"):
        return ["レジデンシャルの回線は、手元の回線で代用した。家庭用・会社の ISP 回線は、レジデンシャルのプロキシと同じ扱いを受けるとは限らない"]
    return []


def _confidence(consistent: bool, downgrade: bool) -> str:
    if not consistent:
        return "低"
    return "中" if downgrade else "高"


def chrome_version(records: list[dict]) -> str | None:
    """通ったブラウザの結果の user_agent から、診断で使った Chrome の主版を取る。取れなければ None。"""
    for rec in records:
        for o in [*rec["outcomes"], *rec.get("confirm", [])]:
            m = re.search(r"Chrome/(\d+)", (o.get("summary") or {}).get("user_agent") or "")
            if m and o.get("result") == "pass":
                return m.group(1)
    return None


def _route_chrome_version(outcome: dict) -> str | None:
    m = re.search(r"Chrome/(\d+)", (outcome.get("route") or {}).get("user_agent") or "")
    return m.group(1) if m else None


def chrome_need(version: str | None) -> str:
    used = f"Chrome {version}" if version else "安定版(版は取れなかった)"
    return f"Google Chrome(診断で通ったのは{used}。最新版とは限らない。これより古い版と Chromium で通るかは未確認)"


_NO_NEEDS_REASONS = {
    "not_reproduced": "ブロッキング要因が確認できなかったため",
    "all_failed": "どの条件でも通らなかったため",
    "no_residential": "レジデンシャルの回線がなく、確かめられなかったため",
    "error": "回線につながらず、診断できなかったため",
    "rate_limited": "429 が返って止まり、診断できなかったため",
}


def read_ladder(ladder: dict, lines: Mapping[str, dict | None], node_client: str = "curl") -> dict:
    """ステップの結果から、原因の層・確度・qcv3 の推奨構成・次の一手を引く(純関数)。"""
    stopped, n = ladder["stopped"], ladder["first_pass"]
    used = {r["line"]["line"] for r in ladder["records"]}
    notes = _auth_notes(lines, used)
    substituted = "residential" in used and bool((lines.get("residential") or {}).get("substitute"))
    notes += _substitute_note(lines, used)
    if ladder["unchecked"]:
        labels = "、".join(step_label(u, node_client) for u in ladder["unchecked"])
        notes.append(f"{labels}は、ブラウザを起動できず未確認")
    if not ladder.get("consistent", True) and ladder["passes"] is not None:
        notes.append(f"通ったステップの結果がばらつく({ladder['tries']} 回中 {ladder['passes']} 回通過)")
    # 診断が求めるものを出せないときの理由(求めるものが null のとき、何と書くか)
    base = {"stopped": stopped, "first_pass": n, "notes": notes, "no_needs_reason": _NO_NEEDS_REASONS.get(stopped)}

    if stopped == "passed":
        layer, client, browser, line_name = _READINGS[n]
        client = client or {"curl": _PLAIN, "basic": "Basic のまま"}.get(node_client, "Axios のまま")
        headers_client = _HEADERS_CLIENT_NAMES[node_client]
        followups: list[str] = []
        if ladder.get("via_top"):
            layer, client = _VIA_TOP_READINGS[n], f"{_BROWSER}(トップページを開いてから、location.href で移る)"
            browser = _BROWSER_CHROME
            notes.append(f"トップページを経由せずに開けなかったのは {FAIL_TRIES} 回(それ以上試すと結果がばらつくかは確かめていない)")
        if STEPS[n]["client"] == "browser":
            notes.append(_BROWSER_NOTE)
        consistent = ladder["consistent"]
        headers = ladder.get("headers_check")
        if headers and headers["result"] == "pass":
            layer = _HEADERS_LAYERS[n]["pass"]
            client = _PLAIN_WITH_HEADERS if node_client == "curl" else "Axios(Chrome のヘッダー一式を付ける)"
            browser = f"不要(ヘッダー一式を付けた{'素のクライアント' if node_client == 'curl' else 'Axios'}で通った)"
            notes.append(_HEADERS_NOTE)
        elif headers and headers["result"] == "fail":
            layer = _HEADERS_LAYERS[n]["fail"]
        elif headers and headers["result"] == "split":
            notes.append(f"Chrome のヘッダー一式を付けた {headers_client} は、{headers['tries']} 回中 {headers['passes']} 回通過(ばらつく)")
        elif headers:
            why = {"error": "回線につながらず、", "rate_limited": "429 が返って、"}.get(headers["outcomes"][-1]["result"], "")
            notes.append(f"Chrome のヘッダー一式を付けた {headers_client} は、{why}確かめられなかった")
        if client in (_PLAIN, _PLAIN_WITH_HEADERS):  # 素の curl で通ったので、本番のクライアントで通るかは確かめていない
            notes.append(_PRODUCTION_UNCONFIRMED_NOTE)
        downgrade = bool(ladder["unchecked"]) or (line_name == "residential" and substituted)
        if browser == _BROWSER_CHROME:
            browser = chrome_need(chrome_version(ladder["records"]))
        return {**base, "layer": layer, "confidence": _confidence(consistent, downgrade),
                "needs": {"client": client, "browser": browser, "line": _line_config(line_name, lines)},
                "next": followups}  # fmt: skip
    if stopped == "not_reproduced":
        followups = ["拒否が出た時刻と頻度を確かめる(アクセスが重なったときだけ拒否される、429 の後だけ、など)"]
        if node_client == "curl":  # 本番の Axios・Basic だけが拒否される場合を、ブロッキングなしと言い切らない
            notes.append(_PRODUCTION_UNCONFIRMED_NOTE)
            followups.append(_CHECK_WITH_AXIOS)
        return {**base, "layer": "なし(拒否が再現しない)", "confidence": _confidence(ladder["consistent"], False), "needs": None,
                "next": followups}  # fmt: skip
    if stopped == "no_residential":
        return {**base, "layer": "回線(IP/ASN)が候補(レジデンシャルでは未確認)", "confidence": "低", "needs": None,
                "next": ["レジデンシャルのプロキシの手配を依頼し、RESIDENTIAL_PROXY を設定して、レジデンシャルの回線での確認を回す",
                         "手元が家庭用・ISP の回線なら、--direct-as-residential で代用して、レジデンシャルの回線での確認を回す", _ROUTE_REQUEST]}  # fmt: skip
    if stopped == "all_failed":
        return {**base, "layer": "遷移の条件か操作データが候補(未確認)", "confidence": "低", "needs": None,
                "next": [_ROUTE_REQUEST, "人の Chrome(human_check.js)での確認"]}  # fmt: skip
    at = ladder["stopped_at"]
    if stopped == "rate_limited":
        return {**base, "layer": None, "confidence": None, "needs": None,
                "next": [f"{step_label(at, node_client)}で 429 が返った。間隔を空けてやり直す"]}  # fmt: skip
    return {**base, "layer": None, "confidence": None, "needs": None,
            "next": [f"{step_label(at, node_client)}の確認で、回線につながらない。VPN・プロキシを確かめてからやり直す"]}  # fmt: skip


def run_route_ladder(lines: Mapping[str, dict | None], run_route: Callable[[dict], dict], with_client_proxy: bool = False) -> dict:
    """ステップ 6(④): レジデンシャルの回線で経路を辿る(純関数)。

    ステップ 6 は joshinweb.jp のような厳しいサイトが前提で、データセンターの回線ではトップから拒否されることが多い。
    データセンターでも試すのは with_client_proxy のときだけ(ユーザーに聞いて、やると言ったとき)。そのときは
    データセンター → レジデンシャルの順に試し、最初に通った回線で止める。
    """
    records = []
    for name in ("client_proxy", "residential") if with_client_proxy else ("residential",):
        line = lines[name]
        if line is None:
            records.append({"line": None, "name": name, "outcome": {"result": "skipped"}})
            continue
        outcome = run_route(line)
        records.append({"line": line, "name": name, "outcome": outcome})
        if outcome["result"] in ("pass", "error", "rate_limited"):
            break
    passed = next((r for r in records if r["outcome"]["result"] == "pass"), None)
    return {"records": records, "first_pass_line": passed["name"] if passed else None}


def read_route(route: dict, lines: Mapping[str, dict | None]) -> dict:
    name = route["first_pass_line"]
    if name is None:
        # 回線がない(skipped)か、ブラウザを起動できなかった(unavailable)回線は、経路を辿っていない
        untried = {r["name"]: r["outcome"]["result"] for r in route["records"] if r["outcome"]["result"] in ("skipped", "unavailable")}
        notes = [f"{LINE_LABELS[n]}は、{'回線がなく' if why == 'skipped' else 'ブラウザを起動できず'}未実施" for n, why in untried.items()]
        if len(untried) == len(route["records"]) and "unavailable" in untried.values():
            return {"layer": None, "confidence": None, "needs": None, "no_needs_reason": "ブラウザを起動できず、経路遷移のテストが行えなかったため",
                    "notes": notes,
                    "next": ["ブラウザを起動できない理由(画面がない、コンテナがない、待ち時間を過ぎた)を取り除き、--route-only で経路を辿る確認をやり直す"]}  # fmt: skip
        if len(untried) == len(route["records"]):
            return {"layer": None, "confidence": None, "needs": None, "no_needs_reason": "レジデンシャルの回線がなく、経路遷移のテストが行えなかったため",
                    "notes": ["レジデンシャルの回線がなく、経路を辿る確認は未実施"],
                    "next": ["レジデンシャルのプロキシの手配を依頼する(手元が家庭用・ISP の回線なら --direct-as-residential で代用できる)",
                             "データセンター(CLIENT_PROXY)で試すかをユーザーに聞き、試すなら --with-client-proxy を付ける"]}  # fmt: skip
        outdated = [LINE_LABELS[r["name"]] for r in route["records"] if r["outcome"].get("route_outdated")]
        if outdated:  # 経路の途中のページが 404。拒否ではないので、操作データなどは疑わない
            return {"layer": None, "confidence": None, "needs": None,
                    "no_needs_reason": "保存した経路の途中のページが 404 で、経路遷移のテストが成立しなかったため",
                    "notes": [*notes, f"{'・'.join(outdated)}では、経路の途中のページが「ページが見つかりません」(404)だった。保存した経路が古い可能性が高い"],
                    "next": ["今のサイトで、人が目的ページに着くまでに通るページの URL(トップ → カテゴリ → 一覧など)を教えてもらい、経路を作り直して確認する"]}  # fmt: skip
        return {"layer": "操作データか、ブラウザの版・種類が候補(未確認)", "confidence": "低", "needs": None,
                "no_needs_reason": "経路に従って遷移してもブロッキング回避できなかったため",
                "notes": notes,
                "next": ["--escalate で、クリックに操作(滞在 → スクロール → マウス移動)を足す"]}
    outcome = next(r["outcome"] for r in route["records"] if r["name"] == name)
    layer = "遷移の条件" if name == "client_proxy" else "回線(IP/ASN)と遷移の条件"
    return {"layer": layer, "confidence": "中", "no_needs_reason": None,
            "needs": {"client": f"{_BROWSER}({outcome.get('how', '経路を辿る')})", "browser": chrome_need(_route_chrome_version(outcome)),
                      "line": _line_config(name, lines)},
            "notes": _auth_notes(lines, {name}) + _substitute_note(lines, {name}) + [_BROWSER_NOTE],
            "next": []}  # fmt: skip


def run_with_route(
    lines: Mapping[str, dict | None],
    run_step: Callable[[dict, dict], dict],
    run_route: Callable[[dict], dict],
    via_top: bool = True,
    with_client_proxy: bool = False,
) -> dict:
    """経路をもらっていても、先にステップ 0〜5 を回す(純関数)。全部通らなかったとき(レジデンシャルの回線がなく、
    ステップ 2 で止まったときも含む)だけ、経路を辿る。途中で通ったときや、回線の障害・429 で止まったときは辿らない。
    """
    ladder = run_ladder(lines, run_step, via_top)
    if ladder["stopped"] not in ("all_failed", "no_residential"):
        return {"ladder": ladder, "route": None}
    return {"ladder": ladder, "route": run_route_ladder(lines, run_route, with_client_proxy)}


# ---- ここから下は、ステップを実際に送る部分(probe.py と browser_run.py を呼ぶ)


class Lines(dict):
    """回線を、初めて使うときに決める(レジデンシャルの確認は、ステップ 3 まで進んだときだけ ipinfo.io へ送る)。"""

    def __init__(self, proxies: dict, force_direct: bool):
        super().__init__()
        self.proxies, self.force_direct = proxies, force_direct

    def __missing__(self, name: str) -> dict | None:
        line = probe.build_line(name, self.proxies, self.force_direct)
        self[name] = line
        return line


def _asn(line: dict) -> str | None:
    """履歴で回線を見分ける ASN。回線を確かめたときの ipinfo.io の結果から取る(ローテーションするプロキシでは目安)。"""
    return asn_of((line.get("info") or {}).get("org"))


def _line_down(line: dict) -> bool:
    """回線そのものにつながらないか(サイトが応答しないのとは別)。ipinfo.io に届くかで見る。"""
    return bool(probe.egress_info([(line["egress"], line["proxy"])])[0].get("error"))


def top_page(url: str | None) -> str | None:
    """ステップ 2・5 の 2 回目で経由するトップページ(オリジン + /)。目的ページがトップなら None。"""
    if not url:
        return None
    u = urlsplit(url)
    if u.path in ("", "/") and not u.query:
        return None
    return f"{u.scheme}://{u.netloc.rsplit('@', 1)[-1]}/"


class StepRunner:
    def __init__(self, url: str, args: argparse.Namespace, saved_route_pages: list[str] | None = None):
        self.url, self.args = url, args
        self.saved_route_pages = saved_route_pages  # 保存済みの経路を使うとき、目的ページを除くページ
        self.top = top_page(url)
        self.history = state_dir() / "history.jsonl"

    def __call__(self, step: dict, line: dict) -> dict:
        if step["client"] == "browser":
            return self._browser_via_top(line) if step.get("via_top") else self._browser(line)
        return self._request(step, line)

    def _request(self, step: dict, line: dict) -> dict:
        if step.get("chrome_headers"):
            # 既定(curl)は curl で送る。--client basic のときは Axios で送る(Basic の request は gzip: true がないと、圧縮された本文を展開しない)
            client = "curl_chrome_headers" if self.args.client == "curl" else "axios_chrome_headers"
            plan = [{"egress": line["egress"], "proxy": line["proxy"], "client": client}]
        else:
            client = self.args.client if step["client"] == "axios" else "curl_cffi"
            plan = [r for r in probe.plan_requests([(line["egress"], line["proxy"])], node_client=self.args.client) if r["client"] == client]
        [row] = probe.probe(self.url, plan, self.args.user_agent, interval=probe.INTERVAL_SEC)
        if not self.args.no_history:
            [row] = attach_previous([row], self.url, load_history(self.history), asn=_asn(line))
            at = datetime.now().astimezone().isoformat(timespec="seconds")
            append_history(self.history, history_records(self.url, [row], at=at, asn=_asn(line)))
            touch_last_request(state_dir(), self.url)
        if not row["ok"]:
            # サイトが接続を切った・応答しないのも拒否のうち。回線そのものが落ちているときだけ止める
            return {"result": "error" if _line_down(line) else "fail", "row": row}
        result = {"ok": "pass", "rate_limited": "rate_limited"}.get(row["kind"], "fail")
        return {"result": result, "row": row}

    def _run_browser(self, *argv: str) -> tuple[int, dict | None, str]:
        p = subprocess.run([sys.executable, str(RUN_BROWSER), *argv], check=False, capture_output=True, text=True, timeout=1200)
        try:
            d = json.loads(p.stdout) if p.stdout.strip() else None
        except json.JSONDecodeError:
            d = None
        return p.returncode, d, probe.redact(p.stderr.strip()[-400:], probe._PROXY_URLS)

    def _line_args(self, line: dict) -> list[str]:
        _match_line_locale(line)
        return [f"--line={line['egress']}", *([f"--proxy={line['proxy']}"] if line["proxy"] else [])]

    def _browser(self, line: dict) -> dict:
        code, d, err = self._run_browser(self.url, *self._line_args(line))
        if d is None:  # 4: 待ち時間を過ぎた(画面がなく起動できないことが多い)
            return {"result": "unavailable", "error": err or f"exit {code}"}
        summary = summarize_browser_probe(d)
        if not self.args.no_history:
            prev = record_browser(self.history, d, summary, asn=_asn(line))
            kind = summary.get("kind") if summary.get("ok") else "error"
            summary = {**summary, "previous": prev, "changed": None if prev is None else prev["kind"] != kind}
        if not summary.get("ok"):
            proxy_failed = re.search(r"ERR_PROXY|ERR_TUNNEL|ERR_NO_SUPPORTED_PROXIES", summary.get("error") or "")
            return {"result": "error" if proxy_failed and _line_down(line) else "fail", "summary": summary}
        return {"result": "pass" if summary.get("kind") == "ok" else "fail", "summary": summary}

    def _browser_via_top(self, line: dict) -> dict:
        """トップページを開き、ページ内の JS(location.href)で目的ページへ移る。ステップ 6 の手 A を 1 回だけ使う。

        goto に Referer を渡すだけだと、Sec-Fetch-Site が none のまま届く(2026-10-21、tls.peet.ws で確認)。
        location.href で移ると、Referer・Sec-Fetch-Site: same-origin・トップの cookie がそろう。
        """
        argv = ("--route", self.url, f"--route-pages={self.top}", "--modes=location", "--repeat=1", *self._line_args(line))
        code, d, err = self._run_browser(*argv)
        if d is None:
            return {"result": "unavailable", "error": err or f"exit {code}"}
        route = summarize_route(d)
        trial = ((route["modes"] or [{}])[0].get("trials") or [None])[0]
        if not trial or not trial["pages"]:
            return {"result": "fail", "summary": {"ok": False, "error": (trial or {}).get("error") or route["reading"]}}
        page = trial["pages"][-1]  # トップで拒否されたら、トップのページ
        summary = {"ok": True, "status": page["status"], "kind": page["class"], "vendors": page["vendors"], "user_agent": route["user_agent"],
                   "title": page["title"] if page["kind"] == "target" else f"(トップで止まった) {page['title'] or ''}"}  # fmt: skip
        return {"result": "pass" if route["first_passing_mode"] == "location" else "fail", "summary": summary, "route": route}

    def route(self, line: dict) -> dict:
        """ステップ 6 の 1 回線分。手 A〜C をブラウザで試し、経路を辿る。"""
        a = self.args
        pages = self.saved_route_pages or a.route_pages
        route = [f"--route-pages={','.join(pages)}"] if pages else [f"--route-file={a.route_file}"]
        target = [self.url] if self.url else []
        code, d, err = self._run_browser("--route", *target, *route, f"--modes={ROUTE_MODES}", *self._line_args(line))
        if d is None:
            return {"result": "unavailable", "error": err or f"exit {code}"}
        summary = summarize_route(d)
        mode, humanize = summary["first_passing_mode"], summary["first_passing_humanize"]
        if not mode:
            return {"result": "fail", "route": summary, "reading": summary["reading"], "route_outdated": summary["route_outdated"]}
        how = _ROUTE_HOW[mode] if humanize in (None, "none") else f"操作({humanize})を足してクリックで辿る"
        return {"result": "pass", "route": summary, "how": how, "reading": summary["reading"]}


# ステップ 6 で最初に通った手 → 推奨構成のクライアントの行に添える遷移
_ROUTE_HOW = {
    "direct": "目的ページを直接開く",
    "location": "手前のページから location.href で移る",
    "click": "リンクをクリックして辿る",
    "warmup_location": "最初のページで _abck が合格するまで操作してから、location.href で移る",
}


def _cell(o: dict) -> tuple[str, ...]:
    """表の 1 行分(status・種別・ベンダー・拒否ページ・タイトル・前回)。"""
    r = o.get("row") or o.get("summary")
    if o["result"] == "unavailable":
        return ("-", "未確認(起動できず)", "-", "-", o.get("error", "-")[:60], "-")
    if r is None or not r.get("ok", True) or r.get("kind") is None:
        return ("エラー", "-", "-", "-", (r or {}).get("error") or "-", probe._previous_cell(r or {}))
    return (str(r.get("status")), probe._kind_cell(r), probe._vendor_cell({"vendors": [], **r}), r.get("deny_signature") or "-",
            r.get("title") or "-", probe._previous_cell(r))  # fmt: skip


def ladder_table(url: str, ladder: dict, node_client: str) -> str:
    lines = [f"## {url}", "", "| ステップ | 資料 | 回線 | クライアント | 試行 | status | 種別 | ベンダー | 拒否ページ | タイトル | 前回 |",
             "|---|---|---|---|---|---|---|---|---|---|---|"]  # fmt: skip
    for rec in ladder["records"]:
        step, line = rec["step"], rec["line"]
        client = {"axios": node_client, "curl_cffi": "curl_cffi", "browser": "nodriver"}[step["client"]]
        via = lambda o: "(トップ経由)" if o.get("via_top") else ""
        tries = [(f"試行 {i}{via(o)}", o) for i, o in enumerate(rec["outcomes"], 1)]
        tries += [(f"確認 {i}{via(o)}", o) for i, o in enumerate(rec.get("confirm", []), 1)]
        rows = [(client, label, o) for label, o in tries]
        if rec is ladder["records"][-1] and ladder.get("headers_check"):  # 通ったステップ(Chrome をまねた接続)のあとに送った確認
            headers_client = "curl_chrome_headers" if node_client == "curl" else "axios_chrome_headers"
            rows += [(headers_client, "試行 1" if i == 0 else f"確認 {i}", o) for i, o in enumerate(ladder["headers_check"]["outcomes"])]
        for c, label, o in rows:
            lines.append(f"| {step['n']} | {step['doc']} | {LINE_LABELS[line['line']]} | {c} | {label} | " + " | ".join(_cell(o)) + " |")
    return "\n".join(lines)


LANG_BY_COUNTRY = {
    "JP": ("ja-JP", "ja,en-US,en"), "US": ("en-US", "en-US,en"), "GB": ("en-GB", "en-GB,en"),
    "KR": ("ko-KR", "ko,en-US,en"), "CN": ("zh-CN", "zh-CN,zh,en"), "TW": ("zh-TW", "zh-TW,zh,en"),
    "DE": ("de-DE", "de,en-US,en"), "FR": ("fr-FR", "fr,en-US,en"),
}


def _match_line_locale(line: dict) -> None:
    """BT_MATCH_LINE のとき、ブラウザのタイムゾーン・言語を、その回線の出口(ipinfo.io の国・タイムゾーン)に合わせる。

    回線の情報が取れていなければ、既定(ja・Asia/Tokyo)のまま開く。表にない国は en-US にする。
    """
    keys = ("BT_BROWSER_TZ", "BT_BROWSER_LOCALE", "BT_BROWSER_ACCEPT_LANG")
    info = line.get("info") or {}
    if not os.environ.get("BT_MATCH_LINE") or not info.get("country"):
        for k in keys:
            os.environ.pop(k, None)
        return
    locale, accept = LANG_BY_COUNTRY.get(info["country"], ("en-US", "en-US,en"))
    for k, v in zip(keys, (info.get("timezone"), locale, accept)):
        if v:
            os.environ[k] = v
        else:
            os.environ.pop(k, None)


def _strip(o: dict) -> dict:
    """JSON に残すとき、本文の先頭は落とす(判定は済んでいる)。"""
    out = dict(o)
    if out.get("row") and not os.environ.get("BT_KEEP_BODY"):
        out["row"] = {k: v for k, v in out["row"].items() if k != "body_head"}
    return out


def _public_line(line: dict | None) -> dict | None:
    return line and {**{k: v for k, v in line.items() if k != "proxy"}, "proxy": mask_proxy(line["proxy"])}


def _print_route(url: str | None, route: dict) -> None:
    print(f"## 経路を辿る確認: {url or '(計画ファイル)'}", file=sys.stderr)
    for r in route["records"]:
        print(f"- {LINE_LABELS[r['name']]}: {r['outcome']['result']}。{r['outcome'].get('reading', '')}", file=sys.stderr)


def _public_route(route: dict) -> dict:
    return {**route, "records": [{**r, "line": _public_line(r["line"]), "outcome": _strip(r["outcome"])} for r in route["records"]]}


def _public_ladder(ladder: dict) -> dict:
    records = [{"step": r["step"], "line": _public_line(r["line"]), "outcomes": [_strip(o) for o in r["outcomes"]],
                "confirm": [_strip(o) for o in r.get("confirm", [])]} for r in ladder["records"]]  # fmt: skip
    headers = ladder.get("headers_check")
    return {**ladder, "records": records, "headers_check": headers and {**headers, "outcomes": [_strip(o) for o in headers["outcomes"]]}}


def _save_route_results(saved_data: dict | None, route: dict, args: argparse.Namespace) -> None:
    """経路を辿る確認の結果を、経路ごとに references/routes.json へ足す(通った・全滅だけ。--no-history では残さない)。

    途中のページが 404 で、経路が古いと判定された結果は、拒否された経路の結果ではないので残さない。
    """
    if saved_data is None or args.no_history:
        return
    at = datetime.now().astimezone().date().isoformat()
    for rec in route["records"]:
        outcome = rec["outcome"]
        pages = (outcome.get("route") or {}).get("steps")
        if pages and not outcome.get("route_outdated"):
            record_route(routes_path(), pages, line=rec["name"], outcome=outcome["result"], how=outcome.get("how"), at=at)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", action="append", default=[], help="拒否された URL(複数指定可。数件まで)。経路を渡すときは目的ページ 1 つ")
    ap.add_argument("--client", choices=("curl", "axios", "basic"), default="curl", help="ステップ 0・3 のクライアント(既定 curl。axios・basic は qcv3 のある環境だけ)")
    ap.add_argument("--client-proxy", help="CLIENT_PROXY。省略すると、.env、なければ環境変数")
    ap.add_argument("--residential-proxy", help="レジデンシャルのプロキシ。省略すると、.env の RESIDENTIAL_PROXY、なければ環境変数")
    ap.add_argument("--direct-as-residential", action="store_true", help="kind_guess が isp でなくても、手元の回線でレジデンシャルを代用する(ユーザーが家庭用・ISP の回線だと言ったときだけ)")
    ap.add_argument("--no-env-proxy", action="store_true", help=".env と環境変数のプロキシを使わない")
    ap.add_argument("--user-agent", default=probe.CHROME_UA, help="curl・Axios・Basic の User-Agent(qcv3 の CLIENT_USER_AGENT にあたる)")
    ap.add_argument("--route-pages", type=lambda s: [u.strip() for u in s.split(",") if u.strip()], help="ステップ 6: 目的ページの手前に通るページ(カンマ区切り。目的ページと同じオリジン)。先にステップ 0〜5 を回し、全部通らなかったときだけ辿る")
    ap.add_argument("--route-file", help="ステップ 6: パーサーから作った経路の計画(references/route-plan.md)。--route-pages と同じく、先にステップ 0〜5 を回す")
    ap.add_argument("--route-only", action="store_true", help="ステップ 0〜5 を回さず、ステップ 6 だけを行う。ステップ 0〜5 を済ませたあとで経路をもらったときだけ使う")
    ap.add_argument("--with-client-proxy", action="store_true", help="ステップ 6 で、レジデンシャルの前に client_proxy(データセンター)でも試す。ユーザーに聞いて、やると言ったときだけ")
    ap.add_argument("--no-history", action="store_true", help="結果の履歴と、経路の結果(references/routes.json)を残さない")
    ap.add_argument("--no-saved-routes", action="store_true", help="全部のステップが通らなかったとき、保存済みの経路(references/routes.json)を使わない")
    args = ap.parse_args()
    if args.route_pages and args.route_file:
        ap.error("--route-pages と --route-file は、どちらか一方")
    route_mode = bool(args.route_pages or args.route_file)
    if args.route_only and not route_mode:
        ap.error("--route-only は、--route-pages か --route-file と一緒に使う")
    if not args.url and not (args.route_file and args.route_only):
        ap.error("--url が必要です(経路の計画ファイルだけで始めるのは、ステップ 0〜5 を済ませたあとの --route-only のときだけ)")
    if route_mode and len(args.url) > 1:
        ap.error("経路を渡すときの目的ページは 1 つ")
    if args.route_pages:
        # 別のサイトのページは経路に使えない(browser_route.py も弾く)。ステップ 0〜5 を回す前に止める
        origin = urlsplit(args.url[0])[:2]
        other = next((p for p in args.route_pages if urlsplit(p)[:2] != origin), None)
        if other:
            ap.error(f"経路には、目的ページと同じサイトの URL だけを指定できる: {other}")

    proxies = probe.resolve_proxies(args.client_proxy, args.residential_proxy, use_env=not args.no_env_proxy)
    lines = Lines(proxies, args.direct_as_residential)
    if not args.route_only or args.with_client_proxy:  # ステップ 6 だけなら、既定ではレジデンシャルだけで試す
        dc = lines["client_proxy"]
        if dc is None:
            ap.error(probe.NO_LINE["client_proxy"])
        if (dc.get("info") or {}).get("error"):
            print(f"client_proxy({mask_proxy(dc['proxy'])})につながらない。VPN・プロキシを確かめる: {dc['info']['error']}", file=sys.stderr)
            return 1

    results = []
    try:
        saved_data = load_routes(routes_path())
    except RoutesFileError as e:
        print(f"保存済みの経路は使わない・残さない: {e}", file=sys.stderr)
        saved_data = None
    for url in args.url or [None]:
        # 経路を渡されていないときは、同じサイトの保存済みの経路を使う(全部のステップが通らなかったときだけ辿る)
        saved_pages = saved_route_pages(saved_data, url, route_given=route_mode, use_saved=not args.no_saved_routes) if saved_data and url else None
        saved_route = find_saved_route(saved_data, url) if saved_pages else None
        runner = StepRunner(url, args, saved_pages)
        if args.route_only:
            route = run_route_ladder(lines, runner.route, with_client_proxy=args.with_client_proxy)
            reading = read_route(route, lines)
            _print_route(url, route)
            _save_route_results(saved_data, route, args)
            results.append({"url": url, "route": _public_route(route), "reading": reading})
        elif route_mode or saved_pages:
            out = run_with_route(lines, runner, runner.route, via_top=runner.top is not None, with_client_proxy=args.with_client_proxy)
            ladder_reading = read_ladder(out["ladder"], lines, node_client=args.client)
            print(ladder_table(url, out["ladder"], args.client), file=sys.stderr)
            if out["route"] is None:
                print("\n経路は辿っていない(ステップ 0〜5 で止まったため)", file=sys.stderr)
                reading = ladder_reading
            else:
                _print_route(url, out["route"])
                reading = read_route(out["route"], lines)
                if saved_route:
                    tried = out["route"]
                    reading["notes"] = [*reading["notes"], *saved_route_notes(saved_route, passed=tried["first_pass_line"] is not None,
                                                                              line=tried["first_pass_line"] or tried["records"][-1]["name"])]  # fmt: skip
                _save_route_results(saved_data, out["route"], args)
            results.append({"url": url, "ladder": _public_ladder(out["ladder"]), "ladder_reading": ladder_reading,
                            "saved_route_used": bool(saved_pages),
                            "route": out["route"] and _public_route(out["route"]), "reading": reading})  # fmt: skip
        else:
            ladder = run_ladder(lines, runner, via_top=runner.top is not None)
            reading = read_ladder(ladder, lines, node_client=args.client)
            print(ladder_table(url, ladder, args.client), file=sys.stderr)
            results.append({"url": url, "ladder": _public_ladder(ladder), "reading": reading})
        print(f"\n読み: {json.dumps(reading, ensure_ascii=False)}\n", file=sys.stderr)
    used_lines = {name: _public_line(line) for name, line in lines.items()}
    print(json.dumps({"lines": used_lines, "results": results}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
