"""classify.py のテスト。判定に要る最小限の応答の断片だけを使う。

実行: uv run --with pytest pytest .claude/skills/blocking-triage/scripts/tests
"""

import pytest

from classify import classify


def test_cloudflare_challenge_page():
    r = classify(
        status=403,
        headers={"server": "cloudflare", "cf-ray": "8a1b2c3d4e5f-NRT", "cf-mitigated": "challenge"},
        cookie_names=["__cf_bm"],
        body="<title>Just a moment...</title><script src='/cdn-cgi/challenge-platform/h/b'></script>",
    )
    assert r["vendors"] == ["cloudflare"]
    assert r["kind"] == "challenge"


def test_cloudflare_turnstile_checkbox():
    r = classify(
        status=403,
        headers={"server": "cloudflare", "cf-ray": "x"},
        cookie_names=[],
        body="<iframe src='https://challenges.cloudflare.com/cdn-cgi/challenge-platform/turnstile'>",
    )
    assert r["vendors"] == ["cloudflare"]
    assert r["kind"] == "turnstile"


def test_cloudflare_plain_403_is_blocked_not_challenge():
    r = classify(
        status=403,
        headers={"server": "cloudflare", "cf-ray": "x"},
        cookie_names=[],
        body="<title>Blocked - Indeed.com</title>",
    )
    assert r["vendors"] == ["cloudflare"]
    assert r["kind"] == "blocked"


def test_akamai_access_denied():
    # 実物(zozo.jp)では、URL が文字参照(&#46; など)で書かれている
    r = classify(
        status=403,
        headers={"server": "AkamaiGHost"},
        cookie_names=[],
        body="<TITLE>Access Denied</TITLE><H1>Access Denied</H1>"
        "Reference&#32;&#35;18&#46;543d3117&#46;1792067559&#46;55a6745\n"
        "<P>https&#58;&#47;&#47;errors&#46;edgesuite&#46;net&#47;18&#46;543d3117</P>",
    )
    assert r["vendors"] == ["akamai"]
    assert r["kind"] == "blocked"
    assert "body errors.edgesuite.net" in r["signals"]


def test_akamai_behavioral_challenge_returned_with_200_and_no_title_is_challenge():
    # zozo.jp をブラウザで開いたときの実物の断片。ブラウザの応答には server ヘッダーがない
    r = classify(
        status=200,
        headers={"content-type": "text/html"},
        cookie_names=["_abck", "ak_bmsc", "bm_sz"],
        body='<!DOCTYPE html><html><head></head><body><script type="text/javascript" '
        'src="/TBR2jNftS_FWbqUjMnmV/DcOu2p5NG7/dGscKF85/Dklue2E/UNQgU?v=89d8b8de"></script>\n'
        '<div id="sec-if-cpt-container" role="main" style="display: none">\n'
        '    <div class="behavioral-content">\n'
        '        <p class="scf-akamai-protected-by">Powered and protected by</p>',
    )
    assert r["vendors"] == ["akamai"]
    assert r["kind"] == "challenge"


def test_challenge_title_given_separately_is_used_when_the_body_head_has_no_title():
    # Indeed のチャレンジのページは先頭に長い <style> があり、ブラウザの body_head(先頭 2048 バイト)にタイトルが入らない
    r = classify(
        status=200,
        headers={},
        cookie_names=[],
        body="<!DOCTYPE html><html lang=en><style>:root{--primary-1000:#0d2d5e;--primary-900:#164081}",
        title="Security Check - Indeed.com",
    )
    assert r["kind"] == "challenge"


def test_akamai_cookie_alone_does_not_mean_blocked():
    r = classify(
        status=200,
        headers={"server": "AkamaiGHost"},
        cookie_names=["_abck", "bm_sz", "ak_bmsc"],
        body="<html><title>商品一覧</title></html>",
    )
    assert r["vendors"] == ["akamai"]
    assert r["kind"] == "ok"


def test_datadome_captcha():
    r = classify(
        status=403,
        headers={"x-datadome": "protected"},
        cookie_names=["datadome"],
        body="<script src='https://geo.captcha-delivery.com/captcha/'></script>",
    )
    assert r["vendors"] == ["datadome"]
    assert r["kind"] == "challenge"


def test_perimeterx_press_and_hold():
    r = classify(
        status=403,
        headers={},
        cookie_names=["_pxhd"],
        body="<div id='px-captcha'></div> Press & Hold to confirm you are a human",
    )
    assert r["vendors"] == ["perimeterx"]
    assert r["kind"] == "challenge"


def test_imperva_incident():
    r = classify(
        status=403,
        headers={"x-iinfo": "1-2-3", "x-cdn": "Imperva"},
        cookie_names=["incap_ses_123_456", "visid_incap_456"],
        body="Request unsuccessful. Incapsula incident ID: 1234",
    )
    assert r["vendors"] == ["imperva"]
    assert r["kind"] == "blocked"


def test_rate_limited():
    r = classify(status=429, headers={}, cookie_names=[], body="Too Many Requests")
    assert r["vendors"] == []
    assert r["kind"] == "rate_limited"


def test_ok_without_vendor():
    r = classify(status=200, headers={}, cookie_names=[], body="<html><title>Example Domain</title></html>")
    assert r == {"vendors": [], "kind": "ok", "signals": [], "deny_signature": None, "challenge_type": None,
                 "akamai_bot_manager": None}


def test_200_block_page_by_title_is_blocked():
    # ステータスが 200 でもタイトルがブロックページを示す場合
    r = classify(status=200, headers={}, cookie_names=[], body="<title>Access Denied</title>")
    assert r["kind"] == "blocked"


def test_signals_explain_the_decision():
    r = classify(
        status=403,
        headers={"server": "cloudflare", "cf-ray": "x"},
        cookie_names=[],
        body="<title>Just a moment...</title>",
    )
    assert any("cf-ray" in s for s in r["signals"])
    assert any("Just a moment" in s for s in r["signals"])


def test_header_names_are_case_insensitive():
    r = classify(status=403, headers={"CF-Ray": "x", "Server": "cloudflare"}, cookie_names=[], body="")
    assert r["vendors"] == ["cloudflare"]


def test_cloudflare_detection_script_on_a_normal_page_is_ok():
    # 通常ページにも Cloudflare の JS 検知スクリプトは入る。チャレンジではない
    r = classify(
        status=200,
        headers={"server": "cloudflare", "cf-ray": "x"},
        cookie_names=["__cf_bm"],
        body="<title>Engineerの求人 | Indeed</title>"
        "<script src='/cdn-cgi/challenge-platform/scripts/jsd/main.js'></script>",
    )
    assert r["vendors"] == ["cloudflare"]
    assert r["kind"] == "ok"


def test_turnstile_widget_embedded_in_a_200_page_is_ok():
    r = classify(
        status=200,
        headers={},
        cookie_names=[],
        body="<title>お問い合わせ</title>"
        "<iframe src='https://challenges.cloudflare.com/cdn-cgi/challenge-platform/turnstile'></iframe>",
    )
    assert r["kind"] == "ok"


def test_challenge_page_returned_with_200_is_still_challenge():
    r = classify(
        status=200,
        headers={},
        cookie_names=[],
        body="<title>Just a moment...</title><script>window._cf_chl_opt = {};</script>",
    )
    assert r["kind"] == "challenge"


def test_unknown_error_status():
    r = classify(status=500, headers={}, cookie_names=[], body="Internal Server Error")
    assert r["kind"] == "error"


def test_aws_waf_javascript_challenge_returned_with_202_and_no_title_is_challenge():
    # www.amazon.co.jp の実物の断片(2026-10-19)。202・title 空。ブラウザの JS が token を取ると再読み込みされる
    r = classify(
        status=202,
        headers={"server": "CloudFront", "content-type": "text/html; charset=UTF-8"},
        cookie_names=[],
        body='<!DOCTYPE html>\n<html lang="en">\n<head>\n    <title></title>\n'
        '    <script type="text/javascript">\n    window.awsWafCookieDomainList = [];\n'
        '    window.gokuProps = {\n"key":"AQID...","iv":"A6xx...","context":"tTw4..."\n};\n    </script>\n'
        '    <script src="https://1c5c1ecf7303.5a59d28b.ap-northeast-1.token.awswaf.com/1c5c1ecf7303/68f86b376542/d807fcba4336/challenge.js"></script>\n'
        '</head>\n<body>\n    <div id="challenge-container"></div>\n'
        "    <script>AwsWafIntegration.saveReferrer();</script>",
    )
    assert r["vendors"] == ["aws_waf"]
    assert r["kind"] == "challenge"


def test_page_that_only_loads_the_aws_waf_script_is_ok():
    # 通常のページが AWS WAF の JS を読み込んでいるだけ(gokuProps も challenge-container もない)
    r = classify(
        status=200,
        headers={"content-type": "text/html"},
        cookie_names=["aws-waf-token"],
        body="<title>商品一覧</title>"
        '<script src="https://x.token.awswaf.com/x/y/z/challenge.js"></script>',
    )
    assert r["kind"] == "ok"


def test_akamai_bm_verify_meta_refresh_returned_with_200_is_challenge():
    # www.amazon.co.jp を client_proxy 経由で取ったときの実物の断片(2026-10-19)。200・title は空白だけで、5 秒後に再読み込みされる
    r = classify(
        status=200,
        headers={"server": "AkamaiGHost", "content-type": "text/html"},
        cookie_names=[],
        body='<!DOCTYPE html><html><head> <meta charset="utf-8"> '
        '<meta http-equiv="refresh" content="5; URL=\'/?bm-verify=AAQAAAAO_____-H2xQ5kJ\'" />'
        "<title>&nbsp;</title><script> var i = 1792387146; </script> </head>",
    )
    assert r["vendors"] == ["akamai"]
    assert r["kind"] == "challenge"


def test_aws_waf_challenge_with_empty_body_is_challenge_by_the_response_header():
    # www.amazon.co.jp を Basic(request)で取ると、202 で本文が空(0 バイト)のことがある。ヘッダーだけが手がかり
    r = classify(
        status=202,
        headers={"server": "CloudFront", "x-amzn-waf-action": "challenge"},
        cookie_names=[],
        body="",
    )
    assert r["vendors"] == ["aws_waf"]
    assert r["kind"] == "challenge"


AKAMAI_DENIED = (
    '<HTML><HEAD>\n<TITLE>Access Denied</TITLE>\n</HEAD><BODY>\n<H1>Access Denied</H1>\n'
    'You don\'t have permission to access "http&#58;&#47;&#47;zozo&#46;jp&#47;" on this server.<P>\n'
    "Reference&#32;&#35;18&#46;{ref}\n<P>https&#58;&#47;&#47;errors&#46;edgesuite&#46;net&#47;18&#46;{ref}</P>\n</BODY>\n</HTML>\n"
)


def test_akamai_denied_pages_that_differ_only_in_the_reference_number_get_the_same_signature():
    # 同じルールで拒否されたかを並べて見るため、リクエストごとに変わる番号はならしてから比べる
    a = classify(403, {"server": "AkamaiGHost"}, [], AKAMAI_DENIED.format(ref="5452cd17&#46;1792145713&#46;fce8799"))
    b = classify(403, {"server": "AkamaiGHost"}, [], AKAMAI_DENIED.format(ref="9a01bc22&#46;1792199999&#46;1ab2c3d"))
    assert a["deny_signature"] is not None
    assert a["deny_signature"] == b["deny_signature"]


def test_different_denied_pages_get_different_signatures():
    a = classify(403, {"server": "AkamaiGHost"}, [], AKAMAI_DENIED.format(ref="5452cd17&#46;1792145713&#46;fce8799"))
    b = classify(403, {"server": "AkamaiGHost"}, [], "<html><title>Forbidden</title><p>Request blocked by policy.</p></html>")
    assert a["deny_signature"] != b["deny_signature"]


def test_normal_page_has_no_deny_signature():
    r = classify(200, {}, [], "<title>商品</title>")
    assert r["deny_signature"] is None


def test_aws_waf_captcha_action_is_a_screen_that_needs_a_person():
    r = classify(405, {"x-amzn-waf-action": "captcha"}, [], "")
    assert r["vendors"] == ["aws_waf"]
    assert r["kind"] == "turnstile"




@pytest.mark.parametrize(
    ("headers", "cookies", "expected"),
    [
        ({"server": "AkamaiGHost"}, ["ak_bmsc", "bm_sz"], True),  # Bot Manager の判定を受けたうえでの拒否
        ({"server": "AkamaiGHost"}, [], False),  # Bot Manager より前のルールで止まった可能性
        ({"server": "cloudflare", "cf-ray": "x"}, [], None),  # Akamai 以外では出さない
    ],
)
def test_akamai_bot_manager_is_reported_by_whether_its_cookies_were_issued_on_the_denial(headers, cookies, expected):
    r = classify(403, headers, cookies, "<title>Access Denied</title>")
    assert r["akamai_bot_manager"] is expected


def test_amazon_page_that_refuses_automated_access_is_blocked_even_with_503():
    body = ("<html><head><title>ご迷惑をおかけしています！</title></head><body><!--\n"
            "        To discuss automated access to Amazon data please contact api-services-support@amazon.com.\n-->")
    r = classify(503, {"server": "Server", "content-type": "text/html"}, [], body)
    assert r["vendors"] == ["amazon"]
    assert r["kind"] == "blocked"


def test_amazon_continue_shopping_page_returned_with_200_is_a_button_challenge():
    # www.amazon.co.jp を client_proxy の Axios で取ったときの実物の断片(2026-10-22)。200・約 3.7KB・title は「Amazon.co.jp」で、
    # 本物のトップページではなく、ボタンを押すと validateCaptcha へ送る確認画面
    r = classify(
        status=200,
        headers={"server": "Server", "content-type": "text/html"},
        cookie_names=[],
        body='<!DOCTYPE html><html class="a-no-js" lang="jp"><head><title dir="ltr">Amazon.co.jp</title></head><body>\n'
        "<!--\n        To discuss automated access to Amazon data please contact api-services-support@amazon.com.\n-->\n"
        '<h4>下のボタンをクリックしてショッピングを続けてください</h4>\n'
        '<form method="get" action="/errors_page/validateCaptcha" name="">\n'
        '<input type="hidden" name="amzn" value="x" /><input type="hidden" name="amzn-r" value="&#047;" />\n'
        '<button type="submit" class="a-button-text" alt="ショッピングを続ける">ショッピングを続ける</button>\n'
        "</form></body></html>",
    )
    assert r["vendors"] == ["amazon"]
    assert r["kind"] == "challenge"
    assert r["challenge_type"] == "button"


@pytest.mark.parametrize(
    ("headers", "body", "expected"),
    [
        ({"cf-mitigated": "challenge"}, "<title>Just a moment...</title><script src='/cdn-cgi/challenge-platform/h/b'>", "auto"),
        ({"server": "AkamaiGHost"}, "<div id='sec-if-cpt-container'></div>", "auto"),
        ({"x-amzn-waf-action": "challenge"}, "", "auto"),
        ({"cf-ray": "x"}, "<iframe src='https://challenges.cloudflare.com/cdn-cgi/challenge-platform/turnstile'>", "button"),
        ({}, "<title>Security Check</title><div class='g-recaptcha' data-sitekey='x'></div><script src='https://www.google.com/recaptcha/api.js'>", "button"),
        ({}, "<title>Access to this page has been denied</title><div id='px-captcha'></div>", "press_hold"),
        ({}, "<title>Security Check</title><script src='https://js.hcaptcha.com/1/api.js'></script>", "puzzle"),
        ({"x-amzn-waf-action": "captcha"}, "", "puzzle"),
        ({"x-datadome": "protected"}, "<script>var dd={'rt':'c','cid':'x'}</script><script src='https://ct.captcha-delivery.com/c.js'>", "puzzle"),
        ({"x-datadome": "protected"}, "<script>var dd={'rt':'i','cid':'x'}</script><script src='https://ct.captcha-delivery.com/i.js'>", "auto"),
    ],
)
def test_challenge_type_tells_what_a_person_has_to_do(headers, body, expected):
    r = classify(403, headers, [], body)
    assert r["kind"] in ("challenge", "turnstile")
    assert r["challenge_type"] == expected


def test_challenge_without_any_known_marker_has_an_unknown_type():
    r = classify(403, {}, [], "<title>Security Check</title><p>Please wait.</p>")
    assert r["kind"] == "challenge"
    assert r["challenge_type"] == "unknown"


def test_page_that_is_not_a_challenge_has_no_challenge_type():
    assert classify(200, {}, [], "<title>商品</title>")["challenge_type"] is None
