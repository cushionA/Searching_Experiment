"""経路を辿る確認の経路を、結果つきで保存し、次回以降に再利用する(references/routes.json)。

通った経路も全滅した経路も、日付・回線・通った手つきで残す。サイトの鍵は、経路のページのホスト名。
"""

from __future__ import annotations

import fcntl
import json
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit


def routes_path() -> Path:
    """保存先。BLOCKING_TRIAGE_ROUTES で変えられる(既定はスキルの references/routes.json。git で共有する)。"""
    env = os.environ.get("BLOCKING_TRIAGE_ROUTES")
    return Path(env) if env else Path(__file__).resolve().parents[1] / "references" / "routes.json"


class RoutesFileError(Exception):
    pass


MAX_RESULTS = 10  # 1 つの経路に残す結果の数(新しい方から)


def load_routes(path: Path) -> dict:
    if not path.exists():
        return {"sites": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        # 空として扱って上書きすると、保存済みの経路が全部消える。直してもらうために、そのままにしてエラーにする
        raise RoutesFileError(f"{path} が JSON として読めない: {e}") from e


def _site(url_or_host: str) -> str:
    """サイトの鍵。ホスト名の小文字で、先頭の www. は外す(www の有無で別のサイトにしない)。"""
    host = (urlsplit(url_or_host).hostname if "://" in url_or_host else url_or_host) or ""
    host = host.lower()
    return host[4:] if host.startswith("www.") else host


def _site_key(data: dict, site: str) -> str:
    """保存済みのファイルで、そのサイトに使われている鍵(www つきで書かれていても同じサイトとして使う)。なければ site。"""
    return next((k for k in data.get("sites") or {} if _site(k) == site), site)


def _site_routes(data: dict, url: str) -> list[dict]:
    site = _site(url)
    return ((data.get("sites") or {}).get(_site_key(data, site)) or {}).get("routes") or []


def _without_www(pages: list[str]) -> list[str]:
    return [p.replace("://www.", "://", 1) for p in pages]


def _shape(url: str) -> tuple[int, str]:
    """ページの形。パスの区切りの数と、最初の区切り(/item/123 なら (2, "item"))。同じ形のページは、同じ経路で辿れる見込み。"""
    parts = [p for p in urlsplit(url).path.split("/") if p]
    return len(parts), parts[0] if parts else ""


@contextmanager
def _locked(path: Path):
    """保存先のディレクトリを排他ロックして、読んでから書くまでの間に、ほかの実行が書き込まないようにする。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(fd)  # 閉じるとロックも外れる


def _write_atomically(path: Path, data: dict) -> None:
    """一時ファイルに書いてから置き換える。途中で止まっても、元のファイルは壊れない。"""
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def record_route(path: Path, pages: list[str], line: str, outcome: str, how: str | None, at: str) -> None:
    """経路と結果を 1 件足す。通った(pass)か全滅(fail)だけを残す。起動できなかった・回線がなかった(未実施)は、経路の結果ではないので残さない。

    目的ページの手前のページの並びが同じなら、同じ経路。目的ページだけが違うときは、経路を増やさず、結果に目的ページの URL(url)を添える。
    """
    if outcome not in ("pass", "fail"):
        return
    with _locked(path):
        data = load_routes(path)
        site = data.setdefault("sites", {}).setdefault(_site_key(data, _site(pages[-1])), {"routes": []})
        routes = site["routes"]
        route = next((r for r in routes if _without_www(r["pages"][:-1]) == _without_www(pages[:-1])), None)
        if route is None:
            route = {"pages": pages, "results": []}
            routes.append(route)
        route["results"] = [*route["results"], {"at": at, "line": line, "outcome": outcome, "how": how, "url": pages[-1]}][-MAX_RESULTS:]
        _write_atomically(path, data)


def find_saved_route(data: dict, url: str) -> dict | None:
    """url を目的ページとして使う保存済みの経路。

    その url で辿ったことのある経路を先に、なければ、同じサイトで、目的ページの形(パスの区切りの数と最初の区切り)が同じ経路。
    別のサイトの経路や、別の種類のページの経路は返さない。
    """
    routes = _site_routes(data, url)
    exact = next((r for r in routes if r["pages"][-1] == url or any(x.get("url") == url for x in r.get("results") or [])), None)
    return exact or next((r for r in routes if _shape(r["pages"][-1]) == _shape(url)), None)


def route_to(saved: dict, url: str) -> list[str]:
    """保存済みの経路を、url を目的ページとする経路にする(最後のページを url に差し替える)。"""
    return [*saved["pages"][:-1], url]


def saved_route_pages(data: dict, url: str, route_given: bool, use_saved: bool) -> list[str] | None:
    """経路を辿る確認に使う、保存済みの経路のページ(目的ページを除く)。使わないとき、または経路がないときは None。"""
    if route_given or not use_saved:
        return None
    saved = find_saved_route(data, url)
    return route_to(saved, url)[:-1] if saved else None


def saved_route_notes(saved: dict, passed: bool, line: str) -> list[str]:
    """保存済みの経路を使った結果の読み。今回の結果を記録する前の saved(前回までの結果)を渡す。前回は、同じ回線の最新の結果。"""
    last = next((r for r in reversed(saved.get("results") or []) if r.get("line") == line), None)
    before = f"前回の結果は {last['at']} に{'通った' if last['outcome'] == 'pass' else '全滅だった'}" if last else None
    if passed:
        return [f"保存済みの経路で通った({before})" if before else "保存済みの経路で通った"]
    base = f"保存済みの経路で通らなかった({before})" if before else "保存済みの経路で通らなかった"
    return [f"{base}。サイトの構成が変わって、経路が古い可能性がある"]
