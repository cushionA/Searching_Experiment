// 人の Chrome で、③(browser_probe.py)と同じ項目を取るスニペット。
// https://tls.peet.ws/api/all を開いたタブの DevTools のコンソールに貼って実行する(Claude in Chrome に頼むときも、同じタブで実行させる)。
// 出力の 1 行の JSON を保存し、`uv run probe.py --compare-human <保存した JSON> --browser-json <③の JSON>` で③と比べる。
// tls.peet.ws の応答には自分の IP も入るが、出力には指紋と JS から見える値だけを残す(IP・cookie は出さない)。
(async () => {
  const d = await (await fetch('/api/all', { cache: 'no-store' })).json();
  const env = {};
  try {
    const gl = document.createElement('canvas').getContext('webgl');
    const ext = gl?.getExtension('WEBGL_debug_renderer_info');
    env.webgl_vendor = gl ? gl.getParameter(ext ? ext.UNMASKED_VENDOR_WEBGL : gl.VENDOR) : null;
    env.webgl_renderer = gl ? gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER) : null;
  } catch {
    env.webgl_renderer = null;
  }
  env.screen = { width: screen.width, height: screen.height, avail_width: screen.availWidth, avail_height: screen.availHeight };
  env.window = { inner_width: innerWidth, inner_height: innerHeight, outer_width: outerWidth, outer_height: outerHeight };
  env.device_pixel_ratio = devicePixelRatio;
  env.plugins = navigator.plugins?.length ?? null;
  env.hardware_concurrency = navigator.hardwareConcurrency ?? null;
  env.device_memory = navigator.deviceMemory ?? null;
  env.platform = navigator.platform ?? null;
  env.ua_brands = navigator.userAgentData?.brands?.map((b) => `${b.brand} ${b.version}`) ?? null;
  const result = {
    engine: 'human_chrome',
    checked_at: new Date().toISOString(),
    user_agent: navigator.userAgent,
    webdriver: navigator.webdriver,
    fingerprint: {
      ja4: d.tls?.ja4 ?? null,
      akamai_h2: d.http2?.akamai_fingerprint ?? null,
      http_version: d.http_version ?? null,
      // GREASE を除いた拡張の名前。pre_shared_key があれば、TLS のセッションを再開した接続
      extensions: d.tls?.extensions?.map((e) => e.name).filter((n) => !/GREASE/.test(n)) ?? null,
    },
    js_env: env,
  };
  const line = JSON.stringify(result);
  console.log(line);
  return line;
})();
