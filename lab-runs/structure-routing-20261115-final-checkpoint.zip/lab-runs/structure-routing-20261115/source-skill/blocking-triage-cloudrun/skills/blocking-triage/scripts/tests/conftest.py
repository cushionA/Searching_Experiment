"""テストから、親のディレクトリ(scripts/)のモジュールを import できるようにする。"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
