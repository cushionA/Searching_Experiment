#!/usr/bin/env bash
# Google Chrome の安定版を、スキルの中の .tools/chrome/ に展開し、実行ファイルのパスを出す(ホストでも、コンテナでも動く)。
# .deb を dpkg-deb -x で展開するだけなので、root もイメージの作り直しも要らない(ダウンロード約 140MB、展開後約 440MB)。
# 展開済みならダウンロードしない。新しい版に替えるときは BLOCKING_TRIAGE_CHROME_REFRESH=1 を付ける。
# Google Chrome の Linux 版は amd64 だけなので、arm64(Apple Silicon の Mac など)では使えない。
set -euo pipefail

skill="$(cd "$(dirname "$0")/../.." && pwd)"  # このスクリプトの 2 つ上がスキルの根。取ったものはスキルの中に収める
dir="${1:-$skill/.tools/chrome}"
bin="$dir/root/opt/google/chrome/chrome"

if [ -x "$bin" ] && [ -z "${BLOCKING_TRIAGE_CHROME_REFRESH:-}" ]; then
  echo "$bin"
  exit 0
fi
if [ "$(uname -m)" != "x86_64" ]; then
  echo "Google Chrome の Linux 版は amd64 だけ。この環境($(uname -m))では --browser=chrome は使えない" >&2
  exit 3
fi

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
curl -fsS -m 600 -o "$tmp/chrome.deb" https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
dpkg-deb -x "$tmp/chrome.deb" "$tmp/root"
mkdir -p "$dir"
rm -rf "$dir/root"
mv "$tmp/root" "$dir/root"
"$bin" --version >&2
echo "$bin"
