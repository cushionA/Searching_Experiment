"""ladder.py のテスト。ステップの進め方と読み。通信はしない(ステップの実行は差し替える)。
実行: uv run --with pytest pytest .claude/skills/blocking-triage/scripts/tests"""

import re

import pytest

from ladder import read_ladder, read_route, run_ladder, run_route_ladder, run_with_route

DC = {"line": "client_proxy", "egress": "client_proxy", "proxy": "http://gke.example.com:57884", "source": ".env", "substitute": False}
RES = {"line": "residential", "egress": "residential", "proxy": "http://res.example.com:8000", "source": ".env", "substitute": False}
RES_BY_DIRECT = {"line": "residential", "egress": "direct", "proxy": None, "source": "手元の回線(isp)", "substitute": True}
LINES = {"client_proxy": DC, "residential": RES}


class Runner:
    """ステップごとの結果を、試した順に返す。足りなければ最後の結果を繰り返す。呼ばれたステップを calls に残す。

    ブラウザのステップでトップページを経由した試行の結果は results[f"{n}t"] から返す(なければ default)。
    Chrome のヘッダー一式を付けた Axios の確認は、ステップとは別に header_calls に残し、結果は results[f"{n}h"] から返す。
    """

    def __init__(self, results: dict, default: str = "fail"):
        self.results, self.default, self.calls, self.variants, self.header_calls = results, default, [], [], []

    def __call__(self, step, line):
        n = step["n"]
        if step.get("chrome_headers"):
            self.header_calls.append((n, line["line"]))
            seq = self.results.get(f"{n}h", ["fail"])
            return {"result": seq[min(len(self.header_calls) - 1, len(seq) - 1)], "line": line["line"]}
        self.calls.append(n)
        variant = (n, bool(step.get("via_top")))  # ブラウザのステップで、トップページを経由したか
        self.variants.append(variant)
        seq = self.results.get(f"{n}t" if variant[1] else n, [self.default])
        i = sum(1 for v in self.variants[:-1] if v == variant)
        return {"result": seq[min(i, len(seq) - 1)], "line": line["line"]}


def executed_steps(calls):
    """同じステップの連続した呼び出し(やり直しと確かめ)を 1 つにまとめた、試したステップの並び。"""
    return [n for i, n in enumerate(calls) if i == 0 or calls[i - 1] != n]


def test_when_axios_passes_on_the_datacenter_line_blocking_is_not_reproduced_and_later_steps_are_not_sent():
    run = Runner({0: ["pass"]})

    ladder = run_ladder(LINES, run)

    assert executed_steps(run.calls) == [0]
    assert (ladder["stopped"], ladder["first_pass"]) == ("not_reproduced", None)


@pytest.mark.parametrize("n", [1, 2, 3, 4, 5])
def test_ladder_stops_at_the_first_step_that_passes_and_sends_nothing_after_it(n):
    run = Runner({n: ["pass"]})

    ladder = run_ladder(LINES, run)

    assert executed_steps(run.calls) == list(range(n + 1))
    assert (ladder["stopped"], ladder["first_pass"]) == ("passed", n)


CHROME_LIKE = "Chrome と同じ接続の作り方(ブラウザ系。ブラウザで通るかは未確認)"
BROWSER = "JS を実行するブラウザ"


@pytest.mark.parametrize(
    "n, layer, needs",
    [
        (1, "接続の作り方(TLS/HTTP2)。ヘッダー一式をそろえるだけでは通らない", (CHROME_LIKE, "今のデータセンターの回線のまま")),
        (2, "JS の判定", (BROWSER, "今のデータセンターの回線のまま")),
        (3, "回線(IP/ASN)", ("Chrome をまねない素のクライアント", "レジデンシャルのプロキシ")),
        (4, "回線(IP/ASN)と、接続の作り方(TLS/HTTP2)。ヘッダー一式をそろえるだけでは通らない", (CHROME_LIKE, "レジデンシャルのプロキシ")),
        (5, "回線(IP/ASN)と JS の判定", (BROWSER, "レジデンシャルのプロキシ")),
    ],
)
def test_first_passing_step_decides_the_layer_and_what_the_diagnosis_needs(n, layer, needs):
    # ステップ 1・4 では、続けて試す Chrome のヘッダー一式を付けた Axios が通らない(Runner の既定)
    reading = read_ladder(run_ladder(LINES, Runner({n: ["pass"]})), LINES)

    assert reading["layer"] == layer
    assert (reading["needs"]["client"], reading["needs"]["line"].split("(")[0]) == needs


def test_the_chrome_version_the_diagnosis_used_is_taken_from_the_user_agent_of_the_passing_try_and_is_not_called_the_latest():
    ladder = run_ladder(LINES, Runner({2: ["pass"]}))
    for rec in ladder["records"]:
        for o in rec["outcomes"]:
            if o["result"] == "pass":
                o["summary"] = {"user_agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"}

    browser = read_ladder(ladder, LINES)["needs"]["browser"]

    assert "Chrome 151" in browser and "最新版とは限らない" in browser and "最新版の" not in browser


def test_when_the_user_agent_is_not_available_the_reading_says_the_version_could_not_be_taken():
    browser = read_ladder(run_ladder(LINES, Runner({2: ["pass"]})), LINES)["needs"]["browser"]

    assert "版は取れなかった" in browser and "最新版とは限らない" in browser


@pytest.mark.parametrize(
    "n, browser_prefix",
    [(2, "Google Chrome"), (5, "Google Chrome"), (3, "不要"), (1, "ブラウザ系が要る見込み"), (4, "ブラウザ系が要る見込み")],
)
def test_the_reading_says_without_an_environment_file_which_browser_the_diagnosis_needs(n, browser_prefix):
    # 推奨構成ではなく分析の結果として、通った Chrome の版か、ブラウザが不要かを書く。最新版とは言い切らない
    reading = read_ladder(run_ladder(LINES, Runner({n: ["pass"]})), LINES)

    assert reading["needs"]["browser"].startswith(browser_prefix)


def test_when_the_page_opened_only_via_the_top_page_chrome_is_needed_too():
    reading = read_ladder(run_ladder(LINES, Runner({2: ["fail"], "2t": ["pass"]})), LINES)

    assert reading["needs"]["browser"].startswith("Google Chrome")


def test_when_axios_with_the_chrome_header_set_passes_no_browser_is_needed():
    reading = read_ladder(run_ladder(LINES, Runner({1: ["pass"], "1h": ["pass"]})), LINES)

    assert reading["needs"]["browser"].startswith("不要")


@pytest.mark.parametrize("n, line", [(1, "client_proxy"), (4, "residential")])
def test_when_a_chrome_like_connection_step_passes_axios_with_the_chrome_header_set_is_tried_on_the_same_line(n, line):
    run = Runner({n: ["pass"]})

    run_ladder(LINES, run)

    assert run.header_calls[:1] == [(n, line)]


@pytest.mark.parametrize(
    "n, layer, line",
    [(1, "ヘッダー一式(接続の作り方は Chrome でなくても通る)", "今のデータセンターの回線のまま"), (4, "回線(IP/ASN)と、ヘッダー一式", "レジデンシャルのプロキシ")],
)
def test_when_axios_with_the_chrome_header_set_passes_every_try_axios_with_the_headers_is_recommended_without_a_browser(n, layer, line):
    run = Runner({n: ["pass"], f"{n}h": ["pass"]})

    reading = read_ladder(run_ladder(LINES, run), LINES, node_client="axios")

    assert len(run.header_calls) == 3
    assert reading["layer"] == layer
    assert (reading["needs"]["client"], reading["needs"]["line"].split("(")[0]) == (
        "Axios(Chrome のヘッダー一式を付ける)", line
    )
    assert reading["confidence"] == "高"


def test_when_axios_with_the_chrome_header_set_fails_twice_nothing_more_is_sent_and_the_connection_layer_is_read():
    run = Runner({1: ["pass"], "1h": ["fail"]})

    reading = read_ladder(run_ladder(LINES, run), LINES)

    assert len(run.header_calls) == 2
    assert reading["layer"] == "接続の作り方(TLS/HTTP2)。ヘッダー一式をそろえるだけでは通らない"
    assert reading["needs"]["client"] == CHROME_LIKE


@pytest.mark.parametrize("node_client, name", [("curl", "curl"), ("axios", "Axios")])
def test_when_the_chrome_header_set_splits_the_need_stays_chrome_like_and_the_variance_is_noted(node_client, name):
    run = Runner({1: ["pass"], "1h": ["pass", "fail", "pass"]})

    reading = read_ladder(run_ladder(LINES, run), LINES, node_client=node_client)

    assert reading["needs"]["client"] == CHROME_LIKE
    assert f"Chrome のヘッダー一式を付けた {name} は、3 回中 2 回通過(ばらつく)" in reading["notes"]


@pytest.mark.parametrize("node_client, name", [("curl", "curl"), ("axios", "Axios")])
@pytest.mark.parametrize(
    "result, why",
    [("error", "回線につながらず、"), ("rate_limited", "429 が返って、")],
)
def test_when_the_chrome_header_set_could_not_be_checked_it_is_noted_and_the_reading_stays_as_for_curl_cffi(result, why, node_client, name):
    note = f"Chrome のヘッダー一式を付けた {name} は、{why}確かめられなかった"
    run = Runner({1: ["pass"], "1h": [result]})

    reading = read_ladder(run_ladder(LINES, run), LINES, node_client=node_client)

    assert reading["layer"] == "接続の作り方(TLS/HTTP2)か、ヘッダー一式"
    assert reading["needs"]["client"] == CHROME_LIKE
    assert note in reading["notes"]


def test_when_basic_is_the_client_the_need_for_the_line_only_case_keeps_basic():
    reading = read_ladder(run_ladder(LINES, Runner({3: ["pass"]})), LINES, node_client="basic")

    assert reading["needs"]["client"] == "Basic のまま"


def test_passing_step_is_tried_three_times_in_all_and_is_consistent_only_when_every_try_passes():
    run = Runner({3: ["pass"]})

    ladder = run_ladder(LINES, run)
    reading = read_ladder(ladder, LINES)

    assert run.calls.count(3) == 3
    assert (ladder["passes"], ladder["tries"], ladder["consistent"]) == (3, 3, True)
    assert reading["confidence"] == "高"


def test_when_a_non_browser_step_fails_first_and_then_passes_it_is_tried_a_third_time_and_stops_there_as_varying():
    run = Runner({1: ["fail", "pass"]})

    ladder = run_ladder(LINES, run)
    reading = read_ladder(ladder, LINES)

    assert executed_steps(run.calls) == [0, 1] and run.calls.count(1) == 3
    assert (ladder["first_pass"], ladder["passes"], ladder["tries"], ladder["consistent"]) == (1, 2, 3, False)
    assert reading["confidence"] == "低"


def test_when_the_tries_of_the_passing_step_split_the_result_is_marked_as_varying_and_confidence_is_low():
    ladder = run_ladder(LINES, Runner({1: ["pass", "fail", "pass"]}))
    reading = read_ladder(ladder, LINES)

    assert (ladder["passes"], ladder["tries"], ladder["consistent"]) == (2, 3, False)
    assert reading["confidence"] == "低"


def test_when_no_step_passes_each_step_is_judged_on_two_failures_and_the_browser_also_via_the_top_page():
    run = Runner({})

    run_ladder(LINES, run)

    twice = lambda n, via_top=False: [(n, via_top)] * 2
    assert run.variants == [*twice(0), *twice(1), *twice(2), *twice(2, True), *twice(3), *twice(4), *twice(5), *twice(5, True)]


@pytest.mark.parametrize(
    "n, layer, line",
    [
        (2, "遷移の条件(トップページを経由すること)。JS の判定も要るかは未確認", "今のデータセンターの回線のまま"),
        (5, "回線(IP/ASN)と、遷移の条件(トップページを経由すること)。JS の判定も要るかは未確認", "レジデンシャルのプロキシ"),
    ],
)
def test_when_only_the_try_via_the_top_page_opens_the_page_the_transition_is_read_as_the_layer(n, layer, line):
    run = Runner({n: ["fail"], f"{n}t": ["pass"]})

    ladder = run_ladder(LINES, run)
    reading = read_ladder(ladder, LINES)

    # 確かめもトップページを経由して行い、経由しない 2 回は割合に数えない(条件が違う)
    assert [v for v in run.variants if v[0] == n] == [(n, False), (n, False), (n, True), (n, True), (n, True)]
    assert (ladder["passes"], ladder["tries"], ladder["consistent"], ladder["via_top"]) == (3, 3, True, True)
    assert reading["layer"] == layer
    assert reading["needs"]["client"] == f"{BROWSER}(トップページを開いてから、location.href で移る)"
    assert reading["needs"]["line"].startswith(line)


def test_when_the_try_via_the_top_page_fails_first_and_then_passes_it_varies_and_the_direct_tries_are_not_counted():
    # joshinweb.jp の 2026-10-23 の 2 回目の形(トップページ経由が 1 回だけ拒否された)
    run = Runner({5: ["fail"], "5t": ["fail", "pass"]})

    ladder = run_ladder(LINES, run)

    assert [v for v in run.variants if v[0] == 5] == [(5, False), (5, False), (5, True), (5, True), (5, True)]
    assert (ladder["first_pass"], ladder["passes"], ladder["tries"], ladder["consistent"], ladder["via_top"]) == (5, 2, 3, False, True)


def test_when_the_target_is_the_top_page_the_browser_step_is_simply_tried_again():
    run = Runner({})

    run_ladder(LINES, run, via_top=False)

    assert [v for v in run.variants if v[0] == 2] == [(2, False), (2, False)]


def test_browser_step_that_opens_on_the_second_plain_try_counts_the_first_failure_in_the_ratio():
    ladder = run_ladder(LINES, Runner({2: ["fail", "pass"]}), via_top=False)

    assert (ladder["first_pass"], ladder["passes"], ladder["tries"], ladder["consistent"]) == (2, 2, 3, False)


@pytest.mark.parametrize("stop", ["error", "rate_limited"])
@pytest.mark.parametrize("before", [[], ["fail"]], ids=["1 回目", "拒否のあとの 2 回目"])
def test_when_the_line_is_unreachable_or_rate_limited_the_ladder_stops_at_that_step(stop, before):
    # VPN が切れたままステップ 3 に進むと、「回線が原因」と読み違える
    run = Runner({1: [*before, stop]})

    ladder = run_ladder(LINES, run)

    assert executed_steps(run.calls) == [0, 1]
    assert (ladder["stopped"], ladder["stopped_at"], ladder["first_pass"]) == (stop, 1, None)


def test_without_a_residential_line_the_ladder_stops_after_the_datacenter_steps_and_asks_for_one():
    run = Runner({})
    lines = {"client_proxy": DC, "residential": None}

    ladder = run_ladder(lines, run)
    reading = read_ladder(ladder, lines)

    assert executed_steps(run.calls) == [0, 1, 2]
    assert ladder["stopped"] == "no_residential"
    assert reading["needs"] is None
    assert any("手配" in n for n in reading["next"])


def test_when_the_local_line_stands_in_for_residential_it_is_stated_and_confidence_stays_at_most_medium():
    lines = {"client_proxy": DC, "residential": RES_BY_DIRECT}

    reading = read_ladder(run_ladder(lines, Runner({3: ["pass"]})), lines)

    assert reading["confidence"] == "中"
    # 代用したことは、推奨構成の回線の行ではなく注記に出す(出力では「診断の条件」に 1 回だけ書く)
    assert any("手元の回線で代用" in n for n in reading["notes"])
    assert "代用" not in reading["needs"]["line"]


def test_browser_that_could_not_launch_leaves_the_step_unchecked_and_the_ladder_goes_on():
    run = Runner({2: ["unavailable"], 3: ["pass"]})

    ladder = run_ladder(LINES, run)
    reading = read_ladder(ladder, LINES)

    assert executed_steps(run.calls) == [0, 1, 2, 3]
    assert ladder["unchecked"] == [2]
    assert reading["confidence"] == "中"


def test_when_every_step_fails_the_route_step_is_recommended_and_a_route_is_asked_for():
    ladder = run_ladder(LINES, Runner({}))
    reading = read_ladder(ladder, LINES)

    assert (ladder["stopped"], ladder["first_pass"]) == ("all_failed", None)
    assert reading["needs"] is None
    assert "経路" in reading["next"][0]


def test_credentials_of_the_residential_proxy_are_flagged_because_production_clients_cannot_send_them():
    lines = {"client_proxy": DC, "residential": {**RES, "proxy": "http://user:secret@res.example.com:8000"}}

    reading = read_ladder(run_ladder(lines, Runner({5: ["pass"]})), lines)

    assert any("認証" in n for n in reading["notes"])
    assert "secret" not in str(reading)


class RouteRunner:
    def __init__(self, results: dict[str, str]):
        self.results, self.calls = results, []

    def __call__(self, line):
        self.calls.append(line["line"])
        return {"result": self.results.get(line["line"], "fail"), "line": line["line"], "how": "手前のページから location.href で移る"}


def test_the_chrome_version_of_the_route_trial_is_reported_in_the_browser_need():
    route = run_route_ladder(LINES, RouteRunner({"residential": "pass"}))
    for r in route["records"]:
        r["outcome"]["route"] = {"user_agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36"}

    assert "Chrome 152" in read_route(route, LINES)["needs"]["browser"]


def test_the_chrome_version_of_the_try_via_the_top_page_is_reported_in_the_browser_need():
    ladder = run_ladder(LINES, Runner({2: ["fail"], "2t": ["pass"]}))
    for rec in ladder["records"]:
        for o in rec["outcomes"]:
            if o["result"] == "pass":
                o["summary"] = {"user_agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36"}

    assert "Chrome 153" in read_ladder(ladder, LINES)["needs"]["browser"]


def test_route_step_is_tried_only_on_residential_unless_the_datacenter_line_is_asked_for():
    # ステップ 6 は joshinweb.jp のような厳しいサイトが前提で、データセンターの回線ではトップから拒否されることが多い
    run = RouteRunner({})

    route = run_route_ladder(LINES, run)

    assert run.calls == ["residential"]
    assert route["first_pass_line"] is None


def test_route_step_with_the_datacenter_line_asked_for_stops_there_when_it_passes():
    run = RouteRunner({"client_proxy": "pass"})

    route = run_route_ladder(LINES, run, with_client_proxy=True)

    assert run.calls == ["client_proxy"]
    assert route["first_pass_line"] == "client_proxy"
    needs = read_route(route, LINES)["needs"]
    assert (needs["client"], needs["line"]) == (f"{BROWSER}(手前のページから location.href で移る)", "今のデータセンターの回線のまま")


def test_route_step_with_the_datacenter_line_asked_for_goes_on_to_residential_when_it_fails():
    run = RouteRunner({"residential": "pass"})

    route = run_route_ladder(LINES, run, with_client_proxy=True)

    assert run.calls == ["client_proxy", "residential"]
    assert route["first_pass_line"] == "residential"
    assert read_route(route, LINES)["needs"]["line"].startswith("レジデンシャル")


def test_route_step_without_a_residential_line_is_not_run_and_asks_for_one():
    run = RouteRunner({})
    lines = {"client_proxy": DC, "residential": None}

    reading = read_route(run_route_ladder(lines, run), lines)

    assert run.calls == []
    assert any("手配" in n for n in reading["next"])


@pytest.mark.parametrize("results", [{}, {"no_residential": True}])
def test_with_a_route_given_the_usual_steps_run_first_and_the_route_only_when_none_of_them_passed(results):
    lines = {"client_proxy": DC, "residential": RES if not results else None}
    run, route_run = Runner({}), RouteRunner({"residential": "pass", "client_proxy": "pass"})

    out = run_with_route(lines, run, route_run, with_client_proxy=bool(results))

    assert executed_steps(run.calls) == ([0, 1, 2] if results else [0, 1, 2, 3, 4, 5])
    assert route_run.calls == (["client_proxy"] if results else ["residential"])
    assert out["route"]["first_pass_line"] is not None


@pytest.mark.parametrize("results", [{0: ["pass"]}, {2: ["pass"]}, {1: ["error"]}])
def test_with_a_route_given_the_route_is_not_followed_when_a_usual_step_passed_or_the_ladder_stopped(results):
    route_run = RouteRunner({})

    out = run_with_route(LINES, Runner(results), route_run)

    assert route_run.calls == []
    assert out["route"] is None


# チャットにそのまま写される文に、skill の中だけの名前(ステップの番号、手の名前、止まり方、資料の番号)を出さない
INTERNAL_TERMS = re.compile(r"ステップ ?[0-9]|手 ?[A-F]|warmup|all_failed|not_reproduced|no_residential|[①②③④]")


def texts(reading):
    return [reading["layer"] or "", reading.get("no_needs_reason") or "", *reading["notes"], *reading["next"],
            *(reading["needs"] or {}).values()]


@pytest.mark.parametrize(
    "lines, results",
    [
        (LINES, {0: ["pass"]}),
        (LINES, {1: ["pass"]}),
        (LINES, {2: ["fail", "pass"]}),
        (LINES, {3: ["pass", "fail", "pass"]}),
        (LINES, {4: ["pass"]}),
        (LINES, {5: ["fail", "pass"]}),
        (LINES, {2: ["unavailable"], 3: ["pass"]}),
        (LINES, {}),
        (LINES, {1: ["error"]}),
        (LINES, {4: ["rate_limited"]}),
        ({"client_proxy": DC, "residential": None}, {}),
        ({"client_proxy": DC, "residential": RES_BY_DIRECT}, {3: ["pass"]}),
    ],
)
def test_reading_of_the_steps_does_not_use_names_known_only_inside_the_skill(lines, results):
    reading = read_ladder(run_ladder(lines, Runner(results)), lines)

    assert [t for t in texts(reading) if INTERNAL_TERMS.search(t)] == []


@pytest.mark.parametrize(
    "lines, results",
    [
        (LINES, {"residential": "pass"}),
        (LINES, {}),
        ({"client_proxy": DC, "residential": None}, {}),
        ({"client_proxy": DC, "residential": RES_BY_DIRECT}, {"residential": "pass"}),
    ],
)
def test_reading_of_the_route_does_not_use_names_known_only_inside_the_skill(lines, results):
    reading = read_route(run_route_ladder(lines, RouteRunner(results)), lines)

    assert [t for t in texts(reading) if INTERNAL_TERMS.search(t)] == []


@pytest.mark.parametrize("results", [{2: ["pass"]}, {5: ["fail", "pass"]}])
def test_when_the_browser_opened_the_page_the_reading_notes_that_the_diagnosis_browser_differs_from_production(results):
    # 診断のブラウザは Chrome(WebGL を有効にして開く)。本番のブラウザは起動条件が違う
    reading = read_ladder(run_ladder(LINES, Runner(results)), LINES)

    assert any("--enable-unsafe-swiftshader" in n and "environment.md" in n for n in reading["notes"])


@pytest.mark.parametrize(
    "lines, results, reason",
    [
        (LINES, {0: ["pass"]}, "ブロッキング要因が確認できなかったため"),
        (LINES, {}, "どの条件でも通らなかったため"),
        ({"client_proxy": DC, "residential": None}, {}, "レジデンシャルの回線がなく、確かめられなかったため"),
        (LINES, {1: ["error"]}, "回線につながらず、診断できなかったため"),
        (LINES, {4: ["rate_limited"]}, "429 が返って止まり、診断できなかったため"),
    ],
)
def test_when_the_diagnosis_needs_nothing_the_reading_gives_the_reason_to_write_instead(lines, results, reason):
    # 出力では「診断が求めるもの: なし(<理由>)」と書く
    reading = read_ladder(run_ladder(lines, Runner(results)), lines)

    assert (reading["needs"], reading["no_needs_reason"]) == (None, reason)


def test_when_a_step_passed_there_is_no_reason_for_a_missing_need():
    reading = read_ladder(run_ladder(LINES, Runner({2: ["pass"]})), LINES)

    assert reading["needs"] is not None and reading["no_needs_reason"] is None


@pytest.mark.parametrize(
    "lines, results, reason",
    [
        (LINES, {}, "経路に従って遷移してもブロッキング回避できなかったため"),
        ({"client_proxy": DC, "residential": None}, {}, "レジデンシャルの回線がなく、経路遷移のテストが行えなかったため"),
    ],
)
def test_when_the_route_gives_no_need_the_reading_gives_the_reason(lines, results, reason):
    reading = read_route(run_route_ladder(lines, RouteRunner(results)), lines)

    assert (reading["needs"], reading["no_needs_reason"]) == (None, reason)


def test_when_the_browser_could_not_launch_on_any_line_the_route_is_left_undiagnosed_with_the_reason():
    # 起動できなかった(画面がない、コンテナがない)だけで、経路を辿って通らなかったわけではない
    run = RouteRunner({"client_proxy": "unavailable", "residential": "unavailable"})

    reading = read_route(run_route_ladder(LINES, run, with_client_proxy=True), LINES)

    assert (reading["layer"], reading["confidence"], reading["needs"]) == (None, None, None)
    assert reading["no_needs_reason"] == "ブラウザを起動できず、経路遷移のテストが行えなかったため"


def test_when_the_route_fails_on_one_line_and_the_browser_could_not_launch_on_the_other_that_line_is_noted_as_untried():
    run = RouteRunner({"client_proxy": "fail", "residential": "unavailable"})

    reading = read_route(run_route_ladder(LINES, run, with_client_proxy=True), LINES)

    assert reading["no_needs_reason"] == "経路に従って遷移してもブロッキング回避できなかったため"
    assert reading["notes"] == ["レジデンシャルの回線は、ブラウザを起動できず未実施"]


def _unconfirmed_for_production(notes):
    return any("本番のクライアント" in note and "未確認" in note for note in notes)


def test_when_only_the_line_matters_the_production_client_is_noted_as_unconfirmed():
    reading = read_ladder(run_ladder(LINES, Runner({3: ["pass"]})), LINES)

    assert _unconfirmed_for_production(reading["notes"])


def test_when_plain_curl_is_not_blocked_the_production_client_is_noted_as_unconfirmed_and_the_check_with_axios_is_suggested():
    reading = read_ladder(run_ladder(LINES, Runner({0: ["pass"]})), LINES)

    assert _unconfirmed_for_production(reading["notes"])
    assert any("--client axios" in step for step in reading["next"])


@pytest.mark.parametrize("n, line", [(1, "client_proxy"), (4, "residential")])
def test_when_curl_with_the_chrome_header_set_passes_every_try_a_plain_client_with_the_headers_is_recommended_without_a_browser(n, line):
    run = Runner({n: ["pass"], f"{n}h": ["pass"]})

    reading = read_ladder(run_ladder(LINES, run), LINES)

    assert reading["needs"]["client"] == "素のクライアント(Chrome のヘッダー一式を付ける)"
    assert reading["needs"]["browser"].startswith("不要")
    assert _unconfirmed_for_production(reading["notes"])


def test_when_the_route_is_outdated_the_reading_does_not_suspect_operation_data_and_asks_for_a_current_route():
    # 経路の途中のページが 404 なら、拒否ではなく経路が古い。そのとき、操作データを疑う読みを返さない
    def run(line):
        return {"result": "fail", "line": line["line"], "route_outdated": line["line"] == "residential"}

    reading = read_route(run_route_ladder(LINES, run, with_client_proxy=True), LINES)

    assert reading["layer"] is None
    assert reading["no_needs_reason"] == "保存した経路の途中のページが 404 で、経路遷移のテストが成立しなかったため"
    assert not any("操作データ" in step for step in reading["next"])
    assert any("経路" in step and "教えて" in step for step in reading["next"])


ROUTE_PAGES = ["https://shop.example.com/", "https://shop.example.com/list", "https://shop.example.com/item/1"]


@pytest.mark.parametrize("route_outdated, saved", [(True, 0), (False, 1)])
def test_a_route_judged_outdated_is_not_saved_as_a_failed_route_but_an_ordinary_failure_is(monkeypatch, tmp_path, route_outdated, saved):
    # 途中のページが 404 の経路を「全滅」と残すと、次回の「前回」の列が、拒否されたと読める
    import argparse

    from ladder import _save_route_results
    from routes_store import load_routes

    path = tmp_path / "routes.json"
    monkeypatch.setenv("BLOCKING_TRIAGE_ROUTES", str(path))
    route = {"records": [{"name": "residential", "outcome": {"result": "fail", "route": {"steps": ROUTE_PAGES}, "route_outdated": route_outdated}}]}

    _save_route_results({}, route, argparse.Namespace(no_history=False))

    routes = load_routes(path)["sites"].get("shop.example.com", {}).get("routes", [])
    assert sum(len(r["results"]) for r in routes) == saved
