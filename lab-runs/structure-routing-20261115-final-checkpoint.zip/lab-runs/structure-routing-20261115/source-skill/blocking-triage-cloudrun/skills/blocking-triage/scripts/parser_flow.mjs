#!/usr/bin/env node
/**
 * qcv3 のパーサー(launch({ initializer, worker }) を呼ぶ .ts / .js)から、遷移の骨組みを取り出す。④の経路づくり用。
 * コードは実行せず、TypeScript の構文木だけを読む(静的解析)。
 *
 *   node parser_flow.mjs <パーサーのパス>      例: node parser_flow.mjs src/example/kakakucom.ts
 *
 * 出力(JSON):
 *   start   initializer が作る起点のジョブ { kind, url_expr, meta_keys }
 *   edges   worker が、ある kind のページから作る子のジョブ { from, to, url_expr, selectors, text_filters, meta_keys }
 *             selectors      その kind の処理内で、DOM を探すために使っているセレクタ(querySelector 系の引数)
 *             text_filters   その kind の処理内で、`.includes('…')` に使っている語(リンクの絞り込みの手がかり)
 *   cases   kind ごとの要約(子のジョブの数、レコードの数)
 *   kinds   出てきた kind の一覧
 *   warnings 読み取れなかったこと
 *
 * 限界: URL の式(`a.href` や `${shopId}`)は、式の文字列のまま返す。値の解決は、コードを読む人(や Claude)が行う。
 * セレクタと語は、その kind の処理内のものを全部集めるので、遷移に関係ないものも混ざる。
 */
import fs from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ts = createRequire('/app/package.json')('typescript');

const SELECTOR_CALLS = new Set(['querySelector', 'querySelectorAll', 'closest', 'matches', '$', '$$', '$eval', '$$eval', 'locator']);

const textOf = (node) => (node ? node.getText() : null);
const literalValue = (node) =>
  node && (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) ? node.text : null;

function propertyName(prop) {
  return prop.name && (ts.isIdentifier(prop.name) || ts.isStringLiteral(prop.name)) ? prop.name.text : null;
}

function objectProperty(obj, name) {
  return obj.properties.find((p) => ts.isPropertyAssignment(p) && propertyName(p) === name);
}

function walk(node, visit) {
  visit(node);
  ts.forEachChild(node, (child) => walk(child, visit));
}

/** childJob({ kind, url, meta }) の呼び出しから、{ kind, url_expr, meta_keys } を取り出す */
function readChildJob(call) {
  const arg = call.arguments[0];
  if (!arg || !ts.isObjectLiteralExpression(arg)) return null;
  const kindProp = objectProperty(arg, 'kind');
  const urlProp = objectProperty(arg, 'url');
  const metaProp = objectProperty(arg, 'meta');
  const meta = metaProp && ts.isObjectLiteralExpression(metaProp.initializer) ? metaProp.initializer : null;
  return {
    kind: literalValue(kindProp?.initializer) ?? textOf(kindProp?.initializer),
    url_expr: textOf(urlProp?.initializer),
    meta_keys: meta ? meta.properties.map((p) => propertyName(p) ?? p.getText()).filter(Boolean) : [],
  };
}

const isCall = (node, name) =>
  ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression) && node.expression.name.text === name;

/** ある範囲の中の、childJob・セレクタ・絞り込みの語・レコードを集める */
function collect(root) {
  const childJobs = [];
  const selectors = [];
  const textFilters = [];
  let records = 0;
  walk(root, (node) => {
    if (isCall(node, 'childJob')) {
      const job = readChildJob(node);
      if (job) childJobs.push({ ...job, line: node.getSourceFile().getLineAndCharacterOfPosition(node.getStart()).line + 1 });
    } else if (isCall(node, 'childRecord')) {
      records++;
    } else if (ts.isCallExpression(node) && ts.isPropertyAccessExpression(node.expression)) {
      const name = node.expression.name.text;
      const first = literalValue(node.arguments[0]);
      if (SELECTOR_CALLS.has(name) && first !== null) selectors.push(first);
      if (name === 'includes' && first !== null) textFilters.push(first);
    }
  });
  return { childJobs, selectors: [...new Set(selectors)], textFilters: [...new Set(textFilters)], records };
}

/** switch (job.kind) の case、または if (job.kind === 'X') の枝を、{ kind, node } の並びにする */
function findKindBranches(workerFn) {
  const branches = [];
  const isJobKind = (n) => n && ts.isPropertyAccessExpression(n) && n.name.text === 'kind' && ts.isIdentifier(n.expression);
  walk(workerFn, (node) => {
    if (ts.isSwitchStatement(node) && isJobKind(node.expression)) {
      for (const clause of node.caseBlock.clauses) {
        const kind = ts.isCaseClause(clause) ? literalValue(clause.expression) : null;
        if (kind) branches.push({ kind, node: clause });
      }
    }
    if (ts.isIfStatement(node) && ts.isBinaryExpression(node.expression)) {
      const { left, right, operatorToken } = node.expression;
      if ([ts.SyntaxKind.EqualsEqualsEqualsToken, ts.SyntaxKind.EqualsEqualsToken].includes(operatorToken.kind)) {
        const kind = isJobKind(left) ? literalValue(right) : isJobKind(right) ? literalValue(left) : null;
        if (kind) branches.push({ kind, node: node.thenStatement });
      }
    }
  });
  return branches;
}

export function analyzeParser(sourceText, fileName = 'parser.ts') {
  const scriptKind = /\.[cm]?jsx?$/.test(fileName) ? ts.ScriptKind.JS : ts.ScriptKind.TS;
  const source = ts.createSourceFile(fileName, sourceText, ts.ScriptTarget.Latest, true, scriptKind);
  const out = { file: fileName, start: [], edges: [], cases: [], kinds: [], warnings: [] };

  let launchArg = null;
  walk(source, (node) => {
    if (!launchArg && ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'launch') {
      const arg = node.arguments[0];
      if (arg && ts.isObjectLiteralExpression(arg)) launchArg = arg;
    }
  });
  if (!launchArg) {
    out.warnings.push('launch({ ... }) の呼び出しが見つからない');
    return out;
  }

  const functionOf = (name) => {
    const prop = objectProperty(launchArg, name);
    const init = prop?.initializer;
    return init && (ts.isArrowFunction(init) || ts.isFunctionExpression(init)) ? init : null;
  };

  const initializer = functionOf('initializer');
  if (initializer) {
    out.start = collect(initializer).childJobs.map(({ kind, url_expr, meta_keys }) => ({ kind, url_expr, meta_keys }));
  } else {
    out.warnings.push('initializer が見つからない');
  }

  const worker = functionOf('worker');
  const kinds = new Set(out.start.map((s) => s.kind).filter(Boolean));
  if (worker) {
    const branches = findKindBranches(worker);
    if (branches.length === 0) out.warnings.push('worker に switch (job.kind) / if (job.kind === …) が見つからない');
    for (const { kind, node } of branches) {
      const found = collect(node);
      kinds.add(kind);
      out.cases.push({ kind, child_jobs: found.childJobs.length, records: found.records });
      for (const c of found.childJobs) {
        kinds.add(c.kind);
        out.edges.push({
          from: kind,
          to: c.kind,
          url_expr: c.url_expr,
          selectors: found.selectors,
          text_filters: found.textFilters,
          meta_keys: c.meta_keys,
          line: c.line,
        });
      }
    }
  } else {
    out.warnings.push('worker が見つからない');
  }
  out.kinds = [...kinds].filter(Boolean);
  return out;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const file = process.argv[2];
  if (!file) {
    console.error('使い方: parser_flow.mjs <パーサーのパス(.ts / .js)>');
    process.exit(2);
  }
  console.log(JSON.stringify(analyzeParser(fs.readFileSync(file, 'utf8'), file), null, 2));
}
