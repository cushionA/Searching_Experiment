// body_decode.mjs のテスト。実行: node --test .claude/skills/blocking-triage/scripts/tests/
import assert from 'node:assert/strict';
import { test } from 'node:test';

import { decode } from '../body_decode.mjs';

// Amazon の 503(ご迷惑をおかけしています！)の頭。応答のヘッダーは text/html だけで、文字コードは本文の meta にしかない
const AMAZON_503_SJIS = Buffer.from(
  '3c68746d6c3e3c686561643e3c4d45544120485454502d45515549563d22436f6e74656e742d547970652220636f6e74656e743d22746578742f68746d6c3b20636861727365743d53686966745f4a4953223e3c7469746c653e82b296c0986682f082a882a982af82b582c482a282dc82b781493c2f7469746c653e3c2f686561643e3c2f68746d6c3e',
  'hex',
);

test('decode: ヘッダーに文字コードがないとき、本文の meta の文字コードで読むこと', () => {
  assert.match(decode(AMAZON_503_SJIS, 'text/html'), /<title>ご迷惑をおかけしています！<\/title>/);
});

test('decode: ヘッダーの文字コードがあるとき、それを優先すること', () => {
  assert.equal(decode(Buffer.from('<title>ok</title>'), 'text/html; charset=utf-8'), '<title>ok</title>');
});
