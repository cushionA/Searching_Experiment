# 環境の構成(qcv3 のクローラー)

診断が求めるもの(`reading.needs`)を、この環境で満たす構成に当てはめるための情報。SKILL.md の手順 7 が読む。環境が変わったら、ここを直す。

- 確認日: 2026-10-27
- 版のように変わりやすい値は写さず、読む場所を書く
- 「未確認」は、リポジトリから読めない。ユーザーに聞いて埋める

## 使えるクライアント

対象は、このリポジトリの qcv3(`@keywalker/queueing-crawler-v3`。版は `package.json`)で使えるもの。

| クライアント | 呼び方 | 制約 |
|---|---|---|
| Basic | `getBasicClient`(`request` ライブラリ) | HTTP/1.1。TLS は Node が作る。`gzip: true` がないと、圧縮された本文を展開しない |
| Axios | `getAxiosClient`(`AxiosClient`) | HTTP/1.1。TLS は Node が作る(プロキシ経由では、プロキシが作る)。プロキシは host・port・protocol だけを渡し、認証情報(user:pass)を捨てる。ヘッダーは `fetchResponse` の `axiosOptions.headers` で足せる。Node 20 は zstd を展開できない |
| Puppeteer / Playwright | `getPuppeteerBrowser` / `getPuppeteerPage` / `getPlaywright` | ブラウザ系。ベースイメージのブラウザで起動する |
| Patchright | `webClient.getPatchright()`([src/example/patchright.ts](../../../../src/example/patchright.ts)) | ブラウザ系。既定は下の「Patchright の既定」 |

curl_cffi は qcv3 のクライアントではない。診断で「curl_cffi で通る」と出ても、原因の層を示す証拠で、そのまま本番に入れられる対策ではない。

## Patchright の既定

読む場所: `.env.example`、[docs/qcv3/qcv3-patchright-migration.md](../../../../docs/qcv3/qcv3-patchright-migration.md)

| 項目 | 既定 |
|---|---|
| 永続コンテキスト(`CLIENT_PATCHRIGHT_PERSISTENT`) | しない(`launch()` + `newContext()`) |
| ヘッドレス(`CLIENT_PATCHRIGHT_HEADLESS`) | しない(ヘッドフル) |
| リソース種別のブロック(`CLIENT_PATCHRIGHT_ENABLE_RESOURCE_TYPE_BLOCKING`) | する |
| User-Agent(`CLIENT_USER_AGENT`) | 空文字のままにする(Patchright が独自の UA を保つため。上書きは非推奨) |
| プロキシ | `CLIENT_PROXY` を `server` にそのまま渡す。認証情報は別に渡さない |
| ブラウザの実行ファイル | `/usr/local/bin/browser`(ベースイメージのブラウザへのリンク) |
| ロケール・タイムゾーン | `ja` / `Asia/Tokyo` |
| WebGL | `CLIENT_PUPPETEER_CHROMIUM_ARGS` の既定(`.env.example`)に `--enable-unsafe-swiftshader` がなく、`--disable-gpu` が入っている |

## ブラウザとベースイメージ

読む場所: `Dockerfile` の `ARG BASE_IMAGE`、`.devcontainer/compose.yaml`

- 既定は Chromium 版(`chromium-base`)。Chrome 版は `chrome-base`
- 切り替えは、`Dockerfile` の `ARG BASE_IMAGE` の既定値を書き換える(手順は [docs/qcv3/qcv3-patchright-migration.md](../../../../docs/qcv3/qcv3-patchright-migration.md) の「ブラウザの選択」)
- devcontainer で Chrome を使うときは、`.devcontainer/compose.yaml` の `BASE_IMAGE` のコメントアウトを外し、`shm_size` も有効にする(ヘッドフルの Chrome が落ちるのを防ぐ)
- イメージの中のブラウザの版は、イメージで確かめる。診断のブラウザ(Google Chrome の安定版)より古くないかを見る

## 回線

- **データセンター**: `CLIENT_PROXY`。既定はクラスタ内の `proxy-gcp`(`src/utils/envs.ts`、`README.md` の `CLIENT_PROXY` の行)。GKE の worker と同じ経路
- **レジデンシャル**: 未確認(プロキシがあるか、手配済みか)。使うときは、`CLIENT_PROXY` の向き先を差し替える
- **認証つき(user:pass)のプロキシ**: Axios は認証情報を渡さず、Patchright も `server` に URL をそのまま入れるだけなので、認証を通せない見込み(Patchright で通らないことは未確認)。使うには、IP 許可型のプロキシにするか、qcv3 側で認証を渡す対応が要る
- **間隔と並列**: `createExecute` の `intervalMs` と、同時実行数

## 診断のブラウザとの違い

診断のブラウザは、nodriver(CDP で直接操作)で起動した Google Chrome の安定版で、WebGL を有効にし、毎回新しいプロファイルで開き、リソースのブロックをしない。qcv3 の Patchright とは、自動化のライブラリが違う。上の既定とは違うので、「診断で開けた」が「qcv3 で開ける」を保証しない。推奨構成を出すときは、この違いを「確認できていないこと」に書く。

## 診断が求めるものの当てはめ

`reading.needs` の `client`・`browser`・`line` を、次の表から選ぶ。`browser` が「Google Chrome」のときは、Chrome 版のベースイメージにし、中の Chrome の版が、診断で通った版より古くないかを確かめる。Chromium で通るかは確かめていないので、ベースイメージを Chromium のままにする案は、「確認できていないこと」に書く。

| 求めるもの(client) | クライアント | ブラウザ | 備考 |
|---|---|---|---|
| Chrome をまねない素のクライアント | Axios(Basic) | 不要 | 診断の基準は素の curl(HTTP/2、TLS は OpenSSL)。本番の Axios・Basic は HTTP/1.1 で、TLS は Node が作る。同じ結果になるかは確かめていないので、「確認できていないこと」に書く。確かめるには、qcv3 のある環境で `--client axios` を付けて回す |
| 素のクライアント(Chrome のヘッダー一式を付ける) | Axios | 不要 | `axiosOptions.headers` に、下の「Chrome のヘッダー一式」を付ける。本番の Axios で通るかは確かめていないので、上の行と同じく「確認できていないこと」に書く |
| Axios のまま(Basic のまま) | Axios(Basic) | 不要 | `--client axios`・`--client basic` で診断したときの行。本番のクライアントそのもので確かめている |
| Axios(Chrome のヘッダー一式を付ける) | Axios | 不要 | `--client axios` で診断したときの行。`axiosOptions.headers` に、下の「Chrome のヘッダー一式」を付ける |
| Chrome と同じ接続の作り方(ブラウザ系。ブラウザで通るかは未確認) | Patchright | Chrome 版のベースイメージ | Axios の TLS は設定で変えられない。ブラウザで通るかは確かめていないので、「確認できていないこと」に書く(同じ回線で `browser_run.py` を回すと確かめられる) |
| JS を実行するブラウザ | Patchright | Chrome 版のベースイメージ | Chromium で通るかは未確認 |
| JS を実行するブラウザ(トップページを開いてから、location.href で移る) | Patchright。トップページを開いてから `location.href` で移る | 同上 | 効いたのが Referer・トップの cookie・ページ内からの遷移のどれかは分からない |
| JS を実行するブラウザ(経路を辿る) | Patchright。通った手と同じ遷移をパーサーに入れる | 同上 | |

| 求めるもの(line) | 回線 |
|---|---|
| 今のデータセンターの回線のまま | 今の `CLIENT_PROXY` のまま |
| レジデンシャル | `CLIENT_PROXY` の向き先をレジデンシャルのプロキシに差し替える(手配が要る) |

そのほかの当てはめは次のとおり。

- 429 のときは、間隔(`intervalMs`)と同時実行数を見直す
- ブラウザで得た cookie を軽いクライアントに渡す案で、qcv3 の受け手になれるのは Basic と Axios。どちらも HTTP/1.1 で、TLS は Node が作る。この案を推奨構成に出すのは、Axios が `blocked` にならず、チャレンジまで進むときだけにして、「要確認」を付ける

## Chrome のヘッダー一式

診断の `ladder.py` が curl(`--client axios` のときは Axios)に付けるヘッダー(`probe.py` の `AXIOS_CHROME_HEADERS`)。Chrome 155(Linux)が実際に送った 13 個を、同じ順序で付ける。`accept-encoding` だけは、Node 20 が展開できない `zstd` を外している(zstd で返されると、本文が読めない)。パーサーに入れるときも、同じ値にする。

| ヘッダー | 値 |
|---|---|
| `sec-ch-ua` | `"Google Chrome";v="155", "Chromium";v="155", "Not(A:Brand";v="24"` |
| `sec-ch-ua-mobile` | `?0` |
| `sec-ch-ua-platform` | `"Linux"` |
| `upgrade-insecure-requests` | `1` |
| `user-agent` | `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36` |
| `accept` | `text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7` |
| `sec-fetch-site` | `none` |
| `sec-fetch-mode` | `navigate` |
| `sec-fetch-user` | `?1` |
| `sec-fetch-dest` | `document` |
| `accept-encoding` | `gzip, deflate, br` |
| `accept-language` | `ja,en-US;q=0.9,en;q=0.8` |
| `priority` | `u=0, i` |

`sec-ch-ua` と `user-agent` の版は、診断のときの Chrome の安定版。版を上げるときは、`probe.py` の `CHROME_UA` と `CHROME_HEADERS` を一緒に直す。
