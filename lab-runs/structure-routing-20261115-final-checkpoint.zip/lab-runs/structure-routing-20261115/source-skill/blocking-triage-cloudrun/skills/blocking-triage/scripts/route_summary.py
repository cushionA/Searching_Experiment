"""browser_probe.py(③)と browser_route.py(④)の結果を、classify で判定し直して、読みやすい要約にする(純関数)。

ブラウザ側(route_lib.py の looks_blocked)は status・タイトル・チャレンジの要素の有無だけで通過を決めている。
ここで本文・ヘッダー・cookie も使って判定し直し、チャレンジのページを通過にしない。
本文は先頭しか残らないので、タイトルはブラウザで取ったものを渡す。
"""

from __future__ import annotations

import os

from browser_env import env_flags, read_fingerprint
from classify import classify

HOW_LINK_MISSING = "goto(リンクなし)"  # route_lib.py の HOW_LINK_MISSING と同じ値


def _verdict(p: dict) -> dict:
    return classify(p.get("status") or 0, p.get("headers", {}), p.get("cookie_names", []), p.get("body_head", ""), p.get("title"))


def summarize_browser_probe(d: dict) -> dict:
    """browser_probe.py(③)の結果。本文は出さない。

    指紋(fingerprint)と、ページの JS から見える値の手がかり(env_flags)も読む。開けなかったときに、
    どの層の情報が Chrome と違うかを挙げるため。since_last_request_sec は、同じホストへの直前のリクエスト
    (probe など)からの秒数で、直後だと結果が悪く出ることがある。
    """
    timing = {"engine": d.get("engine", "nodriver"), "line": d.get("line"), "since_last_request_sec": d.get("since_last_request_sec"),
              "cooldown_waited_sec": d.get("cooldown_waited_sec")}  # fmt: skip
    if not d.get("ok"):
        return {"ok": False, "error": d.get("error"), **timing}
    keep = ("first_status", "status", "challenge_unresolved", "final_url", "title", "user_agent", "webdriver", "headless", "cookie_names", "js_env")
    if os.environ.get("BT_KEEP_BODY"):
        keep += ("body_head", "language", "languages", "timezone")
    fp = read_fingerprint({"user_agent": d.get("user_agent"), **(d.get("fingerprint") or {})} if d.get("fingerprint") else None)
    # 切り分けとして返すのは、接続の層が Chrome と同じかどうかだけ。項目ごとの値は fingerprint・env_flags に残す
    if fp["ja4_ciphers_match_chrome"] is None or fp["h2_matches_chrome"] is None:
        connection_layer = "未確認"
    else:
        connection_layer = "Chrome と同じ" if fp["ja4_ciphers_match_chrome"] and fp["h2_matches_chrome"] else "Chrome と違う"
    return {
        "ok": True,
        **timing,
        "connection_layer": connection_layer,
        **{k: d.get(k) for k in keep},
        **_verdict(d),
        "fingerprint": fp,
        "env_flags": env_flags(d.get("user_agent"), d.get("webdriver"), d.get("js_env")),
    }


def _summarize_page(p: dict) -> dict:
    verdict = _verdict(p)
    return {
        "kind": p.get("kind"),
        "how": p.get("how"),
        "status": p.get("status"),
        "title": p.get("title"),
        "url": p.get("url"),
        "class": verdict["kind"],
        "vendors": verdict["vendors"],
        "abck_state": p.get("abck_state"),
    }


def _summarize_trial(t: dict) -> dict:
    pages = [_summarize_page(p) for p in t.get("pages", [])]
    # サイトの「ページが見つかりません」(404・410)は、拒否ではない。経路のページが今のサイトにない(経路が古い)
    not_found_at = next((i for i, p in enumerate(pages) if p["class"] == "error" and p["status"] in (404, 410)), None)
    blocked_at = next((i for i, p in enumerate(pages) if p["class"] != "ok" and i != not_found_at), None)
    # リンクが見つからず直接遷移に切り替えたページ(browser_route.py の HOW_LINK_MISSING)は、クリックで辿れていない
    link_missing_at = next((i for i, p in enumerate(pages) if p["how"] == HOW_LINK_MISSING), None)
    reached_target = bool(pages) and pages[-1]["kind"] == "target"
    return {
        "passed": reached_target and blocked_at is None and not_found_at is None and link_missing_at is None and not t.get("error"),
        "blocked_at": blocked_at,
        "not_found_at": not_found_at,
        "link_missing_at": link_missing_at,
        "error": t.get("error"),
        "actions": t.get("actions"),
        "warmup": t.get("warmup"),
        "elapsed_ms": t.get("elapsed_ms"),
        "pages": pages,
    }


def _reading(
    first: dict | None,
    any_split: bool,
    stopped: str | None,
    plain_click_failed: bool,
    resolution: dict | None = None,
    all_modes: bool = False,
    plain_location_failed: bool = False,
) -> str:
    if stopped == "resolve_failed":
        i = (resolution or {}).get("failed_at")
        return (
            f"計画の {i} 手目のセレクタに合う、見えているリンクが見つからなかった。パーサーの読み違いか、ページの変更、"
            "または JS で描画される前の可能性がある。セレクタ(と text_includes・url_prefix)を見直す"
        )
    if stopped == "resolve_blocked":
        i = (resolution or {}).get("failed_at")
        return f"経路の解決中に、計画の {i} 番目のページで拒否された。目的ページ以前の問題なので、ブラウザで直接開けるかの確認までの層に戻る"
    if first is not None:
        name, humanize = first["name"], first["humanize"]
        if name == "direct":
            text = "目的ページを直接開いても通る(すべての試行)。この経路の問題としては再現しなかった"
        elif name == "location":
            text = (
                "手前のページから location.href で移ると通る。クリックは要らない。"
                "ページ内からの遷移として届くこと(Sec-Fetch-Site: same-origin など)が候補"
            )
        elif name == "warmup_location":
            accepted = all((t.get("warmup") or {}).get("accepted") for t in first["trials"])
            tried = "操作なしの location.href では通らなかったので、" if plain_location_failed else "操作なしの location.href は試していないので、"
            if not accepted:
                text = (
                    "最初のページで操作してから location.href で移ると通ったが、_abck は合格しなかった。_abck の合格は通過の条件ではない。"
                    + (f"{tried}最初のページでの操作(操作データ)が候補" if plain_location_failed else f"{tried}操作が効いたかは分からない")
                )
            else:
                text = (
                    "最初のページで _abck が合格するまで操作してから location.href で移ると通る。"
                    + (f"{tried}_abck の合格(操作データの採点)が候補" if plain_location_failed else f"{tried}_abck の合格と遷移のどちらが効いているかは分からない")
                )
        elif humanize != "none" and plain_click_failed:
            text = f"操作({humanize})を足したクリック遷移で通る。操作なしのクリックでは通らなかったので、操作データの採点が候補"
        elif humanize != "none":
            text = (
                f"操作({humanize})を足したクリック遷移で通る。操作なしのクリックは試していないので、"
                "クリックと操作のどちらが効いているかは分からない(--escalate で、操作を 1 つずつ足して絞る)"
            )
        else:
            text = "実際のクリック遷移で通る。クリックが付ける遷移の情報(Sec-Fetch-* など)や、遷移元のページの種類が候補"
        return text
    if stopped == "passed" and not all_modes:
        return (
            "ブラウザ側では通過と見て止まったが、本文・ヘッダーで判定し直すと、通過した移り方はなかった。残りの移り方は試していない。"
            "--all-modes を付けて再実行する"
        )
    if stopped == "route_blocked":
        return "経路の入口(最初のページ)で拒否された。目的ページ以前の問題なので、ブラウザで直接開けるかの確認までの層(回線・接続・JS の判定)に戻る"
    if any_split:
        return "通る試行と拒否される試行が混在していて(割れ)、決められない。回数を増やして、割合で判断する"
    return "試した経路では通らない。操作データ(--escalate)、回線、ブラウザの版・種類、自動化の痕跡も疑う"


def summarize_route(d: dict) -> dict:
    modes = []
    first = None
    plain_click_failed = False
    warmup_skipped = False
    for m in d.get("modes", []):
        trials = [_summarize_trial(t) for t in m.get("trials", [])]
        passes = sum(1 for t in trials if t["passed"])
        total = len(trials)
        outcome = "pass" if total > 0 and passes == total else "fail" if passes == 0 else "split"
        if m.get("skipped"):
            # warmup は、それまでの試行で _abck が付かなかったサイトでは試さない(browser_route.py)
            outcome = "skipped"
            warmup_skipped = True
        modes.append(
            {
                "name": m["name"],
                "humanize": m.get("humanize", "none"),
                "label": m.get("label"),
                "outcome": outcome,
                "passes": passes,
                "total": total,
                "trials": trials,
            }
        )
        if m["name"] == "click" and m.get("humanize", "none") == "none" and outcome != "pass":
            plain_click_failed = True
        if outcome == "pass" and first is None:
            first = modes[-1]

    reading = _reading(
        first,
        any(m["outcome"] == "split" for m in modes),
        d.get("stopped"),
        plain_click_failed,
        d.get("resolution"),
        bool((d.get("params") or {}).get("all_modes")),
        any(m["name"] == "location" and m["outcome"] != "pass" for m in modes),
    )
    # どの試行も、経路の途中のページが 404 だった。拒否ではなく、保存した経路が今のサイトに合っていない(リンクが見つからないのも同じ原因)
    tried = [t for m in modes if m["outcome"] != "skipped" for t in m["trials"]]
    route_outdated = first is None and bool(tried) and all(t["not_found_at"] is not None for t in tried)
    link_missing = sum(1 for m in modes for t in m["trials"] if t["link_missing_at"] is not None)
    if route_outdated:
        reading = "経路の途中のページが、サイトの「ページが見つかりません」(404)だった。拒否ではなく、保存した経路が古い(今のサイトに合っていない)可能性が高い。今の経路を確かめ直す"
    elif link_missing:
        note = (
            f"クリックで辿る移り方で、次のページへのリンクが見つからず直接遷移に切り替わった試行が {link_missing} 回ある"
            "(クリックの結果としては数えていない)。リンクの探し方か、経路に渡したページを見直す"
        )
        reading = note if first is None else f"{note}。{reading}"
    if warmup_skipped:
        reading = f"{reading}。_abck が合格するまで操作してから移る確認は、_abck が付かなかった(Akamai ではない)ので試していない"
    return {
        "target_url": d.get("target_url"),
        "line": (d.get("params") or {}).get("line"),
        "user_agent": (d.get("params") or {}).get("user_agent"),
        "steps": d.get("steps"),
        "seed": d.get("seed"),
        "request_count": d.get("request_count"),
        "stopped": d.get("stopped"),
        "route_outdated": route_outdated,
        "first_passing_mode": first["name"] if first else None,
        "first_passing_humanize": first["humanize"] if first else None,
        "reading": reading,
        "plan": d.get("plan"),
        "resolution": d.get("resolution"),
        "modes": modes,
    }
