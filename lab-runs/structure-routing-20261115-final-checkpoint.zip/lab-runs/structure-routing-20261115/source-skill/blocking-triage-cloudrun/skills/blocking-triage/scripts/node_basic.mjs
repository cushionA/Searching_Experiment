// qcv3 の Basic クライアント(getBasicClient)と同じ request ライブラリで 1 URL を取得し、結果を JSON で標準出力に出す。
// 接続の作り方は Node の TLS(OpenSSL)と HTTP/1.1。Axios も同じ系統。probe.py の basic の行に使う。
// 使い方: echo '{"url":"https://example.com/","userAgent":"...","proxy":null}' | node node_basic.mjs
import fs from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { decode } from './body_decode.mjs';

// request は qcv3 の依存。pnpm はリポジトリ直下に置かないので、qcv3 の実体の場所から解決する
const QCV3_PACKAGE = '/app/node_modules/@keywalker/queueing-crawler-v3/package.json';
const request = createRequire(fs.realpathSync(QCV3_PACKAGE))('request');

const MAX_REDIRECTS = 5;

function setCookieNames(headers) {
  return [headers?.['set-cookie'] ?? []].flat().map((c) => c.split('=', 1)[0].trim());
}

/** Basic と同じ設定(encoding: null、cookie の jar、user-agent だけ)で取得する。cookie は名前だけ返す。 */
export function fetchBasic({ url, proxy = null, userAgent, timeoutMs = 20000 }) {
  const started = Date.now();
  const cookieNames = [];
  return new Promise((resolve) => {
    const req = request(
      url,
      {
        encoding: null,
        proxy: proxy || undefined,
        jar: request.jar(),
        headers: { 'user-agent': userAgent },
        timeout: timeoutMs,
        maxRedirects: MAX_REDIRECTS,
      },
      (err, res) => {
        if (err) return resolve({ error: `${err.code ?? err.name}: ${String(err.message).slice(0, 200)}` });
        cookieNames.push(...setCookieNames(res.headers));
        resolve({
          status: res.statusCode,
          http_version: `http/${res.httpVersion}`,
          final_url: res.request.uri.href,
          elapsed_ms: Date.now() - started,
          headers: Object.fromEntries(
            Object.entries(res.headers)
              .filter(([k]) => k !== 'set-cookie') // cookie の値は出さない
              .map(([k, v]) => [k, [v].flat().join(', ')]),
          ),
          cookie_names: [...new Set(cookieNames)].sort(),
          body: decode(res.body ?? Buffer.alloc(0), res.headers['content-type']),
        });
      },
    );
    req.on('redirect', function onRedirect() {
      cookieNames.push(...setCookieNames(this.response.headers)); // 途中の応答の cookie も拾う
    });
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const input = JSON.parse(fs.readFileSync(0, 'utf8'));
  process.stdout.write(JSON.stringify(await fetchBasic(input)));
}
