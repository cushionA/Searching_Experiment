"""state.py のテスト。サイトごとの結果の履歴と、直前のリクエストの時刻。実行: uv run --with pytest pytest .claude/skills/blocking-triage/scripts/tests"""

from state import (
    append_history,
    attach_previous,
    history_records,
    load_history,
    record_browser,
    since_last_request,
    touch_last_request,
)

URL = "https://jp.indeed.com/jobs?q=engineer"


def row(egress="direct", client="curl_cffi", kind="ok", status=200, **extra):
    return {"egress": egress, "client": client, "ok": True, "status": status, "kind": kind,
            "vendors": ["cloudflare"], "title": "求人", "cookie_names": ["__cf_bm"], "body_head": "<html>", **extra}


def test_records_keep_the_verdict_and_the_asn_of_the_line_but_not_bodies_or_cookies():
    [rec] = history_records(URL, [row()], at="2026-10-15T10:00:00+09:00", asn="AS2527")
    assert rec == {"at": "2026-10-15T10:00:00+09:00", "url": URL, "egress": "direct", "asn": "AS2527", "client": "curl_cffi",
                   "status": 200, "kind": "ok", "vendors": ["cloudflare"], "title": "求人"}


def test_previous_result_of_the_same_egress_and_client_is_attached_and_a_change_is_marked(tmp_path):
    path = tmp_path / "history.jsonl"
    append_history(path, history_records(URL, [row(kind="ok"), row(client="basic", kind="blocked", status=403)], at="2026-10-15T10:00:00+09:00"))
    append_history(path, history_records(URL, [row(kind="blocked", status=403)], at="2026-10-16T10:00:00+09:00"))

    [now] = attach_previous([row(kind="blocked", status=403)], URL, load_history(path))
    assert now["previous"] == {"at": "2026-10-16T10:00:00+09:00", "status": 403, "kind": "blocked"}
    assert now["changed"] is False

    [now_basic] = attach_previous([row(client="basic", kind="ok")], URL, load_history(path))
    assert now_basic["previous"]["kind"] == "blocked"
    assert now_basic["changed"] is True


def test_missing_history_file_is_empty(tmp_path):
    assert load_history(tmp_path / "none.jsonl") == []


def browser_run(started_at, kind="ok", status=200, engine="nodriver", proxy=None, line=None, browser=None):
    applied = {"proxy": proxy, **({"browser": browser} if browser else {})}
    d = {"url": URL, "engine": engine, "started_at": started_at, "applied": applied, **({"line": line} if line else {})}
    return d, {"ok": True, "status": status, "kind": kind, "vendors": ["cloudflare"], "title": "求人"}


def test_browser_result_returns_the_previous_run_and_is_recorded_once_per_run(tmp_path):
    path = tmp_path / "history.jsonl"
    assert record_browser(path, *browser_run("2026-10-15T10:00:00+09:00", kind="challenge", status=403)) is None
    # 同じ JSON を --classify-json に 2 回かけても、前回は 1 つ前の実行のままで、履歴は増えない
    for _ in range(2):
        prev = record_browser(path, *browser_run("2026-10-16T10:00:00+09:00"))
        assert prev == {"at": "2026-10-15T10:00:00+09:00", "status": 403, "kind": "challenge"}
    assert [(h["egress"], h["client"], h["kind"]) for h in load_history(path)] == [
        ("direct", "nodriver", "challenge"),
        ("direct", "nodriver", "ok"),
    ]


def test_browser_result_through_a_proxy_without_a_recorded_line_is_recorded_as_client_proxy(tmp_path):
    # 回線を記録していない、以前の JSON の読み方
    path = tmp_path / "history.jsonl"
    record_browser(path, *browser_run("2026-10-16T10:00:00+09:00", engine="nodriver", proxy="gke.example.com:57884"))
    [rec] = load_history(path)
    assert (rec["egress"], rec["client"]) == ("client_proxy", "nodriver")


def test_browser_result_is_compared_with_the_previous_run_on_the_line_it_recorded(tmp_path):
    # データセンターとレジデンシャルは、どちらもプロキシ経由なので、プロキシの有無では見分けられない
    path = tmp_path / "history.jsonl"
    record_browser(path, *browser_run("2026-10-15T10:00:00+09:00", kind="challenge", proxy="gke.example.com:57884", line="client_proxy"))

    prev = record_browser(path, *browser_run("2026-10-16T10:00:00+09:00", proxy="res.example.com:8000", line="residential"))

    assert prev is None
    assert [(h["egress"], h["kind"]) for h in load_history(path)] == [("client_proxy", "challenge"), ("residential", "ok")]


def test_last_request_time_is_kept_per_host_as_the_file_mtime(tmp_path):
    # browser_run.py が since_last_request で読む
    touch_last_request(tmp_path, URL, now=1000.0)
    assert (tmp_path / "last" / "jp.indeed.com").stat().st_mtime == 1000.0
    assert not (tmp_path / "last" / "zozo.jp").exists()


def test_previous_result_is_taken_only_from_the_same_asn_because_the_local_line_changes_from_day_to_day(tmp_path):
    # 手元の回線は、日によって BIGLOBE(AS2518)だったり So-net(AS2527)だったりする。どちらも direct として残る
    path = tmp_path / "history.jsonl"
    append_history(path, history_records(URL, [row(kind="ok")], at="2026-10-19T10:00:00+09:00", asn="AS2518"))
    append_history(path, history_records(URL, [row(kind="blocked", status=403)], at="2026-10-20T10:00:00+09:00", asn="AS2527"))

    [now] = attach_previous([row(kind="blocked", status=403)], URL, load_history(path), asn="AS2518")

    assert now["previous"]["at"] == "2026-10-19T10:00:00+09:00"
    assert now["changed"] is True


def test_results_recorded_before_the_asn_was_kept_are_not_used_as_the_previous_result(tmp_path):
    path = tmp_path / "history.jsonl"
    append_history(path, history_records(URL, [row(kind="ok")], at="2026-10-20T10:00:00+09:00"))

    [now] = attach_previous([row(kind="blocked", status=403)], URL, load_history(path), asn="AS2527")

    assert (now["previous"], now["changed"]) == (None, None)


def test_browser_result_is_compared_only_with_the_same_kind_of_browser(tmp_path):
    # zozo.jp は、Chromium 132 は拒否し、Chrome 155 は開けた(2026-10-19)。違うブラウザと比べると、変化に見える
    path = tmp_path / "history.jsonl"
    record_browser(path, *browser_run("2026-10-20T10:00:00+09:00", line="direct", browser="chrome"), asn="AS2527")
    record_browser(path, *browser_run("2026-10-21T10:00:00+09:00", kind="blocked", status=403, line="direct", browser="chromium"), asn="AS2527")

    prev = record_browser(path, *browser_run("2026-10-22T10:00:00+09:00", kind="blocked", status=403, line="direct", browser="chromium"), asn="AS2527")

    assert prev == {"at": "2026-10-21T10:00:00+09:00", "status": 403, "kind": "blocked"}
    assert [(h["browser"], h["asn"]) for h in load_history(path)][-1] == ("chromium", "AS2527")


def test_seconds_since_the_last_request_are_read_from_the_per_host_file(tmp_path):
    touch_last_request(tmp_path, URL, now=1000.0)
    assert since_last_request(tmp_path, URL, now=1042.5) == 42.5


def test_seconds_since_the_last_request_are_none_for_a_host_never_requested(tmp_path):
    touch_last_request(tmp_path, URL, now=1000.0)
    assert since_last_request(tmp_path, "https://zozo.jp/", now=1042.5) is None
