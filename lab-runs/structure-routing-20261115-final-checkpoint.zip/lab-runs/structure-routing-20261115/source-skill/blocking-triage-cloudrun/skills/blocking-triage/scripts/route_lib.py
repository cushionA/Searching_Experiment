"""browser_route.py の、ブラウザに依存しない部分(手の定義、経路の組み立て、リンクの選び方、通過の判定、操作の計画)。

乱数は引数で渡す。テストでは種を固定した mulberry32 を使う(以前の Node 版 route_lib.mjs と同じ並びを返す)。
"""

from __future__ import annotations

import math
import re
from urllib.parse import urljoin, urlsplit

BLOCK_TITLE = re.compile(r"access denied|blocked|forbidden|just a moment|security check|checking your browser|attention required", re.IGNORECASE)


def looks_blocked(status: int | None, title: str | None, challenge: bool = False) -> bool:
    """ブロックされたように見えるか。根拠は status・タイトル・チャレンジの要素があるか(challenge)だけ。詳細な判定は classify.py。"""
    return challenge or (status or 0) >= 400 or bool(BLOCK_TITLE.search(title or ""))


# click の手に足す操作。後ろの水準ほど、前の水準の操作を全部含む
HUMANIZE_LEVELS = ["none", "dwell", "scroll", "mouse"]


def humanize_flags(level: str) -> dict:
    i = HUMANIZE_LEVELS.index(level)
    return {"dwell": i >= 1, "scroll": i >= 2, "mouse": i >= 3}


def build_modes(humanize: str = "none", escalate: bool = False) -> list[dict]:
    """試す手。安い順に、直接 → location.href で移る → 実際にクリックして辿る
    → 最初のページで _abck が合格するまで操作してから、location.href で移る(warmup_location。資料の調査と同じ移り方)。
    escalate を付けると、クリックの手に操作(滞在 → スクロール → マウス移動)を 1 つずつ足した手を、warmup_location の前に足す。
    """
    modes = [
        {"name": "direct", "humanize": "none", "label": "目的ページを直接開く(Referer なし)"},
        {"name": "location", "humanize": "none", "label": "手前のページを開き、location.href で目的ページへ移る"},
        {"name": "click", "humanize": humanize, "label": "リンクをクリックして辿る" if humanize == "none" else f"リンクをクリックして辿る(操作: {humanize})"},
    ]
    if escalate:
        for level in HUMANIZE_LEVELS[HUMANIZE_LEVELS.index(humanize) + 1 :]:
            modes.append({"name": "click", "humanize": level, "label": f"リンクをクリックして辿る(操作: {level})"})
    modes.append({"name": "warmup_location", "humanize": "none", "label": "最初のページで _abck が合格するまで操作してから、location.href で移る"})
    return modes


def abck_state(value: str | None) -> str | None:
    """_abck は値を出さず、状態だけを出す。`~` で区切った 2 つ目の欄が、0 なら合格、-1 ならセンサーデータが未承認のままという目安。

    合格した値でも、末尾に ~-1~ が続くことがあるので、値のどこかに ~-1~ があるかでは決めない。
    """
    if not value:
        return None
    fields = value.split("~")
    return {"-1": "pending", "0": "accepted"}.get(fields[1] if len(fields) > 1 else "", "other")


def warmup_applies(mode_records: list[dict]) -> bool:
    """warmup_location は Akamai の _abck の合格を待つ手なので、それまでの試行で _abck が一度も付かなかったサイトでは試さない。

    それまでの試行がない(--modes=warmup_location だけを指定した)ときは、判断できないので試す。
    """
    pages = [p for m in mode_records for t in m["trials"] for p in t.get("pages") or []]
    return not pages or any(p.get("abck_state") for p in pages)


def _strip_hash(href: str) -> str:
    return href.split("#")[0]


def _normalize(url: str) -> str:
    """URL を、ブラウザの URL と同じ形にする(スキームとホストは小文字、パスが空なら /)。"""
    u = urlsplit(url)
    return f"{u.scheme.lower()}://{u.netloc.lower()}{u.path or '/'}" + (f"?{u.query}" if u.query else "") + (f"#{u.fragment}" if u.fragment else "")


def _origin(url: str) -> str:
    u = urlsplit(url)
    return f"{u.scheme.lower()}://{u.netloc.lower()}"


def build_steps(target: str, route: list[str] | tuple[str, ...] = ()) -> list[str]:
    """辿るページの並び(目的ページが最後)。経路の指定がなければ、オリジンのトップ → 目的ページ。

    経路はユーザーから共有された、人が目的ページに着くまでに通るページ。別のサイトの URL は受け付けない。
    """
    origin = _origin(target)
    target_url = _strip_hash(_normalize(target))
    pages = list(route) if route else [f"{origin}/"]
    steps: list[str] = []
    for p in pages:
        u = _normalize(urljoin(f"{origin}/", p))
        if _origin(u) != origin:
            raise ValueError(f"経路には、目的ページと同じサイトの URL だけを指定できる: {p}")
        key = _strip_hash(u)
        if key == target_url or (steps and key == steps[-1]):
            continue
        steps.append(key)
    return [*steps, target_url]


def find_link(candidates: list[dict], next_url: str, current_url: str) -> dict | None:
    """今のページから、次のページ(next_url)へ行くリンクを選ぶ。

    URL(ハッシュを除く)が一致するものを先に、なければクエリだけ違うものを選ぶ。見えていて、同じタブで開くものだけ。
    candidates: {attr(href 属性の値), text, target, download, visible, in_viewport}
    """
    want = _normalize(next_url)
    ordered = sorted(
        (c for c in candidates if c["visible"] and not c["download"] and (not c["target"] or c["target"] == "_self")),
        key=lambda c: not c["in_viewport"],
    )
    resolved = []
    for c in ordered:
        try:
            u = _normalize(urljoin(current_url, c["attr"]))
            resolved.append((c, u, _origin(u), urlsplit(u).path))  # 組み立て直した URL の解釈も、ここで済ませる
        except ValueError:  # href が壊れているリンクは、候補から外す(1 件で、ほかのリンクの探索まで止めない)
            continue
    exact = next((c for c, u, _, _ in resolved if _strip_hash(u) == _strip_hash(want)), None)
    same_path = next((c for c, _, origin, path in resolved if origin == _origin(want) and path == urlsplit(want).path), None)
    return exact or same_path


def select_link(candidates: list[dict], text_includes: str | None = None, url_prefix: str | None = None) -> dict:
    """計画のリンクの手で、合うリンクの数と、最初のリンクを選ぶ。

    candidates: セレクタに合う、見えているリンクの {href(ブラウザが解決した URL), text(表示する文字), content(textContent)}。
    url_prefix は、href の属性値ではなく、解決した URL で比べる(相対 URL のリンクも、同じように合う)。
    """
    matched = candidates
    if text_includes:
        matched = [c for c in matched if text_includes.lower() in (c.get("content") or "").lower()]
    if url_prefix:
        matched = [c for c in matched if c["href"].startswith(url_prefix)]
    first = matched[0] if matched else None
    return {"count": len(matched), "href": first["href"] if first else None, "text": first["text"] if first else ""}


# click の手で、次のページへのリンクが見つからず、直接遷移に切り替えたときの how。route_summary.py も同じ値を見る
HOW_LINK_MISSING = "goto(リンクなし)"


def evaluate_trial(pages: list[dict]) -> dict:
    """1 回の試行の結果から、通過したかを決める。pages は {kind: route | target, blocked, how}。

    リンクが見つからず直接遷移に切り替えたページがあれば、クリックで辿れていないので通過にしない(link_missing_at に位置を入れる)。
    """
    first_blocked = next((i for i, p in enumerate(pages) if p["blocked"]), -1)
    link_missing = next((i for i, p in enumerate(pages) if p.get("how") == HOW_LINK_MISSING), -1)
    return {
        "passed": first_blocked == -1 and link_missing == -1 and bool(pages) and pages[-1]["kind"] == "target",
        "blocked_at": None if first_blocked == -1 else first_blocked,
        **({} if link_missing == -1 else {"link_missing_at": link_missing}),
    }


def evaluate_mode(trials: list[dict]) -> dict:
    """1 つの手の、繰り返した試行から結果を決める。割れたときは split(回数を増やして割合で見る)。"""
    passes = sum(1 for t in trials if t["passed"])
    total = len(trials)
    outcome = "pass" if total > 0 and passes == total else "fail" if passes == 0 else "split"
    return {"outcome": outcome, "passes": passes, "total": total}


def route_blocked_at_entry(trials: list[dict]) -> bool:
    """経路の入口(最初のページ)で全試行が拒否されたか。そのときだけ、目的ページ以前の問題として残りの手を打ち切る。

    途中のページでの拒否は、その手の開き方(goto など)が原因かもしれないので、打ち切らずに次の手を試す。
    """
    return len(trials) > 0 and all(t.get("blocked_at") == 0 for t in trials)


def _imul(a: int, b: int) -> int:
    return (a * b) & 0xFFFFFFFF


def mulberry32(seed: int):
    """種つきの乱数(テストで同じ結果を得るため)。"""
    a = seed & 0xFFFFFFFF

    def rng() -> float:
        nonlocal a
        a = (a + 0x6D2B79F5) & 0xFFFFFFFF
        t = a
        t = _imul(t ^ (t >> 15), t | 1)
        t ^= (t + _imul(t ^ (t >> 7), t | 61)) & 0xFFFFFFFF
        return ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296

    return rng


def _between(rng, lo: float, hi: float) -> float:
    return lo + rng() * (hi - lo)


def _round(x: float) -> int:
    """JavaScript の Math.round と同じ(.5 は切り上げ)。"""
    return math.floor(x + 0.5)


def plan_pause(rng, min_ms: float, max_ms: float) -> int:
    """待ち時間(ミリ秒)。"""
    return _round(_between(rng, min_ms, max_ms))


def plan_scroll(rng, page_height: float, viewport_height: float) -> list[dict]:
    """スクロールの計画。ページの下まで一気に飛ばず、3〜6 回に分けて、画面より少し下に進む。

    動かせる量(ページの高さ − 画面の高さ)の 7 割までに収め、ときどき少し戻る。
    """
    scrollable = max(page_height - viewport_height, 0)
    if scrollable < 100:
        return []
    budget = scrollable * 0.7
    steps: list[dict] = []
    used = 0
    count = 3 + math.floor(rng() * 4)
    for _ in range(count):
        if used >= budget:
            break
        dy = min(_round(_between(rng, 250, 650)), _round(budget - used))
        if dy <= 0:
            break
        steps.append({"dy": dy, "pauseMs": _round(_between(rng, 250, 700))})
        used += dy
    if steps and rng() < 0.3:
        steps.append({"dy": -_round(_between(rng, 100, 250)), "pauseMs": _round(_between(rng, 250, 700))})
    return steps


def plan_mouse_path(rng, start: dict, end: dict) -> list[dict]:
    """マウスの移動経路。始点から終点まで、少しふくらんだ曲線で、12〜24 点で動かす。

    ふくらみは終点に近づくほど小さくなり、最後の点は終点にちょうど着く。
    """
    n = 12 + math.floor(rng() * 13)
    dx, dy = end["x"] - start["x"], end["y"] - start["y"]
    length = math.hypot(dx, dy) or 1
    nx, ny = -dy / length, dx / length
    bulge = _between(rng, -0.12, 0.12) * length
    path = []
    for i in range(1, n + 1):
        t = i / n
        ease = t * t * (3 - 2 * t)
        offset = math.sin(math.pi * t) * bulge + (rng() - 0.5) * 3 * (1 - t)
        path.append({"x": _round(start["x"] + dx * ease + nx * offset), "y": _round(start["y"] + dy * ease + ny * offset)})
    path[-1] = {"x": _round(end["x"]), "y": _round(end["y"])}
    return path


# Playwright だけが解釈するセレクタの書き方。ブラウザ側は CSS(querySelectorAll)で探すので、書いても 0 件になる
_PLAYWRIGHT_ONLY = re.compile(r":has-text\(|:text\(|:text-is\(|:text-matches\(|:visible\b|:nth-match\(|^\s*(text|xpath|css|id|data-testid)=|>>")


def parse_plan(plan: dict) -> dict:
    """経路の計画ファイル(JSON)を読み込んで、検証する。パーサーのコードから作った経路を、browser_route.py に渡す形式。

      { "description": "…", "source": "src/example/kakakucom.ts",
        "steps": [ { "url": "https://…/shopitem/1208/" },
                   { "selector": "#tabContents td.mark a", "text_includes": "パソコン" } ] }

    - 最初の手は URL(パーサーの initializer が作る起点)。
    - 2 つ目以降は URL、または selector。selector は「前のページの、次のページへ行くリンク」を CSS セレクタ(Chrome が解釈できるもの。:has() は使える)で指す
      (パーサーの worker が、子のジョブの URL を取る DOM の場所)。text_includes を付けると、そのリンクの文字で絞る。
    - 最後の手が、目的ページ(パーサーが本番で辿る、最も深いページ)になる。
    """
    if not isinstance(plan, dict) or not isinstance(plan.get("steps"), list):
        raise ValueError("計画ファイルには steps(配列)が必要")
    if len(plan["steps"]) < 2:
        raise ValueError("steps は 2 つ以上必要(起点と、そこから辿る手)")

    steps = []
    for i, raw in enumerate(plan["steps"]):
        raw = raw if isinstance(raw, dict) else {}
        if isinstance(raw.get("url"), str) and raw["url"].strip():
            steps.append({"type": "url", "url": _strip_hash(_normalize(raw["url"]))})
        elif isinstance(raw.get("selector"), str) or isinstance(raw.get("url_prefix"), str):
            selector = raw["selector"].strip() if isinstance(raw.get("selector"), str) else "a[href]"  # url_prefix だけなら、ページ内のすべてのリンク
            if not selector:
                raise ValueError(f"steps[{i}] の selector が空")
            if _PLAYWRIGHT_ONLY.search(selector):
                raise ValueError(f"steps[{i}] の selector は CSS だけ(:has-text・text=・>> などの Playwright の書き方は使えない)。リンクの文字で絞るときは text_includes を使う")
            step = {"type": "link", "selector": selector}
            if isinstance(raw.get("text_includes"), str) and raw["text_includes"]:
                step["text_includes"] = raw["text_includes"]
            if isinstance(raw.get("url_prefix"), str) and raw["url_prefix"].strip():
                step["url_prefix"] = _normalize(raw["url_prefix"].strip())
            steps.append(step)
        else:
            raise ValueError(f"steps[{i}] には url か selector(url_prefix だけでもよい)が必要")

    if steps[0]["type"] != "url":
        raise ValueError("最初の手は url でなければならない(起点のページ)")
    origin = _origin(steps[0]["url"])
    for i, s in enumerate(steps):
        target = s["url"] if s["type"] == "url" else s.get("url_prefix")
        if target and _origin(target) != origin:
            raise ValueError(f"steps[{i}] の URL は、起点と同じサイトでなければならない: {target}")
    return {"description": plan.get("description"), "source": plan.get("source"), "steps": steps}
