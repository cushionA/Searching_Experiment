# /// script
# requires-python = ">=3.10,<3.14"
# dependencies = []
# ///
"""回線(egress)の扱い。プロキシの URL の解決、ASN の組織名からの種類の推定、認証情報の伏せ字。

回線は 3 つ。ステップの順に強くなる。
  client_proxy  qcv3 の worker が使う CLIENT_PROXY(データセンター。GKE と同じ経路)。ステップ 0〜2
  residential   レジデンシャル。RESIDENTIAL_PROXY。なければ、手元の回線が isp のときだけ代用する。ステップ 3〜5
  direct        この環境から直接(開発者の手元の回線)。レジデンシャルの代用と --self-check に使う

browser_run.py の --line は、resolve_proxy でプロキシの URL を得る(認証情報をコマンドに書かずに済む)。
"""

from __future__ import annotations

import os
import re
from collections.abc import Mapping
from pathlib import Path
from urllib.parse import urlsplit

REPO_DOTENV = Path(__file__).resolve().parents[4] / ".env"  # qcv3 と同じ /app/.env
PROXY_KEYS = {"client_proxy": "CLIENT_PROXY", "residential": "RESIDENTIAL_PROXY"}

# データセンター(クラウド・ホスティング)の組織名に含まれやすい語
_DATACENTER = re.compile(
    r"amazon|\baws\b|google|microsoft|azure|digitalocean|ovh|hetzner|linode|vultr|oracle|alibaba|tencent|cloudflare|"
    r"leaseweb|contabo|scaleway|hosting|cloud|data ?cent|colo(?:cation)?\b|\bservers?\b",
    re.IGNORECASE,
)
# 家庭用・モバイル回線を提供する通信事業者の組織名に含まれやすい語
_ISP = re.compile(
    r"communications|telecom|broadband|cable|wireless|mobile|\bntt\b|kddi|softbank|docomo|j:com|jcom|so-?net|"
    r"biglobe|\bocn\b|plala|nifty|nuro|asahi ?net",
    re.IGNORECASE,
)

def asn_of(org: str | None) -> str | None:
    """ipinfo.io の org(例: "AS2527 Sony Network Communications Inc.")から ASN を取り出す。履歴で回線を見分けるのに使う。"""
    m = re.match(r"(AS\d+)\b", org or "")
    return m.group(1) if m else None


def egress_kind(org: str | None) -> str:
    """ASN の組織名から、回線の種類を推定する(datacenter / isp / unknown)。

    組織名だけの推定で、確定ではない。企業向けの回線を持つ事業者や、クラウドも提供する事業者は外れることがある。
    isp は「家庭用・モバイル回線を持つ事業者」という意味で、レジデンシャルのプロキシそのものではない。
    """
    if not org:
        return "unknown"
    if _DATACENTER.search(org):
        return "datacenter"
    if _ISP.search(org):
        return "isp"
    return "unknown"


def _value_in_dotenv(path: Path, key: str) -> str | None:
    """.env から key の行だけを読む。同じキーが複数あれば後の行を使う(dotenv と同じ)。"""
    try:
        lines = path.read_text().splitlines()
    except OSError:
        return None
    pattern = re.compile(rf"""^\s*(?:export\s+)?{key}\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s#]*))""")
    found = None
    for line in lines:
        if m := pattern.match(line):
            found = next(g for g in m.groups() if g is not None)
    return found or None


def resolve_proxy(key: str, arg: str | None, dotenv_path: Path | None, environ: Mapping[str, str]) -> tuple[str | None, str | None]:
    """プロキシの URL(CLIENT_PROXY / RESIDENTIAL_PROXY)を、引数 → .env → 環境変数の順に探し、(URL, 取った場所)を返す。

    .env を source したときと同じく、.env の値を環境変数より優先する。環境変数は .env にないときの予備。
    """
    if arg:
        return arg, "引数"
    if dotenv_path and (url := _value_in_dotenv(dotenv_path, key)):
        return url, ".env"
    if url := environ.get(key):
        return url, "環境変数"
    return None, None


def choose_residential(proxy: str | None, source: str | None, direct_kind: str | None, force_direct: bool = False) -> dict | None:
    """ステップ 3〜5 で使うレジデンシャルの回線を決める。なければ None(ステップ 3〜5 は実施せず、手配を依頼する)。

    プロキシがなければ、手元の回線(kind_guess が isp)で代用する。家庭用・会社の ISP 回線は、
    レジデンシャルのプロキシと同じ扱いを受けるとは限らないので、代用したことを結果に残す(substitute)。
    force_direct は、kind_guess が外れていて、ユーザーが手元を家庭用・ISP の回線だと言ったときだけ使う。
    """
    if proxy:
        return {"line": "residential", "egress": "residential", "proxy": proxy, "source": source, "substitute": False}
    if direct_kind == "isp" or force_direct:
        source = "手元の回線(isp)" if direct_kind == "isp" else "手元の回線(指定)"
        return {"line": "residential", "egress": "direct", "proxy": None, "source": source, "substitute": True}
    return None


def mask_proxy(url: str | None) -> str | None:
    """プロキシ URL の認証情報(user:pass@)を伏せる。出力・記録には、必ずこれを通す。"""
    if not url:
        return url
    parts = urlsplit(url)
    if parts.username is None and parts.password is None:
        return url
    host = parts.hostname or ""
    port = f":{parts.port}" if parts.port else ""
    return f"{parts.scheme}://***@{host}{port}"


def redact(text: str, urls: list[str | None]) -> str:
    """エラー文などに、認証情報つきのプロキシ URL が混ざっていたら伏せる(URL 全体と user:pass@ の形)。"""
    for url in urls:
        if not url:
            continue
        parts = urlsplit(url)
        if parts.username is None and parts.password is None:
            continue
        userinfo = f"{parts.username or ''}:{parts.password or ''}"
        text = text.replace(url, mask_proxy(url) or "").replace(f"{userinfo}@", "***@")
    return text
