# /// script
# requires-python = ">=3.10,<3.14"
# dependencies = ["curl_cffi"]
# ///
"""URL を、1 つの回線でクライアントごとに確認し、結果を JSON で出す。

ステップを順に回すのは ladder.py(この関数を使う)。probe.py を直接使うのは、通った回線での追加調査
(--impersonate・--chrome-ua)と、--self-check・--egress-info・--classify-json・--compare-human。

クライアント:
  curl                   OpenSSL の curl コマンド。既定の基準線(原典と同じ)。HTTP/2 を話し、TLS は OpenSSL が作る。
                         qcv3 も Node も要らない。本番の Axios・Basic(HTTP/1.1、Node の TLS)と同じ結果とは限らない
  axios                  --client axios のとき、curl の代わりに出す。qcv3 の AxiosClient そのもの(node_axios.mjs)。
                         直接は Node の TLS と HTTP/1.1。プロキシ経由では CONNECT を使わず、サイトとの TLS はプロキシが作る。
                         ヘッダーは UA・Accept・Accept-Encoding
  basic                  --client basic のとき、curl の代わりに出す。qcv3 の Basic と同じ request ライブラリ(node_basic.mjs)。
                         Node の TLS と HTTP/1.1(プロキシ経由も CONNECT で Node のまま)。ヘッダーは UA だけ
  curl_cffi              impersonate="chrome"。TLS と HTTP/2 を Chrome にそろえ、Chrome のヘッダー一式も送る
  curl_chrome_headers    curl に Chrome 155 のヘッダー一式を足す(accept-encoding から zstd を外す)。ladder.py が、
                         curl_cffi で通ったときに送る(ヘッダーをそろえるだけで、ブラウザなしで通るか)
  axios_chrome_headers   --client axios のときの、同じ確認(axios に同じヘッダー一式を足す)
回線(--line。既定は client_proxy):
  client_proxy qcv3 の worker が使う CLIENT_PROXY(データセンター)。--client-proxy → リポジトリの .env → 環境変数の順に探す
  residential  レジデンシャル。--residential-proxy → .env の RESIDENTIAL_PROXY → 環境変数の順に探す。
               なければ、手元の回線が isp のときだけ代用する(--direct-as-residential で、isp と推定できなくても代用する)
  direct       この環境から直接(開発者の手元の回線)

1 URL につき、1 回線あたり 2 リクエスト。相手に負荷をかけないよう、リクエストの間に待ち時間を置き、
429 が返ったら、その URL への残りのリクエストは送らない。cookie は名前だけ出し、値は出さない。

結果は temp/blocking-triage/history.jsonl に残し(--no-history で残さない)、同じ URL・回線・クライアントの
前回の結果を表の「前回」の列に出す。ホストごとの最後のリクエストの時刻も残し、browser_run.py はそれを見て、
probe の直後にブラウザを起動しないよう待つ。

使い方:
  uv run probe.py --url https://example.com/   # client_proxy で curl と curl_cffi
  uv run probe.py --url https://example.com/ --line residential   # レジデンシャルで curl と curl_cffi
  uv run probe.py --url https://example.com/ --client axios   # curl の代わりに qcv3 の Axios で比べる(qcv3 のある環境だけ)
  uv run probe.py --url https://example.com/ --client basic   # curl の代わりに qcv3 の Basic で比べる
  uv run probe.py --url https://example.com/ --impersonate chrome131   # curl_cffi の模倣する版を変える(版が古すぎる疑いの確認)
  uv run probe.py --url https://example.com/ --chrome-ua 155   # curl_cffi が名乗る Chrome の版だけを替える(TLS は模倣のまま)
  uv run probe.py --self-check                 # axios・basic・curl・curl_cffi の指紋を確認(直接のみ)
  uv run probe.py --egress-info                # 手元・client_proxy・レジデンシャルの IP・ASN・種類の推定を確認
  uv run probe.py --compare-human human.json --browser-json bp.json   # 人の Chrome(human_check.js)と③を項目ごとに比べる
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

from classify import classify, extract_title
from egress import (
    PROXY_KEYS,
    REPO_DOTENV,
    asn_of,
    choose_residential,
    egress_kind,
    mask_proxy,
    redact,
    resolve_proxy,
)
from state import (
    append_history,
    attach_previous,
    history_records,
    load_history,
    record_browser,
    state_dir,
    touch_last_request,
)

# Axios・Basic・curl の既定の User-Agent。資料の比較(indeed_header_swap.py・indeed_fingerprint_clients.py)と同じ Chrome 155(Linux)
CHROME_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36"
)
# curl_cffi(impersonate="chrome")が自分で送る User-Agent と sec-ch-ua(Chrome 150 の模倣)。--chrome-ua は、この版だけを替える。
# Chrome をまねた接続は、既定ではこの UA のまま送る(資料の主な結果と同じ。joshinweb.jp は、TLS の版と食い違う UA を拒否した)
CHROME_IMPERSONATE_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
)
CURL_CFFI_SEC_CH_UA = '"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"'
# Chrome 155 が実際に送ったヘッダー 13 個を、同じ順序で並べたもの
CHROME_HEADERS = (
    ("sec-ch-ua", '"Google Chrome";v="155", "Chromium";v="155", "Not(A:Brand";v="24"'),
    ("sec-ch-ua-mobile", "?0"),
    ("sec-ch-ua-platform", '"Linux"'),
    ("upgrade-insecure-requests", "1"),
    ("user-agent", CHROME_UA),
    ("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"),
    ("sec-fetch-site", "none"),
    ("sec-fetch-mode", "navigate"),
    ("sec-fetch-user", "?1"),
    ("sec-fetch-dest", "document"),
    ("accept-encoding", "gzip, deflate, br, zstd"),
    ("accept-language", "ja,en-US;q=0.9,en;q=0.8"),
    ("priority", "u=0, i"),
)
# ladder.py が、Chrome をまねた接続で通ったときに Axios に付けるヘッダー。パーサーが axiosOptions.headers で付けられる。
# Node 20 は zstd を展開できない(zstd で返されると本文が読めない)ので、accept-encoding からは外す
AXIOS_CHROME_HEADERS = tuple((k, "gzip, deflate, br") if k == "accept-encoding" else (k, v) for k, v in CHROME_HEADERS)
BODY_HEAD_BYTES = int(os.environ.get("BT_BODY_BYTES", "2048"))
_PROXY_URLS: list[str | None] = []  # エラー文から認証情報を伏せるための、使っているプロキシ URL
TIMEOUT_SEC = 20
INTERVAL_SEC = 1.0
KEEP_HEADERS = ("server", "cf-ray", "cf-mitigated", "x-amzn-waf-action", "x-datadome", "x-iinfo", "content-type", "location", "retry-after")
IPINFO_URL = "https://ipinfo.io/json"
FINGERPRINT_URL = "https://tls.peet.ws/api/all"
NODE_BASIC = Path(__file__).with_name("node_basic.mjs")
NODE_AXIOS = Path(__file__).with_name("node_axios.mjs")


def _summarize(req: dict, resp: dict) -> dict:
    """クライアントごとの生の応答を、共通の形の 1 行にまとめる。"""
    head = {"client": req["client"], "egress": req["egress"]}
    if resp.get("error"):
        return {**head, "ok": False, "error": redact(resp["error"], _PROXY_URLS)}
    body = resp["body"]
    verdict = classify(resp["status"], resp["headers"], resp["cookie_names"], body)
    return {
        **head,
        "ok": True,
        "status": resp["status"],
        "http_version": resp["http_version"],
        "final_url": resp["final_url"],
        "elapsed_ms": resp["elapsed_ms"],
        "title": extract_title(body),
        "bytes": len(body.encode("utf-8", "replace")),
        "headers": {k: v for k, v in resp["headers"].items() if k in KEEP_HEADERS},
        "cookie_names": resp["cookie_names"],
        "body_head": body[:BODY_HEAD_BYTES],
        **verdict,
        **({"proxy_auth_added": True} if resp.get("proxy_auth_added") else {}),  # 本番の AxiosClient は認証情報を捨てる
    }


def decode_body(content: bytes, content_type: str) -> str:
    """応答の本文を文字列にする。ヘッダーに文字コードがなければ、本文の先頭の meta の charset で読む。

    Amazon の 503 は、ヘッダーが text/html だけで、本文は Shift_JIS(meta にだけ書いてある)。body_decode.mjs と同じ読み方
    """
    from_header = re.search(r"charset=([^;]+)", content_type or "", re.IGNORECASE)
    from_meta = re.search(rb"""<meta[^>]+charset=["']?([\w-]+)""", content[:2048], re.IGNORECASE)
    for charset in (from_header and from_header.group(1).strip(), from_meta and from_meta.group(1).decode("ascii")):
        if charset:
            try:
                return content.decode(charset, errors="replace")
            except LookupError:
                continue
    return content.decode("utf-8", errors="replace")


def _split_header_blocks(raw: str) -> list[str]:
    return [b for b in re.split(r"\r?\n\r?\n", raw.strip()) if b.strip()]


def fetch_curl(url: str, proxy: str | None, ua: str | None, headers: tuple[tuple[str, str], ...] | None = None) -> dict:
    """OpenSSL の curl コマンドで取得する(リダイレクトは 5 回まで追う)。

    headers は、渡した順に -H で付ける。同じ名前の curl の既定のヘッダーは置き換わる。
    headers に accept-encoding があるときだけ、圧縮された本文を curl が展開する(--compressed。値は headers のまま送る)。
    素の curl は accept-encoding を送らないので、本文は圧縮されない。
    """
    with tempfile.TemporaryDirectory() as tmp:
        hfile, bfile = Path(tmp, "h"), Path(tmp, "b")
        cmd = [
            "curl", "-sS", "-L", "--max-redirs", "5", "-m", str(TIMEOUT_SEC),
            "-D", str(hfile), "-o", str(bfile),
            "-w", "%{http_code}\t%{http_version}\t%{url_effective}",
        ]  # fmt: skip
        if any(name.lower() == "accept-encoding" for name, _ in headers or ()):
            cmd.append("--compressed")
        if ua:
            cmd += ["-A", ua]
        for name, value in headers or ():
            cmd += ["-H", f"{name}: {value}"]
        if proxy:
            cmd += ["-x", proxy]
        cmd.append(url)
        started = time.monotonic()
        p = subprocess.run(cmd, check=False, capture_output=True, text=True, timeout=TIMEOUT_SEC + 10)  # 終了コードは下で見る
        elapsed = int((time.monotonic() - started) * 1000)
        if p.returncode != 0:
            return {"error": f"curl exit {p.returncode}: {p.stderr.strip()[:200]}"}
        status, version, final_url = (p.stdout.split("\t") + ["", "", ""])[:3]
        blocks = _split_header_blocks(hfile.read_text(errors="replace"))
        headers: dict[str, str] = {}
        cookie_names: list[str] = []
        for block in blocks:  # 最後のブロックが最終応答。cookie は途中の応答のものも拾う
            for line in block.splitlines()[1:]:
                if ":" in line:
                    k, v = line.split(":", 1)
                    if k.strip().lower() == "set-cookie":
                        cookie_names.append(v.split("=", 1)[0].strip())
        for line in (blocks[-1].splitlines()[1:] if blocks else []):
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip().lower()] = v.strip()
        return {
            "status": int(status or 0),
            "http_version": {"2": "h2", "1.1": "http/1.1"}.get(version, version),
            "final_url": final_url,
            "elapsed_ms": elapsed,
            "headers": headers,
            "cookie_names": sorted(set(cookie_names)),
            "body": decode_body(bfile.read_bytes(), headers.get("content-type", "")),
        }


def _fetch_node(script: Path, url: str, proxy: str | None, ua: str, headers: tuple[tuple[str, str], ...] | None = None) -> dict:
    payload = json.dumps({"url": url, "proxy": proxy, "userAgent": ua, "timeoutMs": TIMEOUT_SEC * 1000, **({"headers": headers} if headers else {})})
    p = subprocess.run(
        ["node", str(script)], input=payload, check=False, capture_output=True, text=True, timeout=TIMEOUT_SEC + 10
    )  # 終了コードは下で見る
    if p.returncode != 0:
        return {"error": f"node exit {p.returncode}: {p.stderr.strip()[-200:]}"}
    return json.loads(p.stdout)


def fetch_basic(url: str, proxy: str | None, ua: str) -> dict:
    """qcv3 の Basic クライアントと同じ request ライブラリ(node_basic.mjs)で取得する。結果の形は fetch_curl と同じ。"""
    return _fetch_node(NODE_BASIC, url, proxy, ua)


def fetch_axios(url: str, proxy: str | None, ua: str, headers: tuple[tuple[str, str], ...] | None = None) -> dict:
    """qcv3 の AxiosClient(node_axios.mjs)で取得する。結果の形は fetch_curl と同じ。headers は既定のヘッダーに足す。"""
    return _fetch_node(NODE_AXIOS, url, proxy, ua, headers)


def fetch_cffi(url: str, proxy: str | None, headers: dict[str, str] | None = None, impersonate: str = "chrome") -> dict:
    """curl_cffi で取得する。User-Agent などは impersonate の既定に任せる(既定の "chrome" は、curl_cffi が持つ最新の Chrome)。

    headers は既定のヘッダーに足す。同じ名前の既定のヘッダーは、その位置のまま値が置き換わる。
    """
    from curl_cffi import requests as cr

    started = time.monotonic()
    try:
        r = cr.get(
            url,
            impersonate=impersonate,
            headers=headers,
            proxies={"http": proxy, "https": proxy} if proxy else None,
            timeout=TIMEOUT_SEC,
            allow_redirects=True,
            max_redirects=5,
        )
    except Exception as e:  # noqa: BLE001 - 失敗の種類は文字列で報告する
        return {"error": f"{type(e).__name__}: {str(e)[:200]}"}
    elapsed = int((time.monotonic() - started) * 1000)
    names = sorted({c.name for c in r.cookies.jar})
    version = {1: "http/1.0", 2: "http/1.1", 3: "h2", 30: "h3"}.get(getattr(r, "http_version", 0), "unknown")
    return {
        "status": r.status_code,
        "http_version": version,
        "final_url": r.url,
        "elapsed_ms": elapsed,
        "headers": {k.lower(): v for k, v in r.headers.items()},
        "cookie_names": names,
        "body": decode_body(r.content, r.headers.get("content-type", "")),
    }


def chrome_ua_headers(version: int) -> dict[str, str]:
    """--chrome-ua で curl_cffi に足すヘッダー。TLS と HTTP/2 は模倣のまま、名乗る Chrome の版だけを替える。

    zozo.jp は、TLS が同じでも、UA の版が古い(2026-10-20 は 150 以下)と拒否した。拒否が TLS か UA の版かを分ける。
    sec-ch-ua も同じ版にそろえる(UA とずれた組み合わせは、ブラウザではありえないため)。
    """
    ua = re.sub(r"Chrome/\d+\.", f"Chrome/{version}.", CHROME_IMPERSONATE_UA)
    brands = re.sub(r'("(?:Chromium|Google Chrome)";v=")\d+"', rf'\g<1>{version}"', CURL_CFFI_SEC_CH_UA)
    return {"User-Agent": ua, "sec-ch-ua": brands}


def plan_requests(
    egresses: list[tuple[str, str | None]],
    node_client: str = "curl",
) -> list[dict]:
    """1 URL に送るリクエストの並び。回線ごとに curl(node_client="axios"・"basic" ならそれ)・curl_cffi の 2 件(ステップ 0・1、ステップ 3・4 と同じ組)。"""
    return [{"egress": e, "proxy": p, "client": c} for e, p in egresses for c in (node_client, "curl_cffi")]


def _fetch(url: str, req: dict, ua: str, impersonate: str, chrome_ua: int | None = None) -> dict:
    if req["client"] == "curl":
        return fetch_curl(url, req["proxy"], ua)
    if req["client"] == "curl_chrome_headers":
        return fetch_curl(url, req["proxy"], ua, AXIOS_CHROME_HEADERS)
    if req["client"] == "axios":
        return fetch_axios(url, req["proxy"], ua)
    if req["client"] == "axios_chrome_headers":
        return fetch_axios(url, req["proxy"], ua, AXIOS_CHROME_HEADERS)
    if req["client"] == "basic":
        return fetch_basic(url, req["proxy"], ua)
    return fetch_cffi(url, req["proxy"], chrome_ua_headers(chrome_ua) if chrome_ua else None, impersonate=impersonate)


def probe(
    url: str, plan: list[dict], ua: str, interval: float, impersonate: str = "chrome", chrome_ua: int | None = None
) -> list[dict]:
    rows: list[dict] = []
    for req in plan:
        if any(r.get("kind") == "rate_limited" for r in rows):
            rows.append({"client": req["client"], "egress": req["egress"], "ok": False,
                         "skipped": True, "error": "先に 429 が返ったため送らなかった"})  # fmt: skip
            continue
        row = _summarize(req, _fetch(url, req, ua, impersonate, chrome_ua))
        if req["client"] == "curl_cffi":
            row["impersonate"] = impersonate
            if chrome_ua:
                row["chrome_ua"] = chrome_ua
        rows.append(row)
        time.sleep(interval)
    return rows


def _previous_cell(r: dict) -> str:
    """前回の種別と日付(MM-DD)。種別が変わっていたら「→変化」を付ける。"""
    prev = r.get("previous")
    if not prev:
        return "-"
    return f"{prev['kind']}({prev['at'][5:10]})" + ("→変化" if r.get("changed") else "")


def _table(url: str, rows: list[dict]) -> str:
    lines = [
        f"## {url}",
        "",
        "| 回線 | クライアント | status | HTTP | 種別 | ベンダー | 拒否ページ | タイトル | 前回 |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        client = r["client"]
        if r.get("impersonate", "chrome") != "chrome":
            client += f"({r['impersonate']})"
        if not r["ok"]:
            lines.append(f"| {r['egress']} | {client} | {'未送信' if r.get('skipped') else 'エラー'} | - | - | - | - | {r['error']} | {_previous_cell(r)} |")
            continue
        lines.append(
            f"| {r['egress']} | {client} | {r['status']} | {r['http_version']} | {_kind_cell(r)} "
            f"| {_vendor_cell(r)} | {r.get('deny_signature') or '-'} | {r['title'] or '-'} | {_previous_cell(r)} |"
        )
    return "\n".join(lines)


def _kind_cell(r: dict) -> str:
    """チャレンジ画面には、人が何をすれば通るか(auto / button / press_hold / puzzle / unknown)を添える"""
    return f"{r['kind']}({r['challenge_type']})" if r.get("challenge_type") else r["kind"]


def _vendor_cell(r: dict) -> str:
    """Akamai の拒否には、Bot Manager の cookie が発行されたか(BM あり / なし)を添える"""
    bm = r.get("akamai_bot_manager")
    names = [f"{v}(BM {'あり' if bm else 'なし'})" if v == "akamai" and bm is not None else v for v in r["vendors"]]
    return ",".join(names) or "-"


def egress_info(egresses: list[tuple[str, str | None]]) -> list[dict]:
    """各回線の IP と ASN を外部サービス(ipinfo.io)で確認する。"""
    out = []
    for egress, p in egresses:
        resp = fetch_cffi(IPINFO_URL, p)
        if resp.get("error"):
            out.append({"egress": egress, "error": redact(resp["error"], _PROXY_URLS)})
            continue
        try:
            d = json.loads(resp["body"])
            out.append(
                {
                    "egress": egress,
                    "proxy": mask_proxy(p),
                    "ip": d.get("ip"),
                    "org": d.get("org"),
                    "country": d.get("country"),
                    **({"timezone": d.get("timezone")} if os.environ.get("BT_MATCH_LINE") else {}),
                    "kind_guess": egress_kind(d.get("org")),  # ASN の組織名からの推定。確定ではない
                }
            )
        except json.JSONDecodeError:
            out.append({"egress": egress, "error": f"JSON ではない応答 (status {resp['status']})"})
    return out


LINES = ("client_proxy", "residential", "direct")
NO_LINE = {
    "client_proxy": "CLIENT_PROXY が見つからない(--client-proxy、.env、環境変数のどれにもない)。ステップ 0〜2 はデータセンターの回線で行う",
    "residential": "レジデンシャルの回線がない(RESIDENTIAL_PROXY がなく、手元の回線も isp と推定できない)。手配を依頼する。"
    "手元が家庭用・ISP の回線だと分かっているときだけ --direct-as-residential を付ける",
}


def resolve_proxies(client_proxy: str | None, residential_proxy: str | None, use_env: bool = True) -> dict[str, tuple[str | None, str | None]]:
    """client_proxy・residential のプロキシの (URL, 取った場所)。見つけた URL は、エラー文で伏せる対象にも足す。"""
    dotenv, environ = (REPO_DOTENV, os.environ) if use_env else (None, {})
    args = {"client_proxy": client_proxy, "residential": residential_proxy}
    proxies = {name: resolve_proxy(key, args[name], dotenv_path=dotenv, environ=environ) for name, key in PROXY_KEYS.items()}
    _PROXY_URLS.extend(url for url, _ in proxies.values() if url)
    return proxies


def build_line(name: str, proxies: dict[str, tuple[str | None, str | None]], force_direct: bool = False) -> dict | None:
    """回線の名前から {line, egress, proxy, source, substitute, info} を作る。作れないときは None(理由は NO_LINE)。

    info は ipinfo.io で見た IP・ASN・kind_guess(つながらなければ error)。residential でプロキシがないときは、
    手元の回線の kind_guess で、代用に使えるか(isp か)を決める。
    """
    if name == "direct":
        line = {"line": "direct", "egress": "direct", "proxy": None, "source": None, "substitute": False}
    elif name == "client_proxy":
        url, source = proxies[name]
        if not url and not os.environ.get("BT_DC_DIRECT"):
            return None
        line = ({"line": name, "egress": name, "proxy": url, "source": source, "substitute": False} if url
                else {"line": name, "egress": "direct", "proxy": None, "source": "Cloud Run の出口", "substitute": False})
    else:
        url, source = proxies[name]
        if url:
            line = choose_residential(url, source, None)
        else:
            [info] = egress_info([("direct", None)])
            line = choose_residential(None, None, info.get("kind_guess"), force_direct)
            return line and {**line, "info": info}
    [info] = egress_info([(line["egress"], line["proxy"])])
    return {**line, "info": info}


def line_label(line: dict) -> str:
    """回線の表示。プロキシは認証情報を伏せる。代用した手元の回線は、そう分かるようにする。"""
    if line["substitute"]:
        return f"{line['line']}({line['source']}で代用)"
    if line["proxy"]:
        return f"{line['line']}({mask_proxy(line['proxy'])}、{line['source']}から)"
    return line["line"]


def self_check(ua: str) -> dict:
    """tls.peet.ws に自分の指紋を返させ、axios・basic・curl と curl_cffi で違うことを確認する(直接だけ)。"""
    clients = []
    for client, fn in (
        ("axios", lambda: fetch_axios(FINGERPRINT_URL, None, ua)),
        ("basic", lambda: fetch_basic(FINGERPRINT_URL, None, ua)),
        ("curl", lambda: fetch_curl(FINGERPRINT_URL, None, ua)),
        ("curl_cffi", lambda: fetch_cffi(FINGERPRINT_URL, None)),
    ):
        resp = fn()
        if resp.get("error"):
            clients.append({"client": client, "error": resp["error"]})
            continue
        try:
            d = json.loads(resp["body"])
        except json.JSONDecodeError:
            clients.append({"client": client, "error": f"JSON ではない応答 (status {resp['status']})"})
            continue
        clients.append(
            {
                "client": client,
                "http_version": d.get("http_version"),
                "ja4": (d.get("tls") or {}).get("ja4"),
                "akamai_h2": (d.get("http2") or {}).get("akamai_fingerprint"),
            }
        )
        time.sleep(INTERVAL_SEC)
    return {"clients": clients}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", action="append", default=[], help="確認する URL(複数指定可)")
    ap.add_argument("--line", choices=LINES, default="client_proxy", help="確かめる回線(既定 client_proxy)")
    ap.add_argument("--client-proxy", help="CLIENT_PROXY(GKE の worker と同じ経路)。省略すると、リポジトリの .env の CLIENT_PROXY、なければ環境変数を使う")
    ap.add_argument("--residential-proxy", help="レジデンシャルのプロキシ。省略すると、.env の RESIDENTIAL_PROXY、なければ環境変数を使う")
    ap.add_argument("--direct-as-residential", action="store_true", help="レジデンシャルのプロキシがないとき、kind_guess が isp でなくても手元の回線で代用する(ユーザーが家庭用・ISP の回線だと言ったときだけ)")
    ap.add_argument("--no-env-proxy", action="store_true", help=".env と環境変数のプロキシを使わない(--client-proxy・--residential-proxy だけを使う)")
    ap.add_argument("--user-agent", default=CHROME_UA, help="axios・basic と curl に付ける User-Agent(qcv3 の CLIENT_USER_AGENT にあたる)")
    ap.add_argument("--client", choices=("curl", "axios", "basic"), default="curl", help="既定の表で curl_cffi と並べるクライアント(既定 curl。axios・basic は qcv3 のある環境だけ)")
    ap.add_argument("--interval", type=float, default=INTERVAL_SEC, help="リクエスト間の待ち時間(秒)")
    ap.add_argument("--impersonate", default="chrome", help="curl_cffi が模倣するブラウザ(既定 chrome。例: chrome131、firefox)")
    ap.add_argument("--chrome-ua", type=int, metavar="VERSION", help="curl_cffi が名乗る Chrome の版(User-Agent と sec-ch-ua)だけを替える。TLS は模倣のまま。UA の版で拒否されていないかを確かめる(例: 155)")
    ap.add_argument("--no-history", action="store_true", help="結果の履歴と、最後のリクエストの時刻を残さない")
    ap.add_argument("--classify-json", metavar="FILE", help="browser_probe.py(③)か browser_route.py(④)の JSON(- で標準入力)を判定して出す。通信はしない")
    ap.add_argument("--compare-human", metavar="FILE", help="human_check.js の出力(人の Chrome)を、--browser-json の③の結果と比べる。通信はしない")
    ap.add_argument("--browser-json", metavar="FILE", help="--compare-human で比べる browser_probe.py(③)の JSON")
    ap.add_argument("--self-check", action="store_true", help="自分の TLS/HTTP/2 指紋を確認する(外部サービスへ送る)")
    ap.add_argument("--egress-info", action="store_true", help="手元・client_proxy・レジデンシャルの IP と ASN を確認する(外部サービスへ送る)")
    args = ap.parse_args()
    proxies = resolve_proxies(args.client_proxy, args.residential_proxy, use_env=not args.no_env_proxy)

    if args.compare_human:
        if not args.browser_json:
            ap.error("--compare-human には --browser-json(③の結果)も要る")
        from browser_env import compare_browsers

        c = compare_browsers(json.loads(Path(args.compare_human).read_text()), json.loads(Path(args.browser_json).read_text()))
        print(f"層: {c['layer']}。{c['reading']}", file=sys.stderr)  # 項目ごとの比較(rows・candidates)は JSON に出す
        print(json.dumps(c, ensure_ascii=False, indent=2))
        return 0
    if args.classify_json:
        raw = sys.stdin.read() if args.classify_json == "-" else Path(args.classify_json).read_text()
        d = json.loads(raw)
        if "modes" in d:  # browser_route.py(④)の結果
            from route_summary import summarize_route

            print(json.dumps(summarize_route(d), ensure_ascii=False, indent=2))
            return 0
        from route_summary import summarize_browser_probe  # browser_probe.py(③)の結果

        summary = summarize_browser_probe(d)
        if not args.no_history and d.get("url"):
            # 手で回したブラウザの結果は、どの回線(ASN)だったか分からないので、記録だけして前回とは比べない
            record_browser(state_dir() / "history.jsonl", d, summary)
            summary = {**summary, "previous": None, "changed": None}
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 0
    if args.self_check:
        print(json.dumps({"self_check": self_check(args.user_agent)}, ensure_ascii=False, indent=2))
        return 0
    if args.egress_info:
        lines = [("direct", None), *((name, url) for name, (url, _) in proxies.items() if url)]
        print(json.dumps({"egress_info": egress_info(lines)}, ensure_ascii=False, indent=2))
        return 0
    if not args.url:
        ap.error("--url が必要です")
    line = build_line(args.line, proxies, args.direct_as_residential)
    if line is None:
        ap.error(NO_LINE[args.line])
    print(f"回線: {line_label(line)}", file=sys.stderr)
    egresses = [(line["egress"], line["proxy"])]
    plan = plan_requests(egresses, node_client=args.client)

    results = []
    history_path = state_dir() / "history.jsonl"
    for url in args.url:
        rows = probe(url, plan, args.user_agent, args.interval, args.impersonate, args.chrome_ua)
        if not args.no_history:
            asn = asn_of((line.get("info") or {}).get("org"))
            rows = attach_previous(rows, url, load_history(history_path), asn=asn)
            append_history(history_path, history_records(url, rows, at=datetime.now().astimezone().isoformat(timespec="seconds"), asn=asn))
            touch_last_request(state_dir(), url)
        print(_table(url, rows), file=sys.stderr)
        print(file=sys.stderr)
        results.append({"url": url, "rows": rows})
    print(json.dumps({"results": results}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
