# ボット対策ベンダーの見分け方

`scripts/classify.py` が使っている手がかりと、その読み方。手がかりは「応答に残った痕跡」で、判定ロジックの中身は分からない。CDN として前に立っているだけでも付く。

| ベンダー | 手がかり | 注意 |
|---|---|---|
| Cloudflare | ヘッダー `cf-ray`・`server: cloudflare`、cookie `cf_clearance`・`__cf_bm`、本文の `cdn-cgi/challenge-platform` | 通常ページにも検知スクリプト(`cdn-cgi/challenge-platform/scripts/jsd/`)が入る。ベンダーが出ただけでは、ブロックされているとは言えない |
| Akamai | `server: AkamaiGHost`、cookie `_abck`・`bm_sz`・`ak_bmsc`、本文の `errors.edgesuite.net`(Access Denied のページ)・`sec-if-cpt-container`(チャレンジ画面) | `_abck` は通常の応答にも付く。値が `~-1~` を含む間は、センサーデータがまだ承認されていない目安。joshinweb.jp では、ページを開いただけでは `~-1~` のままで、操作のデータの層が原因と読まれている。チャレンジ画面は 200・タイトル空で返ることがあり、ブラウザの応答には `server` ヘッダーが付かないことがある(zozo.jp。2026-10-15) |
| AWS WAF | ヘッダー `x-amzn-waf-action`、cookie `aws-waf-token`、本文の `token.awswaf.com`・`gokuProps` | JS のチャレンジは 202・タイトル空で返り、ブラウザの JS が token を取ると再読み込みされる。Basic(request)で取ると、本文が 0 バイトのことがある(www.amazon.co.jp。2026-10-19)。`token.awswaf.com` は JS を読み込むだけの通常ページにも入る。`challenge` にするのは、本文に `gokuProps`(チャレンジ画面の設定)があるときと、ヘッダーの値が `challenge` のときだけ。このヘッダーの値は AWS の仕様にもとづく想定で、実際の応答ではまだ確かめていない |
| Amazon(自社の確認画面) | 本文の `To discuss automated access to Amazon data` のコメント、`validateCaptcha` へ送るフォーム | 503 の「ご迷惑をおかけしています！」は `blocked`。「下のボタンをクリックしてショッピングを続けてください」の画面は、200 で返り、本文は約 3.7KB、タイトルは「Amazon.co.jp」だった(www.amazon.co.jp、client_proxy の Axios、2026-10-22)。通常ページと見分けにくい。フォームがあれば `challenge`(種類は `button`)にする。ボタンを押したあとの画面は未確認。本物のトップページ(タイトルは「Amazon \| 本, ファッション, 家電から食品まで \| アマゾン」)の応答には、このコメントが付いていなかった(2026-10-22 の履歴) |
| DataDome | ヘッダー `x-datadome`、cookie `datadome`、本文の `captcha-delivery.com` | |
| PerimeterX(HUMAN) | cookie `_px*`、本文の `px-captcha`・Press & Hold | |
| Imperva(Incapsula) | ヘッダー `x-iinfo`、cookie `incap_ses_*`・`visid_incap_*`、本文の `Incapsula incident` | |

## kind(ブロックの種類)の読み方

| kind | 意味 | 次に見ること |
|---|---|---|
| `ok` | 通常のページが返った | 本文が期待どおりか(ログインページや空ページでないか) |
| `blocked` | 403 などで拒否された。チャレンジの手がかりはない | 回線を変える、クライアントを変える、の両方で差が出るか |
| `challenge` | JS の確認を求めるページ | ブラウザで JS を実行すれば通るか |
| `turnstile` | 人の操作(チェックボックス)を求めるページ | ブラウザで通るか。回線の評判が悪いと出やすい |
| `rate_limited` | 429 | 回数と間隔。1 URL ずつ間隔を空けて再確認する |
| `error` | 上記以外の 4xx/5xx | ブロックではなくサイト側の障害の可能性 |

- status が 200 でも、タイトルが `Access Denied` などのページは `blocked` にする。
- status が 200 でも、`Just a moment...` や `_cf_chl_opt`、Akamai の `sec-if-cpt-container` を含むページ、タイトルが `Security Check` などのページは `challenge` にする。
- 次の 2 つも、タイトルが空か空白だけで返るチャレンジなので `challenge` にする(www.amazon.co.jp、2026-10-19)。
  - Akamai の `bm-verify`: 200 で、`meta refresh` の URL に `bm-verify=` が入っている。5 秒後に再読み込みされる。
  - AWS WAF: 202 で、本文に `gokuProps` がある。または、ヘッダー `x-amzn-waf-action: challenge` がある(本文が空でもよい)。
- 本文は、文字参照(`&#46;` など)を解いてから照合する。Akamai の Access Denied のページは、URL を文字参照で書いている。
- ブラウザの結果(③④)は本文の先頭しか残らないので、タイトルはブラウザで取ったものを使って判定する。Indeed のチャレンジのページは、先頭の 2048 バイトにタイトルが入っていなかった(2026-10-15)。
- status が 400 以上のときだけ、`cdn-cgi/challenge-platform`・Turnstile・`captcha-delivery.com`・`px-captcha` を根拠にする。通常ページにも同じ文字列が入るため。
- 手がかりは経験則。新しいパターンを見つけたら、`scripts/tests/test_classify.py` にサンプルを足してから `classify.py` を直す。
