"""ブラウザの確認(browser_probe.py・browser_route.py)を、この環境で動かして、JSON を標準出力に出す。

使い方:
  browser_run.py <URL> [--headless] [--body-bytes=N] [--no-fingerprint] [--chrome=PATH]   ③ 1 URL を開く(browser_probe.py)
  browser_run.py --route <目的ページの URL> [--route-pages=URL,URL] [--repeat=2] ...        ④ 経路を通ると着けるか(browser_route.py)
  browser_run.py --route --route-file=<計画の JSON> [--repeat=2] ...
  どちらにも --line=client_proxy|residential を付けると、その回線のプロキシ(CLIENT_PROXY / RESIDENTIAL_PROXY。.env か環境変数)を
  経由する。--proxy=URL を直接渡したときは、そちらを使う。どちらもなければ手元の回線(direct)。
  residential で RESIDENTIAL_PROXY がないときは、手元の回線で開く(ladder.py がステップ 3 で代用を確かめたあとにだけ使う)。

- ブラウザは、Google Chrome の安定版。初回だけ setup/ensure_chrome.sh がスキルの中の .tools/ に取る(amd64 のみ)。docker は要らない。
  既定はヘッドフル(画面が要る。WSL2 は WSLg、Mac は XQuartz)。--headless は動作確認用で、UA に HeadlessChrome が入るので、サイトの判定には使わない
- ④ は時間がかかる(数分)。待ち時間の上限は BROWSER_PROBE_TIMEOUT_SEC(既定は ③ が 90 秒、④ が 900 秒)。過ぎたら、
  ブラウザごと止めて、終了コード 4 で終わる
- 同じホストへ直前にリクエストを送っていたら(probe.py やこのスクリプト)、BROWSER_PROBE_COOLDOWN_SEC(既定 60 秒)
  経つまで待ってから起動する。続けてアクセスした直後は拒否されやすく、ブラウザの層の結果が悪く出ることがあるため。
  直前からの秒数と待った秒数は、結果の since_last_request_sec・cooldown_waited_sec に入る
"""

from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import urlsplit

from state import since_last_request, state_dir, touch_last_request

SCRIPTS = Path(__file__).parent
SCRIPT_FOR = {"probe": "browser_probe.py", "route": "browser_route.py"}
DEFAULT_TIMEOUT_SEC = {"probe": 90, "route": 900}
DEFAULT_COOLDOWN_SEC = 60
TIMED_OUT = 4


class UsageError(Exception):
    pass


def cooldown_wait(since: float | None, cooldown: float) -> float:
    """直前のリクエストから cooldown 秒経つまでの、残りの秒数。送ったことがなければ待たない。"""
    if since is None:
        return 0
    return max(cooldown - since, 0)


def parse_args(argv: list[str]) -> dict:
    """引数を、確認の種類(probe / route)・URL・子に渡すオプションに分ける。オプションはどの位置に置いてもよい。"""
    kind, url, options = "probe", None, []
    for a in argv:
        if a == "--route":
            kind = "route"
        elif a.startswith("--"):
            options.append(a)
        elif url is None:
            url = a
        else:
            options.append(a)
    if url is None and not (kind == "route" and any(o.startswith("--route-file=") for o in options)):
        raise UsageError("使い方: browser_run.py [--route] <URL | --route-file=計画の JSON> [オプション]")
    return {"kind": kind, "url": url, "options": options}


def _plan_start_url(path: str) -> str | None:
    try:
        step = json.loads(Path(path).read_text())["steps"][0]
        return step["url"] if isinstance(step.get("url"), str) and step["url"] else None
    except (OSError, ValueError, KeyError, IndexError, TypeError, AttributeError):
        return None


def start_url(parsed: dict) -> str | None:
    """直前のリクエストを確かめるホストの URL。計画ファイルのときは、計画の起点(steps[0].url)。"""
    if parsed["url"]:
        return parsed["url"]
    path = next((o.split("=", 1)[1] for o in parsed["options"] if o.startswith("--route-file=")), None)
    return _plan_start_url(path) if path else None


def proxy_args(options: list[str], resolver) -> list[str]:
    """--line を、プロキシの --proxy に直す(認証情報をコマンドに書かずに済む)。--line がなければ、記録する回線の名前を足す。"""
    line = next((o.split("=", 1)[1] for o in options if o.startswith("--line=")), None)
    has_proxy = any(o.startswith("--proxy=") for o in options)
    out = list(options)
    if line and not has_proxy and line != "direct":
        resolved = resolver(line)
        if resolved:
            out.append(f"--proxy={resolved}")
    if not line:
        out.append(f"--line={'client_proxy' if has_proxy else 'direct'}")
    return out


def timeout_sec(kind: str, environ) -> float:
    env = environ.get("BROWSER_PROBE_TIMEOUT_SEC")
    return float(env) if env else DEFAULT_TIMEOUT_SEC[kind]


def _stop_group(proc: subprocess.Popen, grace: float) -> None:
    """子のプロセスのグループ(ブラウザを含む)に SIGTERM を送り、片付けを待つ。終わらなければ SIGKILL。"""
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        proc.wait(timeout=grace)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait()


def run_child(cmd: list[str], timeout: float, grace: float = 30) -> tuple[int, str, str]:
    """cmd を実行して (終了コード, 標準出力, 標準エラー) を返す。timeout を過ぎたら、グループごと止めて終了コード 4。

    ブラウザは子のプロセスのさらに子。グループごと止めないと、相手へのアクセスが続く。
    このプロセスが SIGTERM・Ctrl-C で止められたときも、子を止めてから抜ける。
    """
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
    try:
        out, err = proc.communicate(timeout=timeout)
        return proc.returncode, out, err
    except subprocess.TimeoutExpired:
        _stop_group(proc, grace)
        out, err = proc.communicate()
        return TIMED_OUT, out or "", f"{timeout:g} 秒待っても終わらなかったので止めた(画面がなくて起動できていない可能性がある)\n{err or ''}"
    except BaseException:
        _stop_group(proc, grace)
        raise


def find_uv() -> str:
    uv = shutil.which("uv") or next((str(p) for p in (SCRIPTS.parent / ".tools" / "bin" / "uv", Path.home() / ".local" / "bin" / "uv") if p.exists()), None)
    if uv:
        return uv
    subprocess.run(["bash", str(SCRIPTS / "setup" / "ensure_uv.sh")], check=True, capture_output=True)
    return str(SCRIPTS.parent / ".tools" / "bin" / "uv")


def resolve_line(line: str) -> str:
    """回線の名前を、プロキシの URL にする(.env か環境変数から。residential でなければ空)。"""
    from egress import PROXY_KEYS, REPO_DOTENV, mask_proxy, resolve_proxy

    if line not in PROXY_KEYS:
        raise UsageError(f"--line は client_proxy・residential・direct のどれか: {line}")
    url, source = resolve_proxy(PROXY_KEYS[line], None, dotenv_path=REPO_DOTENV, environ=os.environ)
    if url:
        print(f"{line}: {mask_proxy(url)}({source}から)", file=sys.stderr)
    elif line == "client_proxy" and not os.environ.get("BT_DC_DIRECT"):
        raise UsageError("CLIENT_PROXY が見つからない(.env にも環境変数にもない)")
    else:
        print("RESIDENTIAL_PROXY がないので、手元の回線で開く(レジデンシャルの代用)", file=sys.stderr)
    return url or ""


def main(argv: list[str] | None = None) -> int:
    try:
        parsed = parse_args(sys.argv[1:] if argv is None else argv)
        options = proxy_args(parsed["options"], resolve_line)
    except UsageError as e:
        print(e, file=sys.stderr)
        return 2
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(128 + signal.SIGTERM))

    url = start_url(parsed)
    if url is None and parsed["url"] is None:
        print("計画ファイルから起点の URL を読めなかったため、直前のリクエストを待たずに起動する", file=sys.stderr)
    state = state_dir()
    since = since_last_request(state, url) if url else None
    if since is not None:
        wait = cooldown_wait(since, float(os.environ.get("BROWSER_PROBE_COOLDOWN_SEC", DEFAULT_COOLDOWN_SEC)))
        if wait > 0:
            print(f"{urlsplit(url).hostname} へは {int(since)} 秒前にリクエストを送っている。続けてアクセスした直後を避けるため、{int(wait)} 秒待ってから起動する", file=sys.stderr)
            time.sleep(wait)
        options += [f"--since-last-request={int(since)}", f"--cooldown-waited={int(wait)}"]

    cmd = [find_uv(), "run", "--quiet", str(SCRIPTS / SCRIPT_FOR[parsed["kind"]]), *([parsed["url"]] if parsed["url"] else []), *options]
    try:
        code, out, err = run_child(cmd, timeout_sec(parsed["kind"], os.environ))
    finally:
        if url:
            touch_last_request(state, url)
    sys.stdout.write(out)
    if code != 0:
        sys.stderr.write(err[:800])
    return code


if __name__ == "__main__":
    sys.exit(main())
