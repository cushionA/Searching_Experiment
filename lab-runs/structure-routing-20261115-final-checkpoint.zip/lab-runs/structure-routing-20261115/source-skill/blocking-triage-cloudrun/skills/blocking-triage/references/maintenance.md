# 保守: 同梱のファイルと、判定ロジックの直し方

診断の実行中には読まなくてよい。スクリプトを直すとき、新しい応答のパターンを見つけたとき、curl_cffi を上げたときに読む。

## 同梱のファイル

`scripts/` の直下は、診断で呼ぶスクリプトと、それが使うモジュール。テストは `scripts/tests/`、環境の用意は `scripts/setup/` に分けている。テストのファイル名は、対象のファイル名から決まる(`ladder.py` → `tests/test_ladder.py`、`node_axios.mjs` → `tests/node_axios.test.mjs`)。

| ファイル | 用途 |
|---|---|
| `scripts/setup/ensure_uv.sh` | uv を用意する |
| `scripts/setup/ensure_chrome.sh` | Google Chrome の安定版を、スキルの中の `.tools/chrome/` に取る(ブラウザの確認の既定。`browser_common.setup_chrome` が呼ぶ)。新しい版に替えるときは `BLOCKING_TRIAGE_CHROME_REFRESH=1` |
| `scripts/setup/ensure_chrome_libs.sh` | Chrome が要る共有ライブラリ(libnspr4・libnss3・libasound2 など。対応表は `package_for`)が足りないとき、root なしで `.tools/libs/` に取る。冪等。システムの apt に索引がなければ、索引を `.tools/apt/` に作って使う。`.tools/libs/` に、この環境の glibc では読めないライブラリが残っていれば、`.tools/libs.stale/` へ退避して取り直す。対応表にないライブラリが足りないときは、`package_for` に足す |
| `scripts/egress.py` | 回線のプロキシの解決(`CLIENT_PROXY`・`RESIDENTIAL_PROXY`)、レジデンシャルを手元の回線で代用するかの判断、ASN の組織名からの種類の推定、プロキシの認証情報の伏せ字。`tests/test_egress.py` で検証する |
| `scripts/ladder.py` | ステップ 0〜5 を順に試し、最初に通ったステップで止める。Chrome をまねた接続のステップ(1・4)で通ったら、同じ回線で Chrome のヘッダー一式を付けた curl(`--client axios` のときは Axios)も試す。ステップ 0・3 の既定は素の curl(`--client axios`・`--client basic` は、qcv3 のある環境だけ)。読み(原因の層・確度・推奨構成)も出す。`--route-pages`・`--route-file` でステップ 6。ステップの実行は probe.py と browser_run.py を使う。ステップの進め方と読みは `tests/test_ladder.py` で検証する |
| `scripts/node_axios.mjs` | qcv3 の `AxiosClient` そのもので 1 URL を取得する(`--client axios` のときのステップ 0・3。qcv3 のある環境だけ)。`headers` を渡すと、パーサーと同じく `axiosOptions.headers` で足す(Chrome のヘッダー一式の確認)。認証つきのプロキシには、本番と違って認証を足して送る(`proxy_auth_added`)。`tests/node_axios.test.mjs` で検証する |
| `scripts/node_basic.mjs` | qcv3 の Basic と同じ `request` ライブラリで 1 URL を取得する(`--client basic` のときのステップ 0・3)。`tests/node_basic.test.mjs` で検証する |
| `scripts/body_decode.mjs` | node_axios.mjs と node_basic.mjs が共有する本文の読み方。ヘッダーに文字コードがなければ、本文の meta の charset で読む。`tests/body_decode.test.mjs` で検証する |
| `scripts/probe.py` | 1 つの回線(`--line`)で、URL をクライアントごとに確認する(ladder.py のステップ 0・1・3・4 もこれを使う)。`--impersonate`(curl_cffi の版)・`--self-check`・`--egress-info`・`--classify-json`(ブラウザの結果の判定)・`--compare-human` もここ。リクエストの組み立てと表は `tests/test_probe.py` で検証する |
| `scripts/routes_store.py` | 経路を辿る確認の経路と結果を、`references/routes.json` に保存・検索する(保存、同じサイトの経路の検索、使うかどうかの判断、読みの文)。保存は、ディレクトリのロックと、一時ファイルからの置き換えで行う(同時に流した診断の結果が消えず、途中で止まってもファイルが壊れない)。`tests/test_routes_store.py` で検証する。保存先は `BLOCKING_TRIAGE_ROUTES` で変えられる |
| `scripts/state.py` | 実行をまたぐ状態。結果の履歴(前回との比較。回線の ASN とブラウザの種類まで同じ結果とだけ比べる)と、ホストごとの直前のリクエストの時刻。置き場所は `temp/blocking-triage/`(`BLOCKING_TRIAGE_STATE_DIR` で変更)。`tests/test_state.py` で検証する |
| `scripts/browser_run.py` | ブラウザの確認(`browser_probe.py`・`browser_route.py`)を、この環境で動かして JSON を出す(ステップ 2・5・6)。`--line` で回線のプロキシを引く。直前のリクエストからの待ち(60 秒)と、待ち時間(③ 90 秒・④ 900 秒)を過ぎたときのブラウザごとの後始末を持つ。docker は使わない。`tests/test_browser_run.py` で検証する |
| `scripts/browser_probe.py` | nodriver で開いた Google Chrome(ヘッドフル)で 1 URL を開く(③)。指紋と JS から見える値も出す。cookie は名前だけ出す |
| `scripts/browser_route.py` | 経路を通ると目的ページに着けるかを調べる(④の手 A〜C)。`browser_run.py --route` から使う |
| `scripts/route_lib.py` | ④の、ブラウザに依存しない部分(手の定義(`_abck` の合格を待ってから `location.href` で移る `warmup_location` を含む)、経路の組み立て、リンクの選び方、通過の判定、操作の計画、計画ファイルの検査)。`tests/test_route_lib.py` で検証する |
| `scripts/browser_common.py` | ③と④が共有する部品。ブラウザに依存しない部分(プロキシの分解、起動の引数、チャレンジの判定、指紋の読み取り)は `tests/test_browser_common.py` で検証する。ブラウザを動かす部分(Chrome の取得、起動、チャレンジを待つ処理、指紋の測定)は、実行して確かめる。Chrome の起動には、WebGL を有効にするフラグ(`--enable-unsafe-swiftshader`)を足す |
| `scripts/parser_flow.mjs` | パーサーのコード(.ts / .js)から、起点・kind の遷移・セレクタを静的に取り出す(④の二案目)。`tests/parser_flow.test.mjs` で検証する |
| `scripts/route_summary.py` | ブラウザのステップとステップ 6 の結果を `classify` で判定し直す。④は、最初に通った手と読みも出す。`tests/test_route_summary.py` で検証する |
| `scripts/browser_env.py` | ③の指紋を Chrome 155 の参照値と比べ、JS から見える値から手がかりを挙げる。人の Chrome と③の比較(`--compare-human`)もここ。`tests/test_browser_env.py` で検証する |
| `scripts/human_check.js` | 人の Chrome(または Chrome 拡張)のコンソールで実行し、③と同じ項目(指紋と JS から見える値)を 1 行の JSON で出すスニペット |
| `scripts/classify.py` | 応答からベンダーと種類を推定する。`tests/test_classify.py` で検証する |
| `references/vendors.md` | ベンダーの見分け方と `kind` の意味 |
| `references/routes.json` | 経路を辿る確認で使った経路と、その結果。ladder.py が自動で足す。git で共有する |
| `references/remedies.md` | 診断から qcv3 の対策への対応表(推奨構成を出すときに使う) |
| `references/extra-checks.md` | 診断の本筋の外の確認(ブラウザの動作確認、人の Chrome と比べる) |
| `references/environment.md` | 環境の構成(使えるクライアント・ブラウザ・ベースイメージ・回線)と、診断が求めるものの当てはめ。推奨構成を出すときに読む。環境が変わったら直す(SKILL.md の手順 7)。qcv3 の構成の情報は、ほかのファイルに書かず、ここにだけ書く |
| `references/route-plan.md` | パーサーから経路の計画を作る手順と、計画ファイルの書き方 |
| `references/qcv3-entry.md` | 補助: ABORTED の Job の URL を取り出す |
| `references/report-template.md` | 記録の様式 |
| `evals/evals.json` | skill の評価用のシナリオ。診断の実行には使わない |

## 判定ロジックを直すとき

新しい応答のパターンを見つけたら、`scripts/tests/test_classify.py` にサンプルを足して、失敗を確認してから `classify.py` を直す。

```bash
cd .claude/skills/blocking-triage/scripts
uv run --with pytest --with curl_cffi pytest -q -p no:cacheprovider tests   # ladder・classify・route_summary・route_lib・probe・egress・state・browser_env・browser_common・browser_run・routes_store
node --test tests/                                                         # parser_flow・node_basic・node_axios・body_decode
```

## 経路の手を足すとき

経路の手は、`location.href` で移る → クリックで辿る → `_abck` の合格を待ってから `location.href` で移る、の 3 つにしている。2026-10-23 に、次の 3 つを外した。

- **curl_cffi に Referer だけを付けて開く手**: 経路を辿るのは、curl_cffi もブラウザも通らなかったときなので、この手だけが通る場面がまずない。通っても curl_cffi は本番のクライアントではなく、そこで止まるため、ブラウザで経路を辿った結果も取れない。
- **手前のページを開いてから、goto に Referer を渡して移る手**: `location.href` で移る手との違いは、`Sec-Fetch-Site` が `none` で届くことだけである。手前のページの cookie は、どちらの手でも付く。この手で通って、`location.href` では通らないサイトは考えにくい。
- **`_abck` の合格を待ってから、クリックで辿る手**: `_abck` が合格したあとに残る条件は移り方で、それは `location.href` の手とクリックの手で切り分けられる。待ちの上限(70 秒)を試行の回数分使い、1 回の確認で使える 40 ロードも減らしていた。

手を足すときは、ほかの手と届くもの(ヘッダー、cookie、操作データ)が違い、その違いを `reading` の候補として書ける手だけにする。

## curl_cffi を上げたとき

`uv run probe.py --self-check` の curl_cffi の JA4 が変わったら、curl_cffi の模倣する Chrome の版が変わっている。`probe.py` の `CHROME_IMPERSONATE_UA` と `CURL_CFFI_SEC_CH_UA`(`--chrome-ua` が版だけを替える元の値)を、curl_cffi が送る値に合わせて直す。

`CHROME_HEADERS` と `CHROME_UA` は、資料の実験と同じ Chrome 155 の値で、curl_cffi を上げても変えない(資料の観測と比べるため)。
