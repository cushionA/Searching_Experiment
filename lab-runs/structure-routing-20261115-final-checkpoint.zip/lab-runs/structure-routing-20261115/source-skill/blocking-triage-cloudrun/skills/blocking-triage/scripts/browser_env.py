"""③のブラウザについて、接続の指紋と、ページの JS から見える値を読む(純関数)。

③で開けなかったとき、どの層の情報が Chrome と違うかを挙げるために使う。
参照値は、資料「ボット対策がリクエストを見分ける仕組み」の Chrome 155 の実測(2026-10-12)。
"""

from __future__ import annotations

import re

CHROME_REFERENCE = {
    "version": 155,
    "date": "2026-10-12",
    "ja4": "t13d1517h2_8daaf6152771_cb7bf5808d99",
    "akamai_h2": "1:65536;2:0;4:6291456;6:262144|15663105|0|m,a,s,p",
}
_SOFTWARE_GL = re.compile(r"swiftshader|llvmpipe|softpipe|software rasterizer|microsoft basic render", re.IGNORECASE)


def _ja4_parts(ja4: str | None) -> list[str]:
    return (ja4 or "").split("_")


def _ua_major(ua: str | None) -> int | None:
    m = re.search(r"Chrome/(\d+)", ua or "")
    return int(m.group(1)) if m else None


def read_fingerprint(fp: dict | None) -> dict:
    """ブラウザが tls.peet.ws に送った指紋を、Chrome の参照値と比べる。

    TLS は JA4 の 2 つ目(暗号スイート)で比べる。3 つ目(拡張)は Chrome の版で変わるので、一致は求めない。
    """
    fp = fp or {}
    ref = CHROME_REFERENCE
    out = {"ja4": fp.get("ja4"), "akamai_h2": fp.get("akamai_h2"), "ua_major": _ua_major(fp.get("user_agent")),
           "ja4_ciphers_match_chrome": None, "h2_matches_chrome": None, "notes": []}  # fmt: skip
    if fp.get("error") or not fp.get("ja4"):
        out["notes"].append(f"指紋を取れなかった({fp.get('error') or '応答に ja4 がない'})。接続の作り方の層は未確認")
        return out
    ours, theirs = _ja4_parts(fp["ja4"]), _ja4_parts(ref["ja4"])
    out["ja4_ciphers_match_chrome"] = len(ours) == 3 and ours[1] == theirs[1]
    out["h2_matches_chrome"] = fp.get("akamai_h2") == ref["akamai_h2"]
    label = f"Chrome {ref['version']}({ref['date']} の実測)"
    if out["ja4_ciphers_match_chrome"] and out["h2_matches_chrome"]:
        out["notes"].append(f"JA4 の暗号スイートの部分と HTTP/2 の指紋は {label} と同じ。接続の作り方の層は Chrome と見分けにくい")
    else:
        diff = [n for n, ok in (("JA4 の暗号スイートの部分", out["ja4_ciphers_match_chrome"]), ("HTTP/2 の指紋", out["h2_matches_chrome"])) if not ok]
        out["notes"].append(f"{'と'.join(diff)}が {label} と違う。接続の作り方の層が原因の候補に残る")
    if len(ours) == 3 and ours[2] != theirs[2]:
        if any(e.startswith("pre_shared_key") for e in fp.get("extensions") or []):
            out["notes"].append(
                "JA4 の拡張の部分は Chrome 155 と違う。pre_shared_key があるので、TLS のセッションを再開した接続で、"
                "その分だけ拡張が増えている。実際の利用者にも普通にある違い(個体差)なので、原因の候補にしない"
            )
        else:
            out["notes"].append(
                "JA4 の拡張の部分は Chrome 155 と違う。Chrome の版のほか、同じサイトへの 2 回目以降の接続で TLS のセッションを"
                "再開すると(pre_shared_key が加わる)変わる"
            )
    major = out["ua_major"]
    if major is not None and major < ref["version"]:
        out["notes"].append(
            f"UA の版は Chrome/{major}。資料の Chrome {ref['version']} より {ref['version'] - major} 版古い。"
            "古い版を受け付けないサイトでは、版の差が原因の候補になる"
        )
    return out


def _ua_os(ua: str) -> str | None:
    if "Windows" in ua:
        return "windows"
    if "Mac OS X" in ua or "Macintosh" in ua:
        return "mac"
    if "Linux" in ua or "X11" in ua:
        return "linux"
    return None


def _platform_os(platform: str | None) -> str | None:
    p = (platform or "").lower()
    if p.startswith("win"):
        return "windows"
    if p.startswith("mac"):
        return "mac"
    if p.startswith("linux"):
        return "linux"
    return None


def env_flags(user_agent: str | None, webdriver: bool | None, js_env: dict | None) -> list[str]:
    """ページの JS から見える値のうち、ボット対策が自動化やヘッドレスの手がかりにしうるものを挙げる。

    手がかりは一般に知られた特徴で、相手のサイトが実際に見ているかは分からない。候補として読む。
    """
    ua = user_agent or ""
    env = js_env or {}
    chrome = "Chrome/" in ua and "Firefox/" not in ua
    flags = []
    if webdriver:
        flags.append("navigator.webdriver が true。自動化の痕跡で、ページの JS から見える")
    if "HeadlessChrome" in ua:
        flags.append("UA に HeadlessChrome が入っている。ヘッドレスで起動している")
    if "webgl_renderer" in env:
        renderer = env["webgl_renderer"]
        if renderer is None:
            flags.append("WebGL が使えない。通常のブラウザではまれ")
        elif _SOFTWARE_GL.search(renderer):
            flags.append(f"WebGL がソフトウェア描画({renderer})。GPU のないコンテナやサーバの特徴")
    if chrome and env.get("plugins") == 0:
        flags.append("navigator.plugins が 0 個。通常のヘッドフルの Chrome は 5 個")
    win = env.get("window") or {}
    if win.get("outer_width") == 0 or win.get("outer_height") == 0:
        flags.append("window の outerWidth / outerHeight が 0。ヘッドレスの特徴")
    brands = env.get("ua_brands")
    if chrome and isinstance(brands, list) and not any(b.startswith("Google Chrome") for b in brands):
        flags.append("userAgentData の brands に Google Chrome がない(Chromium)。正規の Chrome ではないことが JS から分かる")
    ua_os, pf_os = _ua_os(ua), _platform_os(env.get("platform"))
    if ua_os and pf_os and ua_os != pf_os:
        flags.append(f"UA の OS({ua_os})と navigator.platform({env.get('platform')})が合わない")
    return flags


def _software_gl(env: dict) -> bool | None:
    r = env.get("webgl_renderer")
    return None if r is None else bool(_SOFTWARE_GL.search(r))


def _has_chrome_brand(env: dict) -> bool | None:
    brands = env.get("ua_brands")
    return None if not isinstance(brands, list) else any(b.startswith("Google Chrome") for b in brands)


# 実際の利用者のあいだでも普通に違う項目(個体差)。違っても原因の候補にしない
# - JA4 の拡張の部分: 版のほか、同じサイトへの 2 回目以降の接続(セッションの再開)でも変わる。版は「UA の版」で見る
# - navigator.platform: PC の OS。UA と食い違うときだけ env_flags が手がかりにする
_INDIVIDUAL = {"JA4 の拡張の部分", "片方だけにある拡張", "navigator.platform"}


def compare_browsers(human: dict, probe: dict) -> dict:
    """人の Chrome(human_check.js の結果)と、③のブラウザ(browser_probe.py の結果)を項目ごとに並べる。

    目的は③を人の Chrome に合わせることではない。人の Chrome は「そのサイトを通る実際のブラウザ」の 1 例で、
    ③にあって実際の利用者にはまれな違い(古い版、ソフトウェア描画、自動化の痕跡など)を、原因の候補として挙げる。
    PC ごとに違う項目(OS、GPU の機種、セッションの再開による拡張の違い)は個体差として、候補にしない。
    """
    hf, pf = human.get("fingerprint") or {}, probe.get("fingerprint") or {}
    he, pe = human.get("js_env") or {}, probe.get("js_env") or {}
    hj, pj = _ja4_parts(hf.get("ja4")), _ja4_parts(pf.get("ja4"))

    def part(parts: list[str], i: int) -> str | None:
        return parts[i] if len(parts) == 3 else None

    items = [
        ("JA4 の暗号スイートの部分", part(hj, 1), part(pj, 1)),
        ("JA4 の拡張の部分", part(hj, 2), part(pj, 2)),
        ("HTTP/2 の指紋", hf.get("akamai_h2"), pf.get("akamai_h2")),
        ("UA の版", _ua_major(human.get("user_agent")), _ua_major(probe.get("user_agent"))),
        ("brands に Google Chrome があるか", _has_chrome_brand(he), _has_chrome_brand(pe)),
        ("WebGL がソフトウェア描画か", _software_gl(he), _software_gl(pe)),
        ("navigator.webdriver", human.get("webdriver"), probe.get("webdriver")),
        ("plugins の数", he.get("plugins"), pe.get("plugins")),
        ("navigator.platform", he.get("platform"), pe.get("platform")),
    ]
    rows = [{"item": n, "human": h, "browser_probe": p, "same": None if h is None or p is None else h == p} for n, h, p in items]
    hx, px = hf.get("extensions"), pf.get("extensions")
    if isinstance(hx, list) and isinstance(px, list):
        only_h, only_p = [e for e in hx if e not in px], [e for e in px if e not in hx]
        rows.append({"item": "片方だけにある拡張", "human": only_h, "browser_probe": only_p, "same": not only_h and not only_p})
    for r in rows:
        r["role"] = "個体差" if r["item"] in _INDIVIDUAL else "候補"

    hflags = env_flags(human.get("user_agent"), human.get("webdriver"), he)
    pflags = env_flags(probe.get("user_agent"), probe.get("webdriver"), pe)

    def key(f: str) -> str:  # 文言には値(版や GPU の名前)が入るので、手がかりの種類(文頭)で突き合わせる
        return f.split("(")[0].split("。")[0]

    only_probe = [f for f in pflags if key(f) not in {key(x) for x in hflags}]
    only_human = [f for f in hflags if key(f) not in {key(x) for x in pflags}]
    candidates = [r["item"] for r in rows if r["role"] == "候補" and r["same"] is False]

    # 切り分けとして返すのは層だけ。どの項目が違ったか(candidates)は JSON に残し、読みには出さない
    same = {r["item"]: r["same"] for r in rows}
    if same["JA4 の暗号スイートの部分"] is None or same["HTTP/2 の指紋"] is None:
        layer, reading = "未確認", "どちらかの指紋が取れていないので、接続の層は比べられない"
    elif not (same["JA4 の暗号スイートの部分"] and same["HTTP/2 の指紋"]):
        layer, reading = "接続の層", "人の Chrome と③は、接続の作り方(TLS / HTTP/2)が違う。接続の層が原因の候補に残る"
    elif candidates or only_probe:
        layer = "JS の層かブラウザの版"
        reading = "接続の層は同じ。③には、実際の利用者のブラウザにはまれな特徴が、JS から見える値かブラウザの版に残っている。原因の候補はこの層"
    else:
        layer = "比べた層に違いなし"
        reading = "接続の層も JS から見える値も、個体差を除いて同じ。比べていない条件(プロファイルや cookie、回線、操作、アクセスの間隔)が候補"
    return {"layer": layer, "reading": reading, "rows": rows, "candidates": candidates,
            "only_in_browser_probe": only_probe, "only_in_human": only_human}  # fmt: skip
