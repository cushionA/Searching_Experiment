// node_basic.mjs のテスト。ローカルのサーバーだけを使い、外へは送らない。実行: node --test .claude/skills/blocking-triage/scripts/tests/
import assert from 'node:assert/strict';
import http from 'node:http';
import { test } from 'node:test';

import { fetchBasic } from '../node_basic.mjs';

async function serve(handler) {
  const server = http.createServer(handler);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  return { server, origin: `http://127.0.0.1:${port}` };
}

test('リダイレクトを辿ったとき、最終 URL・HTTP/1.1・途中の応答も含めた cookie の名前を返し、送るヘッダーは UA だけであること', async (t) => {
  let received;
  const { server, origin } = await serve((req, res) => {
    if (req.url === '/start') {
      res.writeHead(302, { location: '/end', 'set-cookie': '__cf_bm=secret-1; Path=/' });
      return res.end();
    }
    received = req.headers;
    res.writeHead(403, { 'content-type': 'text/html; charset=utf-8', 'set-cookie': 'cf_clearance=secret-2; Path=/' });
    res.end('<title>Attention Required!</title>');
  });
  t.after(() => server.close());

  const out = await fetchBasic({ url: `${origin}/start`, userAgent: 'UA-for-test' });

  assert.equal(out.status, 403);
  assert.equal(out.http_version, 'http/1.1');
  assert.equal(out.final_url, `${origin}/end`);
  assert.deepEqual(out.cookie_names, ['__cf_bm', 'cf_clearance']);
  assert.equal(out.body, '<title>Attention Required!</title>');
  assert.ok(!JSON.stringify(out).includes('secret-'), 'cookie の値を出さない');
  // Basic は user-agent だけを足す。accept や accept-encoding は付けない
  assert.equal(received['user-agent'], 'UA-for-test');
  assert.equal(received.accept, undefined);
  assert.equal(received['accept-encoding'], undefined);
});

test('プロキシを渡したとき、プロキシに絶対 URL で送り、URL の認証情報を Proxy-Authorization で付けること', async (t) => {
  let seen;
  const { server, origin } = await serve((req, res) => {
    seen = { url: req.url, auth: req.headers['proxy-authorization'] };
    res.writeHead(200, { 'content-type': 'text/html' });
    res.end('<title>ok</title>');
  });
  t.after(() => server.close());
  const proxy = origin.replace('http://', 'http://user:pass@');

  const out = await fetchBasic({ url: 'http://target.example/page', proxy, userAgent: 'UA' });

  assert.equal(out.status, 200);
  assert.equal(seen.url, 'http://target.example/page');
  assert.equal(seen.auth, `Basic ${Buffer.from('user:pass').toString('base64')}`);
});

test('接続できないとき、例外を投げずに error を返すこと', async () => {
  const { server, origin } = await serve(() => {});
  await new Promise((resolve) => server.close(resolve)); // 閉じたポートに送る

  const out = await fetchBasic({ url: `${origin}/`, userAgent: 'UA', timeoutMs: 3000 });

  assert.match(out.error, /ECONNREFUSED/);
});
