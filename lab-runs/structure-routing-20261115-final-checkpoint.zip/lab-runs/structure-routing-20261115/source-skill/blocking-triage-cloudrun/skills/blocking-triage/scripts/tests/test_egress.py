"""egress.py のテスト。実行: uv run --with pytest pytest .claude/skills/blocking-triage/scripts/tests"""

import pytest

from egress import (
    asn_of,
    choose_residential,
    egress_kind,
    mask_proxy,
    redact,
    resolve_proxy,
)


@pytest.mark.parametrize(
    "org, expected",
    [
        ("AS15169 Google LLC", "datacenter"),
        ("AS16509 Amazon.com, Inc.", "datacenter"),
        ("AS8075 Microsoft Corporation", "datacenter"),
        ("AS14061 DigitalOcean, LLC", "datacenter"),
        ("AS12345 Example Hosting Ltd", "datacenter"),
        ("AS2527 Sony Network Communications Inc.", "isp"),
        ("AS2516 KDDI CORPORATION", "isp"),
        ("AS17676 SoftBank Corp.", "isp"),
        ("AS2518 BIGLOBE Inc.", "isp"),
        ("AS4685 Asahi Net", "isp"),
        ("AS99999 Foo Bar", "unknown"),
        ("", "unknown"),
        (None, "unknown"),
    ],
)
def test_egress_kind_is_guessed_from_the_org_name(org, expected):
    assert egress_kind(org) == expected


def test_credentials_are_masked_in_proxy_urls():
    assert mask_proxy("http://gke.example.com:57884") == "http://gke.example.com:57884"
    assert mask_proxy("http://user:secret@res.example.com:8000") == "http://***@res.example.com:8000"
    assert mask_proxy(None) is None


def test_redact_removes_credentials_from_error_text():
    urls = ["http://user:secret@res.example.com:8000", "http://gke.example.com:57884", None]
    text = "curl exit 5: Could not resolve proxy: http://user:secret@res.example.com:8000 (user:secret@res.example.com)"
    out = redact(text, urls)
    assert "secret" not in out and "user:" not in out
    # 認証情報のない URL や、無関係な文は変えない
    assert redact("via http://gke.example.com:57884", urls) == "via http://gke.example.com:57884"
    assert redact("no secrets here", urls) == "no secrets here"


ENV_URL = "http://env.example.com:1111"
DOTENV_URL = "http://dotenv.example.com:2222"
ARG_URL = "http://arg.example.com:3333"


@pytest.mark.parametrize("key", ["CLIENT_PROXY", "RESIDENTIAL_PROXY"])
@pytest.mark.parametrize(
    "arg, dotenv_line, env_value, expected",
    [
        (ARG_URL, f'="{DOTENV_URL}"', ENV_URL, (ARG_URL, "引数")),
        (None, f'="{DOTENV_URL}"', ENV_URL, (DOTENV_URL, ".env")),
        (None, None, ENV_URL, (ENV_URL, "環境変数")),
        (None, None, None, (None, None)),
    ],
)
def test_proxy_is_taken_from_arg_then_dotenv_then_environ(tmp_path, key, arg, dotenv_line, env_value, expected):
    dotenv = tmp_path / ".env"
    dotenv.write_text(f"{key}{dotenv_line}\n" if dotenv_line else "OTHER=1\n")
    environ = {key: env_value} if env_value else {}
    assert resolve_proxy(key, arg, dotenv_path=dotenv, environ=environ) == expected


@pytest.mark.parametrize(
    "dotenv_text, expected",
    [
        (f'CLIENT_PROXY="{DOTENV_URL}"', DOTENV_URL),
        (f"CLIENT_PROXY='{DOTENV_URL}'", DOTENV_URL),
        (f"CLIENT_PROXY={DOTENV_URL}", DOTENV_URL),
        (f"export CLIENT_PROXY={DOTENV_URL}", DOTENV_URL),
        (f"CLIENT_PROXY = {DOTENV_URL}  # 開発用", DOTENV_URL),
        (f'# CLIENT_PROXY="http://old:1"\nCLIENT_PROXY="{DOTENV_URL}"', DOTENV_URL),
        (f'CLIENT_PROXY="http://old:1"\nCLIENT_PROXY="{DOTENV_URL}"', DOTENV_URL),
        ('MY_CLIENT_PROXY="http://other:1"\nCLIENT_PROXY_X="http://other:2"', None),
        ('CLIENT_PROXY=""', None),
    ],
)
def test_proxy_line_in_dotenv_is_read_like_dotenv(tmp_path, dotenv_text, expected):
    dotenv = tmp_path / ".env"
    dotenv.write_text(dotenv_text + "\n")
    url, _ = resolve_proxy("CLIENT_PROXY", None, dotenv_path=dotenv, environ={})
    assert url == expected


def test_missing_dotenv_file_falls_back_to_environ(tmp_path):
    assert resolve_proxy("CLIENT_PROXY", None, dotenv_path=tmp_path / "none.env", environ={"CLIENT_PROXY": ENV_URL}) == (
        ENV_URL,
        "環境変数",
    )


RES_URL = "http://user:secret@res.example.com:8000"


def test_residential_proxy_is_used_when_given_whatever_the_local_line_is():
    line = choose_residential(RES_URL, ".env", direct_kind="datacenter")
    assert line == {"line": "residential", "egress": "residential", "proxy": RES_URL, "source": ".env", "substitute": False}


def test_without_a_residential_proxy_the_local_line_stands_in_only_when_it_looks_like_an_isp():
    line = choose_residential(None, None, direct_kind="isp")
    assert line == {"line": "residential", "egress": "direct", "proxy": None, "source": "手元の回線(isp)", "substitute": True}


@pytest.mark.parametrize("kind", ["unknown", "datacenter", None])
def test_without_a_residential_proxy_and_a_local_line_that_is_not_an_isp_there_is_no_residential_line(kind):
    assert choose_residential(None, None, direct_kind=kind) is None


def test_local_line_stands_in_when_the_user_says_it_is_a_home_line_even_if_the_guess_is_unknown():
    # kind_guess は組織名からの推定。家庭用・会社の ISP 回線だと分かっているときは、人の判断で代用できる
    line = choose_residential(None, None, direct_kind="unknown", force_direct=True)
    assert line == {"line": "residential", "egress": "direct", "proxy": None, "source": "手元の回線(指定)", "substitute": True}


@pytest.mark.parametrize(
    "org, expected",
    [
        ("AS2527 Sony Network Communications Inc.", "AS2527"),
        ("AS396982 Google LLC", "AS396982"),
        ("Foo Bar", None),
        (None, None),
    ],
)
def test_asn_is_taken_from_the_head_of_the_org_name(org, expected):
    assert asn_of(org) == expected
