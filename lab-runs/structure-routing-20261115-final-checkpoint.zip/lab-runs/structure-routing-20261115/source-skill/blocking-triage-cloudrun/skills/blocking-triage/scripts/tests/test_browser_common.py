"""browser_common.py のテスト。ブラウザは起動しない。"""

from browser_common import body_head, cookie_names, error_text, in_challenge, launch_args, parse_fingerprint, proxy_option


def test_proxy_with_credentials_is_split_into_server_and_credentials_and_the_label_hides_them():
    p = proxy_option("http://user:secret@proxy.example.com:8080")

    assert p["option"] == {"server": "http://proxy.example.com:8080", "username": "user", "password": "secret"}
    assert p["label"] == "http://proxy.example.com:8080"
    assert "secret" not in p["label"] and "user" not in p["label"]


def test_url_encoded_proxy_credentials_are_decoded_to_the_original_characters():
    p = proxy_option("http://us%40er:p%3Ass%2Fw@proxy.example.com:8080")

    assert (p["option"]["username"], p["option"]["password"]) == ("us@er", "p:ss/w")


def test_without_a_proxy_nothing_is_returned_so_no_empty_setting_reaches_chrome():
    assert proxy_option(None) == {"option": None, "label": None}
    assert proxy_option("") == {"option": None, "label": None}


def test_chrome_is_started_with_the_flag_that_enables_software_rendered_webgl():
    # GPU のないコンテナでは、Chrome は WebGL を無効にする。本物の Chrome と同じ結果にするため、有効にして開く
    assert "--enable-unsafe-swiftshader" in launch_args("chrome", "--no-sandbox")


def test_chrome_is_started_with_japanese_accept_language_so_that_language_is_not_en_us_in_a_container_without_locale():
    # --lang だけでは、LANG のないコンテナで navigator.language が en-US のままだった(日本語のサイトに en-US で来る)
    assert "--accept-lang=ja,en-US,en" in launch_args("chrome", "--no-sandbox")


def test_when_the_arguments_from_the_environment_are_empty_or_blank_no_empty_element_is_mixed_in():
    assert launch_args("chromium", None) == []
    assert launch_args("chromium", "") == []
    assert launch_args("chromium", "   ") == []
    assert launch_args("chromium", " --a   --b ") == ["--a", "--b"]


import pytest  # noqa: E402


@pytest.mark.parametrize(
    "title, has_element, expected",
    [
        ("Just a moment...", False, True),  # Cloudflare
        ("Security Check", False, True),
        ("Checking your browser before accessing", False, True),
        ("", True, True),  # Akamai・AWS WAF の画面は、200・タイトル空で返ることがあり、タイトルでは分からない
        (None, True, True),
        ("求人 一覧", False, False),  # 通常のページ
        ("", False, False),
    ],
)
def test_the_page_is_judged_to_be_in_a_challenge_by_its_title_or_a_challenge_element(title, has_element, expected):
    assert in_challenge(title, has_element) is expected


def test_the_fingerprint_gets_ja4_h2_http_version_and_extensions_without_grease_and_broken_json_is_an_error():
    import json

    body = json.dumps({
        "http_version": "h2",
        "user_agent": "Mozilla/5.0 Chrome/155.0.0.0",
        "tls": {"ja4": "t13d1517h2_8daaf6152771_cb7bf5808d99",
                "extensions": [{"name": "TLS_GREASE (0x1a1a)"}, {"name": "server_name (0)"}, {"name": "alpn (16)"}]},
        "http2": {"akamai_fingerprint": "1:65536;2:0;4:6291456;6:262144|15663105|0|m,a,s,p"},
    })

    assert parse_fingerprint(body) == {
        "ja4": "t13d1517h2_8daaf6152771_cb7bf5808d99",
        "akamai_h2": "1:65536;2:0;4:6291456;6:262144|15663105|0|m,a,s,p",
        "http_version": "h2",
        "extensions": ["server_name (0)", "alpn (16)"],
        "user_agent": "Mozilla/5.0 Chrome/155.0.0.0",
    }
    assert "error" in parse_fingerprint("<html>not json")


def test_cookies_are_reported_by_name_only_without_duplicates_in_a_fixed_order():
    cookies = [{"name": "_abck", "value": "SECRET-1"}, {"name": "bm_sz", "value": "SECRET-2"}, {"name": "_abck", "value": "SECRET-3"}]

    names = cookie_names(cookies)

    assert names == ["_abck", "bm_sz"]
    assert "SECRET" not in repr(names)


def test_the_head_of_the_body_is_cut_to_the_given_length():
    assert body_head("a" * 5000, 2048) == "a" * 2048
    assert body_head("short", 2048) == "short"


def test_a_failure_is_reported_as_the_exception_name_and_only_the_first_line_cut_to_300_characters():
    multi_line = RuntimeError("net::ERR_PROXY_CONNECTION_FAILED\n    at stack frame 1\n    at stack frame 2")
    long_line = RuntimeError("x" * 400)

    assert error_text(multi_line) == "RuntimeError: net::ERR_PROXY_CONNECTION_FAILED"
    assert error_text(long_line) == "RuntimeError: " + "x" * 300
