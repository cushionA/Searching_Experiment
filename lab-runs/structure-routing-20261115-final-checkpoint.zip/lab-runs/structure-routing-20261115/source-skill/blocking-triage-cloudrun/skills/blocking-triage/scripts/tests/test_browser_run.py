"""browser_run.py のテスト。ブラウザの確認を動かす前の、待ち時間・引数・回線・後始末。実行: uv run --with pytest pytest .claude/skills/blocking-triage/scripts/tests"""

import json
import os
import sys
import time

import pytest

from browser_run import UsageError, cooldown_wait, parse_args, proxy_args, run_child, start_url, timeout_sec


# ---- 直前のリクエストからの待ち時間


@pytest.mark.parametrize(
    "since, expected",
    [(10, 50), (59.5, 0.5), (60, 0), (300, 0), (None, 0)],
    ids=["10 秒前なら残り 50 秒", "59.5 秒前なら残り 0.5 秒", "ちょうど 60 秒なら待たない", "十分前なら待たない", "送ったことがなければ待たない"],
)
def test_waits_for_the_rest_of_the_cooldown_since_the_last_request(since, expected):
    assert cooldown_wait(since, 60) == expected


# ---- 引数を分ける


def test_a_url_with_options_is_a_single_page_check_and_the_options_stay_in_order():
    parsed = parse_args(["--headless", "https://example.com/x", "--body-bytes=100"])
    assert (parsed["kind"], parsed["url"], parsed["options"]) == ("probe", "https://example.com/x", ["--headless", "--body-bytes=100"])


def test_route_flag_makes_it_a_route_check():
    parsed = parse_args(["--route", "https://example.com/x", "--route-pages=https://example.com/"])
    assert (parsed["kind"], parsed["url"], parsed["options"]) == ("route", "https://example.com/x", ["--route-pages=https://example.com/"])


def test_route_file_can_stand_in_for_the_url():
    parsed = parse_args(["--route", "--route-file=plan.json"])
    assert (parsed["kind"], parsed["url"], parsed["options"]) == ("route", None, ["--route-file=plan.json"])


@pytest.mark.parametrize("argv", [[], ["--headless"], ["--route"], ["--route", "--repeat=2"]], ids=["引数なし", "URL なし", "経路で URL も計画もない", "経路でオプションだけ"])
def test_missing_url_is_a_usage_error(argv):
    with pytest.raises(UsageError):
        parse_args(argv)


# ---- 待ち時間を数えるホスト


def test_the_host_to_wait_on_is_the_url_of_the_page_being_opened():
    assert start_url(parse_args(["https://example.com/x"])) == "https://example.com/x"


def test_with_a_route_file_the_host_to_wait_on_is_the_first_step_of_the_plan(tmp_path):
    plan = tmp_path / "plan.json"
    plan.write_text(json.dumps({"steps": [{"url": "https://shop.example.com/top"}, {"selector": "a"}]}))
    assert start_url(parse_args(["--route", f"--route-file={plan}"])) == "https://shop.example.com/top"


@pytest.mark.parametrize("content", [None, "not json", json.dumps({"steps": []}), json.dumps({"steps": [{"selector": "a"}]})], ids=["ファイルなし", "JSON でない", "手がない", "起点が URL でない"])
def test_when_the_plan_has_no_readable_start_url_there_is_no_host_to_wait_on(tmp_path, content):
    plan = tmp_path / "plan.json"
    if content is not None:
        plan.write_text(content)
    assert start_url(parse_args(["--route", f"--route-file={plan}"])) is None


# ---- 回線 → プロキシ


def resolver_for(table):
    calls = []

    def resolve(line):
        calls.append(line)
        return table[line]

    resolve.calls = calls
    return resolve


def test_a_proxy_given_directly_wins_over_the_line_and_the_line_is_kept_as_recorded():
    r = resolver_for({})
    out = proxy_args(["--line=residential", "--proxy=http://p.example.com:8000"], r)
    assert out == ["--line=residential", "--proxy=http://p.example.com:8000"]
    assert r.calls == []


@pytest.mark.parametrize("options", [["--line=direct"], []], ids=["direct を指定", "回線の指定なし"])
def test_direct_or_unspecified_line_has_no_proxy_and_records_direct(options):
    r = resolver_for({})
    assert proxy_args(options, r) == ["--line=direct"]
    assert r.calls == []


def test_a_named_line_is_resolved_to_its_proxy_so_credentials_stay_off_the_command_line():
    r = resolver_for({"client_proxy": "http://u:p@dc.example.com:3128"})
    assert proxy_args(["--line=client_proxy", "--headless"], r) == ["--line=client_proxy", "--headless", "--proxy=http://u:p@dc.example.com:3128"]
    assert r.calls == ["client_proxy"]


def test_a_residential_line_without_a_proxy_opens_from_the_local_line():
    r = resolver_for({"residential": ""})
    assert proxy_args(["--line=residential"], r) == ["--line=residential"]


def test_a_proxy_without_a_line_is_recorded_as_client_proxy():
    r = resolver_for({})
    assert proxy_args(["--proxy=http://p.example.com:8000"], r) == ["--proxy=http://p.example.com:8000", "--line=client_proxy"]


# ---- 待ち時間の上限


@pytest.mark.parametrize("kind, environ, expected", [("probe", {}, 90), ("route", {}, 900), ("probe", {"BROWSER_PROBE_TIMEOUT_SEC": "30"}, 30), ("route", {"BROWSER_PROBE_TIMEOUT_SEC": "30"}, 30)])
def test_timeout_depends_on_the_kind_and_can_be_overridden_by_the_environment(kind, environ, expected):
    assert timeout_sec(kind, environ) == expected


# ---- 子のプロセスの後始末


def alive(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    return True


def test_a_child_that_finishes_returns_its_exit_code_and_output():
    code, out, err = run_child([sys.executable, "-c", "import sys; print('{\"ok\": 1}'); print('warn', file=sys.stderr); sys.exit(3)"], timeout=10)
    assert (code, out.strip(), err.strip()) == (3, '{"ok": 1}', "warn")


def test_a_child_that_outlives_the_timeout_is_stopped_with_its_own_children_and_the_code_is_4(tmp_path):
    # ブラウザは子のプロセスの、さらに子。グループごと止めないと、相手へのアクセスが続く
    pidfile = tmp_path / "grandchild.pid"
    script = (
        "import subprocess, sys, time\n"
        f"p = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'])\n"
        f"open({str(pidfile)!r}, 'w').write(str(p.pid))\n"
        "time.sleep(60)\n"
    )
    started = time.monotonic()
    code, _, _ = run_child([sys.executable, "-c", script], timeout=1.5, grace=5)
    assert code == 4
    assert time.monotonic() - started < 10
    grandchild = int(pidfile.read_text())
    time.sleep(0.3)
    assert not alive(grandchild)
