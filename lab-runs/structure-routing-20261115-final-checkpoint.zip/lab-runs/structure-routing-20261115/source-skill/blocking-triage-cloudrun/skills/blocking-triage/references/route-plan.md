# パーサーのコードから経路を作る(ステップ 6 の二案目)

本番の worker が辿る経路を、開発環境にあるパーサーのコードから組み立てて、その経路で目的ページに着けるかを確かめる。ユーザーが経路の URL を共有してくれたとき(`--route-pages`)と違い、パーサーを指定するだけで始められる。SKILL.md の手順 5 で、ステップ 5 まで全部通らなかったときに使う。

## 手順

### 1. パーサーの骨組みを取り出す

```bash
node .claude/skills/blocking-triage/scripts/parser_flow.mjs <パーサーのパス>   # 例: src/example/kakakucom.ts
```

コードは実行しない(構文木を読むだけ)。出力の意味は次のとおり。

| 項目 | 意味 |
|---|---|
| `start` | `initializer` が作る起点のジョブ。`url_expr` は URL の式(`` `https://…/${shopId}/` `` など) |
| `edges` | `worker` が、ある kind のページから作る子のジョブ(`from` → `to`) |
| `edges[].url_expr` | 子の URL の式。`a.href` なら、ページ内のリンクから取っている |
| `edges[].selectors` | その kind の処理内で、DOM を探すために使っているセレクタ **全部**(遷移に関係ないものも混ざる) |
| `edges[].text_filters` | その kind の処理内の `.includes('…')` の語。リンクを絞り込む手がかり |
| `edges[].line` | `childJob` の呼び出しの行。ここ周辺のコードを読んで、どのセレクタが効いているかを確かめる |
| `warnings` | 読み取れなかったこと(`worker` が `switch (job.kind)` でない、など) |

### 2. 計画ファイルを書く

`edges[].line` の周辺のコードを読んで、「どのセレクタで、どのリンクを取って、子のジョブにしているか」を決める。計画は、代表の 1 経路だけを書く。`temp/route-<サイト名>.json` に置く(`temp/` は gitignore 済み)。

```json
{
  "description": "kakakucom の LIST → ITEMS",
  "source": "src/example/kakakucom.ts",
  "steps": [
    { "url": "https://kakaku.com/shopitem/1208/" },
    { "selector": "#tabContents > div > div:has(h4:has-text(\"パソコン本体\")) td.mark a" }
  ]
}
```

- 最初の手は `url`。`start[].url_expr` を、代表の値で具体的にした URL にする(複数の起点があれば、1 つを選ぶ)。
- 2 つ目以降の手は `selector`(前のページの、次のページへ行くリンク)。深い経路は、`edges` を `from` → `to` の順にたどって、手を並べる(LIST → ITEMS → DETAIL なら、起点、LIST のリンク、ITEMS のリンクの 3 手)。
- 最後の手のページが、目的ページ(パーサーが本番で辿る、いちばん深いページ)。
- セレクタは CSS(Chrome が解釈できるもの)。`:has(…)` は使えるが、`:has-text("…")`・`text=`・`>>` のような Playwright だけの書き方は使えない(計画の読み込みでエラーにする)。パーサーが「あるブロックの語で絞ってから、その中のリンクを取る」場合は、CSS で書ける範囲(`コンテナ:has(見出し.クラス) リンク`)で書き、語での絞り込みは `text_includes` に寄せる。
- `text_includes` を付けると、リンクの文字(大文字小文字を区別しない部分一致)でも絞れる。
- `url_prefix` を付けると、リンクの URL が、その文字列で始まるものだけに絞れる(前方一致)。比べるのは、属性の文字ではなく、解決した URL なので、相対 URL のリンクも合う。`selector` は省略できる(省略すると、ページ内のすべてのリンクから探す)。起点と同じサイトの URL だけ指定できる。
  - 例: `{ "selector": ".grid a", "url_prefix": "https://shop.example.com/dp/" }`
  - 広すぎる前方一致は、商品以外のリンクを選ぶ。zozo.jp で `https://zozo.jp/shop/` だけにすると、先頭が商品ページではなく `…/shop/adidas/image.html` になった(2026-10-27)。`/goods/` のように、前方一致で書けない途中の語は、`selector` の `a[href*="/goods/"]` で絞る。
- URL の手を途中に入れてもよい(経路が、リンクでは辿れない場合)。

### 3. 実行する

```bash
cd .claude/skills/blocking-triage/scripts
uv run ladder.py --url "<目的ページ>" --route-file=../../../../temp/route-<サイト名>.json > /tmp/route.json   # ステップ 0〜5 から回す
uv run ladder.py --route-file=../../../../temp/route-<サイト名>.json --route-only > /tmp/route.json      # ステップ 0〜5 を済ませたあと
```

`--url` を付けると、`ladder.py` は先に通常の確認(ステップ 0〜5)を回し、全部通らなかったときだけ経路を辿る(SKILL.md の手順 5)。ステップ 0〜5 を済ませたあとで計画を作ったときは、`--route-only` を付けて経路だけを確かめる。このときは、目的ページが計画の最後の手から決まるので、`--url` は要らない。

経路は、レジデンシャルの回線で次の 2 段階で辿る。データセンターでも試すとユーザーが言ったときは `--with-client-proxy` を付け、データセンター → レジデンシャルの順に、回線ごとに 2 段階を行い、最初に通った回線で止まる。

1. **解決**: 計画を順に辿る。最初のページだけ goto で開き、2 ページ目以降は、手前のページからページ内の JS(location.href)で移る(経路の確認の location と同じ移り方)。リンクの手は、前のページから、セレクタ(と text_includes・url_prefix)に合う、見えている最初のリンクを探して、その URL へ移る。これで、目的ページの URL が決まる。
2. **確認**: 決まった経路で、手 A〜C(`location` → `click` → `warmup_location`)を試す。読み方は SKILL.md の手順 5。

1 つの回線だけで確かめるときは、`browser_run.py` を直接使う(`--line` は `client_proxy` か `residential`)。

```bash
python3 browser_run.py --route --route-file=../../../../temp/route-<サイト名>.json --line=client_proxy > /tmp/route.json
uv run probe.py --classify-json /tmp/route.json
```

`resolution` に、手ごとの結果が出る(`matched_links` はセレクタに合ったリンクの数、`link_text` は選んだリンクの文字)。

## 解決が失敗したとき

| `stopped` | 意味 | 次にすること |
|---|---|---|
| `resolve_failed` | その手のセレクタに合う、見えているリンクがない | パーサーの読み違い、ページの変更、JS の描画前の可能性。セレクタを見直す。パーサーが DOM を取る時点のページと、ブラウザのページが違わないかも疑う |
| `resolve_blocked` | 解決の途中のページで拒否された | 目的ページ以前の問題。ステップ 0〜5 の読み(SKILL.md の手順 3)に戻る |

## 限界

- 静的解析なので、URL の式の値や、条件分岐(どの `if` を通るか)は、コードを読む人が決める。
- パーサーが JSDOM でパースしたページ(`utils.JSDOM`)と、ブラウザが描画したページは、同じとは限らない。JS で描画される部分は、パーサー(JSDOM)には見えないが、ブラウザには見える。セレクタが合わないときは、まずここを疑う。
- 計画は代表の 1 経路。サイト全体の網羅はしない。
- 負荷: 解決と確認を合わせて、1 回線あたり 40 ロードまで。ページ間は 8 秒前後。
