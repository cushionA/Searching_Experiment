# /// script
# requires-python = ">=3.10,<3.14"
# dependencies = ["nodriver"]
# ///
"""切り分けの ④ 用。直接開くと拒否されるページ(目的ページ)に、サイト内の経路を通ると着けるかを調べる。結果は JSON で標準出力に出す。

直接実行せず、browser_run.py --route を使う(待ち時間・回線・時間切れの後始末を持っている)。
  browser_run.py --route <目的ページの URL> [--route-pages=URL,URL,...] [--repeat=2] [--interval=8]
                 [--humanize=none|dwell|scroll|mouse] [--escalate] [--all-modes] [--modes=direct,location,click,warmup_location]
                 [--line=client_proxy|residential|direct] [--proxy=URL] [--seed=N] [--chrome=PATH]
  browser_run.py --route --route-file=<計画の JSON> ...

手(安い順。最初に全試行が通った手で止まる):
  direct    目的ページを直接開く(Referer なし)
  location  経路の各ページで、ページ内の JS から location.href で次のページへ移る(クリックの操作はない)
  click     経路の各ページで、次のページへ行くリンクを実際にクリックして辿る
  warmup_location  最初のページで、Akamai の _abck が合格するまで(最大 70 秒)ホイールでのスクロールとマウス移動を続けてから、
            location.href で移る。それまでの試行で _abck が付かなかったサイトでは試さない(skipped)
  --escalate を付けると、click に操作(滞在 → スクロール → マウス移動)を 1 つずつ足した手を、warmup_location の前に足す

- 経路は、ユーザーから共有された「人が目的ページに着くまでに通るページ」(--route-pages)。なければ、オリジンのトップ → 目的ページ
- 手ごとに --repeat 回(最大 3)、毎回新しいプロファイルで試す。結果が割れたら split として返す
- 相手への負荷を抑える: ページ間は --interval 秒前後、全体で 40 ロードまで
- cookie は名前だけ出す。_abck は、値ではなく状態(pending / accepted / other)だけ出す
"""

from __future__ import annotations

import asyncio
import json
import shutil
import sys
import time
from contextlib import asynccontextmanager

import browser_common as bc
import route_lib as rl

NAV_TIMEOUT_SEC = 30
# warmup_location で _abck の合格を待つ上限。元の調査の joshin_scrape.py は 45 秒だったが、joshinweb.jp では 45 秒で合格しなかったので、70 秒まで延ばしている
WARMUP_MAX_SEC = 70
CHALLENGE_WAIT_SEC = 15
BODY_BYTES = 1500
MAX_LOADS = 40
KEEP_HEADERS = {"server", "cf-ray", "cf-mitigated", "x-datadome", "x-iinfo", "content-type", "location"}

# 今のページの、リンクの候補(DOM の順の番号、href 属性の値、表示、画面内かどうか)。ページ内のすべての a[href] を返す
COLLECT_LINKS_JS = """
Array.from(document.querySelectorAll('a[href]')).map((a, index) => {
  const r = a.getBoundingClientRect();
  const cs = getComputedStyle(a);
  const visible = r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
  return {
    index,
    attr: a.getAttribute('href'),
    target: a.getAttribute('target') || '',
    download: a.hasAttribute('download'),
    visible,
    in_viewport: visible && r.top >= 0 && r.top < window.innerHeight,
  };
})
"""


def clamp(n: float, lo: float, hi: float) -> float:
    return min(max(n, lo), hi)


class Session:
    """1 つのブラウザ(新しいプロファイル)と、その最初のタブ。"""

    def __init__(self, browser, tab, nav):
        self.browser, self.tab, self.nav = browser, tab, nav
        self.pointer = {"x": 0, "y": 0}
        self.stats = {"scroll_steps": 0, "mouse_moves": 0, "dwell_ms": 0}


class Route:
    def __init__(self, args: list[str], chrome: str):
        self.chrome = chrome
        self.proxy = bc.opt(args, "proxy")
        self.repeat = int(clamp(float(bc.opt(args, "repeat") or 2), 1, 3))
        self.interval = clamp(float(bc.opt(args, "interval") or 8), 3, 60)
        self.seed = int(bc.opt(args, "seed") or int(time.time() * 1000) % 100_000)
        self.humanize = bc.opt(args, "humanize") or "none"
        self.escalate = "--escalate" in args
        self.all_modes = "--all-modes" in args
        only = bc.opt(args, "modes")
        self.only_modes = [s.strip() for s in only.split(",") if s.strip()] if only else None
        self.rng = rl.mulberry32(self.seed)
        self.loads = 0
        self.user_agent: str | None = None

    # ---- 待ち

    async def sleep_ms(self, ms: float) -> None:
        await asyncio.sleep(ms / 1000)

    async def pause(self, sec: float) -> None:
        await self.sleep_ms(rl.plan_pause(self.rng, sec * 800, sec * 1400))

    # ---- ブラウザ

    @asynccontextmanager
    async def session(self):
        profile = bc.new_profile_dir()
        browser = None
        try:
            browser, via_forwarder = await bc.start_browser(self.chrome, False, self.proxy, profile)
            tab, nav = await bc.open_tab(browser, via_forwarder, self.proxy)
            yield Session(browser, tab, nav)
        finally:
            if browser is not None:
                browser.stop()
                await asyncio.sleep(0.5)  # 後始末が終わる前にループが閉じると、警告が出る
            shutil.rmtree(profile, ignore_errors=True)

    async def snapshot(self, s: Session, response, extra: dict) -> dict:
        tab = s.tab
        title = await tab.evaluate("document.title") or ""
        status = response.status if response else None
        cookies = await s.browser.cookies.get_all()
        abck = next((c.value for c in cookies if c.name == "_abck"), None)
        headers = {k.lower(): v for k, v in (response.headers or {}).items() if k.lower() in KEEP_HEADERS} if response else {}
        challenge = await bc.page_in_challenge(tab)
        return {
            **extra,
            "url": await tab.evaluate("location.href"),
            "status": status,
            "title": title,
            "blocked": rl.looks_blocked(status, title, challenge),
            "challenge_unresolved": challenge,
            "abck_state": rl.abck_state(abck),
            "cookie_names": bc.cookie_names([{"name": c.name} for c in cookies]),
            "headers": headers,
            "body_head": bc.body_head(await tab.get_content(), BODY_BYTES),
        }

    # ---- 操作

    async def move_pointer(self, s: Session, to: dict) -> None:
        from nodriver import cdp

        for p in rl.plan_mouse_path(self.rng, s.pointer, to):
            await s.tab.send(cdp.input_.dispatch_mouse_event("mouseMoved", p["x"], p["y"]))
            s.stats["mouse_moves"] += 1
            await self.sleep_ms(8 + round(self.rng() * 17))
        s.pointer = {"x": round(to["x"]), "y": round(to["y"])}

    async def wheel(self, s: Session, dy: float) -> None:
        from nodriver import cdp

        await s.tab.send(cdp.input_.dispatch_mouse_event("mouseWheel", s.pointer["x"], s.pointer["y"], delta_x=0, delta_y=dy))
        s.stats["scroll_steps"] += 1

    async def window_size(self, s: Session) -> tuple[float, float]:
        w, h = await bc.eval_json(s.tab, "[window.innerWidth, window.innerHeight]")
        return w, h

    async def random_point(self, s: Session) -> dict:
        w, h = await self.window_size(s)
        return {"x": 150 + self.rng() * max(w - 300, 1), "y": 120 + self.rng() * max(h - 240, 1)}

    async def behave(self, s: Session, flags: dict) -> None:
        """ページを離れる前に、操作の水準に応じた人間らしい操作をする。"""
        if flags["scroll"]:
            page_height, viewport_height = await bc.eval_json(s.tab, "[document.documentElement.scrollHeight, window.innerHeight]")
            for step in rl.plan_scroll(self.rng, page_height, viewport_height):
                await self.wheel(s, step["dy"])
                await self.sleep_ms(step["pauseMs"])
        if flags["mouse"]:
            await self.move_pointer(s, await self.random_point(s))
        if flags["dwell"]:
            ms = rl.plan_pause(self.rng, 2000, 6000)
            s.stats["dwell_ms"] += ms
            await self.sleep_ms(ms)

    # ---- 遷移

    async def goto_page(self, s: Session, url: str, referer: str | None = None):
        from nodriver import cdp

        self.loads += 1
        s.nav["last"] = None
        if referer:
            result = await asyncio.wait_for(s.tab.send(cdp.page.navigate(url, referrer=referer)), NAV_TIMEOUT_SEC)
            if result[2]:
                raise RuntimeError(result[2])
            await self.wait_loaded(s.tab)
        else:
            await asyncio.wait_for(s.tab.get(url), NAV_TIMEOUT_SEC)
        await bc.settle(s.tab, CHALLENGE_WAIT_SEC)
        return s.nav["last"]

    async def wait_loaded(self, tab) -> None:
        deadline = time.monotonic() + NAV_TIMEOUT_SEC
        while time.monotonic() < deadline:
            try:
                if await asyncio.wait_for(tab.evaluate("document.readyState"), 5) != "loading":
                    return
            except Exception:  # noqa: BLE001  遷移の途中は調べられない
                pass
            await asyncio.sleep(0.3)

    async def wait_url_change(self, tab, before: str) -> None:
        """URL が変わり、読み込みが始まるまで待つ(Playwright の waitForURL(domcontentloaded) と同じ)。"""
        deadline = time.monotonic() + NAV_TIMEOUT_SEC
        while time.monotonic() < deadline:
            try:
                now = await asyncio.wait_for(tab.evaluate("location.href"), 5)
                if now != before and await asyncio.wait_for(tab.evaluate("document.readyState"), 5) != "loading":
                    return
            except Exception:  # noqa: BLE001  遷移の途中は調べられない
                pass
            await asyncio.sleep(0.3)
        raise TimeoutError(f"{NAV_TIMEOUT_SEC} 秒待っても URL が変わらなかった")

    async def location_to_page(self, s: Session, next_url: str):
        """ページ内の JS から location.href で次のページへ移る(Referer と Sec-Fetch-Site: same-origin は付くが、クリックの操作はない)。"""
        self.loads += 1
        s.nav["last"] = None
        before = await s.tab.evaluate("location.href")
        await s.tab.evaluate(f"window.location.href = {json.dumps(next_url)}")
        await self.wait_url_change(s.tab, before)
        await bc.settle(s.tab, CHALLENGE_WAIT_SEC)
        return s.nav["last"]

    async def click_to_page(self, s: Session, next_url: str, flags: dict) -> dict:
        """次のページへ、リンクをクリックして移る。リンクが見つからなければ {"clicked": False}(呼び出し側が切り替える)。"""
        from nodriver import cdp

        found = rl.find_link(await bc.eval_json(s.tab, COLLECT_LINKS_JS), next_url, await s.tab.evaluate("location.href"))
        if not found:
            return {"clicked": False}
        box = await bc.eval_json(
            s.tab,
            f"(() => {{ const el = document.querySelectorAll('a[href]')[{found['index']}]; if (!el) return null;"
            " el.scrollIntoView({block: 'nearest'}); const r = el.getBoundingClientRect(); return [r.x, r.y, r.width, r.height]; })()",
        )
        if not box:
            return {"clicked": False}

        self.loads += 1
        s.nav["last"] = None
        before = await s.tab.evaluate("location.href")
        x, y, w, h = box
        to = {"x": x + w * (0.3 + self.rng() * 0.4), "y": y + h * (0.3 + self.rng() * 0.4)} if flags["mouse"] else {"x": x + w / 2, "y": y + h / 2}
        if flags["mouse"]:
            await self.move_pointer(s, to)
            await self.sleep_ms(rl.plan_pause(self.rng, 80, 250))
        else:
            await s.tab.send(cdp.input_.dispatch_mouse_event("mouseMoved", to["x"], to["y"]))
            s.pointer = {"x": round(to["x"]), "y": round(to["y"])}
        left = cdp.input_.MouseButton.LEFT
        await s.tab.send(cdp.input_.dispatch_mouse_event("mousePressed", to["x"], to["y"], button=left, buttons=1, click_count=1))
        await s.tab.send(cdp.input_.dispatch_mouse_event("mouseReleased", to["x"], to["y"], button=left, buttons=0, click_count=1))
        await self.wait_url_change(s.tab, before)
        await bc.settle(s.tab, CHALLENGE_WAIT_SEC)
        return {"clicked": True, "response": s.nav["last"]}

    async def warmup_until_accepted(self, s: Session) -> dict:
        """最初のページで、_abck が合格(accepted)になるまで、スクロールとマウス移動を続ける(最大 WARMUP_MAX_SEC)。

        合格しなくても打ち切って先へ進み、合格したか・待った時間・回数を返す。
        """
        started = time.monotonic()
        rounds = 0

        async def accepted() -> bool:
            return rl.abck_state(next((c.value for c in await s.browser.cookies.get_all() if c.name == "_abck"), None)) == "accepted"

        while not await accepted() and time.monotonic() - started < WARMUP_MAX_SEC:
            rounds += 1
            await self.wheel(s, 60 + round(self.rng() * 60))
            await self.move_pointer(s, await self.random_point(s))
            await self.sleep_ms(rl.plan_pause(self.rng, 1500, 2500))
        return {"accepted": await accepted(), "waited_ms": int((time.monotonic() - started) * 1000), "rounds": rounds}

    # ---- 計画の解決と試行

    async def resolve_plan(self, plan_steps: list[dict]) -> dict:
        """計画の手を順に実行して、各ページの URL を確定する(解決)。最初のページだけ goto で開き、2 ページ目以降は、
        手前のページからページ内の JS(location.href)で移る(経路の確認の location と同じ移り方。goto だと
        Sec-Fetch-Site: none で届き、ページ内からの遷移しか通さないサイトで、経路の確認の前に拒否される)。
        リンクの手は、前のページから、セレクタ(と text_includes・url_prefix)に合う最初の見えているリンクを探して、その href へ移る。
        パーサーが本番で子のジョブの URL を取る場所(DOM のセレクタ)を、実際のページで確かめる役目もある。
        """
        resolution: dict = {"ok": False, "hops": [], "resolved_urls": [], "failed_at": None, "reason": None}
        try:
            async with self.session() as s:
                for i, step in enumerate(plan_steps):
                    if i > 0:
                        await self.pause(self.interval)
                    url = step.get("url")
                    hop = {"index": i, "type": step["type"], "selector": step.get("selector"), "text_includes": step.get("text_includes"),
                           "url_prefix": step.get("url_prefix")}  # fmt: skip
                    if step["type"] == "link":
                        links = await bc.eval_json(
                            s.tab,
                            "(() => { const vis = (a) => { const r = a.getBoundingClientRect(); const cs = getComputedStyle(a);"
                            " return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };"
                            " return Array.from(document.querySelectorAll(%s)).filter(vis).map((a) => ({ href: a.href,"
                            " text: (a.innerText || '').trim().slice(0, 60), content: a.textContent || '' })); })()"
                            % json.dumps(step["selector"])
                        )
                        found = rl.select_link(links, step.get("text_includes"), step.get("url_prefix"))
                        hop["matched_links"] = found["count"]
                        if found["count"] == 0:
                            resolution.update(failed_at=i, reason="selector_not_found")
                            resolution["hops"].append(hop)
                            return resolution
                        url = found["href"]
                        hop["link_text"] = found["text"]
                    response = await (self.goto_page(s, url) if i == 0 else self.location_to_page(s, url))
                    snap = await self.snapshot(s, response, {"kind": "target" if i == len(plan_steps) - 1 else "route", "how": "goto" if i == 0 else "location", "step_url": url})  # fmt: skip
                    hop.update(url=snap["url"], status=snap["status"], title=snap["title"], blocked=snap["blocked"])
                    resolution["hops"].append(hop)
                    resolution["resolved_urls"].append(url.split("#")[0])
                    if snap["blocked"]:
                        resolution.update(failed_at=i, reason="blocked")
                        return resolution
                resolution["ok"] = True
        except Exception as e:  # noqa: BLE001
            resolution["reason"] = bc.error_text(e)
        return resolution

    async def run_trial(self, mode: dict, steps: list[str]) -> dict:
        """1 回の試行(新しいプロファイル)。手に応じた方法で、経路の各ページを順に開く。"""
        started = time.monotonic()
        flags = rl.humanize_flags(mode["humanize"] if mode["name"] == "click" else "none")
        pages: list[dict] = []
        trial: dict = {"pages": pages}
        try:
            async with self.session() as s:
                if self.user_agent is None:
                    self.user_agent = await s.tab.evaluate("navigator.userAgent")
                sequence = [steps[-1]] if mode["name"] == "direct" else steps
                for i, url in enumerate(sequence):
                    kind = "target" if i == len(sequence) - 1 else "route"
                    how = "goto"
                    # warmup_location は、_abck が合格したら、待たずにすぐ移る(合格のあとに待つと、センサーの状態が古くなる疑いがある)
                    if i > 0 and not (i == 1 and mode["name"] == "warmup_location"):
                        await self.pause(self.interval)
                    if i > 0 and mode["name"] in ("location", "warmup_location"):
                        how = "location"
                        response = await self.location_to_page(s, url)
                    elif i == 0 or mode["name"] != "click":
                        response = await self.goto_page(s, url)
                    else:
                        result = await self.click_to_page(s, url, flags)
                        how, response = "click", result.get("response")
                        if not result["clicked"]:
                            # リンクが見つからなければ、Referer 付きの直接遷移に切り替える。クリックで辿れていないので、
                            # 結果に明記し(evaluate_trial が通過にしない)、この試行はここで打ち切る(無効な経路でロードを重ねない)
                            how = rl.HOW_LINK_MISSING
                            response = await self.goto_page(s, url, sequence[i - 1])
                    snap = await self.snapshot(s, s.nav["last"] or response, {"kind": kind, "how": how, "step_url": url})
                    pages.append(snap)
                    if snap["blocked"] or how == rl.HOW_LINK_MISSING:
                        break
                    if i == 0 and mode["name"] == "warmup_location":
                        trial["warmup"] = await self.warmup_until_accepted(s)
                        snap["abck_state_after_warmup"] = "accepted" if trial["warmup"]["accepted"] else snap["abck_state"]
                    if kind == "route":
                        await self.behave(s, flags)
                trial["actions"] = s.stats
        except Exception as e:  # noqa: BLE001
            trial["error"] = bc.error_text(e)
        trial["elapsed_ms"] = int((time.monotonic() - started) * 1000)
        trial.update(rl.evaluate_trial(pages))
        if trial.get("error"):
            trial["passed"] = False
        return trial


async def run(url: str | None, args: list[str]) -> dict:
    route = Route(args, args_chrome(args))
    route_pages = [s.strip() for s in (bc.opt(args, "route-pages") or "").split(",") if s.strip()]
    route_file = bc.opt(args, "route-file")
    plan = rl.parse_plan(json.load(open(route_file))) if route_file else None
    resolution = None
    steps = [] if plan else rl.build_steps(url, route_pages)
    if plan:
        resolution = await route.resolve_plan(plan["steps"])
        if resolution["ok"]:
            try:
                steps = rl.build_steps(resolution["resolved_urls"][-1], resolution["resolved_urls"][:-1])
            except ValueError as e:
                # 解決の途中で、別のサイトに出てしまった(リダイレクトなど)
                resolution.update(ok=False, reason=str(e), failed_at=len(resolution["resolved_urls"]) - 1)

    modes = [m for m in rl.build_modes(route.humanize, route.escalate) if not route.only_modes or m["name"] in route.only_modes]
    out: dict = {
        "target_url": steps[-1] if steps else None,
        "steps": steps,
        "route_given": bool(route_pages) or plan is not None,
        "plan": {"description": plan["description"], "source": plan["source"], "steps": plan["steps"]} if plan else None,
        "resolution": resolution,
        "seed": route.seed,
        "params": {
            "repeat": route.repeat,
            "interval_sec": route.interval,
            "humanize": route.humanize,
            "escalate": route.escalate,
            "all_modes": route.all_modes,
            "proxy": bc.proxy_option(route.proxy)["label"],
            # 回線の名前(browser_run.py の --line)。state.py が履歴の回線に使う
            "line": bc.opt(args, "line"),
            "browser": "chrome",
        },
        "modes": [],
        "stopped": None,
        "first_passing_mode": None,
        "request_count": 0,
    }
    if plan and not resolution["ok"]:
        out["stopped"] = "resolve_failed" if resolution["reason"] == "selector_not_found" else "resolve_blocked"
        modes = []  # 目的ページの URL が確定していないので、手は試さない

    for mode in modes:
        rec = {"name": mode["name"], "humanize": mode["humanize"], "label": mode["label"], "trials": []}
        out["modes"].append(rec)
        if mode["name"] == "warmup_location" and not rl.warmup_applies(out["modes"]):
            rec["skipped"] = "no_abck"
            rec.update(rl.evaluate_mode(rec["trials"]))
            continue
        for _ in range(route.repeat):
            if route.loads + len(steps) > MAX_LOADS:
                out["stopped"] = "load_limit"
                break
            if rec["trials"]:
                await route.pause(route.interval)
            rec["trials"].append(await route.run_trial(mode, steps))
        rec.update(rl.evaluate_mode(rec["trials"]))
        if out["stopped"] == "load_limit":
            break
        if rec["outcome"] == "pass":
            if out["first_passing_mode"] is None:
                out["first_passing_mode"] = mode["name"] + ("" if mode["humanize"] == "none" else f"+{mode['humanize']}")
            out["stopped"] = "passed"
            if not route.all_modes:
                break
        # 経路の入口(最初のページ)で全部の試行が拒否されたら、目的ページ以前の問題。これ以上は試さない。
        # 途中のページでの拒否は、その手の開き方が原因かもしれないので、次の手(location・クリック)へ進む
        if mode["name"] != "direct" and len(steps) > 1 and rl.route_blocked_at_entry(rec["trials"]):
            out["stopped"] = "route_blocked"
            break
        await route.pause(route.interval)
    out["stopped"] = out["stopped"] or "exhausted"
    out["request_count"] = route.loads
    out["params"]["user_agent"] = route.user_agent
    return out


def args_chrome(args: list[str]) -> str:
    return bc.opt(args, "chrome") or bc.setup_chrome()


def main() -> int:
    args = sys.argv[1:]
    url = next((a for a in args if not a.startswith("--")), None)
    humanize = bc.opt(args, "humanize") or "none"
    if (not url and not bc.opt(args, "route-file")) or humanize not in rl.HUMANIZE_LEVELS:
        print("使い方: browser_route.py <目的ページの URL> | --route-file=<計画の JSON> [--route-pages=URL,URL,...] [--repeat=2] [--interval=8] "
              "[--humanize=none|dwell|scroll|mouse] [--escalate] [--proxy=URL] [--seed=N] [--chrome=PATH]", file=sys.stderr)  # fmt: skip
        return 2
    try:
        result = bc.run_until_terminated(run(url, args))
    except ValueError as e:  # 計画ファイル・経路の指定の誤り
        print(e, file=sys.stderr)
        return 2
    if isinstance(result, int):  # SIGTERM で止められた
        return result
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
