/**
 * node_axios.mjs と node_basic.mjs が共有する、応答の本文の読み方。
 * ヘッダーに文字コードがなければ、本文の先頭の meta の charset で読む(Amazon の 503 は、ヘッダーが text/html だけで、本文は Shift_JIS)。
 */
export function decode(buf, contentType) {
  const fromHeader = /charset=([^;]+)/i.exec(contentType ?? '')?.[1]?.trim();
  const fromMeta = /<meta[^>]+charset=["']?([\w-]+)/i.exec(buf.subarray(0, 2048).toString('latin1'))?.[1];
  for (const charset of [fromHeader, fromMeta]) {
    if (!charset) continue;
    try {
      return new TextDecoder(charset).decode(buf);
    } catch {}
  }
  return new TextDecoder('utf-8').decode(buf);
}
