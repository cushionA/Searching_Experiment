"""route_lib.py のテスト(ブラウザに依存しない、経路の確認の部品)。実行: uv run --with pytest pytest .claude/skills/blocking-triage/scripts/tests"""

import math

import pytest

from route_lib import (
    HOW_LINK_MISSING,
    abck_state,
    build_modes,
    build_steps,
    evaluate_mode,
    evaluate_trial,
    find_link,
    looks_blocked,
    mulberry32,
    parse_plan,
    plan_mouse_path,
    plan_pause,
    plan_scroll,
    select_link,
    route_blocked_at_entry,
    warmup_applies,
)


def link(attr, **over):
    return {"attr": attr, "text": attr, "target": "", "download": False, "visible": True, "in_viewport": True, **over}


def names(modes):
    return [f"{m['name']}:{m['humanize']}" for m in modes]


# ---- 手


def test_default_modes_go_from_direct_to_location_to_click_to_warmup():
    modes = build_modes()
    assert [m["name"] for m in modes] == ["direct", "location", "click", "warmup_location"]
    assert modes[2]["humanize"] == "none"


def test_humanize_is_attached_only_to_the_click_mode():
    modes = build_modes(humanize="scroll")
    assert [f"{m['name']}:{m['humanize']}" for m in modes if m["humanize"] != "none"] == ["click:scroll"]


def test_escalate_adds_humanized_clicks_after_click_and_before_warmup():
    assert names(build_modes(escalate=True)) == [
        "direct:none", "location:none", "click:none", "click:dwell", "click:scroll", "click:mouse", "warmup_location:none",
    ]  # fmt: skip


def test_escalate_with_humanize_adds_only_the_levels_above_the_given_one():
    assert names(build_modes(humanize="dwell", escalate=True)) == [
        "direct:none", "location:none", "click:dwell", "click:scroll", "click:mouse", "warmup_location:none",
    ]  # fmt: skip


@pytest.mark.parametrize(
    "states, expected",
    [([None, None], False), ([None, "pending"], True), ([], True)],
    ids=["それまでの試行で _abck が付いていない", "それまでの試行で _abck が付いていた", "まだ試行がない(--modes=warmup だけを指定した)"],
)
def test_warmup_is_tried_only_when_abck_was_seen_or_nothing_was_tried_before(states, expected):
    records = [{"name": "direct", "trials": [{"pages": [{"abck_state": s}]} for s in states]}]
    assert warmup_applies(records) is expected


@pytest.mark.parametrize(
    "value, expected",
    [
        (None, None),
        ("", None),
        ("AAA~-1~BBB", "pending"),
        ("AAA~0~BBB", "accepted"),
        ("AAA~1~BBB", "other"),
        ("AAA~0~BBB~-1~-1~-1", "accepted"),
        ("AAA~-1~BBB~-1~-1~-1", "pending"),
    ],
    ids=["cookie なし", "空", "未承認", "承認済み", "それ以外", "承認済みで末尾に ~-1~ が続く形", "未承認で末尾に ~-1~ が続く形"],
)
def test_abck_is_reported_as_a_state_and_never_as_the_value(value, expected):
    assert abck_state(value) == expected


# ---- 経路


def test_without_a_given_route_the_steps_are_the_origin_top_then_the_target():
    assert build_steps("https://shop.example.com/dp/1.html?a=1#x") == ["https://shop.example.com/", "https://shop.example.com/dp/1.html?a=1"]


def test_a_given_route_drops_hashes_consecutive_duplicates_and_the_target_itself():
    steps = build_steps(
        "https://shop.example.com/dp/1.html",
        route=["https://shop.example.com/", "https://shop.example.com/#top", "https://shop.example.com/kaden/10.html", "https://shop.example.com/dp/1.html"],
    )
    assert steps == ["https://shop.example.com/", "https://shop.example.com/kaden/10.html", "https://shop.example.com/dp/1.html"]


def test_a_route_page_of_another_site_is_an_error():
    with pytest.raises(ValueError, match="同じサイト"):
        build_steps("https://shop.example.com/dp/1.html", route=["https://other.example.net/"])


# ---- リンクの選び方


def test_the_link_to_the_next_url_is_chosen_resolving_relative_urls_and_ignoring_hashes():
    found = find_link([link("/a"), link("/kaden/10.html#top"), link("/b")], "https://shop.example.com/kaden/10.html", "https://shop.example.com/")
    assert found["attr"] == "/kaden/10.html#top"


def test_a_link_differing_only_by_query_is_the_fallback_and_none_otherwise():
    nxt = "https://shop.example.com/dp/1.html?ACK=NPT"
    assert find_link([link("/dp/1.html")], nxt, "https://shop.example.com/")["attr"] == "/dp/1.html"
    assert find_link([link("/dp/2.html")], nxt, "https://shop.example.com/") is None


def test_hidden_and_new_tab_links_are_skipped_and_links_in_the_viewport_come_first():
    nxt = "https://shop.example.com/dp/1.html"
    assert find_link([link("/dp/1.html", visible=False), link("/dp/1.html", target="_blank")], nxt, "https://shop.example.com/") is None
    found = find_link([link("/dp/1.html?far=1", in_viewport=False), link("/dp/1.html?near=1")], nxt, "https://shop.example.com/")
    assert found["attr"] == "/dp/1.html?near=1"


def test_a_link_whose_href_cannot_be_resolved_is_skipped_and_the_link_to_the_next_url_is_still_found():
    # 角かっこの中が IP アドレスでない href があると、Python の URL の解釈が例外を出す。
    # javascript: の href は、組み立て直した URL(javascript://...[0]...)を解釈し直すときに出る(joshinweb.jp のクリックで再現)
    nxt = "https://shop.example.com/dp/1.html"
    broken = [link("http://[0]/"), link("javascript:void(items[0])")]
    found = find_link([*broken, link("/dp/1.html")], nxt, "https://shop.example.com/")
    assert found["attr"] == "/dp/1.html"


# ---- 通過の判定


@pytest.mark.parametrize(
    "status, title, expected",
    [(403, "x", True), (200, "Access Denied", True), (200, "Just a moment...", True), (200, "商品一覧", False)],
)
def test_blocked_by_status_or_a_blocking_title(status, title, expected):
    assert looks_blocked(status, title) is expected


def test_a_challenge_element_is_blocked_even_with_status_200_and_an_empty_title():
    # zozo.jp(Akamai)のチャレンジは、200・タイトル空で返る
    assert looks_blocked(200, "", challenge=True) is True


def test_a_trial_that_reaches_the_target_without_being_blocked_passes():
    ok = [{"kind": "route", "blocked": False}, {"kind": "target", "blocked": False}]
    assert evaluate_trial(ok) == {"passed": True, "blocked_at": None}


def test_a_trial_blocked_on_a_route_page_reports_where():
    assert evaluate_trial([{"kind": "route", "blocked": True}]) == {"passed": False, "blocked_at": 0}


def test_a_trial_blocked_on_the_target_reports_where():
    t = [{"kind": "route", "blocked": False}, {"kind": "target", "blocked": True}]
    assert evaluate_trial(t) == {"passed": False, "blocked_at": 1}


def test_a_trial_that_fell_back_to_direct_navigation_because_no_link_was_found_does_not_pass():
    t = [{"kind": "route", "blocked": False, "how": "click"}, {"kind": "target", "blocked": False, "how": HOW_LINK_MISSING}]
    assert evaluate_trial(t) == {"passed": False, "blocked_at": None, "link_missing_at": 1}


def test_a_trial_that_never_reached_the_target_does_not_pass():
    assert evaluate_trial([{"kind": "route", "blocked": False}])["passed"] is False
    assert evaluate_trial([])["passed"] is False


def test_a_mode_passes_when_all_trials_pass_splits_when_some_do_and_fails_otherwise():
    assert evaluate_mode([{"passed": True}, {"passed": True}]) == {"outcome": "pass", "passes": 2, "total": 2}
    assert evaluate_mode([{"passed": True}, {"passed": False}]) == {"outcome": "split", "passes": 1, "total": 2}
    assert evaluate_mode([{"passed": False}, {"passed": False}]) == {"outcome": "fail", "passes": 0, "total": 2}
    assert evaluate_mode([]) == {"outcome": "fail", "passes": 0, "total": 0}


def test_the_route_is_given_up_when_every_trial_was_blocked_at_the_first_page():
    assert route_blocked_at_entry([{"blocked_at": 0}, {"blocked_at": 0}]) is True


def test_the_route_is_not_given_up_when_a_later_page_was_the_one_blocked():
    # 途中のページでの拒否は、その手の開き方が原因かもしれない。次の手は試す
    assert route_blocked_at_entry([{"blocked_at": 2}, {"blocked_at": 0}]) is False
    assert route_blocked_at_entry([{"blocked_at": None}]) is False
    assert route_blocked_at_entry([]) is False


# ---- 操作の計画


def test_scrolling_goes_down_in_steps_within_the_limit():
    plan = plan_scroll(mulberry32(1), page_height=6000, viewport_height=800)
    assert 3 <= len(plan) <= 7
    assert sum(s["dy"] for s in plan if s["dy"] > 0) <= (6000 - 800) * 0.7 + 1
    assert plan_scroll(mulberry32(1), page_height=700, viewport_height=800) == []


def test_the_scroll_plan_for_a_seed_is_the_same_as_the_node_version_gave():
    plan = plan_scroll(mulberry32(1), page_height=6000, viewport_height=800)
    assert plan == [{"dy": 251, "pauseMs": 487}, {"dy": 642, "pauseMs": 686}, {"dy": 362, "pauseMs": 526}, {"dy": 538, "pauseMs": 442}, {"dy": 648, "pauseMs": 455}]


def test_the_mouse_path_ends_exactly_at_the_target_and_is_not_a_straight_line():
    path = plan_mouse_path(mulberry32(7), {"x": 10, "y": 20}, {"x": 400, "y": 300})
    assert 12 <= len(path) <= 24
    assert path[-1] == {"x": 400, "y": 300}
    curved = any(abs(p["y"] - (20 + 280 * (i + 1) / len(path))) > 1 or abs(p["x"] - (10 + 390 * (i + 1) / len(path))) > 1 for i, p in enumerate(path))
    assert curved


def test_a_pause_is_within_range_and_the_same_for_the_same_seed():
    a = plan_pause(mulberry32(3), 2000, 6000)
    assert a == plan_pause(mulberry32(3), 2000, 6000)
    assert 2000 <= a <= 6000


def test_the_seeded_random_numbers_are_in_the_unit_interval_and_reproducible():
    r1, r2 = mulberry32(42), mulberry32(42)
    seq = [r1() for _ in range(100)]
    assert seq == [r2() for _ in range(100)]
    assert all(0 <= x < 1 for x in seq) and len(set(seq)) > 90
    assert math.isclose(mulberry32(1)(), 0.6270739405881613)  # JS 版(route_lib.mjs)と同じ種から同じ値


# ---- 計画ファイル


def plan(steps, **extra):
    return {"description": "test", "steps": steps, **extra}


def test_a_plan_reads_the_start_url_and_a_step_pointing_at_a_link_by_selector():
    p = parse_plan(plan([{"url": "https://kakaku.com/shopitem/1208/#x"}, {"selector": "#tabContents td.mark a", "text_includes": "パソコン"}]))
    assert p["steps"] == [
        {"type": "url", "url": "https://kakaku.com/shopitem/1208/"},
        {"type": "link", "selector": "#tabContents td.mark a", "text_includes": "パソコン"},
    ]


def test_a_plan_of_urls_only_is_readable_like_a_shared_route():
    p = parse_plan(plan([{"url": "https://shop.example.com/"}, {"url": "https://shop.example.com/dp/1.html"}]))
    assert [s["type"] for s in p["steps"]] == ["url", "url"]


def test_the_first_step_of_a_plan_must_be_a_url():
    with pytest.raises(ValueError, match="最初"):
        parse_plan(plan([{"selector": "a"}, {"url": "https://shop.example.com/"}]))


def test_a_plan_with_fewer_than_two_steps_is_not_a_route():
    with pytest.raises(ValueError, match="2 つ以上"):
        parse_plan(plan([{"url": "https://shop.example.com/"}]))
    with pytest.raises(ValueError, match="steps"):
        parse_plan({"steps": "x"})


@pytest.mark.parametrize(
    "steps, message",
    [
        ([{"url": "https://a.example.com/"}, {"url": "https://b.example.net/x"}], "同じサイト"),
        ([{"url": "https://a.example.com/"}, {"selector": "  "}], "selector"),
        ([{"url": "https://a.example.com/"}, {"foo": 1}], "url か selector"),
    ],
    ids=["別のサイトの URL", "空のセレクタ", "知らない手"],
)
def test_a_plan_with_another_site_an_empty_selector_or_an_unknown_step_is_an_error(steps, message):
    with pytest.raises(ValueError, match=message):
        parse_plan(plan(steps))


def test_a_plan_keeps_its_description_and_the_source_parser_path():
    p = parse_plan(plan([{"url": "https://a.example.com/"}, {"selector": "a"}], source="src/example/x.ts"))
    assert (p["description"], p["source"]) == ("test", "src/example/x.ts")


@pytest.mark.parametrize(
    "selector",
    ['div:has(h2:has-text("価格")) a', 'a:text("次へ")', 'text=次へ', 'ul >> a'],
    ids=[":has-text", ":text", "text=", ">>"],
)
def test_a_plan_selector_that_only_playwright_understands_is_an_error_instead_of_silently_matching_nothing(selector):
    with pytest.raises(ValueError, match="CSS"):
        parse_plan(plan([{"url": "https://a.example.com/"}, {"selector": selector}]))


def test_has_is_plain_css_and_stays_allowed():
    p = parse_plan(plan([{"url": "https://a.example.com/"}, {"selector": "div:has(h2.price) a"}]))
    assert p["steps"][1]["selector"] == "div:has(h2.price) a"


# ---- 前方一致(url_prefix)

PREFIX_START = {"url": "https://shop.example.com/"}


def test_a_link_step_with_url_prefix_is_read_together_with_its_selector():
    p = parse_plan(plan([PREFIX_START, {"selector": ".grid a", "url_prefix": "https://shop.example.com/dp/"}]))
    assert p["steps"][1] == {"type": "link", "selector": ".grid a", "url_prefix": "https://shop.example.com/dp/"}


def test_a_link_step_with_only_url_prefix_looks_through_all_the_links_of_the_page():
    p = parse_plan(plan([PREFIX_START, {"url_prefix": "https://shop.example.com/dp/"}]))
    assert p["steps"][1] == {"type": "link", "selector": "a[href]", "url_prefix": "https://shop.example.com/dp/"}


def test_url_prefix_of_another_site_is_refused_like_a_url_step_of_another_site():
    with pytest.raises(ValueError, match="同じサイト"):
        parse_plan(plan([PREFIX_START, {"url_prefix": "https://other.example.net/dp/"}]))


def test_a_link_is_chosen_by_the_resolved_url_even_when_its_href_is_relative():
    # href の文字(/dp/1.html)ではなく、解決した URL で比べる。比べ方を href の文字にすると、相対 URL のリンクを見落とす
    links = [
        {"href": "https://shop.example.com/help/", "text": "ヘルプ", "content": "ヘルプ"},
        {"href": "https://shop.example.com/dp/1.html", "text": "", "content": ""},  # <a href="/dp/1.html">
        {"href": "https://shop.example.com/dp/2.html", "text": "", "content": ""},
    ]
    picked = select_link(links, url_prefix="https://shop.example.com/dp/")
    assert (picked["count"], picked["href"]) == (2, "https://shop.example.com/dp/1.html")
