# /// script
# requires-python = ">=3.10"
# dependencies = []
# ///
"""Run blocking-triage on the Cloud Run Job (lab-bt-triage) from GCP, wait for it, and print the results as JSON.

Every API call is made as the invoker service account (impersonated through gcloud), never as the operator.
Proxy URLs are read from --client-proxy / --residential-proxy, else from CLIENT_PROXY / RESIDENTIAL_PROXY.
They are handed to the job through a single Secret Manager version each, which is destroyed after the run,
so credentials never appear in job args, execution history or audit logs.

  uv run gcp_triage.py --url https://example.com/ [--url ...] [--direct-dc] [--no-residential]
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import secrets
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

PROJECT = os.environ.get("GCP_TRIAGE_PROJECT", "groundingsearch")
REGION = os.environ.get("GCP_TRIAGE_REGION", "us-central1")
JOB = os.environ.get("GCP_TRIAGE_JOB", "lab-bt-triage")
INVOKER = os.environ.get("GCP_TRIAGE_INVOKER", f"lab-bt-invoker@{PROJECT}.iam.gserviceaccount.com")
BUCKET = os.environ.get("GCP_TRIAGE_BUCKET", f"{PROJECT}-lab-bt-results")
POLL_SEC = 15
MAX_PARALLEL_TASKS = 2


class Token:
    def __init__(self) -> None:
        self.value, self.at = "", 0.0

    def get(self) -> str:
        if time.monotonic() - self.at > 45 * 60:
            gcloud = shutil.which("gcloud")
            if not gcloud:
                sys.exit("gcloud が見つからない")
            p = subprocess.run([gcloud, "auth", "print-access-token", f"--impersonate-service-account={INVOKER}"],
                               capture_output=True, text=True)
            if p.returncode != 0:
                sys.exit(f"{INVOKER} になりすませない(roles/iam.serviceAccountTokenCreator が要る): {p.stderr.strip()[-300:]}")
            self.value, self.at = p.stdout.strip(), time.monotonic()
        return self.value


TOKEN = Token()


def api(method: str, url: str, body: dict | None = None, raw: bool = False):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        "Authorization": f"Bearer {TOKEN.get()}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        payload = r.read()
    return payload if raw else json.loads(payload or b"{}")


def add_version(kind: str, value: str) -> str:
    secret = f"projects/{PROJECT}/secrets/lab-bt-{kind}-proxy"
    res = api("POST", f"https://secretmanager.googleapis.com/v1/{secret}:addVersion",
              {"payload": {"data": base64.b64encode(value.encode()).decode()}})
    return res["name"]


def destroy_version(name: str) -> None:
    try:
        api("POST", f"https://secretmanager.googleapis.com/v1/{name}:destroy", {})
    except urllib.error.HTTPError as e:
        print(f"警告: Secret のバージョンを破棄できなかった({name}, HTTP {e.code})。手で破棄すること", file=sys.stderr)


def run_job(args: list[str], task_count: int) -> dict:
    name = f"projects/{PROJECT}/locations/{REGION}/jobs/{JOB}"
    return api("POST", f"https://run.googleapis.com/v2/{name}:run",
               {"overrides": {"taskCount": task_count, "containerOverrides": [{"args": args}]}})


def wait(operation: dict, timeout_sec: int) -> dict:
    started = time.monotonic()
    while not operation.get("done"):
        if time.monotonic() - started > timeout_sec:
            raise TimeoutError(f"{timeout_sec} 秒待っても終わらない: {operation['name']}")
        time.sleep(POLL_SEC)
        operation = api("GET", f"https://run.googleapis.com/v2/{operation['name']}")
    return operation


def read_result(name: str) -> dict | None:
    url = f"https://storage.googleapis.com/storage/v1/b/{BUCKET}/o/{urllib.parse.quote(name, safe='')}?alt=media"
    try:
        return json.loads(api("GET", url, raw=True))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


def main() -> int:
    # On Windows a redirected stdout defaults to the ANSI code page (cp932); the JSON must stay UTF-8.
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", action="append", required=True, help="診断する URL(複数可。ホストごとにタスクを分ける)")
    ap.add_argument("--client-proxy", help="データセンターの回線のプロキシ。省略すると CLIENT_PROXY")
    ap.add_argument("--residential-proxy", help="レジデンシャルのプロキシ。省略すると RESIDENTIAL_PROXY")
    ap.add_argument("--direct-dc", action="store_true", help="CLIENT_PROXY を使わず、Cloud Run の出口をデータセンターの回線にする")
    ap.add_argument("--no-residential", action="store_true", help="RESIDENTIAL_PROXY があっても使わない")
    ap.add_argument("--wait-timeout", type=int, default=3900, help="完了を待つ上限(秒)")
    ap.add_argument("--browser-smoke", action="store_true", help="ブラウザの確認だけを回す(Chrome が動くかの確認。診断ではない)")
    args = ap.parse_args()

    client = None if args.direct_dc else (args.client_proxy or os.environ.get("CLIENT_PROXY"))
    residential = None if args.no_residential else (args.residential_proxy or os.environ.get("RESIDENTIAL_PROXY"))
    hosts = {(urllib.parse.urlsplit(u).hostname or "").lower() for u in args.url}
    task_count = min(len(hosts), MAX_PARALLEL_TASKS)
    out = f"triage-{datetime.now(timezone.utc):%Y%m%dT%H%M%S}-{secrets.token_hex(3)}"

    print(f"invoker: {INVOKER}", file=sys.stderr)
    print(f"データセンターの回線: {'CLIENT_PROXY' if client else 'Cloud Run の出口'} / "
          f"レジデンシャルの回線: {'RESIDENTIAL_PROXY' if residential else 'なし'}", file=sys.stderr)

    versions: list[str] = []
    try:
        job_args = [f"--out={out}", *(["--browser-smoke"] if args.browser_smoke else [])]
        if client:
            versions.append(add_version("client", client))
            job_args.append(f"--client-proxy-secret={versions[-1]}")
        if residential:
            versions.append(add_version("residential", residential))
            job_args.append(f"--residential-proxy-secret={versions[-1]}")
        operation = run_job(job_args + args.url, task_count)
        execution = (operation.get("metadata") or {}).get("name", "?")
        print(f"started: {execution} (tasks={task_count}, out={out})", file=sys.stderr)
        operation = wait(operation, args.wait_timeout)
    finally:
        for v in versions:
            destroy_version(v)

    error = operation.get("error")
    names = [f"{out}.json"] if task_count == 1 else [f"{out}.task{i}.json" for i in range(task_count)]
    results, missing = [], []
    for name in names:
        doc = read_result(name)
        if doc is None:
            missing.append(name)
        else:
            results.extend(doc.get("results", []))

    print(json.dumps({"execution": execution, "out": out, "error": error, "missing": missing, "results": results},
                     ensure_ascii=False, indent=2))
    for r in results:
        line = ((r.get("lines") or {}).get("client_proxy") or {}).get("info") or {}
        reading = r.get("reading") or {}
        print(f"- {r['url']}: {r.get('error') or reading.get('layer')}"
              f"(データセンターの回線 {line.get('ip')} {line.get('org')})", file=sys.stderr)
    if error:
        print(f"Job は失敗で終わった: {error.get('message')}", file=sys.stderr)
    return 1 if error or missing else 0


if __name__ == "__main__":
    sys.exit(main())
