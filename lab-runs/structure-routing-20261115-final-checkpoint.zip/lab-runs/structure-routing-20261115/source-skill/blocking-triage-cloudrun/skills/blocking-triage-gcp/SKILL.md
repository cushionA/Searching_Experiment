---
name: blocking-triage-gcp
description: blocking-triage(ブロッキングの原因切り分け)を、GCP の Cloud Run Job(lab-bt-triage)で動かし、GCP から見た結果を返す。「GCP から疎通確認して」「Cloud Run から取れるか」「GCP の IP で通るか」「GCP からこの URL を blocking-triage にかけて」といった依頼で使う。手元の回線ではなく GCP の出口(またはそこから使うプロキシ)での結果が要るときに使う。手元で切り分けるときは blocking-triage を使う。
---

# blocking-triage を GCP で動かす

Cloud Run Job `lab-bt-triage` の中には、blocking-triage がそのまま入っている(プロキシなしでも動くように、環境変数で切り替わるパッチだけ当ててある)。この skill は、Job を起動し、終わるまで待ち、結果を GCS から読んで返す。診断の手順・判定・読みは blocking-triage と同じなので、**結果の読み方と返し方は blocking-triage の SKILL.md(手順 3・6)に従う**。

## 呼び出しの決まり

- API はすべて、専用のサービスアカウント `lab-bt-invoker@<project>.iam.gserviceaccount.com` になりすまして呼ぶ(スクリプトが gcloud で取る)。操作する人には、その SA への `roles/iam.serviceAccountTokenCreator` が要る。自分のアカウントで直接 Job を起動しない。
- プロキシの URL は、引数(`--client-proxy`・`--residential-proxy`)、なければ環境変数(`CLIENT_PROXY`・`RESIDENTIAL_PROXY`)から読む。基本は環境変数。引数は検証で手渡しするときだけ。
- プロキシの URL は、Job の引数に入れない。スクリプトが Secret Manager に 1 バージョンずつ足し、Job にはバージョンの名前だけを渡し、終わったら破棄する。URL の値は、出力にもチャットにも出さない。

## 手順

```bash
cd <この skill>/scripts
uv run gcp_triage.py --url "<URL>" > /tmp/gcp-triage.json    # 数分かかる。Bash の run_in_background で回す
```

| 回線 | 既定 | 変えるとき |
|---|---|---|
| データセンターの回線 | `CLIENT_PROXY` があればそのプロキシ、なければ Cloud Run の出口(Google の IP) | GCP の出口そのものを見たいときは `--direct-dc` |
| レジデンシャルの回線 | `RESIDENTIAL_PROXY` があれば使う。なければレジデンシャルでの確認まで進まない | 使わないときは `--no-residential` |

- ブラウザは、その回線の出口(ipinfo.io の国・タイムゾーン)に合わせたタイムゾーン・言語・Accept-Language で開く(`BT_MATCH_LINE`)。データセンターとレジデンシャルで国が違えば、それぞれに合わせる。取れなければ ja・Asia/Tokyo。
- `--browser-smoke` は、ブラウザの確認だけを回す動作確認(Chrome がこの環境で動くか)。読みは診断にならないので、結果を診断として返さない。
- 複数の URL は `--url` を重ねる。ホストごとにタスクを分け、同じホストは同じタスクで順に回す(並列は 2 まで)。
- 1 URL の上限は 20 分、待つ上限は 65 分。ブラウザの確認まで進むと 5〜15 分かかる。起動だけで 1〜2 分かかる。

## 結果

標準出力の JSON の `results[]` が、URL ごとの結果。

| 項目 | 中身 |
|---|---|
| `reading` | blocking-triage の `reading` と同じ(原因の層・確度・診断が求めるもの・次の一手・確認の限界) |
| `lines` | 使った回線の IP・ASN・`kind_guess`(プロキシは伏せ字) |
| `steps` | 確認ごとの試行(結果・種別・status・タイトル)。ブラウザの試行には、接続の作り方(`connection_layer`)、ページから見えたタイムゾーン・言語、環境の値(`js_env`: 画面・WebGL・CPU・メモリ)、手がかり(`env_flags`)も付く |
| `page` | 最後に通った試行で取れた本文(256KB まで)。通らなければ `null` |
| `table` | blocking-triage の確認の表(標準エラーに出るものと同じ) |
| `error` | 入口で拒否された、または診断が回らなかったときの理由 |

返すときは、blocking-triage の手順 6 の型をそのまま使い、「診断の条件」に次を足す。

- 実行場所: GCP(Cloud Run Job `lab-bt-triage`、<region>)
- データセンターの回線: `lines.client_proxy.info` の IP・org・kind_guess と、それが CLIENT_PROXY か Cloud Run の出口か

## 手元の blocking-triage と違うところ(「確認できていないこと」に書く)

- 前回の結果との比較と、保存済みの経路は使えない(実行ごとにコンテナが新しく、履歴が残らない)。
- サイト内の経路を辿る確認は、この skill では行わない。
- Chrome はコンテナの中で `--no-sandbox` と仮想画面(Xvfb、1366×768)で動き、WebGL はソフトウェア描画(SwiftShader)。手元のヘッドフルの Chrome と同じ結果になるとは限らない。ブラウザの結果を手元と比べるときは、両方の `js_env` を並べる。
- ブラウザの起動がまれに失敗する(2026-11-11 の確認で 6 回中 1 回、`Exception:`)。失敗は拒否として数えられるので、ブラウザの確認で「結果がばらつく」が出たら、試行の中に起動の失敗がないかを `table` で確かめる。
- Cloud Run の出口の IP は、実行ごとに変わることがある。

## 入口で拒否されるもの

`http`/`https` 以外、80・443 以外のポート、URL に埋め込んだ認証情報、名前解決した先がプライベート・ループバック・リンクローカル(169.254.169.254 など)の URL。拒否された URL は `error` に `rejected:` で出る。
