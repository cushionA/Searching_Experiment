import sys
from pathlib import Path

scripts = Path(sys.argv[1])

PATCHES = {
    "probe.py": [
        ("BODY_HEAD_BYTES = 2048", 'BODY_HEAD_BYTES = int(os.environ.get("BT_BODY_BYTES", "2048"))'),
        ('                    "country": d.get("country"),\n',
         '                    "country": d.get("country"),\n'
         '                    **({"timezone": d.get("timezone")} if os.environ.get("BT_MATCH_LINE") else {}),\n'),
        # BT_DC_DIRECT: without CLIENT_PROXY, treat this environment's own egress (Cloud Run) as the datacenter line.
        ('        if not url:\n            return None\n        line = {"line": name, "egress": name, "proxy": url, "source": source, "substitute": False}',
         '        if not url and not os.environ.get("BT_DC_DIRECT"):\n            return None\n'
         '        line = ({"line": name, "egress": name, "proxy": url, "source": source, "substitute": False} if url\n'
         '                else {"line": name, "egress": "direct", "proxy": None, "source": "Cloud Run の出口", "substitute": False})'),
    ],
    "browser_common.py": [
        # BT_BROWSER_*: set by ladder.py under BT_MATCH_LINE so the browser matches the line's egress.
        ('LOCALE = "ja-JP"\nTIMEZONE = "Asia/Tokyo"',
         'LOCALE = os.environ.get("BT_BROWSER_LOCALE") or "ja-JP"\nTIMEZONE = os.environ.get("BT_BROWSER_TZ") or "Asia/Tokyo"'),
        ('        args.append("--accept-lang=ja,en-US,en")',
         '        args.append("--accept-lang=" + (os.environ.get("BT_BROWSER_ACCEPT_LANG") or "ja,en-US,en"))'),
    ],
    "route_summary.py": [
        ("from __future__ import annotations\n", "from __future__ import annotations\n\nimport os\n"),
        ('"user_agent", "webdriver", "headless", "cookie_names", "js_env")',
         '"user_agent", "webdriver", "headless", "cookie_names", "js_env")\n'
         '    if os.environ.get("BT_KEEP_BODY"):\n'
         '        keep += ("body_head", "language", "languages", "timezone")'),
    ],
    "browser_run.py": [
        ('    elif line == "client_proxy":\n        raise UsageError',
         '    elif line == "client_proxy" and not os.environ.get("BT_DC_DIRECT"):\n        raise UsageError'),
    ],
    "ladder.py": [
        ("import argparse\n", "import argparse\nimport os\n"),
        ('    if out.get("row"):\n        out["row"] = {k: v for k, v in out["row"].items() if k != "body_head"}',
         '    if out.get("row") and not os.environ.get("BT_KEEP_BODY"):\n        out["row"] = {k: v for k, v in out["row"].items() if k != "body_head"}'),
        # BT_ONLY_BROWSER: smoke test of the browser steps only. The reading is meaningless in this mode.
        ("    for step in STEPS:\n",
         '    for step in [s for s in STEPS if s["client"] == "browser"] if os.environ.get("BT_ONLY_BROWSER") else STEPS:\n'),
        ("    def _line_args(self, line: dict) -> list[str]:\n",
         "    def _line_args(self, line: dict) -> list[str]:\n        _match_line_locale(line)\n"),
        ("def _strip(o: dict) -> dict:\n",
         'LANG_BY_COUNTRY = {\n'
         '    "JP": ("ja-JP", "ja,en-US,en"), "US": ("en-US", "en-US,en"), "GB": ("en-GB", "en-GB,en"),\n'
         '    "KR": ("ko-KR", "ko,en-US,en"), "CN": ("zh-CN", "zh-CN,zh,en"), "TW": ("zh-TW", "zh-TW,zh,en"),\n'
         '    "DE": ("de-DE", "de,en-US,en"), "FR": ("fr-FR", "fr,en-US,en"),\n'
         '}\n\n\n'
         'def _match_line_locale(line: dict) -> None:\n'
         '    """BT_MATCH_LINE のとき、ブラウザのタイムゾーン・言語を、その回線の出口(ipinfo.io の国・タイムゾーン)に合わせる。\n\n'
         '    回線の情報が取れていなければ、既定(ja・Asia/Tokyo)のまま開く。表にない国は en-US にする。\n'
         '    """\n'
         '    keys = ("BT_BROWSER_TZ", "BT_BROWSER_LOCALE", "BT_BROWSER_ACCEPT_LANG")\n'
         '    info = line.get("info") or {}\n'
         '    if not os.environ.get("BT_MATCH_LINE") or not info.get("country"):\n'
         '        for k in keys:\n'
         '            os.environ.pop(k, None)\n'
         '        return\n'
         '    locale, accept = LANG_BY_COUNTRY.get(info["country"], ("en-US", "en-US,en"))\n'
         '    for k, v in zip(keys, (info.get("timezone"), locale, accept)):\n'
         '        if v:\n'
         '            os.environ[k] = v\n'
         '        else:\n'
         '            os.environ.pop(k, None)\n\n\n'
         'def _strip(o: dict) -> dict:\n'),
    ],
    "browser_probe.py": [
        ("import asyncio\n", "import asyncio\nimport os\n"),
        ('int(opt(args, "body-bytes") or 2048)', 'int(opt(args, "body-bytes") or os.environ.get("BT_BODY_BYTES", 2048))'),
    ],
}

for name, pairs in PATCHES.items():
    path = scripts / name
    text = path.read_text(encoding="utf-8")
    for old, new in pairs:
        if new in text:  # already patched (some replacements contain the original text, so check `new` first)
            continue
        if text.count(old) != 1:
            sys.exit(f"patch failed: {name}: {old[:60]!r} found {text.count(old)} times")
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")
    print(f"patched {name}")
