import ipaddress
import json
import os
import signal
import socket
import subprocess
import tempfile
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit

SCRIPTS = "/app/.claude/skills/blocking-triage/scripts"
ALLOWED_HOSTS = {h.strip().lower() for h in os.environ.get("ALLOWED_HOSTS", "").split(",") if h.strip()}
TIMEOUT_SEC = int(os.environ.get("TRIAGE_TIMEOUT_SEC", "270"))
BODY_BYTES = int(os.environ.get("BT_BODY_BYTES", "262144"))
SECRET_VALUES: list[str] = []


def add_secret(value: str) -> None:
    if not value:
        return
    SECRET_VALUES.append(value)
    password = urlsplit(value).password
    if password:
        SECRET_VALUES.append(password)


add_secret(os.environ.get("CLIENT_PROXY", ""))


# Browser tries also carry what the page saw, so a run can be checked against its line (timezone, language)
# and compared with a local browser (js_env: screen, WebGL, CPU, memory).
BROWSER_FIELDS = ("connection_layer", "user_agent", "language", "languages", "timezone", "js_env", "env_flags")


class Rejected(Exception):
    pass


def validate(url: str) -> str:
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https"):
        raise Rejected("scheme must be http or https")
    if parts.username or parts.password:
        raise Rejected("credentials in URL are not allowed")
    if parts.port not in (None, 80, 443):
        raise Rejected("only ports 80 and 443 are allowed")
    host = (parts.hostname or "").lower()
    if "*" not in ALLOWED_HOSTS and host not in ALLOWED_HOSTS:
        raise Rejected(f"host not in ALLOWED_HOSTS: {host}")
    try:
        addrs = {ai[4][0] for ai in socket.getaddrinfo(host, parts.port or 443, proto=socket.IPPROTO_TCP)}
    except socket.gaierror as e:
        raise Rejected(f"cannot resolve host: {e}") from e
    bad = [a for a in addrs if not ipaddress.ip_address(a.split("%")[0]).is_global]
    if bad:
        raise Rejected(f"host resolves to non-public address: {bad}")
    return url


def redact(text: str) -> str:
    for v in SECRET_VALUES:
        text = text.replace(v, "***")
    return text


def run_ladder(url: str) -> tuple[int, str, str, float]:
    with tempfile.TemporaryDirectory(prefix="bt-") as work:
        env = {
            **os.environ,
            "HOME": work,
            "TMPDIR": work,
            "BLOCKING_TRIAGE_STATE_DIR": work,
            "BT_KEEP_BODY": "1",
            "BT_BODY_BYTES": str(BODY_BYTES),
        }
        cmd = ["xvfb-run", "-a", "-s", "-screen 0 1366x768x24",
               "uv", "run", "--quiet", "ladder.py", "--url", url, "--no-history", "--no-saved-routes"]
        started = time.monotonic()
        proc = subprocess.Popen(cmd, cwd=SCRIPTS, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, start_new_session=True)
        try:
            out, err = proc.communicate(timeout=TIMEOUT_SEC)
            code = proc.returncode
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            out, err = proc.communicate()
            code = -1
            err = f"timed out after {TIMEOUT_SEC}s\n{err}"
        return code, out, err, time.monotonic() - started


def pick_page(result: dict) -> dict | None:
    page = None
    for rec in result.get("ladder", {}).get("records", []):
        for o in rec.get("outcomes", []) + rec.get("confirm", []):
            row = o.get("row") or o.get("summary") or {}
            if o.get("result") == "pass" and row.get("body_head") is not None:
                body = row["body_head"]
                page = {
                    "client": row.get("client") or rec.get("step", {}).get("client"),
                    "status": row.get("status"),
                    "final_url": row.get("final_url"),
                    "title": row.get("title"),
                    "bytes": row.get("bytes"),
                    "truncated": (row.get("bytes") or 0) > len(body.encode("utf-8")),
                    "body": body,
                }
    return page


def summarize(result: dict) -> list[dict]:
    steps = []
    for rec in result.get("ladder", {}).get("records", []):
        tries = []
        for o in rec.get("outcomes", []) + rec.get("confirm", []):
            row = o.get("row") or o.get("summary") or {}
            browser = {k: row[k] for k in BROWSER_FIELDS if k in row}
            tries.append({"result": o.get("result"), "kind": row.get("kind"), "status": row.get("status"),
                          "title": row.get("title"), "via_top": o.get("via_top"), **browser})
        steps.append({"line": rec.get("line", {}).get("line"), "client": rec.get("step", {}).get("client"), "tries": tries})
    return steps


class Handler(BaseHTTPRequestHandler):
    def _send(self, code: int, payload: dict) -> None:
        body = redact(json.dumps(payload, ensure_ascii=False, indent=2)).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        self._send(200, {"ok": True, "allowed_hosts": sorted(ALLOWED_HOSTS)})

    def do_POST(self) -> None:
        if self.path != "/triage":
            return self._send(404, {"error": "not found"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > 4096:
                raise Rejected("request too large")
            url = validate(json.loads(self.rfile.read(length) or b"{}").get("url", ""))
        except (Rejected, ValueError, AttributeError) as e:
            print(json.dumps({"severity": "WARNING", "message": "rejected", "reason": str(e)}), flush=True)
            return self._send(400, {"error": str(e)})

        code, out, err, elapsed = run_ladder(url)
        print(json.dumps({"severity": "INFO", "message": "triage done", "url": url, "exit": code,
                          "elapsed_sec": round(elapsed, 1)}), flush=True)
        try:
            data = json.loads(out)
        except ValueError:
            return self._send(502, {"error": "ladder failed", "exit": code, "elapsed_sec": round(elapsed, 1),
                                    "stderr_tail": redact(err[-3000:])})
        result = data["results"][0]
        self._send(200, {
            "url": url,
            "elapsed_sec": round(elapsed, 1),
            "lines": data.get("lines"),
            "reading": result.get("reading"),
            "stopped": result.get("ladder", {}).get("stopped"),
            "steps": summarize(result),
            "page": pick_page(result),
            "table": redact(err),
        })

    def log_message(self, *args) -> None:
        pass


if __name__ == "__main__":
    HTTPServer(("0.0.0.0", int(os.environ.get("PORT", "8080"))), Handler).serve_forever()
