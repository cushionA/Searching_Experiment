"""Tests for the Cloud Run additions: the env-gated skill patches, server.py's entry checks and job.py's argument checks.

Run against a patched skill (Linux; the skill imports fcntl):
  BT_SKILL_SCRIPTS=<repo>/.claude/skills/blocking-triage/scripts uv run --with pytest --with curl_cffi pytest tests
"""

import importlib
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, os.environ["BT_SKILL_SCRIPTS"])
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import browser_run  # noqa: E402
import job  # noqa: E402
import ladder  # noqa: E402
import probe  # noqa: E402
import server  # noqa: E402

NO_PROXIES = {"client_proxy": (None, None), "residential": (None, None)}
REAL_EGRESS_INFO = probe.egress_info  # the autouse fixture stubs it; keep the real one for its own test


@pytest.fixture(autouse=True)
def no_egress_lookup(monkeypatch):
    monkeypatch.setattr(probe, "egress_info", lambda pairs: [{"egress": e, "ip": "192.0.2.1"} for e, _ in pairs])
    monkeypatch.delenv("BT_DC_DIRECT", raising=False)
    monkeypatch.delenv("BT_KEEP_BODY", raising=False)
    monkeypatch.delenv("CLIENT_PROXY", raising=False)


# ---- skill patches


def test_client_proxy_line_is_missing_without_proxy_or_flag():
    assert probe.build_line("client_proxy", NO_PROXIES) is None


def test_client_proxy_line_falls_back_to_direct_egress_with_flag(monkeypatch):
    monkeypatch.setenv("BT_DC_DIRECT", "1")
    line = probe.build_line("client_proxy", NO_PROXIES)
    assert line["line"] == "client_proxy"
    assert line["egress"] == "direct"
    assert line["proxy"] is None
    assert line["info"]["ip"] == "192.0.2.1"


def test_given_proxy_wins_over_direct_flag(monkeypatch):
    monkeypatch.setenv("BT_DC_DIRECT", "1")
    proxies = {**NO_PROXIES, "client_proxy": ("http://u:p@proxy.example:3128", "環境変数")}
    line = probe.build_line("client_proxy", proxies)
    assert line["egress"] == "client_proxy"
    assert line["proxy"] == "http://u:p@proxy.example:3128"


def test_browser_line_requires_client_proxy_without_flag():
    with pytest.raises(browser_run.UsageError):
        browser_run.resolve_line("client_proxy")


def test_browser_line_opens_direct_with_flag(monkeypatch):
    monkeypatch.setenv("BT_DC_DIRECT", "1")
    assert browser_run.resolve_line("client_proxy") == ""


def test_body_is_dropped_from_json_by_default():
    out = ladder._strip({"result": "pass", "row": {"status": 200, "body_head": "<html>"}})
    assert "body_head" not in out["row"]


def test_body_is_kept_with_flag(monkeypatch):
    monkeypatch.setenv("BT_KEEP_BODY", "1")
    out = ladder._strip({"result": "pass", "row": {"status": 200, "body_head": "<html>"}})
    assert out["row"]["body_head"] == "<html>"


def test_body_size_follows_env(monkeypatch):
    monkeypatch.setenv("BT_BODY_BYTES", "12345")
    try:
        assert importlib.reload(probe).BODY_HEAD_BYTES == 12345
    finally:
        monkeypatch.delenv("BT_BODY_BYTES")
        importlib.reload(probe)


# ---- matching the browser to the line (BT_MATCH_LINE)

BROWSER_KEYS = ("BT_BROWSER_TZ", "BT_BROWSER_LOCALE", "BT_BROWSER_ACCEPT_LANG")


@pytest.fixture
def clean_browser_env(monkeypatch):
    for k in (*BROWSER_KEYS, "BT_MATCH_LINE"):
        monkeypatch.delenv(k, raising=False)
    yield
    for k in BROWSER_KEYS:
        os.environ.pop(k, None)


def test_line_locale_is_untouched_without_flag(clean_browser_env):
    ladder._match_line_locale({"info": {"country": "US", "timezone": "America/Chicago"}})
    assert not any(k in os.environ for k in BROWSER_KEYS)


@pytest.mark.parametrize(("info", "expected"), [
    ({"country": "US", "timezone": "America/Chicago"}, ("America/Chicago", "en-US", "en-US,en")),
    ({"country": "JP", "timezone": "Asia/Tokyo"}, ("Asia/Tokyo", "ja-JP", "ja,en-US,en")),
    ({"country": "BR", "timezone": "America/Sao_Paulo"}, ("America/Sao_Paulo", "en-US", "en-US,en")),
])
def test_line_locale_follows_egress(clean_browser_env, monkeypatch, info, expected):
    monkeypatch.setenv("BT_MATCH_LINE", "1")
    ladder._match_line_locale({"info": info})
    assert tuple(os.environ[k] for k in BROWSER_KEYS) == expected


def test_line_without_egress_info_keeps_defaults(clean_browser_env, monkeypatch):
    monkeypatch.setenv("BT_MATCH_LINE", "1")
    monkeypatch.setenv("BT_BROWSER_TZ", "left/over")
    ladder._match_line_locale({"info": {"error": "unreachable"}})
    assert not any(k in os.environ for k in BROWSER_KEYS)


def test_browser_constants_follow_env(clean_browser_env, monkeypatch):
    import browser_common

    monkeypatch.setenv("BT_BROWSER_TZ", "America/Chicago")
    monkeypatch.setenv("BT_BROWSER_LOCALE", "en-US")
    monkeypatch.setenv("BT_BROWSER_ACCEPT_LANG", "en-US,en")
    try:
        bc = importlib.reload(browser_common)
        assert (bc.TIMEZONE, bc.LOCALE) == ("America/Chicago", "en-US")
        assert "--accept-lang=en-US,en" in bc.launch_args("chrome")
    finally:
        for k in BROWSER_KEYS:
            monkeypatch.delenv(k)
        bc = importlib.reload(browser_common)
    assert (bc.TIMEZONE, bc.LOCALE) == ("Asia/Tokyo", "ja-JP")
    assert "--accept-lang=ja,en-US,en" in bc.launch_args("chrome")


def test_egress_info_keeps_timezone_only_with_flag(monkeypatch):
    body = '{"ip": "192.0.2.1", "org": "AS396982 Google LLC", "country": "US", "timezone": "America/Chicago"}'
    monkeypatch.setattr(probe, "fetch_cffi", lambda url, proxy: {"body": body, "status": 200})
    monkeypatch.delenv("BT_MATCH_LINE", raising=False)
    assert "timezone" not in REAL_EGRESS_INFO([("direct", None)])[0]
    monkeypatch.setenv("BT_MATCH_LINE", "1")
    assert REAL_EGRESS_INFO([("direct", None)])[0]["timezone"] == "America/Chicago"


def test_browser_summary_keeps_body_and_locale_with_flag(monkeypatch):
    import route_summary

    d = {"ok": True, "status": 200, "title": "Example Domain", "headers": {}, "cookie_names": [],
         "body_head": "<html>ok</html>", "language": "en-US", "languages": ["en-US", "en"], "timezone": "America/Chicago"}
    monkeypatch.delenv("BT_KEEP_BODY", raising=False)
    assert "body_head" not in route_summary.summarize_browser_probe(d)
    monkeypatch.setenv("BT_KEEP_BODY", "1")
    s = route_summary.summarize_browser_probe(d)
    assert (s["body_head"], s["language"], s["timezone"]) == ("<html>ok</html>", "en-US", "America/Chicago")


def test_only_browser_steps_run_with_smoke_flag(monkeypatch):
    seen = []

    def run_step(step, line):
        seen.append(step["n"])
        return {"result": "pass", "row": {"kind": "ok"}}

    line = {"line": "client_proxy", "egress": "direct", "proxy": None, "info": {}}
    monkeypatch.setenv("BT_ONLY_BROWSER", "1")
    out = ladder.run_ladder({"client_proxy": line, "residential": None}, run_step, via_top=False)
    assert set(seen) == {2}
    assert out["stopped_at"] == 2


# ---- server.py entry checks


@pytest.fixture
def any_host(monkeypatch):
    monkeypatch.setattr(server, "ALLOWED_HOSTS", {"*"})
    monkeypatch.setattr(server.socket, "getaddrinfo", lambda host, *a, **k: [(None, None, None, None, (FAKE_DNS[host], 0))])


FAKE_DNS = {"public.example": "93.184.215.14", "metadata.example": "169.254.169.254", "private.example": "10.0.0.5",
            "loop.example": "127.0.0.1", "v6loop.example": "::1"}


@pytest.mark.parametrize("url", ["https://public.example/", "http://public.example:80/x?q=1"])
def test_public_urls_pass(any_host, url):
    assert server.validate(url) == url


@pytest.mark.parametrize(("url", "reason"), [
    ("ftp://public.example/", "scheme"),
    ("file:///etc/passwd", "scheme"),
    ("https://public.example:8443/", "port"),
    ("https://u:p@public.example/", "credentials"),
    ("https://metadata.example/", "non-public"),
    ("https://private.example/", "non-public"),
    ("https://loop.example/", "non-public"),
    ("https://v6loop.example/", "non-public"),
])
def test_unsafe_urls_are_rejected(any_host, url, reason):
    with pytest.raises(server.Rejected, match=reason):
        server.validate(url)


def test_allowlist_is_enforced_when_not_wildcard(monkeypatch):
    monkeypatch.setattr(server, "ALLOWED_HOSTS", {"example.com"})
    with pytest.raises(server.Rejected, match="ALLOWED_HOSTS"):
        server.validate("https://other.example/")


def test_redact_hides_proxy_url_and_password(monkeypatch):
    monkeypatch.setattr(server, "SECRET_VALUES", [])
    server.add_secret("http://user:s3cret-pw@proxy.example:3128")
    text = server.redact("using http://user:s3cret-pw@proxy.example:3128 (pw s3cret-pw)")
    assert "s3cret-pw" not in text


# ---- job.py argument checks


@pytest.mark.parametrize("name", ["triage-20261111T043125-ea5c09", "a", "x.y_z-1"])
def test_valid_out_names(name):
    assert job.OUT_NAME.match(name)


@pytest.mark.parametrize("name", ["../escape", "a/b", "", ".hidden", "-x", "x" * 101])
def test_invalid_out_names(name):
    assert not job.OUT_NAME.match(name)


@pytest.mark.parametrize("version", [
    "projects/groundingsearch/secrets/lab-bt-client-proxy/versions/1",
    "projects/363571044248/secrets/lab-bt-residential-proxy/versions/12",
])
def test_only_proxy_secret_versions_are_accepted(version):
    assert job.SECRET_VERSION.match(version)


@pytest.mark.parametrize("version", [
    "projects/p/secrets/other-secret/versions/1",
    "projects/p/secrets/lab-bt-client-proxy/versions/latest",
    "projects/p/secrets/lab-bt-client-proxy",
])
def test_other_secrets_are_refused_before_any_read(monkeypatch, version):
    monkeypatch.setattr(job, "read_secret", lambda v: pytest.fail("must not read"))
    with pytest.raises(ValueError):
        job.load_proxies(version, None)


def test_load_proxies_sets_env_and_registers_redaction(monkeypatch):
    monkeypatch.setattr(server, "SECRET_VALUES", [])
    monkeypatch.setattr(job, "read_secret", lambda v: "http://u:pw-xyz@resi.example:8000\n".strip())
    monkeypatch.setenv("CLIENT_PROXY", "stale")
    lines = job.load_proxies(None, "projects/p/secrets/lab-bt-residential-proxy/versions/3")
    assert lines == {"RESIDENTIAL_PROXY": "lab-bt-residential-proxy"}
    assert os.environ["RESIDENTIAL_PROXY"] == "http://u:pw-xyz@resi.example:8000"
    assert "CLIENT_PROXY" not in os.environ
    assert "pw-xyz" not in job.redact("pw-xyz")
    assert "HTTPS_PROXY" not in os.environ and "HTTP_PROXY" not in os.environ
    monkeypatch.delenv("RESIDENTIAL_PROXY")
