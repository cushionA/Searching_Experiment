import argparse
import base64
import json
import os
import re
import sys
import urllib.parse
import urllib.request
from collections import OrderedDict
from datetime import datetime, timezone

from server import Rejected, add_secret, pick_page, redact, run_ladder, summarize, validate

OUT_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$")
SECRET_VERSION = re.compile(r"^projects/[^/]+/secrets/lab-bt-(client|residential)-proxy/versions/\d+$")
METADATA = "http://metadata.google.internal/computeMetadata/v1"


def access_token() -> str:
    req = urllib.request.Request(f"{METADATA}/instance/service-accounts/default/token", headers={"Metadata-Flavor": "Google"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.load(r)["access_token"]


def read_secret(version: str) -> str:
    req = urllib.request.Request(f"https://secretmanager.googleapis.com/v1/{version}:access",
                                 headers={"Authorization": f"Bearer {access_token()}"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return base64.b64decode(json.load(r)["payload"]["data"]).decode("utf-8").strip()


def load_proxies(client: str | None, residential: str | None) -> dict:
    # Proxy URLs reach ladder.py only through these env vars. HTTP(S)_PROXY is never set, so this process's own
    # calls (metadata, Secret Manager, GCS) stay direct.
    lines = {}
    for env, version in (("CLIENT_PROXY", client), ("RESIDENTIAL_PROXY", residential)):
        os.environ.pop(env, None)
        if not version:
            continue
        if not SECRET_VERSION.match(version):
            raise ValueError(f"unexpected secret version name for {env}")
        url = read_secret(version)
        add_secret(url)
        os.environ[env] = url
        lines[env] = version.rsplit("/versions/", 1)[0].rsplit("/", 1)[1]
    return lines


def upload(bucket: str, name: str, payload: dict) -> None:
    # ifGenerationMatch=0: create only. The job SA has objectCreator, so an existing result can never be replaced.
    q = urllib.parse.urlencode({"uploadType": "media", "name": name, "ifGenerationMatch": "0"})
    req = urllib.request.Request(
        f"https://storage.googleapis.com/upload/storage/v1/b/{bucket}/o?{q}",
        data=redact(json.dumps(payload, ensure_ascii=False, indent=2)).encode("utf-8"),
        method="POST",
        headers={"Authorization": f"Bearer {access_token()}", "Content-Type": "application/json; charset=utf-8"},
    )
    with urllib.request.urlopen(req, timeout=30) as r:
        r.read()


def triage(url: str) -> tuple[bool, dict]:
    try:
        validate(url)
    except Rejected as e:
        return False, {"url": url, "error": f"rejected: {e}"}
    code, out, err, elapsed = run_ladder(url)
    try:
        data = json.loads(out)
        result = data["results"][0]
    except (ValueError, KeyError, IndexError):
        return False, {"url": url, "error": "ladder failed", "exit": code, "elapsed_sec": round(elapsed, 1), "stderr_tail": err[-3000:]}
    return True, {
        "url": url,
        "elapsed_sec": round(elapsed, 1),
        "lines": data.get("lines"),
        "reading": result.get("reading"),
        "stopped": result.get("ladder", {}).get("stopped"),
        "steps": summarize(result),
        "page": pick_page(result),
        "table": err,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="result object name (without .json)")
    ap.add_argument("--client-proxy-secret", help="Secret Manager version holding CLIENT_PROXY (datacenter line)")
    ap.add_argument("--residential-proxy-secret", help="Secret Manager version holding RESIDENTIAL_PROXY")
    ap.add_argument("--browser-smoke", action="store_true", help="run only the browser steps (checks that Chrome works here; the reading is not a diagnosis)")
    ap.add_argument("urls", nargs="+")
    args = ap.parse_args()
    if args.browser_smoke:
        os.environ["BT_ONLY_BROWSER"] = "1"
    if not OUT_NAME.match(args.out):
        print(json.dumps({"severity": "ERROR", "message": "invalid --out", "out": args.out}), flush=True)
        return 2
    try:
        proxies = load_proxies(args.client_proxy_secret, args.residential_proxy_secret)
    except Exception as e:
        print(json.dumps({"severity": "ERROR", "message": "proxy secret unavailable", "error": redact(str(e))}), flush=True)
        return 2

    groups: "OrderedDict[str, list[str]]" = OrderedDict()
    for url in args.urls:
        groups.setdefault((urllib.parse.urlsplit(url).hostname or "").lower(), []).append(url)
    index = int(os.environ.get("CLOUD_RUN_TASK_INDEX", "0"))
    count = int(os.environ.get("CLOUD_RUN_TASK_COUNT", "1"))
    mine = [u for i, (_, urls) in enumerate(groups.items()) if i % count == index for u in urls]

    started = datetime.now(timezone.utc)
    results, all_ok = [], True
    for url in mine:
        ok, res = triage(url)
        all_ok &= ok
        results.append(res)
        print(json.dumps({"severity": "INFO" if ok else "WARNING", "message": "triage done", "url": url,
                          "stopped": res.get("stopped"), "error": res.get("error")}), flush=True)

    name = f"{args.out}.json" if count == 1 else f"{args.out}.task{index}.json"
    upload(os.environ["RESULT_BUCKET"], name, {
        "execution": os.environ.get("CLOUD_RUN_EXECUTION"),
        "task_index": index,
        "proxies_from": proxies,
        "browser_smoke": args.browser_smoke,
        "started_at": started.isoformat(),
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "results": results,
    })
    print(json.dumps({"severity": "INFO", "message": "uploaded", "object": f"gs://{os.environ['RESULT_BUCKET']}/{name}"}), flush=True)
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
