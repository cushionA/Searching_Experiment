variable "project" {
  type    = string
  default = "groundingsearch"
}

variable "region" {
  type    = string
  default = "us-central1"
}

variable "image" {
  type    = string
  default = "us-central1-docker.pkg.dev/groundingsearch/lab-bt/blocking-triage:v6"
}

variable "invoker_sa_id" {
  type    = string
  default = "lab-bt-invoker"
}

# Principals allowed to impersonate the invoker SA (e.g. "user:someone@example.com").
variable "operators" {
  type    = list(string)
  default = ["user:tatuki.s1105@gmail.com"]
}

variable "result_retention_days" {
  type    = number
  default = 7
}

variable "parallelism" {
  type    = number
  default = 2
}

# ladder.py worst case: about 5-7 minutes per line (browser direct + via top, each after a 60 s cooldown).
# With a residential proxy the browser steps run on two lines.
variable "per_url_timeout_sec" {
  type    = number
  default = 1200
}

variable "task_timeout_sec" {
  type    = number
  default = 3600
}
