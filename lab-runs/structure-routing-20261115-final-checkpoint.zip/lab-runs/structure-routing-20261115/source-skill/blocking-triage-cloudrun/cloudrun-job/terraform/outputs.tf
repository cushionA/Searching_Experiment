output "job_name" {
  value = google_cloud_run_v2_job.triage.name
}

output "result_bucket" {
  value = google_storage_bucket.results.name
}

output "job_service_account" {
  value = google_service_account.job.email
}

output "invoker_service_account" {
  value = google_service_account.invoker.email
}

output "proxy_secrets" {
  value = { for k, s in google_secret_manager_secret.proxy : k => s.secret_id }
}
