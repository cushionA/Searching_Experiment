terraform {
  required_version = ">= 1.6"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 6.0"
    }
  }
}

provider "google" {
  project = var.project
  region  = var.region
}

resource "google_service_account" "job" {
  account_id   = "lab-bt-job-sa"
  display_name = "lab blocking-triage job"
}

resource "google_storage_bucket" "results" {
  name                        = "${var.project}-lab-bt-results"
  location                    = upper(var.region)
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = true

  lifecycle_rule {
    condition {
      age = var.result_retention_days
    }
    action {
      type = "Delete"
    }
  }
}

# Create-only: the job can write new results but cannot read, overwrite or delete existing ones.
resource "google_storage_bucket_iam_member" "job_writes_results" {
  bucket = google_storage_bucket.results.name
  role   = "roles/storage.objectCreator"
  member = "serviceAccount:${google_service_account.job.email}"
}

resource "google_cloud_run_v2_job" "triage" {
  name                = "lab-bt-triage"
  location            = var.region
  deletion_protection = false

  template {
    task_count  = 1
    parallelism = var.parallelism

    template {
      service_account       = google_service_account.job.email
      timeout               = "${var.task_timeout_sec}s"
      max_retries           = 0
      execution_environment = "EXECUTION_ENVIRONMENT_GEN2"

      containers {
        image   = var.image
        command = ["python", "/app/job.py"]

        resources {
          limits = {
            cpu    = "2"
            memory = "2Gi"
          }
        }

        # The security boundary is "who can run this job" (the invoker SA), not a host allowlist:
        # env vars can be overridden per execution, so an env-based allowlist would not hold anyway.
        env {
          name  = "ALLOWED_HOSTS"
          value = "*"
        }
        env {
          name  = "RESULT_BUCKET"
          value = google_storage_bucket.results.name
        }
        env {
          name  = "TRIAGE_TIMEOUT_SEC"
          value = tostring(var.per_url_timeout_sec)
        }
      }
    }
  }

  depends_on = [google_storage_bucket_iam_member.job_writes_results]
}

# ---- Proxy URLs travel through Secret Manager, never through job args (args are kept in execution history).
# Only the secret containers are managed here; versions are added per run by the invoker and destroyed afterwards,
# so proxy credentials never appear in Terraform state.

resource "google_secret_manager_secret" "proxy" {
  for_each  = toset(["client", "residential"])
  secret_id = "lab-bt-${each.key}-proxy"
  replication {
    auto {}
  }
}

resource "google_secret_manager_secret_iam_member" "job_reads_proxy" {
  for_each  = google_secret_manager_secret.proxy
  secret_id = each.value.id
  role      = "roles/secretmanager.secretAccessor"
  member    = "serviceAccount:${google_service_account.job.email}"
}

# ---- Invoker: the only identity that runs the job. Operators impersonate it.

resource "google_service_account" "invoker" {
  account_id   = var.invoker_sa_id
  display_name = "lab blocking-triage invoker"
}

resource "google_cloud_run_v2_job_iam_member" "invoker_runs_job" {
  for_each = toset(["roles/run.jobsExecutorWithOverrides", "roles/run.viewer"])
  name     = google_cloud_run_v2_job.triage.name
  location = var.region
  role     = each.value
  member   = "serviceAccount:${google_service_account.invoker.email}"
}

# run.operations.get is only grantable at project level; keep it to that single permission.
resource "google_project_iam_custom_role" "run_operation_reader" {
  role_id     = "labBtRunOperationReader"
  title       = "lab-bt Cloud Run operation reader"
  permissions = ["run.operations.get"]
}

resource "google_project_iam_member" "invoker_reads_operations" {
  project = var.project
  role    = google_project_iam_custom_role.run_operation_reader.id
  member  = "serviceAccount:${google_service_account.invoker.email}"
}

# Add and destroy versions, but never read them back.
resource "google_secret_manager_secret_iam_member" "invoker_manages_proxy_versions" {
  for_each  = google_secret_manager_secret.proxy
  secret_id = each.value.id
  role      = "roles/secretmanager.secretVersionManager"
  member    = "serviceAccount:${google_service_account.invoker.email}"
}

resource "google_storage_bucket_iam_member" "invoker_reads_results" {
  bucket = google_storage_bucket.results.name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${google_service_account.invoker.email}"
}

resource "google_service_account_iam_member" "operators_impersonate_invoker" {
  for_each           = toset(var.operators)
  service_account_id = google_service_account.invoker.name
  role               = "roles/iam.serviceAccountTokenCreator"
  member             = each.value
}
