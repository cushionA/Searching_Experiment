#!/usr/bin/env python3
"""Render Stage C independent reach and acquisition costs from its score JSON."""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DEFAULT = ROOT / "lab-runs/structure-routing-20261115/stage-c-score.json"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("score", nargs="?", type=Path, default=DEFAULT)
    args = parser.parse_args()
    data = json.loads(args.score.read_text(encoding="utf-8"))
    print("Stage C independent target evaluation")
    print(f"Frozen manifest SHA256: {data['manifest_sha256']}")
    print(f"Documents: selection {data['selection_documents']}, bulk {data['bulk_documents']}, total {data['total_documents']} / 400")
    for site in data["sites"]:
        print(f"\nSite {site['id']}: {site['independent_targets_reached']} / {site['frozen_target_count']} independent targets reached")
        print(f"Bulk document attempts: {site['bulk_document_attempts']}; useful saved HTML targets: {site['useful_html_documents']}")
        print("Independent-target milestones:")
        for item in site["success_milestones"]:
            if item.get("unmet"):
                print(f"  {item['independent_targets']} targets: unmet")
            else:
                print(f"  {item['independent_targets']} targets: docs {item['cumulative_document_cost']} (+{item['incremental_document_cost']}), "
                      f"requests {item['cumulative_request_cost']} (+{item['incremental_request_cost']}), "
                      f"time {item['cumulative_time_ms']}ms (+{item['incremental_time_ms']}ms)")
        print("Attempt-count checkpoints:")
        for item in site["attempt_milestones"]:
            if item.get("unmet"):
                print(f"  {item['attempts']} attempts: unmet after {item['observed_attempts']} observations")
            else:
                print(f"  {item['attempts']} attempts: {item['cumulative_independent_reached']} reached, "
                      f"docs {item['cumulative_document_cost']} (+{item['incremental_document_cost']}), "
                      f"requests {item['cumulative_request_cost']} (+{item['incremental_request_cost']}), "
                      f"time {item['cumulative_time_ms']}ms (+{item['incremental_time_ms']}ms)")
        if site["unreached_urls"]:
            print(f"Unreached frozen URLs: {len(site['unreached_urls'])}")
    print("\nSelection labels are unverified title/path proxies.")


if __name__ == "__main__":
    main()
