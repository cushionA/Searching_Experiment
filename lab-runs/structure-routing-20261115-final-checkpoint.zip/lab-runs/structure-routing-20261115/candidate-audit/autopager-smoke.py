from pathlib import Path

import autopager
from autopager.autopager import train_crf

root = Path(__file__).parent / "autopager"
model = Path(__file__).parent / "autopager-fixture.crf"
page = """<html><body><div class='paginator'>
<a href='/blog/?page=1' class='prev'>Prev</a><a href='/blog/?page=1'>1</a>
<a href='/blog/?page=3'>3</a><a href='/blog/?page=4' class='last'>4</a>
<a href='/blog/?page=3' class='next'>Next</a></div></body></html>"""
train_crf(str(root / "autopager" / "data"), str(model))
pager = autopager.AutoPager(path=str(model))
print("version", autopager.__version__)
print("types", [kind for kind, _ in pager.extract(page)])
print("urls", pager.urls(page, "http://fixture.local"))
model.unlink(missing_ok=True)
