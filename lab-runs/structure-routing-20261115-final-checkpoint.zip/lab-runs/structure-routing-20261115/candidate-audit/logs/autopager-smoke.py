from pathlib import Path
import csv
from time import perf_counter

import autopager
from autopager.autopager import train_crf

root = Path(__file__).parent
model = root.parent / "autopager-fixture.crf"
page = """<html><body><div class='paginator'>
<a href='/blog/?page=1' class='prev'>Prev</a><a href='/blog/?page=1'>1</a>
<a href='/blog/?page=3'>3</a><a href='/blog/?page=4' class='last'>4</a>
<a href='/blog/?page=3' class='next'>Next</a></div></body></html>"""
for name, call in (("default_extract", lambda: autopager.extract(page)), ("default_urls", lambda: autopager.urls(page, "http://fixture.local"))):
    try:
        print(name, call())
    except Exception as error:
        print(name, "failed", type(error).__name__, str(error))
data = root.parent / "autopager-fixture-data"
(data / "html").mkdir(parents=True, exist_ok=True)
with (data / "data.csv").open("w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=["File Name", "Page URL", "Encoding", "PREV", "PAGE", "NEXT", "LAST", "FIRST", "failed", "comment"])
    writer.writeheader()
    for number in range(1, 5):
        writer.writerow({"File Name": str(number), "Page URL": f"http://fixture.local/{number}", "Encoding": "UTF-8", "PREV": ".prev", "PAGE": ".page", "NEXT": ".next", "LAST": "", "FIRST": "", "failed": "", "comment": ""})
        (data / "html" / f"{number}.html").write_text("<div><a class='prev' href='/p1'>Prev</a><a class='page' href='/p2'>2</a><a class='next' href='/p3'>Next</a></div>", encoding="utf-8")
train_crf(str(data), str(model))
pager = autopager.AutoPager(path=str(model))
start = perf_counter()
types = [kind for kind, _ in pager.extract(page)]
extract_seconds = perf_counter() - start
start = perf_counter()
urls = pager.urls(page, "http://fixture.local")
urls_seconds = perf_counter() - start
print("version", autopager.__version__)
print("model_source", "locally trained on four tiny HTML fixtures")
print("input_bytes", len(page.encode("utf-8")))
print("candidate_links", len(types))
print("inference_calls", 2)
print("result_types", types)
print("urls", urls)
print("extract_runtime_seconds", round(extract_seconds, 6))
print("urls_runtime_seconds", round(urls_seconds, 6))
model.unlink(missing_ok=True)
