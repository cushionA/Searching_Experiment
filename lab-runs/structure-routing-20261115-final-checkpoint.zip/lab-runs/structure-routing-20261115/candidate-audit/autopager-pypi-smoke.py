import autopager
from time import perf_counter

page = """<html><body><div class='paginator'>
<a href='/blog/?page=1' class='prev'>Prev</a><a href='/blog/?page=1'>1</a>
<a href='/blog/?page=3'>3</a><a href='/blog/?page=4' class='last'>4</a>
<a href='/blog/?page=3' class='next'>Next</a></div></body></html>"""
print("version", autopager.__version__)
start = perf_counter()
types = [kind for kind, _ in autopager.extract(page)]
extract_seconds = perf_counter() - start
start = perf_counter()
urls = autopager.urls(page, "http://fixture.local")
urls_seconds = perf_counter() - start
print("input_bytes", len(page.encode("utf-8")))
print("candidate_links", len(types))
print("inference_calls", 2)
print("types", types)
print("urls", urls)
print("extract_runtime_seconds", round(extract_seconds, 6))
print("urls_runtime_seconds", round(urls_seconds, 6))
