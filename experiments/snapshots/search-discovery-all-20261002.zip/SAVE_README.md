# テーマ探索・検索入口の全保存

4getをかなり有力な候補として優先保持する。ブロック対策で取得できる可能性は検証待ち。4get.caのIQテストと4get.chの環境proxy失敗は別々に記録した。この保存作業で追加通信はしていない。

- search-candidates-20261002.json: 全15候補群、4get 2サイト、公開SearXNG 6サイト、条件と観測根拠。
- checkpoints/: 5回の調査のstate、要求、回答、元の取得データ、抽出本文、出典、失敗・予算の履歴。
- ACQUIRED_SOURCES.json: 取得資料のURL・タイトル・種別・時刻・ハッシュとcheckpoint参照。
- DISCOVERED_LINKS.json: 抽出済みリンクと観測元、実際に本文を取得したかどうか。
- TOPIC_ANSWER.md: テーマ探索で作成した出典付き回答。
- source.zip: 最新実装・テスト・設定例・候補台帳・手順書。MANIFEST.jsonで各ファイルのSHA-256を照合できる。
- SAVE_INDEX.json / MANIFEST.json: 保存内容、runの入口、成果物ハッシュ。

## 再開

source.zipを任意の作業ディレクトリへ展開し、checkpoints内の対象ZIPを別のrunディレクトリへ展開する。Python 3.12以上でソースのディレクトリから `python3 -B -m jse.lab verify --run /absolute/path/to/restored-run` を実行する。各runは結果判断待ちの状態を保持している。保存を理由に判断・予算・取得履歴を変更していない。

Google選択画面の確認は、Google由来の実検索結果を取得したことを意味しない。未取得リンク・書誌メタデータ・確認画面も明示して残した。日本語のGoogle同等品質・Web全体の網羅率・モデルの実IDは未測定。
