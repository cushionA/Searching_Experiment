# テーマに関連する未知の情報源を発見する調査手法を探し、出典付きで使い方を答える。

引用は保存本文と照合済み。情報の意味・鮮度・網羅性は別途確認が必要。

未知の関連文献を見つける方法として、引用追跡（snowballing）が使えます。すでに関連性を確認した文献を出発点に、その参考文献をたどる後方検索と、その文献を引用した新しい論文を探す前方検索を行います。

出典: [Citation Chaining & Snowballing a Search — CASRAI](https://casrai.org/guides/citation-chaining-and-snowballing)（取得: 2026-10-01T17:12:15Z）

> Citation chaining (also called snowballing) is the practice of finding new relevant papers by following citation links from a paper you already know is relevant, rather than by running another keyword search. It works in two directions: backward, through a paper’s own reference list, and forward, through the later papers that have cited it.

まずデータベース検索などで関連文献（seed articles）を選び、各文献の参考文献と被引用文献を確認します。前方検索にはGoogle Scholar、PubMed、Web of Scienceなどが挙げられています。見つけた文献も新たな起点にして繰り返すと、検索語が異なる関連研究を拾える場合があります。

出典: [Snowball Method - Citation Searching - Database Search Tips - LibGuides at Texas Medical Center Library](https://libguides.library.tmc.edu/dbsearching/SnowballMethod_CitationSearching)（取得: 2026-10-01T17:20:26Z）

> Citation searching uses seed references (usually the set of included records from the results of a database search) and checks whether additional relevant articles can be found through forward citation searching and backward citation searching.

出典: [Snowball Method - Citation Searching - Database Search Tips - LibGuides at Texas Medical Center Library](https://libguides.library.tmc.edu/dbsearching/SnowballMethod_CitationSearching)（取得: 2026-10-01T17:20:26Z）

> Useful databases for forward snowballing are:
> Google Scholar
> Medline Ovid
> PubMed
> Web of Science

出典: [Citation Chaining & Snowballing a Search — CASRAI](https://casrai.org/guides/citation-chaining-and-snowballing)（取得: 2026-10-01T17:12:15Z）

> Used together and repeated across newly found papers, the two directions “snowball” outward from a small starting set into a much fuller picture of a literature — and they routinely surface work that a keyword search misses entirely, because a genuinely relevant paper may use different terminology, sit in an adjacent discipline’s vocabulary, or predate the specific term you searched for.

未解決: 個別テーマに対する起点文献の選定と、そのテーマでの具体的な引用追跡結果。

限界: 引用追跡の手順を説明する資料は確認できましたが、個別テーマや起点文献は指定されていません。網羅率は測定しておらず、検索結果の意味的な正しさも独立に検証していません。
