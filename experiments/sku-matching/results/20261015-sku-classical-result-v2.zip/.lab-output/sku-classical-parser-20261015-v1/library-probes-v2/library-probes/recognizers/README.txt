Microsoft Recognizers-Text Japanese Dimension probe scaffold.
No restore, build, network, or execution is performed by the Python probe.
The official Japanese Dimension specs mark Python/JavaScript/Java as not supported by design;
use this .NET probe after separately authorizing and provisioning the SDK/package.
AST decisions such as pack count, range semantics, and product conditions are out of scope.
