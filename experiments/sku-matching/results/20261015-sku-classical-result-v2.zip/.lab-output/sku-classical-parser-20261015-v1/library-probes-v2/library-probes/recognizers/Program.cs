using System.Text.Json;
using Microsoft.Recognizers.Text;
using Microsoft.Recognizers.Text.NumberWithUnit;

var examples = new (string Id, string Text)[]
{
    ("metric_equivalents", "100cm / 1m / 1000mm"),
    ("dimensions_pair", "幅100×丈80cm"),
    ("weight_and_pack_count", "250g×2袋"),
    ("piece_count", "4枚組"),
    ("plus_minus", "100±5cm"),
    ("approximation", "約100cm"),
    ("negative_condition", "レースなし/別売"),
    ("color_synonyms", "ブルー/青/水色"),
    ("kanji_variant", "附属/付属"),
    ("unicode_variants", "全角/①/Mvsｍ"),
};

var results = examples.Select(example => new
{
    example.Id,
    example.Text,
    ClassifierEnabled = false,
    Results = NumberWithUnitRecognizer.RecognizeDimension(example.Text, Culture.Japanese)
        .Select(result => new
        {
            result.Text,
            result.Start,
            result.End,
            result.TypeName,
            result.Resolution,
        })
}).ToArray();

Console.WriteLine(JsonSerializer.Serialize(results, new JsonSerializerOptions { WriteIndented = true }));
