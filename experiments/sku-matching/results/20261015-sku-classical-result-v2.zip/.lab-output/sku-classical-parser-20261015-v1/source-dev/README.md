# Classical parser DEV source bundle

This bundle contains the complete label-blind v7 DEV population inputs (1,370 cases / 107 products), the separate all-row v7 trace (untrusted hints), and the existing full-gate input bundle for the selected 40-case / 20-product subset.

The inspected checkpoint/runtime/adapter contain no full-population (1,370-case) requests, tasks, row-plans, case-plans, or public documents. Files under `gate-subset40/` must not be represented as complete DEV gate coverage. The population case/product records and untrusted trace remain available to a runner that builds full-population tasks.

No labels, TEST inputs, scoring outputs, model weights, or inference code were copied. `untrusted-v7-trace/` is explicitly not evidence or a task filter. All copied files are byte-for-byte copies; see `restore-manifest.json` for source paths, byte lengths, and SHA-256 hashes.
