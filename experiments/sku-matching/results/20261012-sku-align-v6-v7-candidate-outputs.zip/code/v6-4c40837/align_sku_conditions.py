"""Align the selected Rakuten SKU's conditions with every row of its fixed AU product.

similarity  per fixed pair, score every Rakuten option against every AU option with a Japanese
            cross-encoder reranker, in both directions. Scores are only ranked, never thresholded.
align       four table steps, no vocabulary; values are only split at brackets, '/' and numbers:
            1. identical strings after NFKC rank first in both directions;
            2. a Rakuten value and an AU value pair when each is the other's best match; only identical
               pairs are confirmed, the model's pairs are candidates (it always names a best match, so
               it cannot say a value has no counterpart);
            3. a Rakuten axis and an AU axis are symmetric when their pairs, identical or the model's, join
               only each other; other Rakuten axes, and AU axes with several values that join none, are
               one-sided;
            4. per AU row: aligned or contradiction on symmetric axes; model candidates and one-sided
               conditions go to the description check; an unpaired value on a symmetric axis is excluded.
               On a symmetric axis where no AU value is identical to the Rakuten value, the AU values that
               share its core replace the model's single pick: bracketed parts and the other '/' parts are
               set aside, and numbers equal in order with labels added before a number or a unit added at
               the end are the same core. Every such row is aligned, or keeps the set-aside parts as
               residual conditions for the description check; rows with another core are contradictions.
               An AU value identical to another value of the Rakuten axis stays with that value.
               Such a core can confirm a value on a join made only by model pairs, so a wrong core costs adoptions.
score       after the outputs are saved: Luna machine labels and the manual axis reference.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import platform
import re
import time
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
MODEL = ("hotchpotch/japanese-reranker-small-v2", "e8091d132c23b372e059505edbb9255f346100d3")
LABELS = ".lab-output/sku-real-luna-labels-20261010-v3/labels.jsonl"
# A row takes the first state any of its conditions has, in this order.
ROW_STATES = ["contradiction", "symmetric_unresolved", "pending_description_check", "aligned"]
CONDITION_TO_ROW = {"contradiction": "contradiction", "symmetric_unresolved": "symmetric_unresolved",
                    "one_sided": "pending_description_check", "model_candidate": "pending_description_check",
                    "residual": "pending_description_check", "aligned": "aligned"}
BRACKETED = re.compile(r"[（(【［\[]([^）)】］\]]*)[）)】］\]]")
NUMBER = re.compile(r"\d+(?:\.\d+)?")


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).open(encoding="utf-8") if line.strip()]


def write_new(path: Path, rows=None, text=None):
    if path.exists():
        raise FileExistsError(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    body = text if text is not None else "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows)
    path.write_text(body, encoding="utf-8", newline="\n")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def norm(text: str) -> str:
    return "".join(unicodedata.normalize("NFKC", text).split())


def parts(value: str) -> tuple[list, list]:
    text = norm(value)
    return sorted(p for p in BRACKETED.sub("", text).split("/") if p), [p for p in BRACKETED.findall(text) if p]


def subsequence(short: str, long: str) -> bool:
    chars = iter(long)
    return all(c in chars for c in short)


def same_numbers(a: str, b: str) -> bool:
    if not NUMBER.findall(a) or NUMBER.findall(a) != NUMBER.findall(b):
        return False
    *heads_a, tail_a = NUMBER.split(a)
    *heads_b, tail_b = NUMBER.split(b)
    return (all(subsequence(x, y) or subsequence(y, x) for x, y in zip(heads_a, heads_b))
            and (tail_a == tail_b or not tail_a or not tail_b))


def residual(rakuten: str, au: str) -> list | None:
    """None unless the two values share a core; otherwise the parts left over on each side, as [side, text]."""
    (rc, ra), (ac, aa) = parts(rakuten), parts(au)
    if not rc or not ac:
        return None
    if rc == ac or (len(rc) == len(ac) == 1 and same_numbers(rc[0], ac[0])):
        left_r, left_a = [], []
    elif len(rc) == 1 and rc[0] in ac:
        left_r, left_a = [], [p for p in ac if p != rc[0]]
    elif len(ac) == 1 and ac[0] in rc:
        left_r, left_a = [p for p in rc if p != ac[0]], []
    else:
        return None
    return ([["rakuten", p] for p in left_r + [p for p in ra if p not in aa]]
            + [["au", p] for p in left_a + [p for p in aa if p not in ra]])


def load(run: Path):
    """Fixed pairs with their Rakuten options (axis_key, label, value) and AU options (axis, value)."""
    contexts = {c["dossier_id"]: c for c in read_jsonl(run / "inputs" / "products.jsonl")}
    cases = read_jsonl(run / "inputs" / "cases.jsonl")
    rakuten = {}
    for case in cases:
        for a in case["rakuten_selected"]["axes"]:
            for v in a["family_values"]:
                rakuten.setdefault(case["dossier_id"], {}).setdefault((a["axis_key"], v), a["axis_label"])
    rakuten = {d: [[k, label, v] for (k, v), label in opts.items()] for d, opts in rakuten.items()}
    au = {d: [list(o) for o in dict.fromkeys((a["axis_name"], a["value"]) for row in c["au_rows"] for a in row["axes"])]
          for d, c in contexts.items()}
    return contexts, cases, rakuten, au


def similarity(args):
    import torch
    from huggingface_hub import snapshot_download
    from transformers import AutoModelForSequenceClassification, AutoTokenizer
    torch.set_num_threads(args.threads)
    run, out = ROOT / args.run, ROOT / args.out
    _, _, rakuten, au = load(run)
    local = Path(snapshot_download(MODEL[0], revision=MODEL[1]))
    tok = AutoTokenizer.from_pretrained(local)
    model = AutoModelForSequenceClassification.from_pretrained(local).eval()

    def scores(query, docs):
        enc = tok([query] * len(docs), docs, padding=True, truncation=True, max_length=512, return_tensors="pt")
        with torch.inference_mode():
            return model(**enc).logits[:, 0].float().tolist()

    start, rows = time.perf_counter(), []
    for d in sorted(rakuten):
        r_text = [f"{label}: {v}" for _, label, v in rakuten[d]]
        a_text = [f"{n}: {v}" for n, v in au[d]]
        rows.append({"dossier_id": d, "rakuten": rakuten[d], "au": au[d],
                     "forward": [scores(q, a_text) for q in r_text], "reverse": [scores(q, r_text) for q in a_text]})
    seconds = time.perf_counter() - start
    write_new(out / "similarities.jsonl", rows)
    write_new(out / "similarities.json", text=json.dumps({
        "model": MODEL[0], "revision": MODEL[1], "threads": args.threads, "seconds": seconds,
        "pairs_scored": sum(2 * len(r["rakuten"]) * len(r["au"]) for r in rows),
        "weights_sha256": {p.name: sha256(p) for p in sorted(local.glob("*.safetensors"))},
        "inputs_sha256": {n: sha256(run / "inputs" / n) for n in ("products.jsonl", "cases.jsonl")},
        "similarities_sha256": sha256(out / "similarities.jsonl"), "code_sha256": sha256(Path(__file__)),
        "torch": torch.__version__, "python": platform.python_version(),
        "finished_at_utc": datetime.now(timezone.utc).isoformat()}, ensure_ascii=False, indent=2) + "\n")
    print(f"{len(rows)} pairs, {seconds:.0f}s")


def value_pairs(entry) -> pd.DataFrame:
    """Steps 1-2: each Rakuten option with its best AU option, paired when the match is mutual."""
    rak = pd.DataFrame(entry["rakuten"], columns=["axis_key", "axis_label", "value"])
    au = pd.DataFrame(entry["au"], columns=["au_axis", "au_value"])
    same = np.array([norm(v) for v in rak["value"]])[:, None] == np.array([norm(v) for v in au["au_value"]])[None, :]
    forward = np.where(same, np.inf, np.array(entry["forward"], dtype=float).reshape(same.shape))
    reverse = np.where(same.T, np.inf, np.array(entry["reverse"], dtype=float).reshape(same.T.shape))
    best_au, best_rak = forward.argmax(axis=1), reverse.argmax(axis=1)
    table = pd.concat([rak, au.iloc[best_au].reset_index(drop=True)], axis=1)
    table["paired"] = best_rak[best_au] == np.arange(len(rak))
    table["matched_by"] = np.where(same[np.arange(len(rak)), best_au], "identical", "model")
    return table


def axis_pairs(table: pd.DataFrame, au_options) -> tuple[dict, list]:
    """Step 3: {Rakuten axis_key: AU axis} for symmetric axes, and the varying AU-only axes."""
    paired = table[table["paired"]]
    links = pd.crosstab(paired["axis_key"], paired["au_axis"]) > 0
    alone = links & (links.sum(axis=1) == 1).to_numpy()[:, None] & (links.sum(axis=0) == 1).to_numpy()[None, :]
    symmetric = alone.idxmax(axis=1)[alone.any(axis=1)].to_dict()
    values = pd.DataFrame(au_options, columns=["au_axis", "au_value"]).groupby("au_axis")["au_value"].nunique()
    au_only = sorted(values[(values > 1) & ~values.index.isin(list(symmetric.values()))].index)
    return symmetric, au_only


def conditions(case, context, table, symmetric, au_only) -> pd.DataFrame:
    """Step 4: one status per (AU row, condition); AU-only axes count as one-sided conditions."""
    rows = pd.DataFrame([{a["axis_name"]: a["value"] for a in r["axes"]} for r in context["au_rows"]],
                        index=[r["row_key"] for r in context["au_rows"]])
    paired = table[table["paired"] & (table["au_axis"] == table["axis_key"].map(symmetric))]
    mapped = {(k, v): (a, m) for k, v, a, m in paired[["axis_key", "value", "au_value", "matched_by"]].itertuples(index=False)}
    out = []
    for axis in case["rakuten_selected"]["axes"]:
        au_axis = symmetric.get(axis["axis_key"])
        au_value, matched_by = mapped.get((axis["axis_key"], axis["value"]), (None, None))
        row_values = rows.get(au_axis, pd.Series(None, index=rows.index, dtype=object)).to_numpy()
        status = np.select([np.full(len(rows), au_axis is None), np.full(len(rows), au_value is None),
                            row_values != au_value, np.full(len(rows), matched_by == "model")],
                           ["one_sided", "symmetric_unresolved", "contradiction", "model_candidate"], "aligned")
        left = [None] * len(rows)
        family = {norm(v) for v in axis["family_values"]}
        options = {v for v in row_values if isinstance(v, str)} if au_axis is not None else set()
        if norm(axis["value"]) not in {norm(v) for v in options}:
            options = {v for v in options if norm(v) not in family}
            cores = {v: residual(axis["value"], v) for v in options}
            if any(c is not None for c in cores.values()):
                left = [cores.get(v) if isinstance(v, str) else None for v in row_values]
                status = np.array(["contradiction" if c is None else "residual" if c else "aligned" for c in left])
        out.append(pd.DataFrame({"row_key": rows.index, "kind": "rakuten", "axis_key": axis["axis_key"],
                                 "axis_label": axis["axis_label"], "value": axis["value"], "au_axis": au_axis,
                                 "au_value": row_values, "status": status, "residual": left}))
    out += [pd.DataFrame({"row_key": rows.index, "kind": "au_only", "axis_key": None, "axis_label": n, "value": None,
                          "au_axis": n, "au_value": rows[n].to_numpy(), "status": "one_sided", "residual": None})
            for n in au_only]
    return pd.concat(out, ignore_index=True)


def row_states(conds: pd.DataFrame) -> pd.Series:
    rank = conds["status"].map(CONDITION_TO_ROW).map(ROW_STATES.index)
    return rank.groupby(conds["row_key"], sort=False).min().map(dict(enumerate(ROW_STATES)))


def decide(states: pd.Series) -> tuple[str, str | None, str]:
    counts = states.value_counts()
    single = counts.get("aligned", 0) == 1 and counts.get("contradiction", 0) == len(states) - 1
    reason = ("all_conditions_aligned_on_one_row" if single else
              "several_rows_aligned" if counts.get("aligned", 0) > 1 else
              "contradiction_on_every_row" if counts.get("contradiction", 0) == len(states) else
              "pending_description_check" if counts.get("pending_description_check", 0) else
              "symmetric_condition_unresolved")
    return ("matched" if single else "unmatched"), (states.index[states == "aligned"][0] if single else None), reason


def tables(out: Path):
    sims = {s["dossier_id"]: s for s in read_jsonl(out / "similarities.jsonl")}
    pairs = {d: value_pairs(s) for d, s in sims.items()}
    axes = {d: axis_pairs(pairs[d], sims[d]["au"]) for d in sims}
    return pairs, axes


def align(args):
    run, out = ROOT / args.run, ROOT / args.out
    meta = json.loads((out / "similarities.json").read_text(encoding="utf-8"))
    if meta["similarities_sha256"] != sha256(out / "similarities.jsonl"):
        raise RuntimeError("Similarities changed after they were saved")
    contexts, cases, _, _ = load(run)
    pairs, axes = tables(out)
    rule = {r["case_id"]: r["binary"] for r in read_jsonl(run / "predictions" / "A-full_spec_notice.jsonl")}
    decisions, handoff, diff = [], [], []
    for case in cases:
        d, sel = case["dossier_id"], case["rakuten_selected"]
        conds = conditions(case, contexts[d], pairs[d], *axes[d])
        states = row_states(conds)
        decision, top, reason = decide(states)
        decisions.append({"case_id": case["case_id"], "dossier_id": d, "decision": decision, "top_row_key": top,
                          "reason": reason, "row_states": states.value_counts().to_dict()})
        for row_key in states.index[states == "pending_description_check"]:
            mine = conds[conds["row_key"] == row_key]
            handoff.append({"case_id": case["case_id"], "dossier_id": d, "au_product_id": case["au_product_id"],
                            "au_row_key": row_key,
                            "au_product_source": {k: contexts[d]["au_product"][k] for k in ("raw_file", "sha256")},
                            "rakuten_sku": {k: sel[k] for k in ("source_sku_key", "sku_record_key", "variant_id", "url",
                                                                "raw_file", "sha256")},
                            "conditions": mine.drop(columns="row_key").to_dict("records"),
                            "rakuten_axes": {a["axis_key"]: {"family_values": a["family_values"], "value_span": a["value_span"]}
                                             for a in sel["axes"]}})
        rb = rule[case["case_id"]]
        if (rb["decision"], rb.get("top_row_key")) != (decision, top):
            diff.append({"case_id": case["case_id"], "rule": [rb["decision"], rb.get("top_row_key")],
                         "rule_reasons": rb["reason_codes"], "alignment": [decision, top], "alignment_reason": reason})
    dest = out / "align"
    write_new(dest / "value_pairs.jsonl", [{"dossier_id": d, **r} for d, t in sorted(pairs.items()) for r in t.to_dict("records")])
    write_new(dest / "axes.jsonl", [{"dossier_id": d, "symmetric": s, "au_only": a} for d, (s, a) in sorted(axes.items())])
    for name, rows in (("decisions.jsonl", decisions), ("handoff.jsonl", handoff), ("diff-vs-rule-v10.jsonl", diff)):
        write_new(dest / name, rows)
    summary = {"created_at_utc": datetime.now(timezone.utc).isoformat(), "labels_read": False,
               "label_informed_changes": args.labels_seen, "similarities_sha256": meta["similarities_sha256"], "code_sha256": sha256(Path(__file__)),
               "decisions": dict(Counter(x["decision"] for x in decisions)),
               "decision_reasons": dict(Counter(x["reason"] for x in decisions)),
               "handoff_rows": len(handoff),
               "handoff_conditions": dict(Counter(f"{c['kind']}:{c['status']}" for h in handoff for c in h["conditions"]
                                                  if c["status"] != "aligned")),
               "diff_vs_rule": dict(Counter(f"{x['rule'][0]}->{x['alignment'][0]}" for x in diff)),
               "outputs_sha256": {p.name: sha256(p) for p in sorted(dest.glob("*.jsonl"))}}
    write_new(dest / "summary.json", text=json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: summary[k] for k in ("decisions", "decision_reasons", "handoff_rows", "handoff_conditions", "diff_vs_rule")},
                     ensure_ascii=False, indent=1))


def score(args):
    run, out = ROOT / args.run, ROOT / args.out
    dest = out / "align"
    summary = json.loads((dest / "summary.json").read_text(encoding="utf-8"))
    changed = [n for n, digest in summary["outputs_sha256"].items() if sha256(dest / n) != digest]
    if changed:
        raise RuntimeError(f"Prediction files changed before scoring: {changed}")
    contexts, cases, _, _ = load(run)
    pairs, axes = tables(out)
    reference = json.loads((ROOT / args.axis_reference).read_text(encoding="utf-8"))["pairs"]
    axis_result = Counter()
    for d, t in pairs.items():
        for key, label in t[["axis_key", "axis_label"]].drop_duplicates().itertuples(index=False):
            want, got = reference[d][label]["au_axis"], axes[d][0].get(key)
            axis_result[("symmetric" if want else "one_sided") + ("_correct" if want == got else "_wrong")] += 1
    gold = {g["case_id"]: g for g in read_jsonl(ROOT / LABELS)}
    adopted = Counter((x["decision"], gold[x["case_id"]]["decision"] if x["case_id"] in gold else None)
                      for x in read_jsonl(dest / "decisions.jsonl"))
    cond, competitors = Counter(), Counter()
    for case in cases:
        g = gold.get(case["case_id"])
        if g is None or g["decision"] != "matched":
            continue
        d = case["dossier_id"]
        conds = conditions(case, contexts[d], pairs[d], *axes[d])
        states = row_states(conds)
        true = conds[conds["row_key"].isin(g["matching_au_row_keys"]) & (conds["kind"] == "rakuten")]
        side = true["axis_label"].map(lambda label: "symmetric" if reference[d][label]["au_axis"] else "one_sided")
        cond.update(side + "_" + true["status"])
        competitors["cases"] += 1
        competitors["all_competitors_contradicted"] += bool((states[~states.index.isin(g["matching_au_row_keys"])]
                                                             == "contradiction").all())
    result = {"axis_reference_sha256": sha256(ROOT / args.axis_reference), "labels_sha256": sha256(ROOT / LABELS),
              "axes": dict(axis_result), "decision_vs_label": {f"{a}/{b}": n for (a, b), n in sorted(adopted.items(), key=str)},
              "labelled_row_conditions": dict(cond), "competitors": dict(competitors),
              "note": "axis reference is Claude's own reading (not blind); labels are Luna machine labels"}
    write_new(dest / "score.json", text=json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=1))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", choices=["similarity", "align", "score"])
    parser.add_argument("--run", default=".lab-output/sku-gate-tasks-20261010-v10")
    parser.add_argument("--out", default=".lab-output/sku-align-20261011-v5/legacy")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--labels-seen", default=None,
                        help="align only: describe changes made after reading labels or references of earlier outputs")
    parser.add_argument("--axis-reference", default=".lab-output/sku-align-20261010-v1/reference/axis-correspondence-legacy.json")
    args = parser.parse_args()
    {"similarity": similarity, "align": align, "score": score}[args.step](args)


if __name__ == "__main__":
    main()
