#!/usr/bin/env python3
"""Assemble a frozen source-only DEV10 body-invariant run; never score or infer."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import sys
import traceback
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
COHORT = ROOT / ".lab-output/sku-next-body-invariant-dev-20261013-v1"
PROOF = ROOT / ".lab-output/sku-next-body-invariant-literal-proofs-20261013-v1"
PRIOR_DEV30 = ROOT / ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/membership.jsonl"
PRIOR_COORDINATE_DEV20 = ROOT / ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/membership.jsonl"
EXPECTED_CASES, EXPECTED_PRODUCTS, EXPECTED_ROWS, EXPECTED_TASKS = 10, 5, 110, 452
VARIANTS = {"body-invariant-v3", "literal-only"}

sys.path.insert(0, str(ROOT / "experiments/sku-matching"))
import evaluate_dev_source_bound_whole_sku_gate_v1 as EVAL  # noqa: E402
import sku_body_invariant_choice_v3 as BODY  # noqa: E402
import sku_directional_choice_nli_v1 as NLI  # noqa: E402


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def pin(path: Path) -> dict[str, Any]:
    return {"bytes": path.stat().st_size, "sha256": sha_file(path)}


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def read_rows(path: Path) -> list[dict[str, Any]]:
    return NLI.read_rows(Path(path))


def write_json(path: Path, value: dict[str, Any]) -> None:
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def write_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    with Path(path).open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(BODY.canon(row).decode("utf-8") + "\n")


def relpath(path: Path) -> str:
    return Path(path).resolve().relative_to(ROOT).as_posix()


def verify_dev10_cohort(prepared_dir: Path) -> tuple[list[dict], list[dict], list[dict], list[dict], list[dict]]:
    manifest = read_json(COHORT / "manifest.json")
    policy = read_json(COHORT / "selection-policy.json")
    plan = read_json(COHORT / "selection-plan.json")
    expected_hashes = manifest.get("outputs_sha256", {})
    for name, digest in expected_hashes.items():
        path = COHORT / name
        if not path.is_file() or sha_file(path) != digest:
            raise ValueError(f"blind DEV10 source input SHA differs: {name}")
    if (manifest.get("schema_version") != "sku-next-body-invariant-dev-source-v1"
            or manifest.get("split") != "dev" or manifest.get("independent_test") is not False
            or manifest.get("selected_case_count") != EXPECTED_CASES
            or manifest.get("selected_product_count") != EXPECTED_PRODUCTS
            or manifest.get("row_count") != EXPECTED_ROWS
            or manifest.get("task_count") != EXPECTED_TASKS
            or manifest.get("labels_read") is not False or manifest.get("predictions_read") is not False
            or manifest.get("test_split_read") is not False or manifest.get("scores_created") is not False):
        raise ValueError("source DEV10 manifest does not match its frozen blind cohort")
    if (policy.get("schema_version") != "sku-next-body-invariant-dev-policy-v1"
            or policy.get("dataset") != manifest.get("dataset")
            or policy.get("labels_read") is not False or policy.get("predictions_read") is not False
            or policy.get("task_details_read") is not False or policy.get("test_split_read") is not False
            or sha_file(COHORT / "selection-policy.json") != manifest.get("selection_policy_sha256")
            or sha_file(COHORT / "selection-plan.json") != manifest.get("selection_plan_sha256")
            or plan.get("policy_sha256") != manifest.get("selection_policy_sha256")):
        raise ValueError("DEV10 identity-only selection policy/plan pins differ")
    members = read_rows(COHORT / "membership.jsonl")
    cases = read_rows(COHORT / "case-plans.jsonl")
    rows = read_rows(COHORT / "row-plans.jsonl")
    tasks = read_rows(COHORT / "tasks.jsonl")
    requests = read_rows(COHORT / "requests.jsonl")
    if (len(members) != EXPECTED_CASES or len(cases) != EXPECTED_CASES
            or len(rows) != EXPECTED_ROWS or len(tasks) != EXPECTED_TASKS
            or len(requests) != 270
            or len({r["case_id"] for r in members}) != EXPECTED_CASES
            or len({r["au_product_id"] for r in members}) != EXPECTED_PRODUCTS):
        raise ValueError("DEV10 exact membership/case/product/row/task/request population differs")
    if sha_file(COHORT / "membership.jsonl") != "b0bd4693ac02e1041ab52246fdcb2f2a4fbe9533022aaeb6bc7915d0652d7cea2":
        raise ValueError("frozen DEV10 membership SHA differs")
    # Disjointness uses identity-only provenance and source membership bytes.
    excluded_hashes = {sha_file(PRIOR_DEV30), sha_file(PRIOR_COORDINATE_DEV20)}
    if excluded_hashes != set(plan.get("excluded_membership_sha256", [])):
        raise ValueError("DEV10 exclusion membership hashes differ from the policy plan")
    excluded_products = {r.get("au_product_id") for path in (PRIOR_DEV30, PRIOR_COORDINATE_DEV20)
                         for r in read_rows(path)}
    if {r.get("au_product_id") for r in members} & excluded_products:
        raise ValueError("DEV10 product membership overlaps prior DEV cohorts")
    return members, cases, rows, tasks, requests


def load_complete_bindings(tasks: list[dict], prepared_dir: Path) -> list[dict]:
    bindings = read_rows(prepared_dir / "validation-bindings.jsonl")
    task_ids = [row["task_id"] for row in tasks]
    binding_ids = [(row.get("task_binding") or {}).get("task_id") for row in bindings]
    if (len(bindings) != EXPECTED_TASKS or len(set(binding_ids)) != EXPECTED_TASKS
            or set(binding_ids) != set(task_ids)):
        raise ValueError("prepared body source bindings must cover every DEV10 task exactly once")
    return bindings


def validate_snapshot(raw_path: Path, receipt_path: Path, pair_ids: set[str]) -> tuple[list[dict], list[dict], dict]:
    receipt = read_json(receipt_path)
    if (receipt.get("schema_version") != "sku-next-body-invariant-dev10-literal-snapshot-v1"
            or receipt.get("status") != "complete_firstpass_snapshot_frozen"
            or receipt.get("all_predictions_frozen") is not True
            or receipt.get("labels_read") is not False or receipt.get("test_labels_read") is not False
            or receipt.get("scores_created") is not False or receipt.get("production_adoption_allowed") is not False
            or receipt.get("prepared_pair_count") != len(pair_ids)
            or receipt.get("snapshot_path") != relpath(raw_path)):
        raise ValueError("body DEV10 literal snapshot receipt is incomplete or not bound to this prepared source")
    if pin(raw_path) != {"bytes": receipt.get("snapshot_bytes"), "sha256": receipt.get("snapshot_sha256")}:
        raise ValueError("body DEV10 immutable raw snapshot bytes/SHA differ from receipt")
    raw = read_rows(raw_path)
    response_ids = [r.get("pair_id") for r in raw]
    if (len(response_ids) != len(set(response_ids)) or not set(response_ids) <= pair_ids
            or receipt.get("response_count") != len(raw)
            or receipt.get("response_pair_ids_sha256") != BODY.sha_bytes(BODY.canon(sorted(response_ids)))):
        raise ValueError("literal snapshot has duplicate, foreign, or unreceipted pair outputs")
    missing_ids = pair_ids - set(response_ids)
    failures_path = ROOT / receipt.get("failure_ledger_path", "")
    if not failures_path.is_file() or failures_path.is_symlink():
        raise FileNotFoundError("body DEV10 failure ledger is required, including an empty one")
    if pin(failures_path) != {"bytes": receipt.get("failure_ledger_bytes"),
                              "sha256": receipt.get("failure_ledger_sha256")}:
        raise ValueError("body DEV10 failure ledger bytes/SHA differ from snapshot receipt")
    failures = read_rows(failures_path)
    fail_ids = [r.get("pair_id") for r in failures]
    if (len(fail_ids) != len(set(fail_ids)) or set(fail_ids) != missing_ids
            or any(r.get("status") != "missing_firstpass_response_unknown"
                   or r.get("model_judgment_recorded") is not False
                   or r.get("semantic_retry_performed") is not False for r in failures)):
        raise ValueError("missing literal model responses must be explicitly unknown without fabricated retry")
    return raw, failures, receipt


def adapt_source_validated_pair(response: dict, pair: dict, payload: dict,
                                source_body: dict, source_root: Path) -> tuple[dict, list[dict]]:
    validation = BODY.validate_source_response(response, pair, payload, source_body, source_root)
    # Keep every model-authored semantic field byte-value equivalent; append
    # only a count of source references that the unchanged validator checked.
    judgments = []
    for decision in response["decisions"]:
        copied = dict(decision)
        copied["citations_verified"] = (2 * len(decision.get("target_fact_indices", []))
                                        + len(decision.get("body_quote_refs", [])))
        judgments.append(copied)
    validated = {"pair_id": pair["pair_id"], "cache_key": pair["cache_key"],
        "judgments": judgments, "source_citations_verified": validation.get("source_citations_verified") is True,
        "semantic_truth_verified": False, "sourceproof_certified": False,
        "production_adoption_allowed": False,
        "validated_source_citation_count": len(validation.get("citations", []))}
    if len(judgments) != len(pair["option_values"]):
        raise ValueError("body source validator returned an incomplete whole-option vector")
    return validated, validation.get("citations", [])


def assemble(prepared_dir: Path, raw_path: Path, snapshot_receipt_path: Path,
             proof_dir: Path, source_root: Path, output_dir: Path) -> dict[str, Any]:
    members, cases, rows, tasks, _requests = verify_dev10_cohort(prepared_dir)
    prepared = read_json(prepared_dir / "manifest.json")
    if (prepared.get("schema_version") != BODY.PROTOCOL
            or prepared.get("task_count") != EXPECTED_TASKS
            or prepared.get("row_count") != EXPECTED_ROWS
            or prepared.get("prepared_pair_count") != 141
            or prepared.get("preparation_error_count") != 0
            or prepared.get("labels_read") is not False
            or prepared.get("predictions_read") is not False
            or prepared.get("model_inference_run") is not False
            or prepared.get("scores_created") is not False):
        raise ValueError("final body-invariant source-only preparation is not a blind 141-pair DEV10 freeze")
    prepared_pairs = read_rows(prepared_dir / "model-pairs-v3.jsonl")
    payloads = read_rows(prepared_dir / "model-payloads-v3.jsonl")
    source_bodies = read_rows(prepared_dir / "source-bodies.jsonl")
    pair_by_id = {r["pair_id"]: r for r in prepared_pairs}
    payload_by_id = {r["pair_id"]: r for r in payloads}
    body_by_sha = {r["document_sha256"]: r for r in source_bodies}
    if (len(pair_by_id) != 141 or len(payload_by_id) != 141 or len(body_by_sha) != 10
            or set(pair_by_id) != set(payload_by_id)):
        raise ValueError("body-invariant prepared pair/payload/document populations differ")
    raw, failures, snapshot_receipt = validate_snapshot(raw_path, snapshot_receipt_path, set(pair_by_id))
    bindings = load_complete_bindings(tasks, prepared_dir)
    proof_manifest = read_json(proof_dir / "manifest.json")
    proof_tasks = read_rows(proof_dir / "task-proof-states.jsonl")
    proof_receipts = read_rows(proof_dir / "task-source-verification.jsonl")
    if (proof_manifest.get("input_case_count") != EXPECTED_CASES
            or proof_manifest.get("input_row_count") != EXPECTED_ROWS
            or proof_manifest.get("input_task_count") != EXPECTED_TASKS
            or len(proof_tasks) != EXPECTED_TASKS or len(proof_receipts) != EXPECTED_TASKS
            or proof_manifest.get("labels_read") is not False
            or proof_manifest.get("predictions_read") is not False
            or proof_manifest.get("classification_or_scoring_run") is not False):
        raise ValueError("frozen body DEV10 independent literal proof population is incomplete or scored")
    output_dir = output_dir.resolve()
    out_rel = relpath(output_dir)
    if not out_rel.startswith(".lab-output/") or output_dir.exists():
        raise FileExistsError("assembly output must be a new .lab-output directory; no overwrite")
    output_dir.mkdir(parents=True)
    try:
        shutil.copyfile(raw_path, output_dir / "raw-literal-responses.jsonl")
        write_json(output_dir / "literal-snapshot-receipt.json", snapshot_receipt)
        write_rows(output_dir / "missing-response-failures.jsonl", failures)
        write_rows(output_dir / "canonical-validation-bindings.jsonl", bindings)
        validated_pairs, validation_report, citations = [], [], []
        for response in raw:
            pid = response.get("pair_id")
            pair, payload = pair_by_id[pid], payload_by_id[pid]
            target_sha = payload["context"]["target_document_sha256"]
            source_body = body_by_sha[target_sha]
            try:
                validated, verified_citations = adapt_source_validated_pair(
                    response, pair, payload, source_body, source_root)
                validated_pairs.append(validated)
                citations.extend(verified_citations)
                validation_report.append({"pair_id": pid, "status": "source_citations_verified",
                    "decision_count": len(validated["judgments"]),
                    "validated_source_citation_count": validated["validated_source_citation_count"]})
            except (KeyError, TypeError, ValueError, OSError) as exc:
                validation_report.append({"pair_id": pid, "status": "invalid_unknown", "error": str(exc)})
        write_rows(output_dir / "source-validation-report.jsonl", validation_report)
        write_rows(output_dir / "validated-pairs-for-eval.jsonl", validated_pairs)
        write_rows(output_dir / "verified-citation-metadata.jsonl", citations)
        gates = {}
        for variant in ("body-invariant-v3", "literal-only"):
            variant_pairs = validated_pairs if variant == "body-invariant-v3" else []
            resolutions = EVAL.build_choice_nli_task_resolutions(
                tasks, bindings, variant_pairs, proof_tasks, proof_receipts)
            internal = "choice_nli_full" if variant == "body-invariant-v3" else "baseline_literal_overlay"
            gate = EVAL.finish_whole_sku_gate(internal, cases, rows, tasks, resolutions)
            gate["variant"] = variant
            gate["assembly_method"] = ("source_validated_body_invariant_model_plus_literal_proofs"
                if variant == "body-invariant-v3" else "independent_literal_proofs_only_unknown_elsewhere")
            gate["production_adoption_allowed"] = False
            if (len(resolutions) != EXPECTED_TASKS or len(gate["rows"]) != EXPECTED_ROWS
                    or len(gate["decisions"]) != EXPECTED_CASES):
                raise ValueError(f"frozen whole-SKU EVAL output coverage differs: {variant}")
            variant_dir = output_dir / variant
            variant_dir.mkdir()
            write_rows(variant_dir / "task-resolutions.jsonl", resolutions)
            write_rows(variant_dir / "all-row-results.jsonl", gate["rows"])
            write_rows(variant_dir / "case-decisions.jsonl", gate["decisions"])
            source_hashes = {"raw_literal_responses": sha_file(raw_path),
                "prepared_manifest": sha_file(prepared_dir / "manifest.json"),
                "validation_bindings": sha_file(prepared_dir / "validation-bindings.jsonl"),
                "literal_proof_manifest": sha_file(proof_dir / "manifest.json"),
                "tasks": sha_file(COHORT / "tasks.jsonl"), "case_plans": sha_file(COHORT / "case-plans.jsonl"),
                "row_plans": sha_file(COHORT / "row-plans.jsonl")}
            gm = EVAL.eval_manifest(internal, source_hashes,
                                    sha_file(variant_dir / "task-resolutions.jsonl"))
            gm.update({"variant": variant, "assembly_method": gate["assembly_method"],
                "source_split": "dev", "independent_test": False,
                "case_count": EXPECTED_CASES, "product_count": EXPECTED_PRODUCTS,
                "row_count": EXPECTED_ROWS, "task_count": EXPECTED_TASKS,
                "labels_read": False, "test_labels_read": False,
                "semantic_truth_verified": False, "sourceproof_certified": False,
                "production_adoption_allowed": False})
            write_json(variant_dir / "gate-manifest.json", gm)
            gates[variant] = {"task_state_counts": gate["task_state_counts"],
                "row_state_counts": gate["row_state_counts"], "decision_counts": gate["decision_counts"]}
        write_json(output_dir / "assembly-receipt.json", {
            "schema_version": "sku-next-body-invariant-dev10-assembly-v1",
            "status": "complete_both_whole_gate_variants_frozen", "variants": gates,
            "case_count": EXPECTED_CASES, "product_count": EXPECTED_PRODUCTS,
            "row_count": EXPECTED_ROWS, "task_count": EXPECTED_TASKS,
            "prepared_pair_count": len(pair_by_id), "raw_response_count": len(raw),
            "missing_response_count": len(failures), "source_validated_pair_count": len(validated_pairs),
            "invalid_or_missing_response_handling": "unknown_no_synthetic_semantics_or_model_fallback",
            "semantic_decisions_edited": False, "source_citations_verified_only": True,
            "semantic_truth_verified": False, "sourceproof_certified": False,
            "labels_read": False, "test_labels_read": False, "scores_created": False,
            "production_adoption_allowed": False})
        files = [p for p in output_dir.rglob("*") if p.is_file() and p.name != "assembly-output-inventory.json"]
        write_json(output_dir / "assembly-output-inventory.json", {"schema_version": "body-dev10-output-inventory-v1",
            "files": {p.relative_to(output_dir).as_posix(): pin(p) for p in sorted(files)},
            "labels_read": False, "scores_created": False})
        return read_json(output_dir / "assembly-receipt.json")
    except Exception as exc:
        write_json(output_dir / "assembly-failure.json", {"schema_version": "body-dev10-assembly-failure-v1",
            "error_type": type(exc).__name__, "error": str(exc), "traceback": traceback.format_exc(),
            "partial_outputs_preserved": True, "labels_read": False, "scores_created": False})
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared-dir", type=Path, required=True)
    parser.add_argument("--raw-responses", type=Path, required=True)
    parser.add_argument("--snapshot-receipt", type=Path, required=True)
    parser.add_argument("--proof-dir", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, default=BODY.DEFAULT_SOURCE)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    result = assemble(args.prepared_dir, args.raw_responses, args.snapshot_receipt,
                      args.proof_dir, args.source_root, args.output_dir)
    print(json.dumps({"status": result["status"], "variants": sorted(result["variants"]),
                      "labels_read": False, "scores_created": False}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
