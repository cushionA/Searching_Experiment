# DEV20 source and first-pass status

- Split: dev; model inference and grading are not complete in this source checkpoint.
- Pre-ML freeze: 202 files, SHA-256 `fd00b9bf05bb5c90d36439540a89a3350cc85d46a2690b2bd46d9e1c44167b2e`.
- First-pass raw snapshot: 186 actual pairs / 2467 whole-option decisions; expected 189 pairs / 2510 decisions.
- Missing pairs: 3. Packet 049's 151-byte foreign placeholder is retained without rewriting.
- Method exclusions v2: 8 pairs, before labels; source audits and metadata-alias disclosures are preserved. Disclosures for packets 028, 045, and 050 remain.
- Pending assembly v2 is still working through all 1,220 bindings. Final QA v3, grade freeze, selected score, and report are not part of this source-only preflight.
- No labels/gold were read and no score, accuracy, or performance claim is included.
