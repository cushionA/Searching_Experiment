#!/usr/bin/env python3
"""Prepare a reusable, root-gated full DEV20 checkpoint package.

Default mode reads only frozen source pins, exact raw source citations, and the
immutable completed-first-pass snapshot. It never reads live worker responses,
gates, freeze receipts, scores, or labels. The final ZIP requires a later root
ready receipt passed explicitly with --root-ready-receipt and --build.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
import zipfile
import zlib
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / ".lab-output/sku-next-dev-coordinate-full-checkpoint-build-20261013-v1"
OUT = ROOT / "experiments/sku-matching/results/20261013-sku-coordinate-dev-checkpoint.zip"
EXEC = ROOT / ".lab-output/sku-next-dev-coordinate-execution-20261013-v1"
FREEZE = EXEC / "experiment-freeze.json"
SNAPSHOT = EXEC / "completed-firstpass-snapshot-v1"
SNAPSHOT_RECEIPT = SNAPSHOT / "snapshot-receipt.json"
METHOD_LEDGER_V1 = EXEC / "root-method-exclusions.json"
METHOD_LEDGER_V2 = EXEC / "root-method-exclusions-v2.json"
SOURCE_BASE = ROOT / ".lab-output/sku-next-dev-coordinate-refids-20261013-v1"
PROOF_BASE = ROOT / ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2"
SOURCE_ROOT = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source"
SOURCE_INDEX = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source-index.json"
CHECKS_DIRS = [
    ROOT / ".lab-output/sku-next-dev-coordinate-required-checks-20261013-v1",
    ROOT / ".lab-output/sku-next-dev-coordinate-required-checks-20261013-v2",
    ROOT / ".lab-output/sku-next-dev-coordinate-required-checks-20261013-v3",
    ROOT / ".lab-output/sku-next-dev-coordinate-required-checks-20261013-v4",
]
ROOT_READY_SCHEMA = "sku-next-dev-coordinate-full-checkpoint-root-ready-v1"
AGGREGATE_SCORE_PATH = ".lab-output/sku-next-dev-coordinate-full-checkpoint-build-20261013-v1/dev20-aggregate-score.json"
EXPECTED_PREML_SHA = "fd00b9bf05bb5c90d36439540a89a3350cc85d46a2690b2bd46d9e1c44167b2e"
EXPECTED_SOURCE_NLI_V3_SHA = "681026e353b595644d66631afcd7f324ee237e973b584c3f7090795f9705c6ec"
EXPECTED_PROOF_FUNCTION_SHA = "ef00e3eae0f985f8293a6369fc79311d82118b33c7cfa7c5a44d5b74f11d47e1"
EXPECTED_SNAPSHOT_RECEIPT_SHA = "0d82142cba281571c0e6e3d4ae95252ad664022e90b944a411c33d7a9c54fa1f"
EXPECTED_SNAPSHOT_SHA = "f9a5d1551e893556992d259ed0be5e72faad3d483e74d0bc9427e3323d1c25cb"
EXPECTED_METHOD_V2_SHA = "601340089b5c0a7a809affc1f24aac8a9641196520d51eb1f65667401d7771bf"
EXPECTED_PREML_PIN_COUNT = 202
EXPECTED_RAW_FILE_COUNT = 67
EXPECTED_RAW_PAIRS = 186
EXPECTED_RAW_OPTIONS = 2467
EXPECTED_MISSING_PAIRS = 3
ALLOWED_WORKER_RESPONSE_PROVENANCE = {
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/worker-responses/packet-050-serializer-metadata.txt",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/worker-responses/packet-038-original-serialization.py",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/worker-responses/packet-038-recovery-receipt.txt",
}

EXTERNAL_ARCHIVES = [
    {"name": "full-reference-archive-v2", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261011-sku-independent-real-eval-v2.zip", "sha256": "6f65d988222c79c758614592340ba28565a51fa8891317724ba354c5fc38b457", "bundled": False, "members_opened": False},
    {"name": "full-reference-archive-v3", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261012-sku-independent-real-eval-v3.zip", "sha256": "52f6faa51127a9c12250a3cdb5eb3d1818a36461a8c09323e481748aeed1f37b", "bundled": False, "members_opened": False},
    {"name": "label-free-token-source-inputs-v2-v3", "path": ".lab-output/sku-claude-dev-input-share-20261012-v1/20261012-sku-independent-real-eval-v2-v3-token-inputs.zip", "sha256": "db2815a3d5c726e45f996ad07e73cdcf1cdff0610de53ad84af8a4a0a880488f", "bundled": False, "members_opened": False},
]
STATIC_EXECUTION_FILES = [
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/root-classification-go.json",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/dispatch-inventory.json",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/bounded-dispatch-and-serialization-supplement.json",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/firstpass-snapshot-receipt-template.json",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/method-exclusion-ledger-template.json",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assembler-draft-preservation.json",
]
HISTORY_REPORTS = [
    ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/source-only-report.json",
    ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/source-only-report-v2.json",
    ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/source-only-report-v3.json",
]
HISTORY_ASSEMBLERS = [
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_coordinate_refids_dev20.pre-contextless-bindings.py",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_coordinate_refids_dev20.pre-method-exclusions.py",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_coordinate_refids_dev20.pre-packet-041-exclusions.py",
]
FORBIDDEN_PARTS = {".deps", "models", "model", "weights", "secrets", "credentials", ".venv", "venv", "labels", "labels-token", "gold", "truth", "answers", "answer-shards", "predictions", "__pycache__"}
FORBIDDEN_SUFFIXES = {".zip", ".safetensors", ".pt", ".pth", ".ckpt", ".bin", ".env", ".pyc", ".pyo"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe(rel: str, *, method_audit: bool = False) -> bool:
    p = Path(rel)
    if p.is_absolute() or ".." in p.parts or p.suffix.lower() in FORBIDDEN_SUFFIXES:
        return False
    if {x.lower() for x in p.parts} & FORBIDDEN_PARTS:
        return False
    if p.name.lower().startswith(("answer-", "label-", "gold-")):
        return False
    if "worker-responses" in p.parts:
        return method_audit and p.name.endswith("-method-audit.json")
    return True


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object in {path}")
    return value


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            obj = json.loads(line)
            if not isinstance(obj, dict):
                raise ValueError(f"expected JSON object in {path}")
            rows.append(obj)
    return rows


def parse_refs(files: dict[str, Path]) -> dict[str, dict[str, Any]]:
    refs: dict[str, dict[str, Any]] = {}
    for arc, path in files.items():
        if not arc.endswith((".json", ".jsonl")) or path.stat().st_size > 10_000_000:
            continue
        data = path.read_bytes()
        lines = data.splitlines() if arc.endswith(".jsonl") else [data]
        for line_no, line in enumerate(lines, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            stack = [obj]
            while stack:
                value = stack.pop()
                if isinstance(value, dict):
                    raw, expected = value.get("raw_file"), value.get("sha256")
                    if isinstance(raw, str) and isinstance(expected, str) and len(expected) == 64:
                        raw = raw.replace("\\", "/")
                        entry = refs.setdefault(raw, {"sha256": expected, "origins": []})
                        if entry["sha256"] != expected:
                            entry.setdefault("conflicts", []).append({"sha256": expected, "file": arc, "line": line_no})
                        entry["origins"].append({"file": arc, "line": line_no})
                    stack.extend(value.values())
                elif isinstance(value, list):
                    stack.extend(value)
    return refs


def preml_receipt() -> dict[str, Any]:
    if not FREEZE.is_file() or sha256(FREEZE) != EXPECTED_PREML_SHA:
        raise SystemExit("pre-ML freeze missing or changed")
    receipt = read_json(FREEZE)
    pins = receipt.get("frozen_files")
    if not isinstance(pins, dict) or len(pins) != EXPECTED_PREML_PIN_COUNT:
        raise SystemExit("pre-ML pin inventory does not contain exactly 202 files")
    return receipt


def gather_source() -> tuple[dict[str, Path], list[dict[str, Any]], list[str], dict[str, Any]]:
    freeze = preml_receipt()
    frozen_pins = freeze["frozen_files"]
    files: dict[str, Path] = {}
    problems: list[str] = []
    method_audit_paths: set[str] = set()

    def add(path: Path, rel: str | None = None, *, method_audit: bool = False, required: bool = True) -> None:
        archive_path = rel or path.relative_to(ROOT).as_posix()
        if not safe(archive_path, method_audit=method_audit):
            problems.append(f"unsafe-member:{archive_path}")
            return
        if not path.is_file() or path.is_symlink():
            if required:
                problems.append(f"missing-member:{archive_path}")
            return
        if archive_path in files and files[archive_path] != path:
            problems.append(f"duplicate-member-source:{archive_path}")
            return
        files[archive_path] = path

    frozen_files: dict[str, Path] = {}
    for rel, pin in sorted(frozen_pins.items()):
        # Never inspect live worker-response files. Only exact immutable snapshot paths are included later.
        if "worker-responses" in Path(rel).parts:
            problems.append(f"live-response-listed-in-preml-freeze:{rel}")
            continue
        path = ROOT / rel
        if not safe(rel) or not path.is_file() or path.is_symlink():
            problems.append(f"invalid-frozen-source:{rel}")
            continue
        if type(pin.get("bytes")) is not int or path.stat().st_size != pin["bytes"] or sha256(path) != pin.get("sha256"):
            problems.append(f"preml-pin-mismatch:{rel}")
            continue
        frozen_files[rel] = path
        add(path, rel)
    add(FREEZE)
    if len(frozen_files) != EXPECTED_PREML_PIN_COUNT:
        problems.append("preml-frozen-file-count-not-202")

    # Explicit source and assembly history files. These are limited files, not a recursive execution scan.
    for rel in STATIC_EXECUTION_FILES + HISTORY_REPORTS + HISTORY_ASSEMBLERS:
        path = ROOT / rel
        add(path, rel)
    add(METHOD_LEDGER_V1)
    add(METHOD_LEDGER_V2)
    if not METHOD_LEDGER_V2.is_file() or sha256(METHOD_LEDGER_V2) != EXPECTED_METHOD_V2_SHA:
        problems.append("method-exclusions-v2-sha-mismatch")
    if not SOURCE_INDEX.is_file():
        problems.append("source-index-missing")
    else:
        add(SOURCE_INDEX)
    if not CHECKS_DIRS[0].is_dir():
        problems.append("required-checks-v1-missing")
    for checks_dir in CHECKS_DIRS:
        if checks_dir.is_dir():
            for path in sorted(checks_dir.rglob("*")):
                if path.is_file() and not path.is_symlink():
                    add(path)

    # Validate the preserved assembler drafts against the code-history receipt.
    preservation_path = EXEC / "assembler-draft-preservation.json"
    if preservation_path.is_file():
        preservation = read_json(preservation_path)
        if preservation.get("preserved_as_code_history_only") is not True or preservation.get("used_for_assembly") is not False:
            problems.append("assembler-code-history-receipt-invalid")
        for draft in preservation.get("drafts", []):
            rel = draft.get("path")
            expected = draft.get("sha256")
            path = ROOT / rel if isinstance(rel, str) else ROOT / "__invalid__"
            if not path.is_file() or sha256(path) != expected:
                problems.append(f"assembler-history-sha-mismatch:{rel}")

    # Method-only audit receipts are explicitly cited by the frozen v2 method ledger.
    method_ledger = read_json(METHOD_LEDGER_V2)
    for source in method_ledger.get("sources", []):
        for path_key, sha_key in (("audit_receipt_path", "audit_receipt_sha256"),):
            rel, expected = source.get(path_key), source.get(sha_key)
            if not isinstance(rel, str) or not isinstance(expected, str):
                problems.append("malformed-method-audit-pin")
                continue
            method_audit_paths.add(rel)
            path = ROOT / rel
            if not path.is_file() or path.is_symlink() or sha256(path) != expected:
                problems.append(f"method-audit-pin-mismatch:{Path(rel).name}")
            else:
                add(path, rel, method_audit=True)
        original = source.get("original_audit_path")
        original_pin = source.get("original_audit_pin")
        if original is not None:
            if not isinstance(original, str) or not isinstance(original_pin, dict):
                problems.append("malformed-original-method-audit-pin")
                continue
            method_audit_paths.add(original)
            path = ROOT / original
            if (not path.is_file() or path.is_symlink() or path.stat().st_size != original_pin.get("bytes")
                    or sha256(path) != original_pin.get("sha256")):
                problems.append(f"original-method-audit-pin-mismatch:{Path(original).name}")
            else:
                add(path, original, method_audit=True)

    # Validate and include only the complete-firstpass snapshot, never live worker responses.
    snapshot_receipt = {}
    snapshot_files = sorted(p for p in SNAPSHOT.rglob("*") if p.is_file() and not p.is_symlink()) if SNAPSHOT.is_dir() else []
    if not SNAPSHOT.is_dir() or not SNAPSHOT_RECEIPT.is_file():
        problems.append("completed-firstpass-snapshot-missing")
    else:
        snapshot_receipt = read_json(SNAPSHOT_RECEIPT)
        if sha256(SNAPSHOT_RECEIPT) != EXPECTED_SNAPSHOT_RECEIPT_SHA:
            problems.append("firstpass-snapshot-receipt-sha-mismatch")
        if (snapshot_receipt.get("schema_version") != "sku-next-dev-coordinate-refids-firstpass-snapshot-v1"
                or snapshot_receipt.get("all_raw_outputs_frozen") is not True
                or snapshot_receipt.get("partial_worker_files_used") is not False
                or snapshot_receipt.get("labels_read") is not False
                or snapshot_receipt.get("test_labels_read") is not False
                or snapshot_receipt.get("raw_response_count") != EXPECTED_RAW_PAIRS
                or snapshot_receipt.get("unique_pair_count") != EXPECTED_RAW_PAIRS
                or snapshot_receipt.get("whole_option_count") != EXPECTED_RAW_OPTIONS
                or snapshot_receipt.get("expected_dispatch_pair_count") != 189
                or snapshot_receipt.get("expected_whole_option_count") != 2510
                or snapshot_receipt.get("missing_pair_count") != EXPECTED_MISSING_PAIRS
                or snapshot_receipt.get("failure_ledger_count") != EXPECTED_MISSING_PAIRS):
            problems.append("firstpass-snapshot-scope-or-count-mismatch")
        for path in snapshot_files:
            add(path)
        # Validate all 67 targets in the snapshot, not their original live response paths.
        raw_pins = snapshot_receipt.get("raw_first_written_file_pins", {})
        if not isinstance(raw_pins, dict) or len(raw_pins) != EXPECTED_RAW_FILE_COUNT:
            problems.append("firstpass-raw-file-pin-count-mismatch")
        for original, pin in raw_pins.items() if isinstance(raw_pins, dict) else []:
            target = pin.get("snapshot_path")
            if (not isinstance(target, str) or "worker-responses" in Path(target).parts
                    or "completed-firstpass-snapshot-v1" not in Path(target).parts):
                problems.append("invalid-firstpass-snapshot-target")
                continue
            target_path = ROOT / target
            if (not target_path.is_file() or target_path.is_symlink()
                    or target_path.stat().st_size != pin.get("bytes")
                    or sha256(target_path) != pin.get("sha256")):
                problems.append(f"firstpass-raw-snapshot-pin-mismatch:{Path(target).name}")
        combined_rel = snapshot_receipt.get("snapshot_path")
        if combined_rel != ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/completed-firstpass-snapshot-v1/all-firstpass-responses.jsonl":
            problems.append("firstpass-combined-snapshot-path-mismatch")
        else:
            combined = ROOT / combined_rel
            if not combined.is_file() or sha256(combined) != EXPECTED_SNAPSHOT_SHA or sha256(combined) != snapshot_receipt.get("raw_output_sha256"):
                problems.append("firstpass-combined-snapshot-sha-mismatch")
        failure_rel = snapshot_receipt.get("failure_ledger_path")
        failure = ROOT / failure_rel if isinstance(failure_rel, str) else ROOT / "__invalid__"
        if (not failure.is_file() or failure.stat().st_size != snapshot_receipt.get("failure_ledger_bytes")
                or sha256(failure) != snapshot_receipt.get("failure_ledger_sha256")):
            problems.append("firstpass-failure-ledger-pin-mismatch")
        if (snapshot_receipt.get("method_exclusion_ledger_path") != METHOD_LEDGER_V2.relative_to(ROOT).as_posix()
                or snapshot_receipt.get("method_exclusion_ledger_sha256") != EXPECTED_METHOD_V2_SHA
                or snapshot_receipt.get("method_exclusion_ledger_bytes") != METHOD_LEDGER_V2.stat().st_size):
            problems.append("firstpass-method-exclusion-ledger-pin-mismatch")
    if SNAPSHOT.is_dir() and (SNAPSHOT / "packet-049.jsonl").is_file():
        if (SNAPSHOT / "packet-049.jsonl").stat().st_size != 151:
            problems.append("packet-049-preserved-placeholder-size-changed")

    # Verify every raw source capture cited by frozen source/input files using the source index.
    raw_refs = parse_refs(frozen_files)
    try:
        index_rows = json.loads(SOURCE_INDEX.read_text(encoding="utf-8"))
        source_index = {row["path"]: row for row in index_rows if isinstance(row, dict) and isinstance(row.get("path"), str)}
    except Exception as exc:
        source_index = {}
        problems.append(f"source-index-invalid:{type(exc).__name__}")
    raw_sources = []
    for raw_path, pin in sorted(raw_refs.items()):
        if not safe(raw_path) or pin.get("conflicts"):
            problems.append(f"unsafe-or-conflicting-source-capture:{raw_path}")
            continue
        index_entry = source_index.get(raw_path)
        if not index_entry or index_entry.get("sha256") != pin["sha256"] or type(index_entry.get("bytes")) is not int:
            problems.append(f"source-capture-not-index-pinned:{raw_path}")
            continue
        source = SOURCE_ROOT / raw_path
        if not source.is_file() or source.is_symlink():
            problems.append(f"selected-source-capture-missing:{raw_path}")
            continue
        size, actual = source.stat().st_size, sha256(source)
        if size != index_entry["bytes"] or actual != index_entry["sha256"]:
            problems.append(f"selected-source-capture-sha-or-size-mismatch:{raw_path}")
            continue
        record = {"path": raw_path, "bytes": size, "sha256": actual, "origins": pin["origins"]}
        raw_sources.append(record)
        add(source, raw_path)

    # Full case/product source files and original reference archives remain external but hash-pinned.
    source_manifest_path = PROOF_BASE / "inputs/selected-source-manifest.jsonl"
    source_input_pins: dict[str, str] = {}
    if not source_manifest_path.is_file():
        problems.append("selected-source-manifest-missing")
    else:
        for row in read_jsonl(source_manifest_path):
            for path_key, hash_key in (("case_source_input", "case_source_sha256"), ("product_source_input", "product_source_sha256")):
                rel, expected = row.get(path_key), row.get(hash_key)
                if not isinstance(rel, str) or not isinstance(expected, str):
                    problems.append("selected-source-manifest-malformed")
                    continue
                if rel in source_input_pins and source_input_pins[rel] != expected:
                    problems.append(f"source-input-pin-conflict:{rel}")
                source_input_pins[rel] = expected
    external = []
    for dep in EXTERNAL_ARCHIVES:
        path = ROOT / dep["path"]
        actual = sha256(path) if path.is_file() else None
        row = dict(dep, present=path.is_file(), bytes=path.stat().st_size if path.is_file() else None, actual_sha256=actual, sha256_matches=actual == dep["sha256"])
        if row["sha256_matches"] is not True:
            problems.append(f"external-reference-pin-mismatch:{dep['name']}")
        external.append(row)
    for rel, expected in sorted(source_input_pins.items()):
        path = SOURCE_ROOT / rel
        actual = sha256(path) if path.is_file() else None
        row = {"name": "full-case-product-source-input", "path": rel, "sha256": expected,
               "present": path.is_file(), "bytes": path.stat().st_size if path.is_file() else None,
               "actual_sha256": actual, "sha256_matches": actual == expected, "bundled": False}
        if row["sha256_matches"] is not True:
            problems.append(f"external-case-product-input-pin-mismatch:{rel}")
        external.append(row)

    # Verify source-only v1/v2/v3 history reports remain unscored and label-blind.
    for rel in HISTORY_REPORTS:
        path = ROOT / rel
        if not path.is_file():
            problems.append(f"source-history-report-missing:{rel}")
            continue
        history = read_json(path)
        if history.get("labels_read") is not False or history.get("scores_created") is not False or history.get("test_split_read") is not False:
            problems.append(f"source-history-report-scope-mismatch:{rel}")
    extra = {
        "freeze": freeze,
        "snapshot_receipt": snapshot_receipt,
        "snapshot_files": snapshot_files,
        "raw_sources": raw_sources,
        "external": external,
        "source_input_pin_count": len(source_input_pins),
        "method_audit_paths": sorted(method_audit_paths),
        "source_method_exclusion_count": len(method_ledger.get("excluded_pair_ids", [])),
        "metadata_alias_disclosures": method_ledger.get("metadata_alias_disclosures", []),
    }
    return files, raw_sources, problems, extra


def write_source_docs(extra: dict[str, Any], *, final_artifacts: list[tuple[Path, str]] | None = None,
                      root_ready_path: str | None = None, root_ready: dict[str, Any] | None = None) -> None:
    snap = extra["snapshot_receipt"]
    if final_artifacts is None:
        readme = """# Coordinate DEV20 source-preflight record

This is the source-only preparation record for the coordinate DEV20 checkpoint. The final ZIP is gated on a later root-ready receipt that binds frozen DEV gates, the grade freeze, selected aggregate score, and final report. The default preflight does not open those artifacts.

The frozen first pass contains 186 actual pairs and 2,467 whole-option decisions against an expected 189 pairs and 2,510 decisions. Three pairs remain missing. Packet 049's 151-byte foreign placeholder is preserved byte-for-byte, with its status in the failure ledger. The full raw snapshot has 67 first-written files and combined-response SHA-256 `f9a5d1551e893556992d259ed0be5e72faad3d483e74d0bc9427e3323d1c25cb`.

Method exclusions v2 records eight code-classified pairs tied to packets 017, 041, and 060; original/canonical audit evidence is pinned. Disclosures for metadata aliases in packets 028, 045, and 050 remain preserved. No semantic reclassification was applied. Continuations and prior assembler drafts are included as provenance.

The canonical source-NLI-v3 freeze is `681026e353b595644d66631afcd7f324ee237e973b584c3f7090795f9705c6ec`; the literal-family proof function is pinned at `ef00e3eae0f985f8293a6369fc79311d82118b33c7cfa7c5a44d5b74f11d47e1`; the 202-file pre-ML freeze is `fd00b9bf05bb5c90d36439540a89a3350cc85d46a2690b2bd46d9e1c44167b2e`. Exact source captures are verified against the source index. Full reference archives and full case/product source inputs remain external and hash-pinned.

This source-only record does not include a score or make an accuracy claim. Historical source reports are preserved; this does not claim byte-for-byte replay of every historical builder revision.
"""
        status = f"""# DEV20 source-preflight status

- Scope: dev source preparation only; scoring and final-gate completion are not asserted by this preflight.
- Pre-ML freeze: 202 files, SHA-256 `{EXPECTED_PREML_SHA}`.
- First-pass raw snapshot: {snap.get('raw_response_count')} actual pairs / {snap.get('whole_option_count')} whole-option decisions; expected {snap.get('expected_dispatch_pair_count')} pairs / {snap.get('expected_whole_option_count')} decisions.
- Missing pairs: {snap.get('missing_pair_count')}. Packet 049's 151-byte foreign placeholder is retained without rewriting.
- Method exclusions v2: 8 pairs; source audits and metadata-alias disclosures are preserved.
- This is a source-only preflight; no final score, accuracy, or performance claim is included.
"""
    else:
        role_names = {"final_gate": "final gate", "grading_freeze": "grading freeze",
                      "selected_score": "sanitized aggregate score", "final_report": "final report",
                      "metadata_supplement": "metadata supplement", "source_code": "source code",
                      "code": "code", "runtime": "runtime dependency", "history": "history",
                      "supplemental_receipt": "supplemental receipt", "root_go": "root GO receipt",
                      "scoring_completion": "scoring-completion receipt"}
        roles = [(role_names.get(row.get("role"), str(row.get("role"))), row.get("path"))
                 for row in (root_ready or {}).get("final_artifacts", []) if isinstance(row, dict)]
        artifact_list = "\n".join(f"- {role}: `{rel}`" for role, rel in roles)
        report_path = next((rel for role, rel in roles if role == "final report"), "the pinned final report")
        score_path = next((rel for role, rel in roles if role == "selected score"), "the pinned selected score")
        readme = f"""# Coordinate DEV20 checkpoint

This checkpoint contains the completed DEV20 source, inference, frozen gates, and scoring artifacts. Root-ready receipt `{root_ready_path or 'provided receipt'}` records scoring completed and pins the artifacts below. The split is dev only.

The available frozen first-pass scope is 186 actual pairs and 2,467 whole-option decisions out of 189 expected pairs and 2,510 decisions. Three model responses are missing and resolve to unknown task states; outputs for all 20 cases remain represented. The selected score and detailed gate/scoring scope are reported in `{report_path}`; the aggregate score artifact is `{score_path}`.

{artifact_list}

No holdout or generalization claim is made. Packet 049's 151-byte foreign placeholder, all first-pass response files, the eight v2 method exclusions, and packet 028/045/050 metadata-alias disclosures remain preserved. No semantic reclassification was applied during packaging. The source-only preflight wording is preserved in `README_SOURCE_PREFLIGHT.md` and `SOURCE_STATUS_SOURCE_PREFLIGHT.md`.

Full reference archives and full case/product source inputs remain external and hash-pinned.
"""
        status = f"""# DEV20 final checkpoint status

- Split: dev only. The root-ready receipt records final gates frozen and scoring completed.
- Frozen first-pass scope: {snap.get('raw_response_count')} actual pairs and {snap.get('whole_option_count')} whole-option decisions; expected {snap.get('expected_dispatch_pair_count')} pairs and {snap.get('expected_whole_option_count')} decisions.
- Missing model responses: {snap.get('missing_pair_count')}; these resolve to unknown task states, with all 20 case outputs retained. Detailed scored scope and result: `{report_path}`.
- Selected aggregate score: `{score_path}`. No holdout or generalization claim is made.
- Frozen gate and grading artifacts are pinned in the root-ready receipt and listed in `README.md`.
"""
        for source_name, history_name in (("README.md", "README_SOURCE_PREFLIGHT.md"),
                                          ("SOURCE_STATUS.md", "SOURCE_STATUS_SOURCE_PREFLIGHT.md")):
            source = BUILD / source_name
            history = BUILD / history_name
            if source.is_file() and not history.exists():
                history.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
    if final_artifacts is None:
        for source_name, history_name in (("README.md", "README_SOURCE_PREFLIGHT.md"),
                                          ("SOURCE_STATUS.md", "SOURCE_STATUS_SOURCE_PREFLIGHT.md")):
            source = BUILD / source_name
            history = BUILD / history_name
            if source.is_file() and not history.exists():
                history.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
    (BUILD / "README.md").write_text(readme, encoding="utf-8")
    (BUILD / "SOURCE_STATUS.md").write_text(status, encoding="utf-8")
    (BUILD / "ROOT_READY_RECEIPT_SCHEMA.md").write_text(f"""# Root-ready receipt required for final ZIP

The full ZIP builder requires `--build --root-ready-receipt PATH`. The receipt must use schema `{ROOT_READY_SCHEMA}`, set `root_ready` and `scoring_completed` to true, set `source_split` to `dev`, and set `gold_or_label_members_included` to false. Its `final_artifacts` array must pin every final gate/assembly artifact plus one grading freeze, one sanitized selected aggregate score, and one final report. The selected score path must be exactly `{AGGREGATE_SCORE_PATH}`. Each entry has `role`, repository-relative `path`, `bytes`, and `sha256`. Required roles are `final_gate`, `grading_freeze`, `selected_score`, and `final_report`; optional roles are `metadata_supplement`, `source_code`, `code`, `runtime`, `history`, `supplemental_receipt`, `root_go`, and `scoring_completion`. Optional roles can carry the archival-split metadata adapter, its tests/code, and supporting receipts without treating them as classifier/gate outputs. The builder packages only explicitly listed files after verifying each pin.

Source-only preflight does not look for, enumerate, or read final gate, freeze, score, report, live response directories, or answer archives.
""", encoding="utf-8")

def generate_source_receipts(extra: dict[str, Any], problems: list[str]) -> None:
    (BUILD / "raw-source-capture-pins.json").write_text(json.dumps({
        "schema_version": "sku-next-dev-coordinate-full-checkpoint-source-captures-v1",
        "source_index_path": SOURCE_INDEX.relative_to(ROOT).as_posix(),
        "source_index_sha256": sha256(SOURCE_INDEX),
        "raw_capture_count": len(extra["raw_sources"]),
        "raw_captures": extra["raw_sources"],
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (BUILD / "external-dependency-pins.json").write_text(json.dumps({
        "schema_version": "sku-next-dev-coordinate-full-checkpoint-external-pins-v1",
        "dependencies": extra["external"],
        "full_source_inputs_bundled": False,
        "full_reference_archive_members_opened": False,
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    method_ledger = read_json(METHOD_LEDGER_V2)
    (BUILD / "method-evidence-inventory.json").write_text(json.dumps({
        "schema_version": "sku-next-dev-coordinate-method-evidence-inventory-v1",
        "method_ledger_path": METHOD_LEDGER_V2.relative_to(ROOT).as_posix(),
        "method_ledger_sha256": sha256(METHOD_LEDGER_V2),
        "excluded_pair_count": len(method_ledger.get("excluded_pair_ids", [])),
        "source_method_audit_count": len(method_ledger.get("sources", [])),
        "metadata_alias_disclosures": method_ledger.get("metadata_alias_disclosures", []),
        "canonical_and_original_method_audit_paths": extra["method_audit_paths"],
        "semantic_reclassification": method_ledger.get("semantic_reclassification"),
        "labels_read": method_ledger.get("labels_read"),
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def future_final_artifacts(root_ready_path: Path) -> tuple[dict[str, Any], list[tuple[Path, str]], list[str]]:
    receipt = read_json(root_ready_path)
    problems = []
    if (receipt.get("schema_version") != ROOT_READY_SCHEMA or receipt.get("root_ready") is not True
            or receipt.get("scoring_completed") is not True or receipt.get("source_split") != "dev"
            or receipt.get("gold_or_label_members_included") is not False):
        raise SystemExit("root-ready receipt does not authorize the final DEV checkpoint artifact set")
    entries = receipt.get("final_artifacts")
    if not isinstance(entries, list) or not entries:
        raise SystemExit("root-ready receipt must enumerate final gate/freeze/score/report pins")
    required_roles = ("final_gate", "grading_freeze", "selected_score", "final_report")
    optional_roles = ("metadata_supplement", "source_code", "code", "runtime", "history",
                      "supplemental_receipt", "root_go", "scoring_completion")
    counts = {role: 0 for role in required_roles + optional_roles}
    files = []
    seen = set()
    for row in entries:
        if not isinstance(row, dict):
            problems.append("malformed-root-ready-artifact-entry")
            continue
        role, rel = row.get("role"), row.get("path")
        if role not in counts or not isinstance(rel, str) or rel in seen or not safe(rel):
            problems.append(f"invalid-root-ready-artifact:{rel}")
            continue
        if role == "selected_score" and rel != AGGREGATE_SCORE_PATH:
            problems.append(f"selected_score_must_be_sanitized_aggregate:{rel}")
            continue
        seen.add(rel); counts[role] += 1
        path = ROOT / rel
        if (not path.is_file() or path.is_symlink() or type(row.get("bytes")) is not int
                or path.stat().st_size != row.get("bytes") or sha256(path) != row.get("sha256")):
            problems.append(f"root-ready-artifact-pin-mismatch:{rel}")
        else:
            files.append((path, rel))
    for role in required_roles:
        count = counts[role]
        if count < 1:
            problems.append(f"root-ready-artifact-role-missing:{role}")
    for role in ("metadata_supplement", "root_go", "scoring_completion"):
        if counts[role] < 1:
            problems.append(f"root-ready-artifact-role-missing:{role}")
    if counts["source_code"] + counts["code"] < 1:
        problems.append("root-ready-artifact-role-missing:source_code_or_code")
    return receipt, files, problems


def grading_freeze_replay_inventory(root_ready: dict[str, Any]) -> tuple[list[tuple[Path, str]], dict[str, Any], list[str]]:
    """Verify and stage every safe frozen dependency, only in root-ready final mode."""
    problems: list[str] = []
    freeze_entry = next((row for row in root_ready.get("final_artifacts", [])
                         if isinstance(row, dict) and row.get("role") == "grading_freeze"), None)
    if not isinstance(freeze_entry, dict) or not isinstance(freeze_entry.get("path"), str):
        return [], {}, ["grading-freeze-artifact-not-pinned"]
    freeze_path = ROOT / freeze_entry["path"]
    if not freeze_path.is_file() or sha256(freeze_path) != freeze_entry.get("sha256"):
        return [], {}, ["grading-freeze-pin-mismatch-before-replay-inventory"]
    freeze = read_json(freeze_path)
    if (freeze.get("source_split") != "dev" or freeze.get("test_identity_use") != "disjointness_only"
            or freeze.get("test_labels_or_details_read_for_classification_or_selection") is not False):
        problems.append("grading-freeze-scope-is-not-dev-identity-only")
    pins = freeze.get("frozen_files")
    if not isinstance(pins, dict) or not pins:
        return [], {}, ["grading-freeze-frozen-files-missing"]
    included: list[tuple[Path, str]] = []
    rows = []
    by_source: dict[str, str] = {}
    # Grading-frozen DEV predictions and gate results are permissible replay members.
    # Gold, labels, answers, secrets, model weights, archives, and raw worker responses stay excluded.
    forbidden_parts = FORBIDDEN_PARTS - {"predictions"}
    for source_rel, pin in sorted(pins.items()):
        if not isinstance(source_rel, str) or not isinstance(pin, dict):
            problems.append("malformed-grading-freeze-pin")
            continue
        p = Path(source_rel)
        rel = p.as_posix()
        method_audit = "worker-responses" in p.parts and p.name.endswith("-method-audit.json")
        if (p.is_absolute() or ".." in p.parts or p.suffix.lower() in FORBIDDEN_SUFFIXES
                or {x.lower() for x in p.parts} & forbidden_parts
                or p.name.lower().startswith(("answer-", "label-", "gold-"))):
            problems.append(f"unsafe-grading-freeze-member:{rel}")
            continue
        if "worker-responses" in p.parts and not (method_audit or rel in ALLOWED_WORKER_RESPONSE_PROVENANCE):
            problems.append(f"raw-worker-response-in-grading-freeze:{rel}")
            continue
        path = ROOT / rel
        expected_bytes, expected_sha = pin.get("bytes"), pin.get("sha256")
        if not path.is_file() or path.is_symlink():
            problems.append(f"missing-grading-freeze-member:{rel}")
            continue
        actual_bytes, actual_sha = path.stat().st_size, sha256(path)
        if type(expected_bytes) is not int or actual_bytes != expected_bytes or actual_sha != expected_sha:
            problems.append(f"grading-freeze-member-pin-mismatch:{rel}")
            continue
        included.append((path, rel))
        by_source[source_rel] = rel
        rows.append({"source_path": source_rel, "archive_path": rel, "bytes": actual_bytes,
                     "sha256": actual_sha, "verification": "matched_grading_freeze_pin"})
    # The only test-side source allowed here is identity-only case-plan membership for disjointness.
    for key in ("full_test_identity_case_plans", "prior_dev20_identity_membership"):
        rel = freeze.get(key)
        if not isinstance(rel, str) or rel not in by_source:
            problems.append(f"identity_only_replay_dependency_not_bundled:{key}")
    inventory = {
        "schema_version": "sku-next-dev-coordinate-grading-freeze-replay-inventory-v1",
        "grading_freeze_path": freeze_entry["path"],
        "grading_freeze_sha256": freeze_entry.get("sha256"),
        "frozen_file_pin_count": len(pins),
        "verified_and_bundled_frozen_file_count": len(rows),
        "frozen_files": rows,
        "external_dependencies": [],
        "full_test_identity_use": freeze.get("test_identity_use"),
        "prior_dev20_identity_membership": freeze.get("prior_dev20_identity_membership"),
        "test_labels_or_details_read_for_classification_or_selection": freeze.get("test_labels_or_details_read_for_classification_or_selection"),
        "labels_or_gold_members_included": False,
    }
    return included, inventory, problems


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--build", action="store_true", help="create final ZIP only with a valid root-ready receipt")
    parser.add_argument("--root-ready-receipt", type=Path, help="root-pinned final artifact manifest; required with --build")
    args = parser.parse_args()
    if args.build and args.root_ready_receipt is None:
        raise SystemExit("final ZIP creation requires --root-ready-receipt; source-only mode never builds the final ZIP")
    BUILD.mkdir(parents=True, exist_ok=True)
    files, raw_sources, problems, extra = gather_source()
    write_source_docs(extra)
    generate_source_receipts(extra, problems)
    builder_sha = sha256(Path(__file__))
    (BUILD / "package-code-receipt.json").write_text(json.dumps({
        "schema_version": "sku-next-dev-coordinate-full-checkpoint-builder-receipt-v1",
        "builder_path": Path(__file__).relative_to(ROOT).as_posix(),
        "builder_sha256": builder_sha,
        "pre_ml_freeze_sha256": EXPECTED_PREML_SHA,
        "snapshot_receipt_sha256": EXPECTED_SNAPSHOT_RECEIPT_SHA,
        "method_exclusions_v2_sha256": EXPECTED_METHOD_V2_SHA,
        "raw_capture_count": len(raw_sources),
        "preml_pin_count": EXPECTED_PREML_PIN_COUNT,
        "source_only_preflight": True,
        "live_worker_responses_opened": False,
        "final_gates_or_grade_outputs_opened": False,
        "labels_or_gold_opened": False,
        "final_zip_created": False,
        "problems": sorted(set(problems)),
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def current_files() -> tuple[list[tuple[Path, str]], list[str]]:
        by_path = {arc: (path, arc) for arc, path in files.items()}
        for path in [
            BUILD / "package.py", BUILD / "README.md", BUILD / "SOURCE_STATUS.md",
            BUILD / "README_SOURCE_PREFLIGHT.md", BUILD / "SOURCE_STATUS_SOURCE_PREFLIGHT.md",
            BUILD / "ROOT_READY_RECEIPT_SCHEMA.md", BUILD / "raw-source-capture-pins.json",
            BUILD / "external-dependency-pins.json", BUILD / "method-evidence-inventory.json",
            BUILD / "package-code-receipt.json", BUILD / "source-inventory.json", BUILD / "source-preflight.json",
        ]:
            if path.is_file():
                rel = path.relative_to(ROOT).as_posix()
                if not safe(rel):
                    problems.append(f"unsafe-builder-member:{rel}")
                else:
                    by_path[rel] = (path, rel)
        return sorted(by_path.values(), key=lambda x: x[1]), []

    files_and_arcs, _ = current_files()
    # Inventory excludes itself to avoid a self-hash cycle, but records every source and snapshot member.
    source_rows = [{"path": arc, "bytes": path.stat().st_size, "sha256": sha256(path)} for path, arc in files_and_arcs if arc != (BUILD / "source-inventory.json").relative_to(ROOT).as_posix()]
    (BUILD / "source-inventory.json").write_text(json.dumps({
        "schema_version": "sku-next-dev-coordinate-full-checkpoint-source-inventory-v1",
        "pre_ml_pin_count": EXPECTED_PREML_PIN_COUNT,
        "snapshot_raw_file_count": EXPECTED_RAW_FILE_COUNT,
        "selected_source_capture_count": len(raw_sources),
        "source_member_count_excluding_inventory": len(source_rows),
        "source_members": source_rows,
        "future_final_artifact_roles": ["final_gate", "grading_freeze", "selected_score", "final_report", "metadata_supplement", "source_code", "code", "runtime", "history", "supplemental_receipt", "root_go", "scoring_completion"],
        "final_zip_path": OUT.relative_to(ROOT).as_posix(),
        "final_zip_created": False,
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    files_and_arcs, _ = current_files()
    source_report = {
        "schema_version": "sku-next-dev-coordinate-full-checkpoint-preflight-v1",
        "phase": "source_only_inventory" if not args.build else "root_ready_final_build",
        "pre_ml_pin_count": EXPECTED_PREML_PIN_COUNT,
        "completed_firstpass_raw_file_count": EXPECTED_RAW_FILE_COUNT,
        "actual_raw_pair_count": extra["snapshot_receipt"].get("raw_response_count"),
        "expected_pair_count": extra["snapshot_receipt"].get("expected_dispatch_pair_count"),
        "actual_whole_option_count": extra["snapshot_receipt"].get("whole_option_count"),
        "expected_whole_option_count": extra["snapshot_receipt"].get("expected_whole_option_count"),
        "missing_pair_count": extra["snapshot_receipt"].get("missing_pair_count"),
        "raw_source_capture_count": len(raw_sources),
        "method_exclusion_count": extra["source_method_exclusion_count"],
        "method_audit_path_count": len(extra["method_audit_paths"]),
        "external_dependency_count": len(extra["external"]),
        "source_member_count": len(files_and_arcs),
        "source_uncompressed_bytes": sum(p.stat().st_size for p, _ in files_and_arcs),
        "source_problems": sorted(set(problems)),
        "final_gates_or_grade_outputs_opened": False,
        "labels_or_gold_opened": False,
        "final_zip_created": False,
        "awaiting_root_ready_receipt": True,
    }
    (BUILD / "source-preflight.json").write_text(json.dumps(source_report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    # Refresh inventory and report after output receipts exist.
    files_and_arcs, _ = current_files()
    source_report["source_member_count"] = len(files_and_arcs)
    source_report["source_uncompressed_bytes"] = sum(p.stat().st_size for p, _ in files_and_arcs)
    (BUILD / "source-preflight.json").write_text(json.dumps(source_report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    files_and_arcs, _ = current_files()
    source_report["source_member_count"] = len(files_and_arcs)
    source_report["source_uncompressed_bytes"] = sum(p.stat().st_size for p, _ in files_and_arcs)
    (BUILD / "source-preflight.json").write_text(json.dumps(source_report, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    root_ready_files: list[tuple[Path, str]] = []
    if args.build:
        missing_checks = [str(path.relative_to(ROOT)) for path in CHECKS_DIRS if not path.is_dir()]
        if missing_checks:
            raise SystemExit("final package requires all four required-check trees: " + ", ".join(missing_checks))
        ready, root_ready_files, ready_problems = future_final_artifacts(args.root_ready_receipt)
        if ready_problems:
            raise SystemExit("root-ready final artifacts do not verify: " + "; ".join(ready_problems[:10]))
        replay_files, replay_inventory, replay_problems = grading_freeze_replay_inventory(ready)
        if replay_problems:
            raise SystemExit("grading-freeze replay inventory does not verify: " + "; ".join(replay_problems[:10]))
        replay_inventory_path = BUILD / "grading-freeze-replay-inventory.json"
        replay_inventory_path.write_text(json.dumps(replay_inventory, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        root_ready_rel = args.root_ready_receipt.resolve().relative_to(ROOT).as_posix()
        if not safe(root_ready_rel):
            raise SystemExit("root-ready receipt path is unsafe")
        root_ready_files.append((args.root_ready_receipt.resolve(), root_ready_rel))
        root_ready_files.append((replay_inventory_path, replay_inventory_path.relative_to(ROOT).as_posix()))
        write_source_docs(extra, final_artifacts=root_ready_files, root_ready_path=root_ready_rel, root_ready=ready)
        payload_by_arc = {arc: path for path, arc in files_and_arcs}
        for path, arc in root_ready_files + replay_files:
            previous = payload_by_arc.get(arc)
            if previous is not None:
                if sha256(previous) != sha256(path) or previous.stat().st_size != path.stat().st_size:
                    raise SystemExit(f"conflicting package member source: {arc}")
                continue
            payload_by_arc[arc] = path
        files_and_arcs = sorted(((path, arc) for arc, path in payload_by_arc.items()), key=lambda x: x[1])
        if problems:
            raise SystemExit("source package has unresolved problems: " + "; ".join(sorted(set(problems))[:10]))
        OUT.parent.mkdir(parents=True, exist_ok=True)
        tmp_fd, tmp_name = tempfile.mkstemp(prefix=OUT.name + ".", suffix=".tmp", dir=OUT.parent)
        os.close(tmp_fd); tmp = Path(tmp_name)
        payload_rows = []
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path, arc in files_and_arcs:
                data = path.read_bytes()
                archive.writestr(arc, data)
                payload_rows.append({"path": arc, "bytes": len(data), "sha256": sha_bytes(data)})
            internal = {
                "schema_version": "sku-next-dev-coordinate-full-checkpoint-v1",
                "root_ready": True,
                "source_split": "dev",
                "pre_ml_freeze_sha256": EXPECTED_PREML_SHA,
                "firstpass_snapshot_receipt_sha256": EXPECTED_SNAPSHOT_RECEIPT_SHA,
                "method_exclusions_v2_sha256": EXPECTED_METHOD_V2_SHA,
                "raw_source_capture_count": len(raw_sources),
                "source_preml_pin_count": EXPECTED_PREML_PIN_COUNT,
                "final_artifact_roles": sorted({row.get("role") for row in ready.get("final_artifacts", []) if isinstance(row, dict)}),
                "grading_freeze_replay_pin_count": replay_inventory["frozen_file_pin_count"],
                "grading_freeze_replay_member_count": replay_inventory["verified_and_bundled_frozen_file_count"],
                "labels_or_gold_members_included": False,
                "members": payload_rows,
            }
            archive.writestr("CHECKPOINT_MANIFEST.json", json.dumps(internal, indent=2, sort_keys=True) + "\n")
        with zipfile.ZipFile(tmp, "r") as archive:
            bad = archive.testzip()
            if bad:
                raise SystemExit(f"ZIP CRC verification failed at {bad}")
            for row in payload_rows:
                data = archive.read(row["path"]); info = archive.getinfo(row["path"])
                if len(data) != row["bytes"] or sha_bytes(data) != row["sha256"] or zlib.crc32(data) & 0xffffffff != info.CRC:
                    raise SystemExit(f"ZIP member verification failed: {row['path']}")
        os.replace(tmp, OUT)
        archive_sha = sha256(OUT)
        final_manifest = {
            "schema_version": "sku-next-dev-coordinate-full-checkpoint-zip-manifest-v1",
            "archive": OUT.relative_to(ROOT).as_posix(),
            "archive_bytes": OUT.stat().st_size,
            "archive_sha256": archive_sha,
            "payload_member_count": len(payload_rows),
            "crc_verified": True,
            "all_member_bytes_and_sha256_verified": True,
            "members": payload_rows,
        }
        manifest_path = OUT.with_suffix(OUT.suffix + ".manifest.json")
        manifest_path.write_text(json.dumps(final_manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        OUT.with_suffix(OUT.suffix + ".sha256").write_text(f"{archive_sha}  {OUT.name}\n", encoding="utf-8")
        print(json.dumps({**source_report, "archive": str(OUT), "archive_bytes": OUT.stat().st_size,
                          "archive_sha256": archive_sha, "manifest": str(manifest_path),
                          "payload_member_count": len(payload_rows), "final_zip_created": True,
                          "final_gates_or_grade_outputs_opened": True,
                          "awaiting_root_ready_receipt": False,
                          "grading_freeze_replay_pin_count": replay_inventory["frozen_file_pin_count"],
                          "grading_freeze_replay_member_count": replay_inventory["verified_and_bundled_frozen_file_count"]}, indent=2, sort_keys=True))
        return 0

    print(json.dumps(source_report, indent=2, sort_keys=True))
    return 2 if problems else 0

if __name__ == "__main__":
    raise SystemExit(main())
