# Coordinate DEV20 checkpoint

This checkpoint contains the completed DEV20 source, inference, frozen gates, and scoring artifacts. Root-ready receipt `.lab-output/sku-next-dev-coordinate-full-checkpoint-build-20261013-v1/root-ready-final-checkpoint-v1.json` records scoring completed and pins the artifacts below. The split is dev only.

The available frozen first-pass scope is 186 actual pairs and 2,467 whole-option decisions out of 189 expected pairs and 2,510 decisions. Three model responses are missing and resolve to unknown task states; outputs for all 20 cases remain represented. The selected score and detailed gate/scoring scope are reported in `experiments/sku-matching/coordinate-dev-refids-result-20261013.txt`; the aggregate score artifact is `the pinned selected score`.

- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/assembly-output-inventory.json`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/assembly-receipt.json`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/citation-normalization-v1/normalization-receipt.json`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/citation-normalization-v1/normalization-report.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/citation-normalization-v1/normalized-responses.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/coordinate-refids-choice-nli/all-row-results.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/coordinate-refids-choice-nli/case-decisions.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/coordinate-refids-choice-nli/gate-manifest.json`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/coordinate-refids-choice-nli/task-resolutions.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/literal-only/all-row-results.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/literal-only/case-decisions.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/literal-only/gate-manifest.json`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/literal-only/task-resolutions.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/method-exclusion-ledger.json`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/method-qualification-report.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/missing-firstpass-failure-ledger.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/raw-firstpass-model-outputs.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/raw-snapshot-receipt.json`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/raw-transport-audit.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/rendered-responses-v2.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/response-validation-report.jsonl`
- final gate: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/final-gate-run-v2/validated-responses-v2.jsonl`
- grading freeze: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/grading-freeze-v1.json`
- sanitized aggregate score: `.lab-output/sku-next-dev-coordinate-full-checkpoint-build-20261013-v1/dev20-aggregate-score.json`
- final report: `experiments/sku-matching/coordinate-dev-refids-result-20261013.txt`
- metadata supplement: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/archival-split-adapter-pin-receipt-v1.json`
- source code: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/grade_dev20_archival_split_metadata_adapter_v1.py`
- source code: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/test_grade_dev20_archival_split_metadata_adapter_v1.py`
- root GO receipt: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/root-scoring-go-v1.json`
- scoring-completion receipt: `.lab-output/sku-next-dev-coordinate-full-checkpoint-build-20261013-v1/scoring-completion-receipt.json`
- runtime dependency: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/archival-split-adapter-synthetic-tests.log`
- history: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/dev20-grade-freeze-spec-v1.json`
- history: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/dev20-grade-freeze-spec-v2.json`
- history: `.lab-output/sku-next-dev-coordinate-execution-20261013-v1/dev20-grade-freeze-spec-v3.json`

No holdout or generalization claim is made. Packet 049's 151-byte foreign placeholder, all first-pass response files, the eight v2 method exclusions, and packet 028/045/050 metadata-alias disclosures remain preserved. No semantic reclassification was applied during packaging. The source-only preflight wording is preserved in `README_SOURCE_PREFLIGHT.md` and `SOURCE_STATUS_SOURCE_PREFLIGHT.md`.

Full reference archives and full case/product source inputs remain external and hash-pinned.
