# DEV20 final checkpoint status

- Split: dev only. The root-ready receipt records final gates frozen and scoring completed.
- Frozen first-pass scope: 186 actual pairs and 2467 whole-option decisions; expected 189 pairs and 2510 decisions.
- Missing model responses: 3; these resolve to unknown task states, with all 20 case outputs retained. Detailed scored scope and result: `experiments/sku-matching/coordinate-dev-refids-result-20261013.txt`.
- Selected aggregate score: `the pinned selected score`. No holdout or generalization claim is made.
- Frozen gate and grading artifacts are pinned in the root-ready receipt and listed in `README.md`.
