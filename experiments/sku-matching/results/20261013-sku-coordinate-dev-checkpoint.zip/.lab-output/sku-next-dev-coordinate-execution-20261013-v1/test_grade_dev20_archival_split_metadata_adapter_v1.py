import copy
import unittest

import grade_dev20_archival_split_metadata_adapter_v1 as adapter


class ArchivalSplitAdapterTests(unittest.TestCase):
    def score_one(self, version, label, prediction):
        membership = [{"case_id": "synthetic", "split": "dev", "source_version": version}]
        before = copy.deepcopy(membership)
        references = {"synthetic": {"label": label, "_reference_split": version}}
        result = adapter.archival_split_score_variant(
            membership, [{"case_id": "synthetic", "decision": prediction}], references
        )
        self.assertEqual(membership, before)
        return result

    def test_v2_v3_matched_and_unmatched_counts_preserved(self):
        for version in ("v2", "v3"):
            with self.subTest(version=version):
                matched = self.score_one(version, "matched", "matched")
                self.assertEqual(matched["metrics"]["tp"], 1)
                self.assertEqual(matched["metrics"]["scored_case_count"], 1)
                unmatched = self.score_one(version, "unmatched", "unmatched")
                self.assertEqual(unmatched["metrics"]["tn"], 1)
                self.assertEqual(unmatched["metrics"]["scored_case_count"], 1)

    def test_missing_or_foreign_source_version_fails(self):
        for member in ({"case_id": "x", "split": "dev"},
                       {"case_id": "x", "split": "dev", "source_version": "v4"}):
            with self.subTest(member=member), self.assertRaises(ValueError):
                adapter.archival_split_score_variant([member], [], {})

    def test_non_dev_membership_fails(self):
        with self.assertRaises(ValueError):
            adapter.archival_split_score_variant(
                [{"case_id": "x", "split": "v2", "source_version": "v2"}], [], {}
            )

    def test_incorrect_reference_split_still_fails_original_check(self):
        with self.assertRaisesRegex(ValueError, "reference split differs from frozen membership"):
            adapter.archival_split_score_variant(
                [{"case_id": "synthetic", "split": "dev", "source_version": "v2"}],
                [{"case_id": "synthetic", "decision": "matched"}],
                {"synthetic": {"label": "matched", "_reference_split": "v3"}},
            )


if __name__ == "__main__":
    unittest.main()
