#!/usr/bin/env python3
"""Assemble frozen first-pass REFIDS responses into source-validated DEV20 gates.

This command is intentionally unavailable until root has registered one complete,
immutable 189-pair/2,510-option raw-response snapshot and its completion receipt.
It does not infer, score, open answer archives, or read TEST results.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import traceback
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
BASE = ROOT / ".lab-output/sku-next-dev-coordinate-refids-20261013-v1"
PREPARED = BASE / "source-nli-v3"
PROOF = ROOT / ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2"
EXPERIMENT_FREEZE = HERE / "experiment-freeze.json"
ROOT_GO = HERE / "root-classification-go.json"
DISPATCH_INVENTORY = HERE / "dispatch-inventory.json"
SUPPLEMENT = HERE / "bounded-dispatch-and-serialization-supplement.json"
RAW_SNAPSHOT_SCHEMA = "sku-next-dev-coordinate-refids-firstpass-snapshot-v1"
METHOD_EXCLUSION_SCHEMA = "sku-next-dev-coordinate-method-exclusions-v1"
RAW_SNAPSHOT_FREEZE_SHA256 = "fd00b9bf05bb5c90d36439540a89a3350cc85d46a2690b2bd46d9e1c44167b2e"
DISPATCH_INVENTORY_SHA256 = "e5280c47e43dba54e098ffc203a61b1c481364a65794e566275db0d9317e3afa"
PREPARED_FREEZE_SHA256 = "681026e353b595644d66631afcd7f324ee237e973b584c3f7090795f9705c6ec"
SEMANTIC_PINS = {
    "sku_directional_choice_nli_v1.py": "a467766b9ca50d925ab390f1d8c0ae1ae7816a118cf2bb99737f68bc309f89b0",
    "normalize_source_nli_citations_v1.py": "f43a496afba1bdfcabc897fb486bb727ced796dc93f892dd7319ba28e57ade28",
    "evaluate_dev_source_bound_whole_sku_gate_v1.py": "2782dfb307eb72e41101249e7cb9059c04c80f695aa9bacb1bfe0e93fadd8fb8",
    "sku_literal_family_proof_v1.py": "ef00e3eae0f985f8293a6369fc79311d82118b33c7cfa7c5a44d5b74f11d47e1",
}
EXPECTED_VARIANTS = {"coordinate-refids-choice-nli", "literal-only"}

sys.path.insert(0, str(ROOT / "experiments/sku-matching"))
import evaluate_dev_source_bound_whole_sku_gate_v1 as EVAL  # noqa: E402
import normalize_source_nli_citations_v1 as NORMALIZER  # noqa: E402
import sku_choice_refids_protocol_v1 as REFIDS  # noqa: E402
import sku_directional_choice_nli_v1 as NLI  # noqa: E402


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def pin(path: Path) -> dict[str, Any]:
    return {"bytes": path.stat().st_size, "sha256": sha_file(path)}


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def read_rows(path: Path) -> list[dict[str, Any]]:
    return NLI.read_rows(Path(path))


def write_json(path: Path, value: dict[str, Any]) -> None:
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def write_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    with Path(path).open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(NLI.canonical(row).decode("utf-8") + "\n")


def repo_rel(path: Path) -> str:
    try:
        return Path(path).resolve().relative_to(ROOT).as_posix()
    except ValueError as exc:
        raise ValueError(f"frozen input must be inside repo workspace: {path}") from exc


def reject_partial_or_test_input(path: Path) -> None:
    rel = repo_rel(path)
    parts = {x.lower() for x in Path(rel).parts}
    if "worker-responses" in parts or "worker-inputs" in parts:
        raise ValueError("do not assemble from partial worker files; pass only the root-registered immutable snapshot")
    if parts & {"labels", "gold", "truth", "answers", "answer-shards", "labels-token"}:
        raise ValueError("label-bearing source is outside this assembly workflow")
    if "test" in parts and rel != ".lab-output/sku-full-condition-adapter-20261013-v2/test/case-plans.jsonl":
        raise ValueError("TEST outputs/details cannot enter this DEV assembly")


def verify_registered_freeze() -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    if sha_file(EXPERIMENT_FREEZE) != RAW_SNAPSHOT_FREEZE_SHA256:
        raise ValueError("pre-inference experiment freeze SHA changed")
    freeze = read_json(EXPERIMENT_FREEZE)
    if (freeze.get("schema_version") != "sku-next-dev-coordinate-refids-inference-freeze-v1"
            or freeze.get("source_split") != "dev" or freeze.get("independent_test") is not False
            or freeze.get("labels_read") is not False or freeze.get("test_labels_read") is not False
            or freeze.get("production_adoption_allowed") is not False
            or freeze.get("primary_policy") != "coordinate-refids-choice-nli"
            or freeze.get("comparison_policy") != "literal-only"
            or freeze.get("membership_sha256") != "436d9c078f944a0265ebc6bedbaae42712c958f079a492387259f149385e2f32"
            or freeze.get("dispatch_pair_count") != 189
            or freeze.get("dispatched_whole_option_count") != 2510):
        raise ValueError("inference freeze does not describe the authorized source-only DEV20 experiment")
    go = read_json(ROOT_GO)
    if (go.get("root_go") is not True or go.get("all_source_and_semantic_code_pins_verified") is not True
            or go.get("source_split") != "dev" or go.get("independent_test") is not False
            or go.get("labels_read") is not False or go.get("test_labels_read") is not False
            or go.get("experiment_freeze_sha256") != RAW_SNAPSHOT_FREEZE_SHA256):
        raise ValueError("root classification GO is absent or does not bind the pinned experiment")
    inventory = read_json(DISPATCH_INVENTORY)
    if sha_file(DISPATCH_INVENTORY) != DISPATCH_INVENTORY_SHA256:
        raise ValueError("first-pass dispatch inventory SHA changed")
    if (len(inventory.get("dispatched_pair_ids", [])) != 189
            or len(set(inventory.get("dispatched_pair_ids", []))) != 189
            or len(inventory.get("protected_pair_ids", [])) != 152
            or inventory.get("dispatched_whole_option_count") != 2510
            or inventory.get("labels_read") is not False
            or inventory.get("test_labels_read") is not False):
        raise ValueError("frozen dispatch inventory does not match 189 pair/2,510 option first pass")
    supplement = read_json(SUPPLEMENT)
    if (supplement.get("original_packet_payloads_and_inference_freeze_unchanged") is not True
            or supplement.get("first_written_raw_files_immutable") is not True
            or supplement.get("labels_read") is not False
            or supplement.get("test_labels_read") is not False):
        raise ValueError("first-pass continuation disclosure is missing or inconsistent")
    return freeze, go, inventory, supplement


def verify_frozen_file_inventory(freeze: dict[str, Any]) -> dict[str, dict[str, Any]]:
    pins = freeze.get("frozen_files")
    if not isinstance(pins, dict) or not pins:
        raise ValueError("experiment freeze has no complete input/code inventory")
    actual: dict[str, dict[str, Any]] = {}
    for rel, expected in pins.items():
        path = ROOT / rel
        if (not path.is_file() or path.is_symlink()
                or "worker-responses" in Path(rel).parts):
            raise ValueError(f"pre-inference frozen file missing/unsafe or includes worker response: {rel}")
        current = pin(path)
        if current != expected:
            raise ValueError(f"pre-inference input/code pin changed: {rel}")
        actual[rel] = current
    return actual


def verify_source_and_proofs(freeze: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    prepared_freeze = read_json(PREPARED / "freeze.json")
    if sha_file(PREPARED / "freeze.json") != PREPARED_FREEZE_SHA256:
        raise ValueError("canonical source-nli-v3 freeze SHA differs")
    if (prepared_freeze.get("schema_version") != NLI.PROTOCOL
            or prepared_freeze.get("labels_read") is not False
            or prepared_freeze.get("test_split_read") is not False
            or prepared_freeze.get("inference_run") is not False
            or prepared_freeze.get("scores_or_gate_outputs_created") is not False
            or prepared_freeze.get("production_adoption_allowed") is not False
            or prepared_freeze.get("selected_case_count") != 20
            or prepared_freeze.get("selected_row_count") != 320
            or prepared_freeze.get("selected_task_count") != 1220
            or prepared_freeze.get("prepared_pair_count") != 341
            or prepared_freeze.get("ready_pair_count") != 341
            or prepared_freeze.get("source_fact_errors") != 0):
        raise ValueError("canonical source-nli-v3 is not the final blind DEV20 freeze")
    proof_manifest = read_json(PROOF / "manifest.json")
    if (proof_manifest.get("schema_version") != "sku-next-dev-coordinate-literal-proof-v2"
            or proof_manifest.get("classification_or_scoring_run") is not False
            or proof_manifest.get("labels_read") is not False
            or proof_manifest.get("predictions_read") is not False
            or proof_manifest.get("whole_gate_evaluation_run") is not False
            or proof_manifest.get("input_case_count") != 20
            or proof_manifest.get("input_row_count") != 320
            or proof_manifest.get("input_task_count") != 1220
            or proof_manifest.get("task_source_verification_count") != 1220
            or proof_manifest.get("task_source_verification_status_counts") != {"verified_complete_ordered_raw_family": 1220}
            or proof_manifest.get("source_code_pins", {}).get("source_nli_v3_freeze") != PREPARED_FREEZE_SHA256):
        raise ValueError("frozen literal-family proof bundle is not the matching source-only DEV20 proof")
    for rel, digest in proof_manifest.get("canonical_output_hashes", {}).items():
        path = PROOF / rel
        if not path.is_file() or sha_file(path) != digest:
            raise ValueError(f"literal proof canonical output SHA differs: {rel}")
    source_tasks = read_rows(BASE / "tasks.jsonl")
    task_proofs = read_rows(PROOF / "task-proof-states.jsonl")
    source_receipts = read_rows(PROOF / "task-source-verification.jsonl")
    if len(source_tasks) != 1220 or len(task_proofs) != 1220 or len(source_receipts) != 1220:
        raise ValueError("complete original task/proof/source receipt populations are required")
    return source_tasks, task_proofs, source_receipts, proof_manifest


def derive_pair_partition(inventory: dict[str, Any], source_tasks: list[dict[str, Any]],
                          task_proofs: list[dict[str, Any]], source_receipts: list[dict[str, Any]]) -> tuple[set[str], set[str]]:
    prepared_freeze, pairs, _contexts, _docs, task_bindings = NLI._load_prepared(PREPARED)
    task_by_id = EVAL.index(source_tasks, "task_id", "original task")
    proof_by_id = EVAL.index(task_proofs, "task_id", "literal task proof")
    receipt_by_id = EVAL.index(source_receipts, "task_id", "literal task source receipt")
    if not (set(task_by_id) == set(proof_by_id) == set(receipt_by_id)):
        raise ValueError("task, proof, and original source receipt ID populations differ")
    protected, dispatched = set(), set()
    for pair_id, pair in pairs.items():
        bindings = task_bindings.get(pair_id, [])
        statuses = [EVAL.source_literal_state(task_by_id[b["task_binding"]["task_id"]],
                    proof_by_id[b["task_binding"]["task_id"]], receipt_by_id[b["task_binding"]["task_id"]])
                    for b in bindings]
        if statuses and all(state is not None for state in statuses):
            protected.add(pair_id)
        elif pair.get("preparation_status") == "ready":
            dispatched.add(pair_id)
    if (protected != set(inventory.get("protected_pair_ids", []))
            or dispatched != set(inventory.get("dispatched_pair_ids", []))
            or len(dispatched) != 189 or len(protected) != 152):
        raise ValueError("literal protection partition differs from root-frozen dispatch IDs")
    option_count = sum(len(pairs[pair_id]["candidate_vector"]) for pair_id in dispatched)
    if option_count != 2510:
        raise ValueError("dispatched whole-option population differs from frozen 2,510 options")
    return protected, dispatched


def validate_method_ledger(method_ledger: dict[str, Any], root: Path,
                           dispatched_pair_ids: set[str], raw_pair_ids: set[str],
                           frozen_files: dict[str, dict[str, Any]]) -> set[str]:
    """Verify dynamic exclusions against actual pinned audit and worker inputs."""
    if (method_ledger.get("schema_version") != METHOD_EXCLUSION_SCHEMA
            or method_ledger.get("method_policy") != "exclude_from_primary_when_worker_authored_nonconforming_vector"
            or method_ledger.get("labels_read") is not False
            or method_ledger.get("test_labels_read") is not False
            or method_ledger.get("semantic_reclassification") is not False
            or method_ledger.get("raw_response_preserved") is not True
            or method_ledger.get("source_validation_still_performed") is not True):
        raise ValueError("method-exclusion ledger schema or no-semantic-edit attestations differ")
    sources = method_ledger.get("sources")
    excluded_ids = method_ledger.get("excluded_pair_ids")
    if not isinstance(sources, list) or not sources:
        raise ValueError("method-exclusion ledger needs one or more provenance audit sources")
    if not isinstance(excluded_ids, list) or not excluded_ids or len(set(excluded_ids)) != len(excluded_ids):
        raise ValueError("method-exclusion ledger needs a nonempty unique flattened pair list")
    union: set[str] = set()
    for source in sources:
        if not isinstance(source, dict):
            raise ValueError("malformed method-exclusion provenance source")
        ids = source.get("pair_ids")
        audit_rel, audit_sha = source.get("audit_receipt_path"), source.get("audit_receipt_sha256")
        assignment_rel, packet_rel = source.get("worker_assignment_path"), source.get("packet_input_path")
        if (not isinstance(ids, list) or not ids or len(ids) != len(set(ids))
                or not set(ids) <= dispatched_pair_ids or not set(ids) <= raw_pair_ids
                or union.intersection(ids)):
            raise ValueError("method source pair IDs must be unique across sources and present in raw dispatched output")
        if (not isinstance(audit_rel, str) or not re.fullmatch(
                r"\.lab-output/sku-next-dev-coordinate-execution-20261013-v1/worker-responses/packet-\d{3}-method-audit\.json", audit_rel)
                or not isinstance(audit_sha, str) or len(audit_sha) != 64):
            raise ValueError("method source must pin an explicit packet method-audit receipt")
        audit_path = root / audit_rel
        if not audit_path.is_file() or audit_path.is_symlink() or sha_file(audit_path) != audit_sha:
            raise ValueError(f"method audit receipt bytes/SHA mismatch: {audit_rel}")
        audit = read_json(audit_path)
        if not isinstance(audit.get("original_toolcode"), str) or not isinstance(audit.get("method_finding"), str):
            raise ValueError(f"method audit lacks the source code and finding needed to verify pair IDs: {audit_rel}")
        ids_in_audit_receipt = set(re.findall(r"choice-pair:[0-9a-f]{64}", json.dumps(audit, ensure_ascii=False)))
        if set(ids) != ids_in_audit_receipt:
            raise ValueError(f"ledger pair IDs do not exactly match the cited method audit receipt: {audit_rel}")
        packet_no = int(re.search(r"packet-(\d{3})-method-audit\.json$", audit_rel).group(1))
        required_assignment = f".lab-output/sku-next-dev-coordinate-execution-20261013-v1/worker-inputs/assignment-{packet_no:03d}.json"
        required_packet = f".lab-output/sku-next-dev-coordinate-execution-20261013-v1/worker-inputs/packet-{packet_no:03d}.json"
        if assignment_rel != required_assignment or packet_rel != required_packet:
            raise ValueError("method source assignment/packet paths do not match its audit packet number")
        for rel, claimed in ((assignment_rel, source.get("worker_assignment_sha256")),
                             (packet_rel, source.get("packet_input_sha256"))):
            if rel not in frozen_files or frozen_files[rel].get("sha256") != claimed:
                raise ValueError(f"worker assignment/packet is not the claimed pre-inference frozen input: {rel}")
            source_path = root / rel
            if not source_path.is_file() or sha_file(source_path) != claimed:
                raise ValueError(f"worker assignment/packet bytes differ from the pre-inference pin: {rel}")
        assignment = read_json(root / assignment_rel)
        instruction_rel = assignment.get("instruction_file")
        instruction_sha = source.get("instruction_sha256")
        if (not isinstance(instruction_rel, str) or instruction_rel not in frozen_files
                or assignment.get("packet_index") != packet_no
                or assignment.get("packet") != packet_rel
                or set(assignment.get("pair_ids", [])) != set(ids)
                or instruction_sha != frozen_files[instruction_rel].get("sha256")
                or not (root / instruction_rel).is_file()
                or sha_file(root / instruction_rel) != instruction_sha):
            raise ValueError(f"method source instruction hash or assigned pair population differs: packet {packet_no}")
        union.update(ids)
    if union != set(excluded_ids):
        raise ValueError("flat method-exclusion pair list does not exactly equal unique provenance-source pair IDs")
    return union


def validate_snapshot_receipt(snapshot_path: Path, receipt_path: Path,
                              dispatched_pair_ids: set[str],
                              method_exclusion_path: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any], set[str], dict[str, Any]]:
    snapshot_path, receipt_path = Path(snapshot_path).resolve(), Path(receipt_path).resolve()
    reject_partial_or_test_input(snapshot_path)
    reject_partial_or_test_input(receipt_path)
    if not snapshot_path.is_file() or snapshot_path.is_symlink() or not receipt_path.is_file() or receipt_path.is_symlink():
        raise FileNotFoundError("root-registered raw snapshot and completion receipt must both exist")
    receipt = read_json(receipt_path)
    if (receipt.get("schema_version") != RAW_SNAPSHOT_SCHEMA
            or receipt.get("snapshot_status") != "all_dispatch_statuses_frozen"
            or receipt.get("all_raw_outputs_frozen") is not True
            or receipt.get("first_written_outputs_unchanged") is not True
            or receipt.get("continuations_are_firstpass_only") is not True
            or receipt.get("all_dispatch_statuses_frozen") is not True
            or receipt.get("partial_worker_files_used") is not False
            or receipt.get("labels_read") is not False
            or receipt.get("test_labels_read") is not False
            or receipt.get("experiment_freeze_sha256") != RAW_SNAPSHOT_FREEZE_SHA256
            or receipt.get("dispatch_inventory_sha256") != DISPATCH_INVENTORY_SHA256
            or receipt.get("snapshot_path") != repo_rel(snapshot_path)
            or receipt.get("expected_dispatch_pair_count") != 189
            or receipt.get("expected_whole_option_count") != 2510
            or receipt.get("dispatch_pair_membership_sha256") != NLI.digest(sorted(dispatched_pair_ids))):
        raise ValueError("raw snapshot completion receipt is absent, partial, or not bound to this experiment")
    method_exclusion_path = Path(method_exclusion_path).resolve()
    if not method_exclusion_path.is_file() or method_exclusion_path.is_symlink():
        raise FileNotFoundError("root method-exclusion ledger is required")
    method_exclusion_pin = pin(method_exclusion_path)
    if (receipt.get("method_exclusion_ledger_path") != repo_rel(method_exclusion_path)
            or receipt.get("method_exclusion_ledger_bytes") != method_exclusion_pin["bytes"]
            or receipt.get("method_exclusion_ledger_sha256") != method_exclusion_pin["sha256"]):
        raise ValueError("root method-exclusion ledger path/bytes/SHA differ from the completion receipt")
    method_ledger = read_json(method_exclusion_path)
    actual_pin = pin(snapshot_path)
    if (receipt.get("snapshot_bytes") != actual_pin["bytes"]
            or receipt.get("raw_output_sha256") != actual_pin["sha256"]):
        raise ValueError("immutable raw first-pass snapshot bytes/SHA differ from its root receipt")
    rows = read_rows(snapshot_path)
    pair_ids = [row.get("pair_id") for row in rows if isinstance(row, dict)]
    if (receipt.get("raw_response_count") != len(rows)
            or receipt.get("unique_pair_count") != len(rows)
            or len(pair_ids) != len(rows) or len(set(pair_ids)) != len(pair_ids)
            or len(rows) > 189 or not set(pair_ids) <= dispatched_pair_ids
            or receipt.get("raw_response_pair_membership_sha256") != NLI.digest(sorted(pair_ids))):
        raise ValueError("raw snapshot must contain unique first-pass outputs only from the frozen dispatched pair IDs")
    frozen_files = read_json(EXPERIMENT_FREEZE).get("frozen_files", {})
    excluded_ids = validate_method_ledger(method_ledger, ROOT, dispatched_pair_ids,
                                          set(pair_ids), frozen_files)
    missing_ids = set(dispatched_pair_ids) - set(pair_ids)
    declared_missing = receipt.get("missing_pair_ids")
    if (not isinstance(declared_missing, list) or len(declared_missing) != len(set(declared_missing))
            or set(declared_missing) != missing_ids or receipt.get("missing_pair_count") != len(missing_ids)):
        raise ValueError("every absent model output must be explicitly accounted for as unknown in the failure ledger")
    failure_rel = receipt.get("failure_ledger_path")
    if not isinstance(failure_rel, str):
        raise ValueError("snapshot receipt must bind a failure ledger, including an empty ledger")
    failure_path = (ROOT / failure_rel).resolve()
    reject_partial_or_test_input(failure_path)
    if not failure_path.is_file() or failure_path.is_symlink():
        raise FileNotFoundError("root completion failure ledger is missing")
    failure_pin = pin(failure_path)
    if (receipt.get("failure_ledger_bytes") != failure_pin["bytes"]
            or receipt.get("failure_ledger_sha256") != failure_pin["sha256"]):
        raise ValueError("failure ledger bytes/SHA differ from root completion receipt")
    failures = read_rows(failure_path)
    if receipt.get("failure_ledger_count") != len(failures):
        raise ValueError("failure ledger count differs from frozen receipt")
    failure_ids = []
    for row in failures:
        pair_id = row.get("pair_id")
        if (pair_id not in missing_ids or row.get("status") != "missing_firstpass_response_unknown"
                or row.get("model_judgment_recorded") is not False
                or row.get("semantic_retry_performed") is not False
                or row.get("firstpass_output_present") is not False):
            raise ValueError("failure ledger must disclose missing outputs as unknown without fabricated/retried judgments")
        failure_ids.append(pair_id)
    if len(failure_ids) != len(set(failure_ids)) or set(failure_ids) != missing_ids:
        raise ValueError("failure ledger does not exactly cover missing dispatched pair IDs")
    raw_option_count = sum(len(row.get("decisions", [])) if isinstance(row.get("decisions"), list) else 0 for row in rows)
    if (receipt.get("whole_option_count") != raw_option_count
            or type(raw_option_count) is not int or not 0 <= raw_option_count <= 2510):
        raise ValueError("actual raw option count must be recorded separately and cannot exceed the 2,510-option dispatch")
    if not set(excluded_ids) <= set(pair_ids):
        raise ValueError("method-excluded pair IDs must have actual first-pass raw outputs")
    return rows, failures, receipt, set(excluded_ids), method_ledger

def audit_raw_transport(raw_rows: list[dict[str, Any]], prepared_pairs: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    audit = []
    for row in raw_rows:
        pair = prepared_pairs[row["pair_id"]]
        expected = len(pair["option_values"])
        decisions = row.get("decisions") if isinstance(row, dict) else None
        decision_count = len(decisions) if isinstance(decisions, list) else None
        indexes = [d.get("option_index") for d in decisions if isinstance(d, dict)] if isinstance(decisions, list) else []
        vector_ok = (decision_count == expected and len(indexes) == expected
                     and indexes == list(range(expected)))
        audit.append({"pair_id": row["pair_id"], "cache_key_matches": row.get("cache_key") == pair.get("cache_key"),
                      "expected_option_count": expected, "raw_decision_count": decision_count,
                      "option_vector_shape_ok": vector_ok,
                      "malformed_transport_fails_closed_to_unknown": not vector_ok or row.get("cache_key") != pair.get("cache_key")})
    return audit


def method_qualify_validated_pairs(validated_pairs: list[dict[str, Any]],
                                   excluded_pair_ids: set[str],
                                   validation_rows: list[dict[str, Any]] | None = None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Apply only the frozen method exclusion after independent source validation."""
    validated_ids = {row["pair_id"] for row in validated_pairs}
    if len(validated_ids) != len(validated_pairs):
        raise ValueError("source-validated response IDs must be unique")
    qualified = [row for row in validated_pairs if row["pair_id"] not in excluded_pair_ids]
    validation_status = {row["pair_id"]: row["validation_status"] for row in (validation_rows or [])}
    report = []
    for pair_id in sorted(validated_ids | excluded_pair_ids):
        is_excluded = pair_id in excluded_pair_ids
        is_valid = pair_id in validated_ids
        report.append({"pair_id": pair_id,
            "source_validation_status": validation_status.get(pair_id, "valid_source_metadata" if is_valid else "no_validated_response"),
            "primary_method_qualified": is_valid and not is_excluded,
            "qualification_reason": ("excluded_worker_authored_nonconforming_vector" if is_excluded
                                     else "follows_frozen_worker_method" if is_valid else "source_validation_failed_or_missing")})
    return qualified, report


def assemble(snapshot_path: Path, snapshot_receipt_path: Path, method_exclusion_path: Path,
             output_dir: Path) -> dict[str, Any]:
    freeze, root_go, inventory, supplement = verify_registered_freeze()
    frozen_inputs = verify_frozen_file_inventory(freeze)
    source_tasks, task_proofs, source_receipts, proof_manifest = verify_source_and_proofs(freeze)
    protected, dispatched = derive_pair_partition(inventory, source_tasks, task_proofs, source_receipts)
    raw_rows, failure_rows, snapshot_receipt, method_excluded_ids, method_ledger = validate_snapshot_receipt(
        snapshot_path, snapshot_receipt_path, dispatched, method_exclusion_path)
    output_dir = Path(output_dir).resolve()
    try:
        output_rel = repo_rel(output_dir)
    except ValueError as exc:
        raise ValueError("output directory must be a new repo-relative .lab-output directory") from exc
    if not output_rel.startswith(".lab-output/") or output_dir.exists():
        raise FileExistsError("output must be a new, non-existing .lab-output directory; no overwrite/retry")
    output_dir.mkdir(parents=True, exist_ok=False)
    try:
        # Copy the exact raw snapshot byte-for-byte and keep the original external
        # snapshot untouched. No partial worker response file is opened or copied.
        raw_copy = output_dir / "raw-firstpass-model-outputs.jsonl"
        with snapshot_path.open("rb") as source, raw_copy.open("xb") as target:
            shutil.copyfileobj(source, target)
        raw_copy_pin = pin(raw_copy)
        if raw_copy_pin != pin(snapshot_path):
            raise AssertionError("raw snapshot copy changed bytes")
        write_json(output_dir / "raw-snapshot-receipt.json", snapshot_receipt)
        write_rows(output_dir / "missing-firstpass-failure-ledger.jsonl", failure_rows)
        write_json(output_dir / "method-exclusion-ledger.json", method_ledger)

        raw_transport_audit = audit_raw_transport(raw_rows, NLI._load_prepared(PREPARED)[1])
        transport_ok_ids = {row["pair_id"] for row in raw_transport_audit
                            if not row["malformed_transport_fails_closed_to_unknown"]}
        # Keep malformed vectors in the immutable raw snapshot and audit, while
        # withholding them from the renderer so they resolve to unknown.
        renderable_rows = [row for row in raw_rows if row["pair_id"] in transport_ok_ids]
        rendered = REFIDS.render_responses(renderable_rows, PREPARED)
        write_rows(output_dir / "rendered-responses-v2.jsonl", rendered)
        source_root = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source"
        normalization_dir = output_dir / "citation-normalization-v1"
        normalization_receipt = NORMALIZER.normalize_file(
            PREPARED, output_dir / "rendered-responses-v2.jsonl", normalization_dir, source_root)
        normalized_path = normalization_dir / "normalized-responses.jsonl"
        normalized = read_rows(normalized_path)

        validation_rows, validated_pairs = [], []
        seen = set()
        for response in normalized:
            pair_id = response.get("pair_id") if isinstance(response, dict) else None
            if pair_id in seen:
                validation_rows.append({"pair_id": pair_id, "validation_status": "invalid_unknown",
                                        "semantic_state_preserved": True, "error": "duplicate normalized response"})
                continue
            if isinstance(pair_id, str):
                seen.add(pair_id)
            try:
                validated = NORMALIZER.validate_normalized_response(PREPARED, response, source_root)
                validated_pairs.append(validated)
                validation_rows.append({"pair_id": pair_id, "validation_status": "valid_source_metadata",
                    "semantic_truth_verified": validated["semantic_truth_verified"],
                    "source_citations_verified": validated["source_citations_verified"],
                    "judgment_count": validated["judgment_count"]})
            except (KeyError, TypeError, ValueError, OSError) as exc:
                validation_rows.append({"pair_id": pair_id, "validation_status": "invalid_unknown",
                    "semantic_state_preserved": True, "error": str(exc)})
        write_rows(output_dir / "validated-responses-v2.jsonl", validated_pairs)
        write_rows(output_dir / "response-validation-report.jsonl", validation_rows)
        qualified_pairs = [row for row in validated_pairs if row["pair_id"] not in method_excluded_ids]
        qualified_pairs, method_qualification_rows = method_qualify_validated_pairs(
            validated_pairs, method_excluded_ids, validation_rows)
        write_rows(output_dir / "method-qualification-report.jsonl", method_qualification_rows)

        case_plans = read_rows(BASE / "case-plans.jsonl")
        row_plans = read_rows(BASE / "row-plans.jsonl")
        task_bindings = NLI._load_prepared(PREPARED)[4]
        flat_bindings = [binding for pair_bindings in task_bindings.values() for binding in pair_bindings]
        gates = {}
        for variant in ("coordinate-refids-choice-nli", "literal-only"):
            pairs_for_variant = qualified_pairs if variant == "coordinate-refids-choice-nli" else []
            resolutions = EVAL.build_choice_nli_task_resolutions(
                source_tasks, flat_bindings, pairs_for_variant, task_proofs, source_receipts)
            # The frozen EVAL API retains its pre-existing internal variant enum;
            # output paths/receipts use only the agreed experiment variant names.
            internal_name = "choice_nli_full" if variant == "coordinate-refids-choice-nli" else "baseline_literal_overlay"
            gate = EVAL.finish_whole_sku_gate(internal_name, case_plans, row_plans, source_tasks, resolutions)
            gate["variant"] = variant
            gate["assembly_method"] = ("validated_refids_choice_nli_plus_protected_literal_proofs"
                                       if variant == "coordinate-refids-choice-nli" else "protected_literal_proofs_only_unknown_elsewhere")
            gate["production_adoption_allowed"] = False
            if (len(resolutions) != 1220 or len(gate["rows"]) != 320 or len(gate["decisions"]) != 20
                    or gate.get("labels_read") is not False):
                raise ValueError(f"whole-SKU EVAL did not produce complete source-only gate: {variant}")
            variant_dir = output_dir / variant
            variant_dir.mkdir()
            write_rows(variant_dir / "task-resolutions.jsonl", resolutions)
            write_rows(variant_dir / "all-row-results.jsonl", gate["rows"])
            write_rows(variant_dir / "case-decisions.jsonl", gate["decisions"])
            source_hashes = {
                "raw_firstpass_snapshot": raw_copy_pin["sha256"],
                "rendered_responses": pin(output_dir / "rendered-responses-v2.jsonl")["sha256"],
                "normalized_responses": pin(normalized_path)["sha256"],
                "validated_responses": pin(output_dir / "validated-responses-v2.jsonl")["sha256"],
                "tasks": pin(BASE / "tasks.jsonl")["sha256"],
                "case_plans": pin(BASE / "case-plans.jsonl")["sha256"],
                "row_plans": pin(BASE / "row-plans.jsonl")["sha256"],
                "task_proof_states": pin(PROOF / "task-proof-states.jsonl")["sha256"],
                "task_source_verification": pin(PROOF / "task-source-verification.jsonl")["sha256"],
            }
            gate_manifest = EVAL.eval_manifest(internal_name, source_hashes,
                                              pin(variant_dir / "task-resolutions.jsonl")["sha256"])
            gate_manifest["variant"] = variant
            gate_manifest["assembly_method"] = gate["assembly_method"]
            gate_manifest.update({"independent_test": False, "source_split": "dev",
                "case_count": 20, "product_count": 10, "row_count": 320, "task_count": 1220,
                "labels_read": False, "test_labels_read": False,
                "production_adoption_allowed": False})
            write_json(variant_dir / "gate-manifest.json", gate_manifest)
            gates[variant] = {"task_state_counts": gate["task_state_counts"],
                              "row_state_counts": gate["row_state_counts"],
                              "decision_counts": gate["decision_counts"],
                              "task_resolution_path": (variant_dir / "task-resolutions.jsonl").relative_to(output_dir).as_posix(),
                              "row_results_path": (variant_dir / "all-row-results.jsonl").relative_to(output_dir).as_posix(),
                              "case_decisions_path": (variant_dir / "case-decisions.jsonl").relative_to(output_dir).as_posix()}

        write_rows(output_dir / "raw-transport-audit.jsonl", raw_transport_audit)
        write_json(output_dir / "assembly-receipt.json", {
            "schema_version": "sku-next-dev-coordinate-refids-assembly-v1",
            "assembly_status": "complete_all_two_dev20_gates_frozen",
            "experiment_freeze_sha256": RAW_SNAPSHOT_FREEZE_SHA256,
            "root_classification_go_sha256": sha_file(ROOT_GO),
            "dispatch_inventory_sha256": DISPATCH_INVENTORY_SHA256,
            "source_nli_freeze_sha256": PREPARED_FREEZE_SHA256,
            "literal_proof_manifest_sha256": sha_file(PROOF / "manifest.json"),
            "raw_snapshot_original_path": repo_rel(snapshot_path),
            "raw_snapshot_receipt_original_path": repo_rel(snapshot_receipt_path),
            "raw_snapshot_copied_sha256": raw_copy_pin["sha256"],
            "raw_response_count": len(raw_rows), "missing_firstpass_pair_count": len(failure_rows),
            "dispatched_pair_count": len(dispatched),
            "literal_protected_pair_count": len(protected),
            "expected_whole_option_count": 2510, "actual_raw_option_count": snapshot_receipt["whole_option_count"],
            "rendered_response_count": len(rendered), "normalized_response_count": len(normalized),
            "validated_pair_count": len(validated_pairs),
            "method_excluded_pair_count": len(method_excluded_ids),
            "method_exclusion_source_count": len(method_ledger["sources"]),
            "method_qualified_validated_pair_count": len(qualified_pairs),
            "source_validated_excluded_pair_count": len(method_excluded_ids & {row["pair_id"] for row in validated_pairs}),
            "method_excluded_pair_ids": sorted(method_excluded_ids),
            "validation_status_counts": dict(Counter(row["validation_status"] for row in validation_rows)),
            "malformed_or_mismatched_raw_vector_count": sum(row["malformed_transport_fails_closed_to_unknown"] for row in raw_transport_audit),
            "renderable_raw_response_count": len(renderable_rows),
            "variants": gates, "all_predictions_and_gates_frozen": True,
            "policy_or_threshold_changed": False, "classifier_outputs_changed_after_freeze": False,
            "labels_read": False, "test_labels_read": False, "scores_created": False,
            "thresholds_selected": False, "production_adoption_allowed": False,
            "hosted_weight_revision_verified": False,
            "source_proof_is_not_semantic_truth": True,
            "invalid_or_missing_model_response_handling": "unknown; no fallback or inferred state",
            "missing_response_failure_ledger_sha256": sha_file(output_dir / "missing-firstpass-failure-ledger.jsonl"),
            "firstpass_raw_output_edited": False, "firstpass_raw_output_deleted": False,
            "raw_snapshot_receipt_sha256": sha_file(output_dir / "raw-snapshot-receipt.json"),
            "normalization_receipt_sha256": sha_file(normalization_dir / "normalization-receipt.json"),
            "experiment_freeze_frozen_files_verified": len(frozen_inputs),
            "continuation_history_supplement_sha256": sha_file(SUPPLEMENT),
        })
        all_files = [p for p in output_dir.rglob("*") if p.is_file() and p.name != "assembly-output-inventory.json"]
        write_json(output_dir / "assembly-output-inventory.json", {
            "schema_version": "sku-next-dev-coordinate-refids-assembly-output-inventory-v1",
            "files": {p.relative_to(output_dir).as_posix(): pin(p) for p in sorted(all_files)},
            "scores_created": False, "labels_read": False})
        return read_json(output_dir / "assembly-receipt.json")
    except Exception as exc:
        failure = {"schema_version": "sku-next-dev-coordinate-refids-assembly-failure-v1",
                   "failure_type": type(exc).__name__, "failure_message": str(exc),
                   "traceback": traceback.format_exc(), "partial_artifacts_preserved": True,
                   "raw_snapshot_sha256": pin(snapshot_path)["sha256"],
                   "labels_read": False, "scores_created": False,
                   "no_automatic_retry_or_cleanup": True}
        with (output_dir / "assembly-failure.json").open("x", encoding="utf-8") as stream:
            json.dump(failure, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.write("\n")
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--responses", type=Path, required=True,
                        help="root-registered immutable combined first-pass raw JSONL, never worker packet files")
    parser.add_argument("--snapshot-receipt", type=Path, required=True,
                        help="root completion receipt matching the exact snapshot contract in this script")
    parser.add_argument("--method-exclusions", type=Path, required=True,
                        help="root-frozen method-exclusion ledger; excludes only its named pairs from primary evaluation")
    parser.add_argument("--output-dir", type=Path, required=True,
                        help="new .lab-output path; existing directories are never overwritten")
    args = parser.parse_args()
    result = assemble(args.responses, args.snapshot_receipt, args.method_exclusions, args.output_dir)
    print(json.dumps({"status": result["assembly_status"], "output_dir": str(args.output_dir),
                      "variants": sorted(result["variants"]), "labels_read": False,
                      "scores_created": False, "production_adoption_allowed": False}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
