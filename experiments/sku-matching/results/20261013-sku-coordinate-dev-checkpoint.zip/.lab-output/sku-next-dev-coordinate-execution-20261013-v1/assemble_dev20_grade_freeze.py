#!/usr/bin/env python3
"""Freeze the completed DEV20 predictions, gates, proofs, code, and audit logs.

This CLI produces only a pre-grade receipt. It never opens answer archives or
computes scores. The later grade helper still requires a separate --root-go.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
BASE = ROOT / ".lab-output/sku-next-dev-coordinate-refids-20261013-v1"
PREPARED = BASE / "source-nli-v3"
PROOF = ROOT / ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2"
PRIOR_DEV = ROOT / ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/membership.jsonl"
FULL_TEST_CASE_PLANS = ROOT / ".lab-output/sku-full-condition-adapter-20261013-v2/test/case-plans.jsonl"
OUTPUT_ROOT = ROOT / ".lab-output"
OLD_FREEZE_ASSEMBLER = ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_grade_freeze.py"
THIS_ASSEMBLER = ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_dev20_grade_freeze.py"
ASSEMBLY_SCRIPT = ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_coordinate_refids_dev20.py"
SNAPSHOT_SCHEMA = "sku-next-dev-coordinate-refids-assembly-v1"
VARIANTS = {"coordinate-refids-choice-nli", "literal-only"}
SOURCE_ARTIFACTS = {
    "source_only_report": f"{BASE.relative_to(ROOT).as_posix()}/source-only-report.json",
    "source_manifest": f"{BASE.relative_to(ROOT).as_posix()}/manifest.json",
    "nli_freeze": f"{PREPARED.relative_to(ROOT).as_posix()}/freeze.json",
    "model_pairs": f"{PREPARED.relative_to(ROOT).as_posix()}/model-pairs.jsonl",
    "paired_contexts": f"{PREPARED.relative_to(ROOT).as_posix()}/paired-contexts.jsonl",
    "source_documents": f"{PREPARED.relative_to(ROOT).as_posix()}/source-documents.jsonl",
    "validation_bindings": f"{PREPARED.relative_to(ROOT).as_posix()}/validation-bindings.jsonl",
    "preparation_errors": f"{PREPARED.relative_to(ROOT).as_posix()}/preparation-errors.jsonl",
}

sys.path.insert(0, str(ROOT / "experiments/sku-matching"))
import evaluate_dev_source_bound_whole_sku_gate_v1 as EVAL  # noqa: E402
import grade_next_dev_coordinate_refids_v1 as GRADER  # noqa: E402
import sku_directional_choice_nli_v1 as NLI  # noqa: E402


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def pin(path: Path) -> dict[str, Any]:
    return {"bytes": path.stat().st_size, "sha256": sha_file(path)}


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def read_rows(path: Path) -> list[dict[str, Any]]:
    return NLI.read_rows(Path(path))


def write_json(path: Path, value: dict[str, Any]) -> None:
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def safe_path(rel: str) -> Path:
    path = Path(rel)
    if path.is_absolute() or ".." in path.parts or not path.is_file() or path.is_symlink():
        raise ValueError(f"freeze artifact must be an existing safe repo-relative file: {rel}")
    lower_parts = {x.lower() for x in path.parts}
    allowed_test_identity = rel == FULL_TEST_CASE_PLANS.resolve().relative_to(ROOT).as_posix()
    if lower_parts & {"labels", "gold", "truth", "answers", "answer-shards", "labels-token"}:
        raise ValueError(f"label-bearing artifact cannot be frozen before grading: {rel}")
    if path.name.lower() in {"resolved.jsonl", "label-manifest.json", "answers.jsonl"}:
        raise ValueError(f"label-bearing artifact cannot be frozen before grading: {rel}")
    if "test" in lower_parts and not allowed_test_identity:
        raise ValueError(f"TEST outputs/details cannot enter pre-grade freeze: {rel}")
    return ROOT / path


def check_log_receipt(check: dict[str, Any]) -> dict[str, Any]:
    name = check.get("check_id")
    fixed_expected = {"historical_errors_14": 14, "skips_37": 37}
    dynamic_expected = {"source_validation_suite", "focused_suite_pass_count"}
    if name in fixed_expected:
        if check.get("expected_count") != fixed_expected[name]:
            raise ValueError(f"historical audit count differs from its frozen requirement: {name}")
        expected_count = fixed_expected[name]
        expected_source_pin = None
    elif name in dynamic_expected:
        source = check.get("expected_count_source")
        if not isinstance(source, dict) or not isinstance(source.get("path"), str):
            raise ValueError(f"dynamic test count must bind to its QA JSON receipt: {name}")
        source_path = safe_path(source["path"])
        source_receipt = read_json(source_path)
        pointer = source.get("pointer")
        if not isinstance(pointer, str) or not pointer.startswith("/"):
            raise ValueError(f"dynamic QA receipt JSON pointer is malformed: {name}")
        expected_count: Any = source_receipt
        for key in pointer.strip("/").split("/"):
            key = key.replace("~1", "/").replace("~0", "~")
            if not isinstance(expected_count, dict) or key not in expected_count:
                raise ValueError(f"dynamic QA receipt count is absent: {name} {pointer}")
            expected_count = expected_count[key]
        if (source_receipt.get("schema_version") != "sku-next-dev-coordinate-required-check-counts-v1"
                or source_receipt.get("complete") is not True
                or source_receipt.get("labels_read") is not False
                or source_receipt.get("scores_created") is not False
                or type(expected_count) is not int or expected_count <= 0):
            raise ValueError(f"dynamic QA count receipt is incomplete or invalid: {name}")
        log_path_field, log_sha_field, pointer_expected = {
            "source_validation_suite": ("source_validation_log_path", "source_validation_log_sha256", "/source_validation_test_count"),
            "focused_suite_pass_count": ("focused_log_path", "focused_log_sha256", "/focused_passing_test_count"),
        }[name]
        if pointer != pointer_expected:
            raise ValueError(f"dynamic QA receipt pointer does not match check type: {name}")
        expected_source_pin = {"path": source["path"], "pointer": pointer,
                               "bytes": source_path.stat().st_size, "sha256": sha_file(source_path),
                               "log_path_field": log_path_field, "log_sha_field": log_sha_field}
    else:
        raise ValueError(f"required frozen audit check is missing: {name}")
    rel = check.get("path")
    if not isinstance(rel, str):
        raise ValueError(f"required audit check has no path: {name}")
    path = safe_path(rel)
    fmt = check.get("format")
    if fmt == "json_pointer":
        value: Any = read_json(path)
        pointer = check.get("pointer")
        if not isinstance(pointer, str) or not pointer.startswith("/"):
            raise ValueError(f"JSON-pointer audit check is malformed: {name}")
        for key in pointer.strip("/").split("/"):
            key = key.replace("~1", "/").replace("~0", "~")
            if not isinstance(value, dict) or key not in value:
                raise ValueError(f"audit JSON pointer is absent: {name} {pointer}")
            value = value[key]
        observed = value
    elif fmt == "jsonl_line_count":
        observed = sum(1 for line in path.open(encoding="utf-8") if line.strip())
    elif fmt == "jsonl_field_count":
        rows = read_rows(path)
        field, equals = check.get("field"), check.get("equals")
        if not isinstance(field, str):
            raise ValueError(f"JSONL field count is malformed: {name}")
        observed = sum(row.get(field) == equals for row in rows)
    elif fmt == "unittest_run_count":
        match = re.search(r"\bRan\s+(\d+)\s+tests?\b", path.read_text(encoding="utf-8"))
        if not match:
            raise ValueError(f"unittest log has no completed test count: {name}")
        observed = int(match.group(1))
    else:
        raise ValueError(f"unsupported audit-check format: {name}")
    if type(observed) is not int or observed != expected_count:
        raise ValueError(f"required audit log count differs for {name}: observed={observed}")
    if expected_source_pin:
        source_path = safe_path(expected_source_pin["path"])
        source_receipt = read_json(source_path)
        if (source_receipt[expected_source_pin["log_path_field"]] != rel
                or source_receipt[expected_source_pin["log_sha_field"]] != sha_file(path)):
            raise ValueError(f"dynamic QA count receipt does not bind the tested log bytes/path: {name}")
    return {"check_id": name, "path": rel, "bytes": path.stat().st_size,
            "sha256": sha_file(path), "observed_count": observed, "expected_count": expected_count,
            "expected_count_source": expected_source_pin,
            "format": fmt, "pointer": check.get("pointer"),
            "field": check.get("field"), "equals": check.get("equals")}


def verify_assembly_output(assembly_dir: Path) -> tuple[dict[str, Any], list[str], dict[str, dict[str, Any]]]:
    assembly_dir = Path(assembly_dir).resolve()
    receipt_path = assembly_dir / "assembly-receipt.json"
    inventory_path = assembly_dir / "assembly-output-inventory.json"
    if not receipt_path.is_file() or not inventory_path.is_file():
        raise ValueError("whole-gate assembly and output inventory are required before grade freeze")
    receipt = read_json(receipt_path)
    inventory = read_json(inventory_path)
    if (receipt.get("schema_version") != SNAPSHOT_SCHEMA
            or receipt.get("assembly_status") != "complete_all_two_dev20_gates_frozen"
            or receipt.get("all_predictions_and_gates_frozen") is not True
            or receipt.get("labels_read") is not False or receipt.get("test_labels_read") is not False
            or receipt.get("scores_created") is not False
            or receipt.get("production_adoption_allowed") is not False
            or set(receipt.get("variants", {})) != VARIANTS):
        raise ValueError("whole-gate assembly receipt is incomplete, scored, or non-DEV")
    files = inventory.get("files")
    if not isinstance(files, dict) or not files:
        raise ValueError("whole-gate output inventory is missing")
    actual_paths = {p.relative_to(assembly_dir).as_posix() for p in assembly_dir.rglob("*")
                    if p.is_file() and p != inventory_path}
    if actual_paths != set(files):
        raise ValueError("whole-gate output directory contains unlisted or missing artifacts")
    pins = {}
    for rel, expected in files.items():
        path = assembly_dir / rel
        if not path.is_file() or path.is_symlink() or pin(path) != expected:
            raise ValueError(f"whole-gate output pin mismatch: {rel}")
        pins[path.resolve().relative_to(ROOT).as_posix()] = pin(path)
    pins[receipt_path.resolve().relative_to(ROOT).as_posix()] = pin(receipt_path)
    pins[inventory_path.resolve().relative_to(ROOT).as_posix()] = pin(inventory_path)
    return receipt, sorted(actual_paths), pins


def assemble_freeze(spec: dict[str, Any], output: Path) -> dict[str, Any]:
    if spec.get("root_go_for_scoring") is not False or spec.get("labels_read") is not False:
        raise ValueError("pre-grade freeze spec must explicitly withhold scoring GO and labels")
    assembly_dir = Path(spec.get("assembly_output_dir", "")).resolve()
    assembly, assembly_files, model_output_pins = verify_assembly_output(assembly_dir)
    assembly_rel = assembly_dir.relative_to(ROOT).as_posix()
    variant_specs = spec.get("variants")
    if not isinstance(variant_specs, dict) or set(variant_specs) != VARIANTS:
        raise ValueError("freeze spec must include exactly primary and literal-only variants")
    variant_entries = {}
    all_gates: list[str] = []
    output_prefix = assembly_dir.relative_to(ROOT).as_posix()
    for variant, entry in variant_specs.items():
        if not isinstance(entry, dict):
            raise ValueError(f"malformed variant entry: {variant}")
        paths = {}
        for key, basename in (("predictions", "case-decisions.jsonl"),
                              ("row_results", "all-row-results.jsonl"),
                              ("task_resolutions", "task-resolutions.jsonl"),
                              ("gate_manifest", "gate-manifest.json")):
            rel = entry.get(key)
            if not isinstance(rel, str) or Path(rel).name != basename:
                raise ValueError(f"variant {variant} must name its frozen {basename}")
            path = safe_path(rel)
            if not rel.startswith(output_prefix + "/"):
                raise ValueError(f"variant output must come from the completed assembly: {rel}")
            paths[key] = rel
        gate = read_json(Path(ROOT / paths["gate_manifest"]))
        if (gate.get("variant") != variant or gate.get("labels_read") is not False
                or gate.get("independent_test") is not False or gate.get("production_adoption_allowed") is not False):
            raise ValueError(f"variant gate manifest is not the correct non-test frozen output: {variant}")
        variant_entries[variant] = {"predictions": paths["predictions"],
            "gate_files": [paths["predictions"], paths["row_results"], paths["task_resolutions"]]}
        all_gates.extend(variant_entries[variant]["gate_files"])
    if len(all_gates) != len(set(all_gates)):
        raise ValueError("variant gate file paths must be unique")

    # Revalidate membership, source lines, prior DEV20, original TEST identity
    # disjointness, and all 320 row keys without touching answer archives.
    cohort = GRADER.ROOT / ".lab-output/sku-next-dev-coordinate-refids-20261013-v1"
    membership, cases, row_keys = GRADER.validate_dev_membership(
        cohort / "membership.jsonl", cohort / "case-plans.jsonl", cohort / "row-plans.jsonl",
        cohort / "selection-plan.json")
    if len(membership) != 20 or len(cases) != 20 or sum(map(len, row_keys.values())) != 320:
        raise ValueError("selected source cohort is not the exact full-row DEV20")
    variant_prediction_rows = {name: read_rows(ROOT / entry["predictions"])
                               for name, entry in variant_entries.items()}
    gate_contents = [(rel, read_rows(ROOT / rel)) for rel in all_gates]
    GRADER.validate_frozen_output_coverage(membership, row_keys, variant_prediction_rows, gate_contents)

    source_artifacts = SOURCE_ARTIFACTS.copy()
    for rel in source_artifacts.values():
        safe_path(rel)
    nli_freeze = read_json(PREPARED / "freeze.json")
    if (sha_file(PREPARED / "freeze.json") != "681026e353b595644d66631afcd7f324ee237e973b584c3f7090795f9705c6ec"
            or nli_freeze.get("source_fact_errors") != 0 or nli_freeze.get("inference_run") is not False):
        raise ValueError("canonical source-nli-v3 preparation pin changed")
    source_report = read_json(BASE / "source-only-report.json")
    if source_report.get("labels_read") is not False or source_report.get("inference_run") is not False:
        raise ValueError("source-only selection report no longer attests blind preparation")

    readiness_checks = spec.get("required_log_checks")
    required_check_ids = {"source_validation_suite", "historical_errors_14", "skips_37", "focused_suite_pass_count"}
    if (not isinstance(readiness_checks, list)
            or {x.get("check_id") for x in readiness_checks if isinstance(x, dict)} != required_check_ids
            or len(readiness_checks) != len(required_check_ids)):
        raise ValueError("grade freeze requires all four source/error/skip/focused audit log checks")
    checks = [check_log_receipt(item) for item in readiness_checks]

    # Artifact groups are explicit; assembled model and gate outputs are added
    # to model_outputs, while proof/source, runtime, and code are independently pinned.
    groups = spec.get("frozen_artifact_groups")
    keys = {"model_outputs", "runtime", "proofs", "code"}
    if not isinstance(groups, dict) or set(groups) != keys:
        raise ValueError("freeze spec must enumerate model outputs, runtime, proofs, and code")
    group_paths: dict[str, set[str]] = {}
    group_paths["model_outputs"] = {f"{assembly_rel}/{rel}" for rel in assembly_files}
    for key in ("runtime", "proofs", "code"):
        values = groups.get(key)
        if not isinstance(values, list) or not values or any(not isinstance(x, str) for x in values):
            raise ValueError(f"freeze spec {key} group must be a nonempty list of repo-relative files")
        group_paths[key] = set(values)
    # Exact source/proof/identity paths are mandatory members of their inventories.
    group_paths["runtime"].update({
        ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/experiment-freeze.json",
        ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/root-classification-go.json",
        ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/dispatch-inventory.json",
        ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/bounded-dispatch-and-serialization-supplement.json",
        ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/membership.jsonl",
        ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/case-plans.jsonl",
        ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/row-plans.jsonl",
        ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/selection-plan.json",
        ".lab-output/sku-full-condition-adapter-20261013-v2/test/case-plans.jsonl",
        ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/membership.jsonl",
    })
    group_paths["proofs"].update({
        ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2/manifest.json",
        ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2/proof-bundle/manifest.json",
        ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2/proof-bundle/proofs.jsonl",
        ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2/task-proof-states.jsonl",
        ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2/task-source-verification.jsonl",
        ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2/protected-nli-contexts.jsonl",
    })
    method_ledger = read_json(assembly_dir / "method-exclusion-ledger.json")
    for method_source in method_ledger.get("sources", []):
        group_paths["proofs"].add(method_source["audit_receipt_path"])
        group_paths["runtime"].update({method_source["worker_assignment_path"],
            method_source["packet_input_path"],
            read_json(ROOT / method_source["worker_assignment_path"])["instruction_file"]})
    # Freeze QA logs with the check receipts so the requested counts are auditable.
    group_paths["runtime"].update(check["path"] for check in checks)
    group_paths["runtime"].update(check["expected_count_source"]["path"]
                                   for check in checks if check.get("expected_count_source"))
    if set(source_artifacts.values()) - group_paths["runtime"] - group_paths["proofs"]:
        group_paths["runtime"].update(source_artifacts.values())
    if THIS_ASSEMBLER not in group_paths["code"] or ASSEMBLY_SCRIPT not in group_paths["code"]:
        group_paths["code"].update({THIS_ASSEMBLER, ASSEMBLY_SCRIPT})
    group_paths["code"].update({
        "experiments/sku-matching/grade_next_dev_coordinate_refids_v1.py",
        ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_coordinate_refids_dev20.pre-method-exclusions.py",
        ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_coordinate_refids_dev20.pre-packet-041-exclusions.py",
        ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_coordinate_refids_dev20.pre-contextless-bindings.py",
        ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assembler-draft-preservation.json",
        "experiments/sku-matching/route_mixed_sku_references_v1.py",
        "experiments/sku-matching/grade_final_test_subset_v1.py",
        "experiments/sku-matching/evaluate_dev_source_bound_whole_sku_gate_v1.py",
        "experiments/sku-matching/sku_directional_choice_nli_v1.py",
        "experiments/sku-matching/normalize_source_nli_citations_v1.py",
        OLD_FREEZE_ASSEMBLER,
        "tests/test_lab_next_dev_coordinate_refids_grade.py",
        "tests/test_lab_next_dev_coordinate_assembler_method_policy.py",
    })
    flat = set().union(*group_paths.values())
    if set().union(*(group_paths[k] for k in keys)) != flat:
        raise AssertionError("artifact group union inconsistency")
    frozen = {}
    for rel in sorted(flat):
        path = safe_path(rel)
        frozen[rel] = pin(path)
    for path, expected in model_output_pins.items():
        if frozen.get(path) != expected:
            raise AssertionError(f"assembled model output pin changed during freeze assembly: {path}")

    receipt = {
        "schema_version": "sku-next-dev-coordinate-refids-grading-freeze-v1",
        "freeze_status": "all_dev_predictions_and_gates_frozen",
        "source_split": "dev", "independent_test": False, "production_adoption_allowed": False,
        "all_predictions_frozen": True, "all_gates_frozen": True,
        "labels_read": False, "test_split_read": False,
        "test_identity_membership_read_for_disjointness": True,
        "test_identity_use": "disjointness_only",
        "test_labels_or_details_read_for_classification_or_selection": False,
        "test_split_read_scope": "original full-source TEST case-plan identities read solely for case/product disjointness; no TEST details, labels, or outcomes read",
        "policy_or_threshold_changed": False, "classifier_outputs_changed_after_freeze": False,
        "membership_sha256": GRADER.MEMBERSHIP_SHA256,
        "variants": variant_entries, "gate_files": all_gates,
        "input_files": {"membership": ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/membership.jsonl",
            "case_plans": ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/case-plans.jsonl",
            "row_plans": ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/row-plans.jsonl",
            "selection_plan": ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/selection-plan.json"},
        "prepared_source_artifacts": source_artifacts,
        "frozen_artifact_groups": {k: sorted(v) for k, v in group_paths.items()},
        "required_artifact_paths": sorted(set().union(*(group_paths[k] for k in keys))),
        "full_test_identity_case_plans": FULL_TEST_CASE_PLANS.relative_to(ROOT).as_posix(),
        "prior_dev20_identity_membership": PRIOR_DEV.relative_to(ROOT).as_posix(),
        "frozen_files": frozen,
        "grader_code_sha256": frozen["experiments/sku-matching/grade_next_dev_coordinate_refids_v1.py"]["sha256"],
        "reference_parser_helper_sha256": frozen["experiments/sku-matching/route_mixed_sku_references_v1.py"]["sha256"],
        "score_helper_sha256": frozen["experiments/sku-matching/grade_final_test_subset_v1.py"]["sha256"],
        "grader_tests_sha256": frozen["tests/test_lab_next_dev_coordinate_refids_grade.py"]["sha256"],
        "freeze_assembler_sha256": frozen[OLD_FREEZE_ASSEMBLER]["sha256"],
        "new_assembly_cli_sha256": frozen[ASSEMBLY_SCRIPT]["sha256"],
        "new_grade_freeze_cli_sha256": frozen[THIS_ASSEMBLER]["sha256"],
        "inference_experiment_freeze_sha256": frozen[".lab-output/sku-next-dev-coordinate-execution-20261013-v1/experiment-freeze.json"]["sha256"],
        "firstpass_assembly_receipt": f"{assembly_rel}/assembly-receipt.json",
        "required_audit_log_checks": checks,
        "scores_created": False, "labels_opened": False,
        "root_go_for_scoring": False, "separate_root_go_required_before_reference_archives": True,
    }
    output = Path(output)
    rel_output = output.resolve().relative_to(ROOT).as_posix()
    if not rel_output.startswith(".lab-output/") or output.exists():
        raise FileExistsError("grade freeze receipt output must be a new .lab-output path")
    output.parent.mkdir(parents=True, exist_ok=True)
    write_json(output, receipt)
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True,
                        help="root-completed freeze spec from dev20-grade-freeze-spec-template.json")
    parser.add_argument("--output", type=Path, required=True,
                        help="new receipt path; receipt creation performs no grading")
    args = parser.parse_args()
    spec = read_json(args.spec)
    receipt = assemble_freeze(spec, args.output)
    print(json.dumps({"freeze_receipt": str(args.output), "frozen_file_count": len(receipt["frozen_files"]),
                      "variant_names": sorted(receipt["variants"]), "labels_read": False,
                      "scores_created": False, "root_go_for_scoring": False}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
