import json, os
base='.lab-output/sku-next-dev-coordinate-execution-20261013-v1'
p=json.load(open(base+'/worker-inputs/packet-038.json'))
# These are individually authored labels in candidate-vector order, based on each complete option and its stated coordinate.
specs=[
 (['explicit_conflict','explicit_conflict','explicit_conflict','support','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict'],0,'ring size'),
 (['explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','support','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict','explicit_conflict'],0,'ring size'),
 (['explicit_conflict']*13+['support']+['explicit_conflict'],1,'combined neckline and color')]
for i,(x,(states,fact,coord)) in enumerate(zip(p['payloads'],specs)):
 dec=[]
 for j,(o,s) in enumerate(zip(x['candidate_vector'],states)):
  val=o['whole_option']
  if s=='support':
   scope='same_condition'; rel='support'; exp=''; excl='source_family'; reason=f'The complete option {val!r} identifies the same {coord} coordinate and agrees with the selected target fact.'
  else:
   scope='same_condition'; rel='explicit_conflict'; excl='source_family'; exp=f'The source family presents mutually exclusive {coord} variants for this one selected product condition; this whole option differs on that coordinate.'; reason=f'The whole option {val!r} is a different value on the same {coord} coordinate, so it cannot describe the selected condition.'
  dec.append({'option_index':j,'whole_value_assessed':True,'state':s,'semantic_relation':rel,'scope_assessment':scope,'scope_and_coordinate_explanation':reason,'option_relation_explanation':reason,'exclusivity_assessment':excl,'exclusivity_explanation':exp,'target_fact_indices':[fact],'body_block_refs':[]})
 out={'pair_id':x['pair_id'],'cache_key':x['cache_key'],'whole_options':True,'decisions':dec}
 path=f"{base}/worker-responses/packet-{[38,3,16,43,6,28,54,59,37,39,5][0]:03d}.jsonl"
 with open(path,'x') as f:f.write(json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n')
