#!/usr/bin/env python3
"""DEV20 grading entry point adapting archival split metadata at score time.

The frozen DEV membership and its source-version provenance stay intact. The
adapter passes a temporary copy to the existing scorer with split=v2/v3, after
strictly checking the original DEV metadata. The archive parser and scorer are
otherwise unchanged.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import FunctionType
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
EXEC_DIR = ROOT / ".lab-output/sku-next-dev-coordinate-execution-20261013-v1"
FREEZE_SHA256 = "b610324496d5d9e5c92bab9359088d7c1ae50896544390f9746b3b31a44aaba4"
BASE_GRADER = ROOT / "experiments/sku-matching/grade_next_dev_coordinate_refids_v1.py"
TESTS = EXEC_DIR / "test_grade_dev20_archival_split_metadata_adapter_v1.py"

if str(ROOT / "experiments/sku-matching") not in sys.path:
    sys.path.insert(0, str(ROOT / "experiments/sku-matching"))
import grade_next_dev_coordinate_refids_v1 as base  # noqa: E402
from grade_final_test_subset_v1 import score_variant as original_score_variant  # noqa: E402


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def archival_split_score_variant(membership: list[dict[str, Any]], predictions: list[dict[str, Any]], references: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Validate frozen DEV provenance, then use a temporary archival split."""
    adapted: list[dict[str, Any]] = []
    for member in membership:
        if member.get("split") != "dev":
            raise ValueError("adapter requires original frozen membership split=dev")
        source_version = member.get("source_version")
        if source_version not in {"v2", "v3"}:
            raise ValueError("adapter requires source_version v2 or v3")
        copy = dict(member)
        copy["evaluation_source_split"] = "dev"
        copy["split"] = source_version
        adapted.append(copy)
    return original_score_variant(adapted, predictions, references)


def patched_grade_from_files(*args: Any, **kwargs: Any) -> Any:
    # FunctionType gives the original implementation a private globals table;
    # only score_variant is replaced, leaving all validation/parsing code intact.
    original = base.grade_from_files
    globals_copy = dict(original.__globals__)
    globals_copy["score_variant"] = archival_split_score_variant
    clone = FunctionType(original.__code__, globals_copy, original.__name__, original.__defaults__, original.__closure__)
    clone.__kwdefaults__ = original.__kwdefaults__
    return clone(*args, **kwargs)


def validate_supplemental_receipt(path: Path) -> None:
    receipt = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(receipt, dict) or receipt.get("schema_version") != "sku-dev20-archival-split-adapter-pin-receipt-v1":
        raise ValueError("unsupported or malformed supplemental adapter pin receipt")
    if receipt.get("original_grading_freeze_sha256") != FREEZE_SHA256:
        raise ValueError("supplemental receipt does not bind the original frozen grading receipt")
    pins = receipt.get("files")
    expected = {
        "adapter": EXEC_DIR / "grade_dev20_archival_split_metadata_adapter_v1.py",
        "adapter_tests": TESTS,
        "original_dev_grader": BASE_GRADER,
        "original_grading_freeze": EXEC_DIR / "grading-freeze-v1.json",
    }
    if not isinstance(pins, dict) or set(pins) != set(expected):
        raise ValueError("supplemental receipt must pin adapter, tests, original grader, and original freeze")
    for name, target in expected.items():
        entry = pins[name]
        if not isinstance(entry, dict) or entry.get("path") != target.resolve().relative_to(ROOT).as_posix():
            raise ValueError(f"supplemental receipt path mismatch: {name}")
        if entry.get("sha256") != sha(target):
            raise ValueError(f"supplemental receipt SHA mismatch: {name}")
    if pins["original_grading_freeze"].get("sha256") != FREEZE_SHA256:
        raise ValueError("original grading freeze SHA differs from the required pin")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--supplemental-pin-receipt", type=Path, required=True)
    args, rest = parser.parse_known_args(argv)
    validate_supplemental_receipt(args.supplemental_pin_receipt)
    # Preserve the original CLI, including mandatory --root-go and
    # --freeze-receipt. The original driver still performs all freeze checks.
    original_main = base.main
    globals_copy = dict(original_main.__globals__)
    globals_copy["grade_from_files"] = patched_grade_from_files
    clone = FunctionType(original_main.__code__, globals_copy, original_main.__name__, original_main.__defaults__, original_main.__closure__)
    clone.__kwdefaults__ = original_main.__kwdefaults__
    return clone(rest)


if __name__ == "__main__":
    raise SystemExit(main())
