from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '.lab-output/sku-resume-20261012-v1'
RESULTS = ROOT / 'experiments/sku-matching/results'
STEM = '20261012-sku-mixed-cpu-checkpoint'
archive = RESULTS / (STEM + '.zip')
if archive.exists():
    raise FileExistsError(archive)
inventory = json.loads((BASE / 'checkpoint-file-list.json').read_text())
names = {r['path'] for r in inventory['files']}
names.update(str(p.relative_to(ROOT)) for p in BASE.iterdir() if p.is_file())
files = []
for name in sorted(names):
    relative = Path(name)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('invalid checkpoint member')
    if any(p in relative.parts for p in ('.deps', '.aws', '.git', '.codex', 'node_modules')):
        raise ValueError('excluded runtime or credential path')
    path = ROOT / relative
    if not path.is_file() or path.is_symlink():
        raise ValueError('checkpoint source must be a regular file: ' + name)
    body = path.read_bytes()
    files.append({'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
manifest = {
    'schema_version': 'sku-mixed-cpu-checkpoint-v1',
    'starting_head': 'fbc91b9d14d73f3472e40fb34b2a049b7942aaef',
    'branch': 'codex-sku-generic-model-gates-20261010',
    'execution_device': 'cpu', 'gpu_state': 'submission_unknown',
    'gpu_submit_attempts': 1, 'gpu_measured': False,
    'independent_test_read': False, 'model_weights_included': False,
    'canonical_evaluation': '.lab-output/sku-mixed-cpu-evaluation-20261012-v4',
    'canonical_run': '.lab-output/sku-mixed-cpu-run-20261012-v1',
    'captured_sources': 'all 93 raw-captures; raw-source-registry.jsonl records original aliases and SHA',
    'restore_rule': 'verify CRC and every byte/SHA before extraction; do not overwrite a different existing source; restore raw aliases from registry only after SHA validation',
    'dependencies': inventory['dependencies'],
    'file_count': len(files), 'files': files,
}
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for row in files:
        body = (ROOT / row['path']).read_bytes()
        if len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']:
            raise ValueError('checkpoint source changed while packing')
        zipped.writestr(row['path'], body)
    zipped.writestr('CHECKPOINT_MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(archive) as zipped:
    if zipped.testzip() is not None:
        raise ValueError('checkpoint CRC failed')
    if set(zipped.namelist()) != {r['path'] for r in files} | {'CHECKPOINT_MANIFEST.json'}:
        raise ValueError('checkpoint inventory differs')
    for row in files:
        body = zipped.read(row['path'])
        if len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']:
            raise ValueError('checkpoint member SHA failed')
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
(RESULTS / (STEM + '.manifest.json')).write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(RESULTS / (STEM + '.zip.sha256')).write_text(sha + '  ' + archive.name + '\n')
(RESULTS / (STEM + '.audit.json')).write_text(json.dumps({'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'crc_verified':True,'all_member_bytes_and_sha256_verified':True,'verified_file_count':len(files)},indent=2)+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'verified_files':len(files)}))
