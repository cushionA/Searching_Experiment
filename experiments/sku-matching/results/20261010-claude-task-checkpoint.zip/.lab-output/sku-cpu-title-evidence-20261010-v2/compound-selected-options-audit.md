# Compound selected-SKU option audit

This is a source-only audit of the v9 residual task set against original AU SKU option arrays. Labels, prices, stock, model predictions, and evaluation metrics were not accessed.

## Inventory

- v9 tasks: **1383** across **29** Rakuten products.
- Literal compound axis families under the stated counting rule: **7**; **27** axis occurrences across **27** cases and **3** products.
- Delimiter-bearing values (`＋`, `+`, slash): **11** occurrences. `セット`/`組` values: **24** occurrences.

Counting rule: selected axis value contains any of `セット`, `組`, `＋`, `+`, ` / `, or `／`. This only inventories likely compounds; it does not determine the meaning of an axis.

Distinct observed families:

- `オプション=毛布セット`: 12 cases (1 product(s))
- `タイプ=スリム / グレー`: 1 cases (1 product(s))
- `タイプ=天板付き / 天然木`: 1 cases (1 product(s))
- `タイプ=本棚付き / 天然木`: 1 cases (1 product(s))
- `枚数=13枚セット(パネル12枚＋ドア1枚)`: 4 cases (1 product(s))
- `枚数=21枚セット(パネル20枚＋ドア1枚)`: 4 cases (1 product(s))
- `枚数=8枚セット(パネルのみ)`: 4 cases (1 product(s))

## Three key cases

- **21-piece pet-fence option** — 4 task cases, 1 product (`653618158`). The exact Rakuten clause `21枚セット(パネル20枚＋ドア1枚)` supports three typed atoms: total 21, 20 panels, 1 door. AU product title says 13 pieces / 12 panels plus a door; AU SKU rows expose only transparency/color. The available selected-row data does not support the 21-piece composition, and the title-level 13-piece clause is a discrepancy that needs explicit source-scope handling. See case IDs in the JSON.
- **Slim / gray** — 1 case, 1 product (`524251610`). AU row `カラー選択=グレー` supports the color atom only. `スリム` remains unresolved; AU `4段` in the title means four tiers and does not establish slimness.
- **Blanket set** — 12 cases, 1 product (`483077897`). Rakuten’s selected option adds a blanket to the base item. AU rows contain only color values, and the AU title describes a mattress pad. Color or size correspondence cannot satisfy the added blanket requirement.

Two other delimiter compounds occur once each on the same toy-rack product: `天板付き / 天然木` (included top board + solid-wood material) and `本棚付き / 天然木` (included bookshelf + solid-wood material). Available AU rows expose only gray. Generic “storage/shelf” title wording does not establish those selected components or material.

The pet-fence family also includes 13-piece `(パネル12枚＋ドア1枚)` and 8-piece `(パネルのみ)` values, each across 4 cases. Preserve total count, component counts, and presence/absence of a door as distinct requirements. Product-title/row axes should not be substituted for the selected option unless the provenance scope connects them.

## Minimal CPU follow-up

Extract candidate typed atoms for each compound axis with exact source spans and row/SKU provenance. Then require **all** explicit atoms to be supported by fixed-AU selected-row evidence. A partial hit stays review; one supported component must never satisfy the whole compound option. Emit `complete`, `partial`, or `ambiguous` decomposition and keep every unresolved atom. Start with the 27 observed occurrences in these seven families as review cards only; no synthetic benchmark, label join, or accuracy claim.

## Source integrity

- v9 task SHA-256: `1df18b67865739a19cdf45e60ac81bcc6707a2883e1f46e4cefb7c9cad9d9628`
- AU raw-array SHA-256: `862aaaebd6973090fcc8c300738c0e9e88842c5aa59c5296d67ee252950b52c3`
- AU option source lines, exact Rakuten selected row/SKU keys, source filenames, and hashes are in the companion JSON.
