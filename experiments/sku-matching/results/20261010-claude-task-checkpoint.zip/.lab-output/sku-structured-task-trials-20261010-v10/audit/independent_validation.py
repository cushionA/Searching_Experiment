"""Independently audit v10 hybrid predictions against repaired v3 labels."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import zipfile
from typing import Any

ROOT = Path(__file__).resolve().parents[3]
V10 = ROOT / ".lab-output/sku-structured-task-trials-20261010-v10"
V4 = ROOT / ".lab-output/sku-structured-task-trials-20261010-v4"
LABELS = ROOT / ".lab-output/sku-real-luna-labels-20261010-v3/labels.jsonl"
LABEL_MANIFEST = LABELS.parent / "manifest.json"
AU_ARRAYS = ROOT / ".lab-output/sku-observed-product-pairs-20261010-final-v4/au_product_sku_arrays.jsonl"
AUDIT_ZIP = Path("/workspace/attachments/9afb6300-a09f-4870-a8d8-5ca58dffecb9/sku-label-audit-20261010.zip")
OUT = V10 / "audit"


def sha(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def unique(rows: list[dict[str, Any]], field: str, name: str) -> dict[str, dict[str, Any]]:
    result = {str(row[field]): row for row in rows}
    if len(result) != len(rows):
        raise ValueError(f"Duplicate {field} in {name}")
    return result


def rate(n: int, d: int) -> float | None:
    return n / d if d else None


def assess(ids: list[str], tasks: dict, labels: dict, predictions: dict) -> dict[str, Any]:
    total = len(ids)
    decision_counts = {d: 0 for d in ("matched", "unmatched", "review")}
    gold_counts = {d: 0 for d in ("matched", "unmatched", "review")}
    gold_matched = 0
    predicted_accepted = tp = fp = known_fp = review_fp = wrong_row = 0
    predicted_review = predicted_unmatched = 0
    false_reject = deferred_positive = rejected_unmatched = rejected_review = 0
    known_labels = known_auto = correct_known_auto = 0
    correct_known_total = 0
    for cid in ids:
        label = labels[cid]
        pred = predictions[cid]
        gold = label["decision"]
        decision = pred["decision"]
        row_key = pred.get("top_row_key")
        correct_row = gold == "matched" and row_key in set(label.get("matching_au_row_keys") or [])
        gold_counts[gold] += 1
        decision_counts[decision] += 1
        if gold == "matched":
            gold_matched += 1
            if decision == "unmatched":
                false_reject += 1
                rejected_unmatched += 1
            elif decision == "review":
                deferred_positive += 1
                rejected_review += 1
        if gold != "review":
            known_labels += 1
            decision_correct = ((gold == "matched" and decision == "matched" and correct_row)
                                or (gold == "unmatched" and decision == "unmatched"))
            correct_known_auto += int(decision_correct and decision in {"matched", "unmatched"})
            correct_known_total += int(decision_correct)
            if decision in {"matched", "unmatched"}:
                known_auto += 1
        if decision == "matched":
            predicted_accepted += 1
            if correct_row:
                tp += 1
            else:
                fp += 1
                if gold == "review":
                    review_fp += 1
                else:
                    known_fp += 1
                    wrong_row += int(gold == "matched")
        elif decision == "review":
            predicted_review += 1
        elif decision == "unmatched":
            predicted_unmatched += 1

    all_review_ids = [cid for cid in ids if labels[cid]["decision"] == "review"]
    accepted_gold_review = sum(predictions[cid]["decision"] == "matched" for cid in all_review_ids)
    return {
        "case_count": total,
        "gold_counts": gold_counts,
        "prediction_counts": decision_counts,
        "accepted": {
            "correct_exact_row": tp,
            "total_predicted_matched": predicted_accepted,
            "precision": rate(tp, predicted_accepted),
            "recall_on_gold_matched": rate(tp, gold_matched),
            "false_accepts_total": fp,
            "false_accepts_known_unmatched_or_wrong_row": known_fp,
            "false_accepts_gold_review": review_fp,
            "wrong_au_row_accepts_on_gold_matched": wrong_row,
            "precision_on_gold_known_labels": rate(tp, tp + known_fp),
        },
        "gold_matched_outcomes": {
            "false_reject_predicted_unmatched": false_reject,
            "false_reject_rate_on_gold_matched": rate(false_reject, gold_matched),
            "deferred_positive_predicted_review": deferred_positive,
            "deferred_positive_rate_on_gold_matched": rate(deferred_positive, gold_matched),
            "match_recall_missing_false_reject_plus_deferred_positive": false_reject + deferred_positive,
            "match_recall_missing_rate_on_gold_matched": rate(false_reject + deferred_positive, gold_matched),
            "predicted_unmatched": rejected_unmatched,
            "predicted_review": rejected_review,
        },
        "auto_known": {
            "gold_known_label_count": known_labels,
            "auto_decided_gold_known_count": known_auto,
            "coverage_of_gold_known_labels": rate(known_auto, known_labels),
            "all_case_auto_decision_coverage": rate(decision_counts["matched"] + decision_counts["unmatched"], total),
            "correct_decisions_on_auto_decided_known": correct_known_auto,
            "accuracy_on_auto_decided_known": rate(correct_known_auto, known_auto),
            "correct_end_to_end_decisions_over_all_gold_known": rate(correct_known_total, known_labels),
        },
        "gold_review_cases": {"count": len(all_review_ids), "accepted_matched": accepted_gold_review,
                              "accepted_case_ids": [cid for cid in all_review_ids if predictions[cid]["decision"] == "matched"]},
    }


def main() -> None:
    for p in (V10 / "tasks.jsonl", V10 / "manifest.json", V10 / "enrichment-manifest.json",
              V10 / "evidence.jsonl", V10 / "hybrid/predictions.jsonl", V10 / "hybrid/summary.json",
              V4 / "tasks.jsonl", LABELS, LABEL_MANIFEST, AU_ARRAYS, AUDIT_ZIP):
        if not p.is_file():
            raise FileNotFoundError(p)
    if any((OUT / name).exists() for name in ("independent-validation.json", "independent-validation.csv", "manifest.json")):
        raise FileExistsError(f"Refusing to overwrite audit artifacts: {OUT}")
    label_manifest = json.loads(LABEL_MANIFEST.read_text(encoding="utf-8"))
    label_input_dir = Path(label_manifest["input_dir"])
    label_input_manifest = label_input_dir / "manifest.json"
    label_cases = label_input_dir / "cases.jsonl"
    source_paths = [V10 / "tasks.jsonl", V10 / "manifest.json", V10 / "enrichment-manifest.json",
                    V10 / "evidence.jsonl", V10 / "hybrid/predictions.jsonl", V10 / "hybrid/summary.json",
                    V4 / "tasks.jsonl", LABELS, LABEL_MANIFEST, label_input_manifest, label_cases,
                    AU_ARRAYS, AUDIT_ZIP]
    before = {p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else str(p): sha(p) for p in source_paths}
    if sha(LABELS) != label_manifest.get("output_sha256", {}).get(LABELS.name):
        raise ValueError("Repaired v3 label file does not match its manifest")
    if sha(label_input_manifest) != label_manifest.get("input_manifest_sha256"):
        raise ValueError("Repaired v3 labels do not reference the current v3 input manifest")
    if sha(label_cases) != label_manifest.get("cases_sha256"):
        raise ValueError("Repaired v3 labels do not reference the current v3 cases file")
    audit_meta = label_manifest["audit_bundle"]["manifest"]
    if sha(AUDIT_ZIP) != label_manifest["audit_bundle"]["sha256"]:
        raise ValueError("External audit archive hash does not match repaired label manifest")
    with zipfile.ZipFile(AUDIT_ZIP) as archive:
        proposal_path = next(p for p in archive.namelist() if p.endswith("review-proposals-35.jsonl"))
        proposal_sha = hashlib.sha256(archive.read(proposal_path)).hexdigest()
        declared = audit_meta["files"]["review-proposals-35.jsonl"]["sha256"]
        if proposal_sha != declared:
            raise ValueError("External 35-case proposal digest does not match the archive manifest")
        external_rows = [json.loads(line) for line in archive.read(proposal_path).decode("utf-8").splitlines() if line.strip()]
    external_ids = [row["case_id"] for row in external_rows]
    if len(external_ids) != 35 or len(set(external_ids)) != 35:
        raise ValueError("Expected 35 unique external audit proposal cases")
    tasks_rows, v4_rows = read_jsonl(V10 / "tasks.jsonl"), read_jsonl(V4 / "tasks.jsonl")
    labels_rows = read_jsonl(LABELS)
    prediction_rows = read_jsonl(V10 / "hybrid/predictions.jsonl")
    tasks = unique(tasks_rows, "case_id", "v10 tasks")
    old_tasks = unique(v4_rows, "case_id", "v4 tasks")
    labels = unique(labels_rows, "case_id", "v3 labels")
    predictions = unique(prediction_rows, "case_id", "v10 hybrid predictions")
    if not tasks.keys() == old_tasks.keys() == labels.keys() == predictions.keys() or len(tasks) != 1383:
        raise ValueError("v10 tasks, v4 task set, v3 labels and hybrid predictions must match exactly at 1,383 cases")
    if not set(external_ids) <= tasks.keys():
        raise ValueError("External audit proposals contain cases outside the frozen task set")
    if not set(labels) <= predictions.keys():
        raise ValueError("Predictions do not cover all repaired-label cases")
    task_manifest = json.loads((V10 / "manifest.json").read_text(encoding="utf-8"))
    enrichment = json.loads((V10 / "enrichment-manifest.json").read_text(encoding="utf-8"))
    hybrid_summary = json.loads((V10 / "hybrid/summary.json").read_text(encoding="utf-8"))
    actual_tasks_sha = sha(V10 / "tasks.jsonl")
    evidence_sha = sha(V10 / "evidence.jsonl")
    if actual_tasks_sha != task_manifest.get("tasks_sha256") or actual_tasks_sha != enrichment.get("tasks_sha256"):
        raise ValueError("v10 task SHA does not match its task/enrichment manifests")
    if evidence_sha != enrichment.get("evidence_sha256"):
        raise ValueError("v10 evidence SHA does not match enrichment manifest")
    if task_manifest.get("source_sha256_pre") != task_manifest.get("source_sha256_post"):
        raise ValueError("v10 task generation source pre/post hashes differ")
    source_map = task_manifest.get("source_sha256_post") or {}
    source_map_verified = 0
    for source_name, expected_sha in source_map.items():
        source_path = Path(source_name)
        if not source_path.is_absolute():
            source_path = ROOT / source_path
        if not source_path.is_file() or sha(source_path) != expected_sha:
            raise ValueError(f"v10 task-generation source hash differs on disk: {source_name}")
        source_map_verified += 1
    if enrichment.get("model_labels_used_for_preparation") is not False or task_manifest.get("labels_read_for_preparation") is not False:
        raise ValueError("v10 task/enrichment preparation unexpectedly consulted labels")
    if hybrid_summary.get("input_sha256_pre") != hybrid_summary.get("input_sha256_post"):
        raise ValueError("Hybrid prediction inputs changed during inference")
    if hybrid_summary.get("predictions_sha256") != sha(V10 / "hybrid/predictions.jsonl"):
        raise ValueError("Hybrid predictions file SHA does not match summary")
    if hybrid_summary.get("labels_used_for_prediction") is not False:
        raise ValueError("Hybrid prediction claims to have consulted labels")
    if hybrid_summary.get("input_sha256_pre", {}).get(str((V10 / "tasks.jsonl").relative_to(ROOT))) != actual_tasks_sha:
        raise ValueError("Hybrid task input hash does not match v10 tasks")
    if hybrid_summary.get("input_sha256_pre", {}).get(str(LABELS.relative_to(ROOT))) != sha(LABELS):
        raise ValueError("Hybrid post-prediction label join does not reference the v3 repaired label file")

    # Check task-to-task candidate rows and then anchor every AU key to final observed arrays.
    candidate_differences = []
    for cid, task in tasks.items():
        new_keys = [x["row_key"] for x in task.get("au_candidates", [])]
        old_keys = [x["row_key"] for x in old_tasks[cid].get("au_candidates", [])]
        if new_keys != old_keys:
            candidate_differences.append(cid)
        predicted_key = predictions[cid].get("top_row_key")
        if predicted_key not in set(new_keys):
            raise ValueError(f"Hybrid top row is outside AU candidate list for {cid}")
    if candidate_differences:
        raise ValueError(f"v10 changed the actual AU candidate key lists vs v4 in {len(candidate_differences)} cases")
    arrays = read_jsonl(AU_ARRAYS)
    observed_keys = set()
    for product in arrays:
        product_id = str(product.get("au_product_id") or product.get("product_id"))
        cells = product.get("au_sku_cells_raw") or product.get("sku_string_array_projection") or []
        for cell in cells:
            grain = cell.get("source_grain") or {}
            if all(grain.get(field) is not None for field in ("sku_id", "row_index", "column_index")):
                observed_keys.add(f"au:{product_id}:{grain['sku_id']}:{grain['row_index']}:{grain['column_index']}")
    all_candidate_keys = {item["row_key"] for task in tasks.values() for item in task.get("au_candidates", [])}
    missing_observed = sorted(all_candidate_keys - observed_keys)
    if missing_observed:
        raise ValueError(f"AU task rows absent from the final observed array: {missing_observed[:5]}")

    splits = {"all": list(tasks), "dev": [cid for cid, task in tasks.items() if task.get("split") == "dev"],
              "reused_test": [cid for cid, task in tasks.items() if task.get("split") == "test"]}
    categories = {
        "curtain": [cid for cid, task in tasks.items() if (task.get("rakuten", {}).get("attrs") or {}).get("category") == "curtain"],
        "non_curtain": [cid for cid, task in tasks.items() if (task.get("rakuten", {}).get("attrs") or {}).get("category") != "curtain"],
    }
    cohort_ids = dict(splits)
    for name, ids in categories.items():
        cohort_ids[name] = ids
    for split in ("dev", "reused_test"):
        for category, category_ids in categories.items():
            cohort_ids[f"{split}_{category}"] = [cid for cid in splits[split] if cid in set(category_ids)]
    cohort_results = {name: assess(ids, tasks, labels, predictions) for name, ids in cohort_ids.items()}

    # Verify no accepted match claims same SKU across explicit opposite lace flags.
    lace_opposite_candidate_pairs = 0
    lace_opposite_candidate_cases = set()
    accepted_lace_crosslinks = []
    predicted_top_lace_conflicts = []
    for cid, task in tasks.items():
        query_lace = (task.get("rakuten", {}).get("attrs") or {}).get("lace")
        if not isinstance(query_lace, bool):
            continue
        candidates = {c["row_key"]: c for c in task.get("au_candidates", [])}
        opposite = []
        for candidate in candidates.values():
            value = (candidate.get("attrs") or {}).get("lace")
            if isinstance(value, bool) and value != query_lace:
                opposite.append(candidate["row_key"])
        if opposite:
            lace_opposite_candidate_cases.add(cid)
            lace_opposite_candidate_pairs += len(opposite)
        pred_key = predictions[cid].get("top_row_key")
        top = candidates.get(pred_key)
        top_lace = (top.get("attrs") or {}).get("lace") if top else None
        if isinstance(top_lace, bool) and top_lace != query_lace:
            predicted_top_lace_conflicts.append(cid)
            if predictions[cid].get("decision") == "matched":
                accepted_lace_crosslinks.append(cid)

    review_ids = {cid for cid, label in labels.items() if label.get("decision") == "review"}
    external_accepts = [cid for cid in external_ids if predictions[cid].get("decision") == "matched"]
    if len(review_ids) != 37 or not review_ids <= tasks.keys():
        raise ValueError("Expected all 37 repaired-label review cases within task set")

    # Cross-check independent results against the frozen hybrid's published summary.
    metric_checks = []
    for split_name, summary_key in (("all", "all"), ("dev", "dev"), ("reused_test", "test")):
        calculated = cohort_results[split_name]
        reported = hybrid_summary.get("results", {}).get(summary_key, {}).get("overall", {})
        comparisons = {
            "case_count": calculated["case_count"],
            "correct_row_match_count": calculated["accepted"]["correct_exact_row"],
            "known_false_accept_count_including_wrong_au_row": calculated["accepted"]["false_accepts_known_unmatched_or_wrong_row"],
            "known_case_precision": calculated["accepted"]["precision_on_gold_known_labels"],
            "known_case_recall": calculated["accepted"]["recall_on_gold_matched"],
            "review_unknown_accept_count": calculated["accepted"]["false_accepts_gold_review"],
        }
        for key, value in comparisons.items():
            reported_value = reported.get(key)
            if isinstance(value, float) and reported_value is not None:
                if abs(value - float(reported_value)) > 1e-10:
                    metric_checks.append({"split": split_name, "key": key, "computed": value, "reported": reported_value})
            elif value != reported_value:
                metric_checks.append({"split": split_name, "key": key, "computed": value, "reported": reported_value})

    post = {p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else str(p): sha(p) for p in source_paths}
    if before != post:
        raise RuntimeError("One or more frozen inputs changed during independent validation")
    source_hashes = before
    external_expected_zero = len(external_accepts) == 0
    review_expected_zero = sum(predictions[cid].get("decision") == "matched" for cid in review_ids) == 0
    lace_expected_zero = len(accepted_lace_crosslinks) == 0
    result = {
        "schema_version": "sku-hybrid-independent-validation-v2",
        "method": "independent row-level recomputation from v10 tasks, v3 repaired labels, and hybrid predictions",
        "human_verified_gold": False,
        "label_status": "v3 source-audit-revised Luna machine labels; not independent gold and not human-verified",
        "test_status": "previously inspected and reused diagnostic; not a fresh holdout",
        "label_counts": label_manifest["decision_counts"],
        "primary_gold_cohorts": cohort_results,
        "required_negative_checks": {
            "all_37_gold_review_cases": {"count": len(review_ids), "accepted_count": sum(predictions[cid]["decision"] == "matched" for cid in review_ids),
                                          "accepted_case_ids": sorted(cid for cid in review_ids if predictions[cid]["decision"] == "matched"),
                                          "passed_zero_accepted": review_expected_zero},
            "external_audit_review_proposals_35": {"count": len(external_ids), "accepted_count": len(external_accepts),
                                                   "accepted_case_ids": external_accepts,
                                                   "source_archive_sha256": sha(AUDIT_ZIP),
                                                   "proposal_file_sha256": proposal_sha,
                                                   "recommendation_counts": {d: sum(x.get("recommended_decision") == d for x in external_rows)
                                                                             for d in ("matched", "unmatched", "review")},
                                                   "passed_zero_accepted": external_expected_zero},
            "explicit_opposite_lace_flags": {"cases_with_at_least_one_opposite_lace_candidate": len(lace_opposite_candidate_cases),
                                             "opposite_lace_candidate_pairs": lace_opposite_candidate_pairs,
                                             "predicted_top_rows_with_opposite_explicit_lace": len(predicted_top_lace_conflicts),
                                             "accepted_opposite_lace_crosslinks": len(accepted_lace_crosslinks),
                                             "accepted_crosslink_case_ids": accepted_lace_crosslinks,
                                             "passed_zero_accepted_crosslinks": lace_expected_zero},
        },
        "candidate_integrity": {"v10_task_count": len(tasks), "v4_task_count": len(old_tasks),
                                "labels_count": len(labels), "predictions_count": len(predictions),
                                "case_membership_exact": True, "duplicate_case_ids": False,
                                "ordered_candidate_key_lists_equal_v4": True,
                                "task_candidate_key_count_unique": len(all_candidate_keys),
                                "missing_from_final_observed_au_arrays": 0,
                                "final_observed_array_row_key_count": len(observed_keys)},
        "summary_reproduction": {"primary_all_dev_reused_test_metrics_match_hybrid_summary": not metric_checks,
                                 "mismatches": metric_checks},
        "input_integrity": {"v10_task_sha256": actual_tasks_sha, "enrichment_task_sha256": enrichment["tasks_sha256"],
                            "v10_evidence_sha256": evidence_sha, "enrichment_evidence_sha256": enrichment["evidence_sha256"],
                            "hybrid_prediction_sha256": sha(V10 / "hybrid/predictions.jsonl"),
                            "hybrid_summary_prediction_sha256": hybrid_summary["predictions_sha256"],
                            "input_hashes_pre_post_equal": True, "task_source_pre_post_equal": True,
                            "enrichment_did_not_use_labels": True,
                            "v3_label_sha256": sha(LABELS), "v3_label_manifest_sha256": sha(LABEL_MANIFEST),
                            "v3_input_manifest_sha256": label_manifest["input_manifest_sha256"],
                            "v3_cases_sha256": label_manifest["cases_sha256"],
                            "v3_audit_bundle_sha256": label_manifest["audit_bundle"]["sha256"],
                            "v10_task_generation_source_file_count": source_map_verified,
                            "source_sha256_pre_post": {"pre": source_hashes, "post": post}},
        "interpretation_limits": [
            "Matched precision and recall require an exact AU SKU row, not only a predicted match decision.",
            "Auto-known accuracy and coverage exclude unresolved review predictions from the covered-known denominator; review-label accepts are reported separately.",
            "v3 labels incorporate source-audit recommendations but remain machine-annotated, human-unverified and are not independent gold.",
            "Test is a reused, previously inspected diagnostic split.",
            "External 35-case audit recommendations are a targeted challenge set, not an independent representative test set.",
            "Opposite-lace crosslinks only count cases where both Rakuten and the predicted AU row have explicit Boolean lace flags with opposite values.",
        ],
        "source_sha256": source_hashes,
    }

    csv_rows = []
    for cohort, metrics in cohort_results.items():
        csv_rows.append({
            "cohort": cohort, "cases": metrics["case_count"],
            "gold_matched": metrics["gold_counts"]["matched"], "gold_unmatched": metrics["gold_counts"]["unmatched"],
            "gold_review": metrics["gold_counts"]["review"],
            "accepted_correct_same_row": metrics["accepted"]["correct_exact_row"],
            "accepted_predictions": metrics["accepted"]["total_predicted_matched"],
            "accepted_precision": metrics["accepted"]["precision"], "accepted_recall": metrics["accepted"]["recall_on_gold_matched"],
            "false_accepts_total": metrics["accepted"]["false_accepts_total"],
            "false_accepts_gold_review": metrics["accepted"]["false_accepts_gold_review"],
            "false_rejects_gold_matched": metrics["gold_matched_outcomes"]["false_reject_predicted_unmatched"],
            "deferred_positive_gold_matched": metrics["gold_matched_outcomes"]["deferred_positive_predicted_review"],
            "match_recall_missing_gold_matched": metrics["gold_matched_outcomes"]["match_recall_missing_false_reject_plus_deferred_positive"],
            "false_reject_rate": metrics["gold_matched_outcomes"]["false_reject_rate_on_gold_matched"],
            "auto_known_accuracy_covered": metrics["auto_known"]["accuracy_on_auto_decided_known"],
            "auto_known_coverage": metrics["auto_known"]["coverage_of_gold_known_labels"],
            "all_case_auto_coverage": metrics["auto_known"]["all_case_auto_decision_coverage"],
            "review_gold_accepts": metrics["gold_review_cases"]["accepted_matched"],
        })
    csv_rows.extend([
        {"cohort": "all_gold_review_37", "cases": len(review_ids),
         "accepted_predictions": sum(predictions[cid]["decision"] == "matched" for cid in review_ids),
         "accepted_precision": None, "accepted_recall": None, "review_gold_accepts": sum(predictions[cid]["decision"] == "matched" for cid in review_ids)},
        {"cohort": "external_audit_proposals_35", "cases": len(external_ids),
         "accepted_predictions": len(external_accepts), "accepted_precision": None, "accepted_recall": None,
         "review_gold_accepts": None},
        {"cohort": "explicit_opposite_lace", "cases": len(lace_opposite_candidate_cases),
         "accepted_predictions": len(accepted_lace_crosslinks), "accepted_precision": None, "accepted_recall": None,
         "review_gold_accepts": None},
    ])
    json_path = OUT / "independent-validation.json"
    csv_path = OUT / "independent-validation.csv"
    with json_path.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    fields = ["cohort", "cases", "gold_matched", "gold_unmatched", "gold_review",
              "accepted_correct_same_row", "accepted_predictions", "accepted_precision", "accepted_recall",
              "false_accepts_total", "false_accepts_gold_review", "false_rejects_gold_matched", "false_reject_rate", "deferred_positive_gold_matched", "match_recall_missing_gold_matched",
              "auto_known_accuracy_covered", "auto_known_coverage", "all_case_auto_coverage", "review_gold_accepts"]
    with csv_path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(csv_rows)
    manifest = {"schema_version": "sku-hybrid-independent-validation-manifest-v1",
                "source_sha256": source_hashes,
                "builder_sha256": sha(Path(__file__)),
                "validation_json_sha256": sha(json_path),
                "validation_csv_sha256": sha(csv_path),
                "source_file_count": len(source_hashes), "csv_row_count": len(csv_rows),
                "audit_passes": {"label_and_candidate_membership": True,
                                 "summary_metrics_reproduced": not metric_checks,
                                 "all_37_review_zero_accept": review_expected_zero,
                                 "external_35_zero_accept": external_expected_zero,
                                 "opposite_lace_zero_crosslink": lace_expected_zero}}
    with (OUT / "manifest.json").open("x", encoding="utf-8") as stream:
        json.dump(manifest, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"output": str(OUT), "cohorts": len(cohort_results), "csv_rows": len(csv_rows),
                      "metric_mismatches": len(metric_checks), "review_cases_accepted": result["required_negative_checks"]["all_37_gold_review_cases"]["accepted_count"],
                      "external35_accepted": len(external_accepts), "lace_crosslinks": len(accepted_lace_crosslinks)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
