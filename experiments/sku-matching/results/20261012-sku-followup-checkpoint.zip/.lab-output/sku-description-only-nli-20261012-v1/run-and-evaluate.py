from pathlib import Path
from collections import Counter
from copy import deepcopy
import json
import os
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import evaluate_mixed_gpu_sku_v1 as E
import evaluate_keyword_filtered_product_v1 as REFERENCES
import trial_keyword_filtered_product_v1 as VERIFY
import trial_product_condition_models_v1 as PRODUCT
import product_condition_sharing_v1 as SHARING

OUT = Path(__file__).resolve().parent
PREP = ROOT/'.lab-output/sku-mixed-gpu-prep-20261012-v5'
CPU = ROOT/'.lab-output/sku-mixed-cpu-run-20261012-v1'
OLD_EVAL = ROOT/'.lab-output/sku-mixed-cpu-evaluation-20261012-v4'
ROUTES = ROOT/'.lab-output/sku-mixed-cpu-reference-routes-20261012-v2'
SOURCE = CPU/'product-model'
MODEL = ROOT/'.deps/sku-fixed-models/nli'
POLICIES = ('description-only-joint-support','description-only-conflict-veto')

def sha(p): return E.sha(Path(p))
def read_json(p): return json.loads(Path(p).read_text())
def read_rows(p): return list(E.rows(Path(p)))
def index(p,key): return E.GATE.indexed(Path(p),key)
def raw_class(r):
    values=r.get('probabilities')
    if not isinstance(values,dict) or set(values)!={'support','conflict','unknown'}:
        return None
    maximum=max(values.values())
    winners=[k for k,v in values.items() if v==maximum]
    return winners[0] if len(winners)==1 and not r.get('error_type') else None

manifest,requests,documents,tasks,cases,membership,hosts=E.load_mixed_prepared(PREP)
cpu_summary,_=E.verify_cpu_run(PREP,CPU,manifest,requests)
fusion_baseline,original_predictions,eligible=E.check_prediction_coverage(PREP,CPU,requests,documents,tasks,cpu_summary)
source=VERIFY.verify_source(SOURCE)
groups=source['groups']
blocks=source['blocks']
group_map={g['group_id']:g for g in groups}
jev=read_rows(SOURCE/'jev-classification-options.jsonl')
old_groups=index(SOURCE/'product-top3-jev-group-results.jsonl','group_id')
plan=source['plan']
saved={v:index(CPU/'baseline-refresh/baseline-model'/f'{v}-predictions.jsonl','request_id') for v in ('jev','nli')}
baseline={rid:saved['nli' if r['direction']=='rakuten_to_au' else 'jev'][rid] for rid,r in requests.items()}
assert len(baseline)==134 and len(set(requests)-eligible)==54
pairs=[]
for pair in read_rows(SOURCE/'model-nli-pairs.jsonl'):
    group=group_map[pair['group_id']]
    block=blocks[pair['block_id']]
    assert pair['premise']==PRODUCT.state_for(group,block)
    assert pair['option_value'] in group['option_values']
    assert pair['hypothesis']==PRODUCT.V1.HYPOTHESIS_TEMPLATE.format(axis_name=group['axis_name'],selected_value=pair['option_value'])
    pairs.append({**pair,'id':'description-only:'+pair['id'],
        'premise':'このページの商品説明（表の文脈を含み、リンク文を除く）：\n'+block['model_passage'],
        'quote_refs':[r for r in pair['quote_refs'] if r['field']=='description'],
        'title_in_model_input':False,'title_context_omitted':group['title']})
E.write_rows(OUT/'model-nli-pairs.jsonl',pairs)
code_sources={name:(PRODUCT.HERE/'manifests/reranker.json' if name=='reranker.json' else PRODUCT.HERE/name)
              for name in source['summary']['code_sha256']}
source_paths=[PREP/'manifest.json',*(PREP/name for name in E.PREP_FILES),
    CPU/'summary.json',CPU/'cpu-source-freeze.json',CPU/'execution-freeze.json',
    SOURCE/'summary.json',SOURCE/'freeze.json',SOURCE/'sharing-plan.json',SOURCE/'product-top3-jev-group-results.jsonl',
    SOURCE/'model-nli-pairs.jsonl',SOURCE/'jev-classification-options.jsonl',
    *(CPU/'baseline-refresh/baseline-model'/f'{v}-predictions.jsonl' for v in ('jev','nli')),
    Path(__file__),Path(E.__file__),Path(REFERENCES.__file__),Path(VERIFY.__file__),
    OUT/'model-nli-pairs.jsonl',*code_sources.values()]
frozen={str(p):sha(p) for p in source_paths}
E.write_json(OUT/'execution-freeze.json',{
    'schema_version':'sku-description-only-nli-v1','experiment_status':'exploratory_dev_informed',
    'labels_read':False,'independent_test':False,'source_sha256':frozen,
    'policies':list(POLICIES),'minimum_votes':2,'new_models':False,
    'model_pins':source['summary']['verified_nli_pin'],'new_input':'same complete original hypotheses and blocks, title removed from premise',
    'invariants':'genuine sharing, all raw options, same row, nonshared NLI forward/JEV reverse',
    'production_adoption_allowed':False})
os.environ.update(CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
unique=PRODUCT.FULL.unique_inputs(pairs,lambda p:PRODUCT.NLI.pair_key(p['premise'],p['hypothesis']))
cache={};runtime={};pins=None
with PRODUCT.FULL.reuse_nli_factories():
    for offset in range(0,len(unique),128):
        result=PRODUCT.FULL.score_nli_chunk(PRODUCT.NLI.run_pairs,unique[offset:offset+128],MODEL,4,16)
        assert [r['id'] for r in result['records']]==[r['id'] for r in unique[offset:offset+128]]
        cache.update({r['cache_key']:r for r in result['records']})
        PRODUCT.FULL._accumulate(runtime,result['runtime'])
        pins=result['pins']
        print(json.dumps({'stage':'description-only-nli','completed_unique_pairs':min(offset+128,len(unique)),'total_unique_pairs':len(unique)}),flush=True)
records=PRODUCT.NLI.run_pairs(pairs,model_dir=MODEL,threads=4,batch_size=16,cache=cache)['records']
E.write_rows(OUT/'nli-classification-options.jsonl',records)
for path,want in frozen.items(): assert sha(path)==want,path
E.verify_cpu_run(PREP,CPU,manifest,requests)
VERIFY.verify_source(SOURCE)
assert pins['precision']=='fp32' and pins['device']=='cpu'
assert pins['file_sha256']==PRODUCT.NLI.NLI_FILE_SHA256
assert pins['model_id']==PRODUCT.NLI.MODEL_ID and pins['revision']==PRODUCT.NLI.MODEL_REVISION
joint=PRODUCT.group_results(groups,jev,records,documents,blocks,'product-top3-verified')
lookup={(r['group_id'],r['block_id'],r['option_value']):r for r in records}
veto=deepcopy(old_groups)
vetoed=[]
for gid,result in veto.items():
    if result['status']!='ok': continue
    conflicts=[bid for bid in result['supporting_block_ids']
        if not VERIFY.is_explicit_keyword_block(blocks[bid])
        and raw_class(lookup.get((gid,bid,result['winning_value']),{}))=='conflict']
    result['description_only_conflict_blocks']=conflicts
    if len(conflicts)>=2:
        vetoed.append(gid)
        result.update(status='unknown',winning_value=None,quote_refs=[],supporting_block_ids=[],
                      reason='two_description_only_raw_nli_conflicts')
group_sets={POLICIES[0]:joint,POLICIES[1]:veto}
gates={};gate_shas={}
for policy,results in group_sets.items():
    directory=OUT/policy;directory.mkdir(exist_ok=False)
    E.write_rows(directory/'group-results.jsonl',results.values())
    predictions=SHARING.fan_out(plan,results,baseline)
    predicted={p['request_id']:p for p in predictions}
    E.SHARED.validate_shared_predictions(requests,documents,tasks,predicted,baseline,eligible,'product-top3-jev')
    assert all(predicted[k]==baseline[k] for k in set(requests)-eligible)
    E.write_rows(directory/'predictions.jsonl',predictions)
    E.GATE.finish(PREP,directory/'predictions.jsonl',directory/'gates')
    gates[policy]=index(directory/'gates/decisions.jsonl','case_id')
    assert set(gates[policy])==set(cases)
    gate_shas.update({str(p):sha(p) for p in directory.rglob('*') if p.is_file()})
E.write_json(OUT/'all-gates-frozen.json',{'labels_read':False,'all_gates_frozen':True,'case_count':83,'request_count':134,'gate_sha256':gate_shas})
_,_,_,references,old_results=REFERENCES.verify_original_sources(PREP,OLD_EVAL,ROUTES)
score_ids={r['case_id'] for r in E.eligibility_rows(membership,hosts)[0] if r['primary_score_eligible']}
scored={k:v for k,v in references.items() if k in score_ids and not v.get('reference_uncertain',False)}
assert len(scored)==73
score_rows=[];metrics={}
for policy in POLICIES:
    metrics[policy]={}
    for stratum in E.STRATA:
        subset={k:v for k,v in scored.items() if membership[k]['membership_strata']==[stratum]}
        m=E.metrics_for(gates[policy],subset)
        metrics[policy][stratum]={k:v for k,v in m.items() if k!='case_results'}
        score_rows.extend({'policy':policy,'stratum':stratum,**r} for r in m['case_results'])
    m=E.metrics_for(gates[policy],scored)
    metrics[policy]['scored_primary_reference_union']={k:v for k,v in m.items() if k!='case_results'}
E.write_rows(OUT/'case-results.jsonl',score_rows)
for path,want in {**frozen,**gate_shas}.items():assert sha(path)==want,path
E.write_json(OUT/'summary.json',{
    'schema_version':'sku-description-only-nli-result-v1','experiment_status':'exploratory_dev_informed',
    'independent_test':False,'production_adoption_allowed':False,'scored_case_count':73,
    'labels_read_after_all_gates_frozen':True,'source_hashes_verified_after_inference_and_scoring':True,
    'verified_nli_pin':pins,'nli_runtime':runtime,'unique_inferred_pair_count':len(unique),'pair_count':len(pairs),
    'two_conflict_vetoed_group_ids':vetoed,'variants':metrics,
    'output_sha256':{str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()}})
print(json.dumps({p:metrics[p]['scored_primary_reference_union'] for p in POLICIES}),flush=True)
