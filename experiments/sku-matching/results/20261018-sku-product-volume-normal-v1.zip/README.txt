商品単位SKU突合：通常用途ボリュームテスト用（2026-10-18 JST）

本体: 実際の楽天→au 商品ペア 152件。
楽天の全実在SKU 1,934件 / auの全実在SKU 1,600件。
全比較候補 45,454組。最大は楽天60 SKU×au60行。
価格・在庫で行を除外せず、片側だけの軸、複合表現、追加品を含む通常の混合集です。軸数の異なる商品も36件あります。

使うファイル
inputs/products.jsonl : 1行=1商品ペア。各行に両サイトの商品名、URL、全SKU、軸の全選択肢、説明文を含みます。
packets/*.json       : 同じ152入力を1商品1ファイルにしたものです。JSONLと重複して実行しないでください。
subsets.json         : smoke_10 / normal_50 / all_152 / largest_20 の商品ID。すべて同じ本体からの部分集合です。
products.csv         : 商品別SKU数・候補数・説明モードの一覧。
TASK.txt             : 商品単位での推奨依頼文。モデル/APIの実行は含みません。
schemas/             : 入力と推奨出力のJSON Schema。
annotation_template.csv : 人手注釈用の空欄テンプレート。正解ではありません。
PROFILE.json         : 件数・サイズ分布・欠損状況。
source_records/      : 取得原本との対応、選定条件、除外記録。モデル入力ではありません。元レコード内の色語彙/クロスウォーク等もモデル用JSONから除外しています。
sources/             : SHA256で重複排除した公開ページ/API応答の原本298ファイル。
scripts/             : 作成処理・既存抽出器・原本照合を含む検証コード。
validation.ipynb     : プロファイルと原本整合性を再確認する小さなノートブック。

説明文
auのitemComment/detailComment/extraItemCommentの既存説明欄を対象にします。楽天は既存のspan.item_descを対象にします。適格な仕様表があるときは表だけを選び、ないときはその説明欄の全文に戻します。fallbackではリンクの可視文言を残し、選択範囲内のリンク先URLもlinksへ保存しています。未知の本文を推測して補完していません。
テキストが取れない側はunavailableです。楽天10件・au1件あり、画像のみ/対象の説明領域がない場合等を含みます。SKU列挙の網羅性と本文テキストの充足は別です。原本は収録されています。

通常セットとは、保存済みコーパスの一般的な混合集という意味で、市場全体の分布を代表する無作為標本ではありません。beauty/apparel/foodは元収集フォルダー名で、正確な商品カテゴリではありません。
保存時点の両サイト原本SHA・全楽天variantId/selectorValues・au stockList全実在セルを検証した152ペアだけを収録しました。選択肢の直積は生成せず、売切れ行も残しています。原本不足60商品と、楽天variant1件が不足する1商品を除外しました。Webの現在状態の完全性ではありません。
商品ペアは従来の候補対応で、人手で商品同一性やSKU正解を確認したものではありません。正解ラベル・モデル予測は含みません。通常の入力形状・負荷・処理比較に使い、精度測定には別途注釈を用意してください。過去の開発/評価で使われたデータなので、新しい独立評価とは扱えません。元TRAIN72/EVAL80の区分はprovenanceに保存しています。

追加購入オプション
has_paid_options/has_free_optionsやobserved_unselected_textは選択済みの証明ではありません。complete_value_lists/current_selected_valuesは未取得のままnullです。SKU行だけで表せない必要購入条件を保持してください。

別枠のau_only_stress/
実au 58商品・2,937 SKU、最大300 SKUの入力サイズ/負荷用資料です。楽天側を複製していません。楽天との対応は未取得で、通常ペアの精度評価や152商品の件数へ混ぜないでください。原本とSKU行を含みます。

検証方法（Python標準ライブラリのみ）
python3 -B scripts/verify_product_volume_normal_v1.py .
検証はsourcesのSHA、元SKUとの対応、全行被覆、説明文の再抽出一致まで確認します。生ページのリンク先は取得せず、外部APIやモデルは呼びません。入力をJSON Schemaで検査したい場合は、お使いの標準JSON Schemaバリデータでschemas/product-pair.schema.jsonを使ってください。
