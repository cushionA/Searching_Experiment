"""Freeze the already reviewed 14-case v9 diagnostic into private Kaggle transport."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / '.lab-output/sku-kaggle-gpu-20261010-v9-smoke-prepared'
OUT = Path(__file__).resolve().parent
UPLOAD = OUT / 'dataset-upload'
NOTEBOOK = OUT / 'notebook-upload'
RUNNER = ROOT / 'experiments/sku-matching/kaggle_gpu_sku_runner_v3.py'
DATASET_REF = 'superbigzabuton/sku-gpu-qwen35-4b-nf4-v9-smoke'
KERNEL_REF = 'superbigzabuton/sku-qwen35-4b-nf4-v9-smoke'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

if UPLOAD.exists() or NOTEBOOK.exists():
    raise FileExistsError('Refusing to overwrite a frozen Kaggle package')
manifest = json.loads((SOURCE / 'manifest.json').read_text())
if manifest['runner_sha256'] != sha(RUNNER):
    raise ValueError('Prepared source manifest is not the current reviewed runner')
if manifest['case_count'] != 14 or manifest['au_row_count'] != 798:
    raise ValueError('Not the complete 14-case smoke pool')
UPLOAD.mkdir(parents=True)
NOTEBOOK.mkdir()
for name in ('inputs.jsonl', 'source-cases.jsonl', 'config.json', 'manifest.json'):
    shutil.copyfile(SOURCE / name, UPLOAD / name)
shutil.copyfile(RUNNER, UPLOAD / RUNNER.name)
files = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in UPLOAD.iterdir()}
write(UPLOAD / 'upload-manifest.json', {
    'schema_version': 'sku-gpu-v9-private-upload-v1', 'label_blind': True,
    'labels_read': False, 'input_count': 14, 'inference_count': 28,
    'all_au_pools_retained': True, 'upload_payloads': files})
write(UPLOAD / 'dataset-metadata.json', {
    'id': DATASET_REF, 'title': 'SKU Qwen35 4B NF4 v9 paired smoke',
    'licenses': [{'name': 'CC0-1.0'}]})
old = ROOT / '.lab-output/sku-kaggle-gpu-20261010-v8/notebook-upload/trial.ipynb'
notebook = json.loads(old.read_text())
for cell in notebook['cells']:
    cell['source'] = [x.replace('v8', 'v9').replace('kaggle_gpu_sku_runner_v2.py', RUNNER.name)
                      for x in cell.get('source', [])]
    cell['outputs'] = []
    cell['execution_count'] = None
write(NOTEBOOK / 'trial.ipynb', notebook)
write(NOTEBOOK / 'kernel-metadata.json', {
    'id': KERNEL_REF, 'title': 'SKU Qwen35 4B NF4 v9 smoke',
    'code_file': 'trial.ipynb', 'language': 'python', 'kernel_type': 'notebook',
    'is_private': True, 'enable_gpu': True, 'enable_tpu': False,
    'enable_internet': True, 'dataset_sources': [DATASET_REF],
    'competition_sources': [], 'kernel_sources': []})
write(NOTEBOOK / 'training-params.json', {'timeout_seconds': 3600})
write(OUT / 'transport-freeze.json', {
    'schema': 'sku-gpu-v9-transport-freeze-v1', 'label_blind': True,
    'labels_read': False, 'model': json.loads((UPLOAD/'config.json').read_text())['models'],
    'case_count': 14, 'inference_count': 28, 'au_row_count': 798,
    'dataset_ref': DATASET_REF, 'kernel_ref': KERNEL_REF,
    'payloads': files, 'upload_manifest_sha256': sha(UPLOAD/'upload-manifest.json'),
    'notebook_sha256': sha(NOTEBOOK/'trial.ipynb'),
    'kernel_metadata_sha256': sha(NOTEBOOK/'kernel-metadata.json'),
    'runner_sha256': sha(RUNNER)})
print(json.dumps({'prepared': True, 'dataset_ref': DATASET_REF, 'kernel_ref': KERNEL_REF,
                  'case_count': 14, 'inference_count': 28, 'runner_sha256': sha(RUNNER)}))
