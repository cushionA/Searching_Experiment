#!/usr/bin/env python3
"""Build the v9 continuation ZIP after a completed Kaggle result is available.

This deliberately packages a narrow allowlist. It never bundles model weights,
credentials, environments, session logs, mutable job metadata, or prior zips.
Run from the repository root:
  python3 .lab-output/v9/prepare_checkpoint.py --results-dir PATH --evaluation-dir PATH
"""
from __future__ import annotations
import argparse, hashlib, json, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "experiments/sku-matching/results/20261010-sku-gpu-v9-checkpoint.zip"
MANIFEST = OUT.with_suffix(".manifest.json")
SHA = OUT.with_suffix(".zip.sha256")
V9 = ROOT / ".lab-output/sku-kaggle-gpu-20261010-v9"

FIXED = {
    ".lab-output/v9/prepare_checkpoint.py": "packaging/prepare_checkpoint.py",
    "experiments/sku-matching/gpu-v9-handoff-20261010.txt": "handoff/gpu-v9-handoff-20261010.txt",
    ".lab-output/sku-kaggle-gpu-20261010-v9/transport-freeze.json": "transport-freeze.json",
    ".lab-output/sku-kaggle-gpu-20261010-v9/test_cpu_prefill_wrapper.py": "proof/test_cpu_prefill_wrapper.py",
    ".lab-output/sku-kaggle-gpu-20261010-v9/test-validation.json": "proof/test-validation.json",
    ".lab-output/sku-kaggle-gpu-20261010-v9/prefill-targeted-tests.log": "proof/prefill-targeted-tests.log",
    ".lab-output/sku-kaggle-gpu-20261010-v9/post-evaluation-validation.json": "proof/post-evaluation-validation.json",
    ".lab-output/sku-kaggle-gpu-20261010-v9/post-evaluation-tests.log": "proof/post-evaluation-tests.log",
    ".lab-output/sku-kaggle-gpu-20261010-v9/prepare_transport.py": "transport/prepare_transport.py",
    ".lab-output/sku-kaggle-gpu-20261010-v9/dataset-upload/manifest.json": "input/manifest.json",
    ".lab-output/sku-kaggle-gpu-20261010-v9/dataset-upload/config.json": "input/config.json",
    ".lab-output/sku-kaggle-gpu-20261010-v9/dataset-upload/inputs.jsonl": "input/inputs.jsonl",
    ".lab-output/sku-kaggle-gpu-20261010-v9/dataset-upload/source-cases.jsonl": "input/source-cases.jsonl",
    ".lab-output/sku-kaggle-gpu-20261010-v9/dataset-upload/upload-manifest.json": "input/upload-manifest.json",
    ".lab-output/sku-kaggle-gpu-20261010-v9/dataset-upload/kaggle_gpu_sku_runner_v3.py": "runner/kaggle_gpu_sku_runner_v3.py",
    ".lab-output/sku-kaggle-gpu-20261010-v9/notebook-upload/trial.ipynb": "notebook/trial.ipynb",
    ".lab-output/sku-kaggle-gpu-20261010-v9/notebook-upload/kernel-metadata.json": "notebook/kernel-metadata.json",
    "experiments/sku-matching/evaluate_gpu_sku_trial_v3.py": "evaluation/evaluate_gpu_sku_trial_v3.py",
    "tests/test_lab_gpu_sku_evaluation_v3.py": "evaluation/test_lab_gpu_sku_evaluation_v3.py",
    "tests/test_lab_gpu_sku_runner_v3.py": "runner/test_lab_gpu_sku_runner_v3.py",
    "experiments/sku-matching/gpu-residual-task-design-20261010.txt": "design/gpu-residual-task-design-20261010.txt",
}
# Only immutable completed-result artifacts are accepted from these directories.
RESULT_NAMES = (
    "predictions-simple-qwen3-5-4b-nf4-v9.jsonl",
    "predictions-strict-qwen3-5-4b-nf4-v9.jsonl",
    "summary.json", "runtime.json", "run-manifest.json",
)
EVALUATION_NAMES = (
    "manifest.json", "metrics.csv", "metrics.json", "report.txt",
    "predictions-scored-strict-raw.jsonl", "predictions-scored-strict-guard.jsonl",
    "predictions-scored-simple-raw.jsonl", "predictions-scored-simple-guard.jsonl",
    "predictions-scored-cpu.jsonl",
)

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", required=True, type=Path,
                    help="directory holding the completed, retrieved v9 result artifacts")
    ap.add_argument("--evaluation-dir", required=True, type=Path,
                    help="directory holding the completed v3 evaluation outputs")
    ap.add_argument("--output", type=Path, default=OUT)
    args = ap.parse_args()
    results = args.results_dir.resolve()
    if not results.is_dir():
        ap.error(f"results directory not found: {results}")
    evaluation = args.evaluation_dir.resolve()
    if not evaluation.is_dir():
        ap.error(f"evaluation directory not found: {evaluation}")
    statefile = V9 / "job/continuation.json"
    state = json.loads(statefile.read_text())
    if state.get("status") != "complete" or not state.get("ready_for_verification"):
        ap.error(f"Kaggle state is not complete/ready: {state.get('status')!r}; do not finalize")
    files: dict[str, Path] = {}
    for src, dest in FIXED.items():
        p = ROOT / src
        if not p.is_file():
            ap.error(f"missing frozen package source: {src}")
        files[dest] = p
    missing = [name for name in RESULT_NAMES if not (results / name).is_file()]
    if missing:
        ap.error(f"missing completed result artifacts: {', '.join(missing)}")
    for name in RESULT_NAMES:
        files[f"result/{name}"] = results / name
    missing = [name for name in EVALUATION_NAMES if not (evaluation / name).is_file()]
    if missing:
        ap.error(f"missing completed evaluation artifacts: {', '.join(missing)}")
    for name in EVALUATION_NAMES:
        files[f"evaluation/{name}"] = evaluation / name
    summary = json.loads((results / "summary.json").read_text())
    run_manifest = json.loads((results / "run-manifest.json").read_text())
    if (summary.get("status") != "complete" or summary.get("input_count") != 14
            or summary.get("inference_count") != 28 or summary.get("valid_prediction_count") != 5
            or summary.get("invalid_prediction_count") != 23 or summary.get("oom_count") != 0):
        ap.error("retrieved summary does not match the completed 14-case/28-inference v9 smoke")
    for name in RESULT_NAMES:
        actual = sha(results / name)
        reported = run_manifest.get("files_sha256", {}).get(name)
        retrieved = any(x.get("path", "").endswith("/" + name) and x.get("sha256") == actual
                        for x in state.get("files", []))
        if (name != "run-manifest.json" and reported != actual) or not retrieved:
            ap.error(f"completed-result hash not verified by run/continuation manifests: {name}")
    evaluation_manifest = json.loads((evaluation / "manifest.json").read_text())
    if (evaluation_manifest.get("runner_sha256") !=
            "3149f26ed19ad342ea1f1e796e848debe986ff6daa597f0f5bbb949d033a2517"):
        ap.error("evaluation manifest does not identify the frozen v9 runner")
    if evaluation_manifest.get("evaluator_sha256") != sha(files["evaluation/evaluate_gpu_sku_trial_v3.py"]):
        ap.error("evaluation output was not produced by the packaged evaluator source")
    for name in EVALUATION_NAMES:
        if name == "manifest.json":
            continue
        expected = evaluation_manifest.get("outputs", {}).get(name, {}).get("sha256")
        if not expected or sha(evaluation / name) != expected:
            ap.error(f"evaluation output hash is absent or mismatched: {name}")
    metrics = json.loads((evaluation / "metrics.json").read_text())
    simple = metrics["mode_metrics"]["simple"]
    cpu = metrics["mode_metrics"]["cpu_baseline"]["overall"]
    raw = simple["raw_model_alone_with_review_fallback"]["overall"]
    guard = simple["conservative_fixed_pool_guard"]["overall"]
    if not (raw.get("accepted_count") == 5 and raw.get("false_accept_known_negative_count") == 3
            and raw.get("accepted_gold_review_count") == 2 and raw.get("wrong_row_accept_count") == 0
            and guard.get("accepted_count") == 0 and cpu.get("correct_row_accept_count") == 2):
        ap.error("audited evaluation metrics do not match the reviewed v9 outcome")
    freeze = json.loads((V9 / "transport-freeze.json").read_text())
    checks = {
        "runner/kaggle_gpu_sku_runner_v3.py": freeze["runner_sha256"],
        "input/config.json": freeze["payloads"]["config.json"]["sha256"],
        "input/inputs.jsonl": freeze["payloads"]["inputs.jsonl"]["sha256"],
        "input/source-cases.jsonl": freeze["payloads"]["source-cases.jsonl"]["sha256"],
        "input/manifest.json": freeze["payloads"]["manifest.json"]["sha256"],
        "input/upload-manifest.json": freeze["upload_manifest_sha256"],
        "notebook/trial.ipynb": freeze["notebook_sha256"],
        "notebook/kernel-metadata.json": freeze["kernel_metadata_sha256"],
    }
    for name, expected in checks.items():
        actual = sha(files[name])
        if actual != expected:
            ap.error(f"frozen hash mismatch for {name}: {actual} != {expected}")
    validation = json.loads(files["proof/test-validation.json"].read_text())
    if validation.get("exit_code") != 0 or validation.get("skipped") != 0:
        ap.error("CPU runner validation record is incomplete or failing")
    out = args.output.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    entries = []
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for name, p in sorted(files.items()):
            zf.write(p, name)
            entries.append({"path": name, "size_bytes": p.stat().st_size, "sha256": sha(p)})
    digest = sha(out)
    manifest = {
        "schema": "sku-gpu-v9-continuation-checkpoint-v1",
        "status": "completed_result_packaged",
        "kaggle_ref": state["ref"], "kaggle_version": state.get("version"),
        "base_packages_extraction_order": [
            "20261010-claude-task-checkpoint.zip",
            "20261010-sku-continuation-cpu-checkpoint.zip",
            "20261010-sku-gpu-v9-checkpoint.zip",
        ],
        "base_package_sha256": {
            "20261010-claude-task-checkpoint.zip": "89909023f95fa211f4b45b54749b9a464d08f8313186a1ae3e64df13608096d4",
            "20261010-sku-continuation-cpu-checkpoint.zip": "ba6d7b8131df2e2dd258da8f1b7355d5340f9bd69070bfe8afa8dddbe6ed1eaf",
        },
        "frozen_payload_sha256": checks,
        "result_sha256": {name: sha(results / name) for name in RESULT_NAMES},
        "evaluation_sha256": {name: sha(evaluation / name) for name in EVALUATION_NAMES},
        "smoke_summary": summary,
        "archive": out.name, "archive_sha256": digest, "entries": entries,
        "excluded": ["weights", "venv", "secrets", "job.json", "continuation.json", "session.log", "mutable logs", "prior checkpoint archives"],
    }
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    SHA.write_text(f"{digest}  {out.name}\n")
    print(json.dumps({"archive": str(out), "sha256": digest, "entries": len(entries)}, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
