"""Random tiny architecture fixture; no SKU samples or downloaded weights."""
from pathlib import Path
import json
import torch
import transformers
from transformers import Qwen3_5Config, Qwen3_5TextConfig, Qwen3_5VisionConfig
from transformers import Qwen3_5ForConditionalGeneration

torch.set_num_threads(2)
torch.manual_seed(1701)
text = Qwen3_5TextConfig(vocab_size=64, hidden_size=32, intermediate_size=64,
    num_hidden_layers=2, num_attention_heads=2, num_key_value_heads=1, head_dim=16,
    linear_num_key_heads=2, linear_num_value_heads=4, linear_key_head_dim=8,
    linear_value_head_dim=8, layer_types=['linear_attention', 'full_attention'],
    eos_token_id=2, pad_token_id=0)
vision = Qwen3_5VisionConfig(depth=1, hidden_size=32, intermediate_size=64,
    num_heads=2, out_hidden_size=32, num_position_embeddings=16,
    patch_size=2, temporal_patch_size=2, spatial_merge_size=2)
config = Qwen3_5Config(text_config=text.to_dict(), vision_config=vision.to_dict())
model = Qwen3_5ForConditionalGeneration(config).eval()
ids = torch.randint(4, 63, (1, 13))
mask = torch.ones_like(ids)
with torch.inference_mode():
    full = model(input_ids=ids, attention_mask=mask, use_cache=True, logits_to_keep=1)
    cache = None
    chunks = []
    for begin in range(0, ids.shape[1], 4):
        end = min(ids.shape[1], begin+4)
        partial = model(input_ids=ids[:,begin:end], attention_mask=mask[:,:end],
            past_key_values=cache, use_cache=True, logits_to_keep=1)
        cache = partial.past_key_values
        chunks.append([begin,end])
    assert cache.get_seq_length() == ids.shape[1]
    error = float((full.logits-partial.logits).abs().max())
    assert torch.allclose(full.logits, partial.logits, atol=2e-5, rtol=2e-5), error
    plain = model.generate(input_ids=ids, attention_mask=mask, max_new_tokens=6,
        do_sample=False, use_cache=True, logits_to_keep=1)
    native = model.generate(input_ids=ids, attention_mask=mask, max_new_tokens=6,
        do_sample=False, use_cache=True, logits_to_keep=1, prefill_chunk_size=4)
    assert torch.equal(plain, native), (plain.tolist(),native.tolist())
proof = {'scope':'random_tiny_architecture_fixture_not_SKU_data_or_quantization_quality',
    'torch_version':torch.__version__, 'transformers_version':transformers.__version__,
    'model_class':model.__class__.__name__, 'input_tokens':13, 'prefill_chunks':chunks,
    'native_prefill_chunk_size':4, 'all_input_tokens_cached':True,
    'max_absolute_final_logit_difference':error,
    'greedy_generation_tokens_equal':True, 'new_tokens':native.shape[-1]-ids.shape[-1]}
(Path(__file__).parent/'cpu-prefill-wrapper-proof.json').write_text(
    json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
