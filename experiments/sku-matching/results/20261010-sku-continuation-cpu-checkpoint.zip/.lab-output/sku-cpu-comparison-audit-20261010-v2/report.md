# CPU residual audit: v16 result

v16 preserves 296 of the 337 matches selected by the recomputed fixed-pool source gate. The other 41 become review; v16 creates no new match beyond that gate. The residual model contributes zero accepted entailments. The source gate itself matches the v10 hybrid baseline on all 1,383 rows.

| Cohort | System | Exact-row accepts | Matched recall | Coverage | Review rate | False accepts¹ |
|---|---|---:|---:|---:|---:|---:|
| Full 1,383 | v10 hybrid/source gate | 337/337 | 77.5% | 83.3% | 16.7% | 0 |
| Full 1,383 | v16 hybrid residual | 296/296 | 68.0% | 80.3% | 19.7% | 0 |
| Fixed GPU 196 | v10 hybrid/source gate | 37/37 | 67.3% | 72.4% | 27.6% | 0 |
| Fixed GPU 196 | v16 hybrid residual | 23/23 | 41.8% | 65.3% | 34.7% | 0 |
| Curtain 720 | v10 hybrid/source gate | 279/279 | 83.8% | 88.8% | 11.2% | 0 |
| Curtain 720 | v16 hybrid residual | 279/279 | 83.8% | 88.8% | 11.2% | 0 |
| Non-curtain 663 | v10 hybrid/source gate | 58/58 | 56.9% | 77.4% | 22.6% | 0 |
| Non-curtain 663 | v16 hybrid residual | 17/17 | 16.7% | 71.2% | 28.8% | 0 |

Dossier-macro matched recall is 61.5% for v10 and 26.9% for v16; macro coverage is 72.4% and 64.3%. All accepts are exact single-row agreements with the machine labels. There are no wrong-row accepts, accepts on gold unmatched/review, or gold-matched predictions set to unmatched. V16’s 41 removed matches are reviews, so they reduce recall without counting as false deletions under the requested unmatched definition.

The source-blind audit verified 1,383 exact case IDs, the same fixed 196 subset, 29 products, 481 AU row keys, 100,757 AU row references, an unchanged complete AU candidate pool, 37/37 task-source hashes, 50/50 v16 frozen code/input hashes, and 104/104 original raw source-reference hashes. There were no row-gate, selected-row, direct source-fact, or pool mismatch failures.

V16 adds strict curtain contents count conservation. For both variants, 153 resolution records were independently rederived from the selected AU SKU JSONL line and the fixed item’s raw `extraItemComment` table: the selected SKU must explicitly state width and total panels; the `内容` table must have one exact width section; listed drape and lace quantities must parse; and their sum must equal the SKU total. All 306 variant checks passed, with zero proof failures. V16 also retained 126 directly cited source-fact resolutions per variant. Among the 296 hybrid accepts, 153 used the count proof, 126 used direct source evidence, and the remainder had no unresolved residual condition. The cached model had zero accepted entailed residuals.

Four secondary composite Rakuten HTML-body quote records did not match verbatim in the stored HTML. Their original raw file hashes are verified; none are used in the v16 count proof or direct source-fact resolution. The count proof reads the original AU SKU row and item JSON directly and pins both to frozen hashes.

V16 reused v11 cached model raw/residual outputs and ran no new inference. It also referenced the existing v10 hybrid prediction artifact for a label-blind diagnostic. V14 and v15 are diagnostic iterations; v16 is the strict source-count variant assessed here. This is still development-only evaluation: labels are Luna machine annotation, not human-verified or independent external gold, and the diagnostic set was previously inspected and reused. The reported 100% accepted precision means agreement among accepted rows with those labels, including gold review in the precision denominator; it does not establish human accuracy or generalization.

¹ False accepts include accepted cases whose label is either unmatched or review. Precision uses the exact-one-row gold-key condition. The CPU title extractor v2 discovers spans and has no SKU matching accuracy score.

Hashes: v16 raw `9fb25bb5283f7016b42d62e6ab17baaabd126af66c53848628e4e65e50c33299`; freeze `32eac0a62dee2b203e0bc5960ab6f3b2256cd32ac55107464e998cdaa5098513`; summary `f7ff91a91983a9d452758b992b993e7c1a2ad8abdb570c6932318352ee135c3a`; v16 code `ee52b2d8cd2c6094fe3cb6b1e1e2ef0ae4948dda4eb34730ca68877d25964735`; v10 hybrid predictions `b2a7cbf08017d9559ac32d1f148831c8c4f114fbd9aaeb17b8cdf53c7d3bdf23`; labels `a461717495fea768d03e79d5d884c32e3a2eee4da6a7167795a1c57fcf38ea28`.
