#!/usr/bin/env python3
"""Source-blind audit of the cached-model v14 gate ablation."""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parents[2]
GPU = ROOT / ".lab-output/sku-kaggle-gpu-20261010-v2/dataset-upload/inputs.jsonl"
TASK = ROOT / ".lab-output/sku-cpu-residual-task-20261010-v10"
STRUCTURED = ROOT / ".lab-output/sku-structured-task-trials-20261010-v10/tasks.jsonl"
V11 = ROOT / ".lab-output/sku-cpu-residual-task-20261010-v11/gliner-decide"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def j(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def jl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(s) for s in path.read_text(encoding="utf-8").splitlines() if s.strip()]


def resolve(s: str) -> Path:
    p = Path(s)
    return p if p.is_absolute() else ROOT / p


class VisibleHTML(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(s)).strip()


def json_path_value(doc: Any, path: str) -> Any:
    if not path.startswith("$."):
        return None
    cur = doc
    for part in path[2:].split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def quote_is_present(p: Path, quote: str | None, json_path: str | None) -> bool | None:
    if not quote:
        return None
    if not p.is_file():
        return False
    raw = p.read_bytes()
    text = raw.decode("utf-8", errors="replace")
    q = norm(quote)
    if q in norm(text):
        return True
    if p.suffix.lower() == ".json" and json_path:
        try:
            value = json_path_value(json.loads(text), json_path)
            if isinstance(value, str) and (norm(value) == q or q in norm(value)):
                return True
        except (json.JSONDecodeError, UnicodeDecodeError):
            pass
    if p.suffix.lower() in {".html", ".htm"}:
        parser = VisibleHTML()
        try:
            parser.feed(text)
            return q in norm(" ".join(parser.parts))
        except Exception:
            return False
    return False


class ContentsTableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self.row: list[str] | None = None
        self.cell: list[str] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "tr":
            self.row = []
        elif tag in {"td", "th"} and self.row is not None:
            self.cell = []
        elif tag == "br" and self.cell is not None:
            self.cell.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"td", "th"} and self.row is not None and self.cell is not None:
            self.row.append("".join(self.cell))
            self.cell = None
        elif tag == "tr" and self.row is not None:
            self.rows.append(self.row)
            self.row = None

    def handle_data(self, data: str) -> None:
        if self.cell is not None:
            self.cell.append(data)


def verify_count_proof(task: dict[str, Any], product: dict[str, Any], row: dict[str, Any],
                       residual: dict[str, Any], proof: dict[str, Any]) -> dict[str, Any]:
    """Independently rederive width-scoped N = drape + lace from raw source files."""
    refs = proof.get("source_refs") or {}
    sku_ref, contents_ref = refs.get("selected_au_sku_option") or {}, refs.get("fixed_product_contents") or {}
    sku_path = resolve(str(sku_ref.get("file") or ""))
    line_no = sku_ref.get("line")
    result = {"case_id": task.get("case_id"), "semantic_key": proof.get("semantic_key"),
              "sku_file": str(sku_path), "sku_line": line_no, "valid": False, "reasons": []}
    if not sku_path.is_file() or not isinstance(line_no, int) or line_no < 1:
        result["reasons"].append("sku_source_missing_or_line_invalid")
        return result
    sku_lines = sku_path.read_text(encoding="utf-8").splitlines()
    if line_no > len(sku_lines):
        result["reasons"].append("sku_line_out_of_range")
        return result
    try:
        sku = json.loads(sku_lines[line_no - 1])
    except json.JSONDecodeError:
        result["reasons"].append("sku_line_invalid_json")
        return result
    selected = row.get("selected_source_entity") or {}
    selected_row = next((x for x in product.get("au_sku_rows", [])
                         if x.get("row_key") == row.get("top_row_key")), {})
    selected_size = next((a for a in selected_row.get("axes", []) if a.get("semantic_key") == "size"), {})
    selected_grain = (selected_size.get("source_ref") or {}).get("source_grain") or {}
    sku_value = sku.get("column_option_value")
    sku_id = sku.get("sku_id")
    if (str(sku.get("item_id")) != str(task.get("product_id")) or
        str(sku_id) != str(sku_ref.get("sku_id")) or
        sku.get("column_option_name") != "サイズ" or
        sku_value != sku_ref.get("option_value") or
        sku_path.resolve() != resolve(str(selected_grain.get("file") or "")).resolve() or
        line_no != selected_grain.get("line") or
        str(sku_id) != str(selected_grain.get("sku_id")) or
        sku.get("row_index") != selected_grain.get("row_index") or
        sku.get("column_index") != selected_grain.get("column_index") or
        selected.get("row_key") != row.get("top_row_key") or
        not any(a.get("semantic_key") == "size" and a.get("value_raw") == sku_value
                for a in selected_row.get("axes", []))):
        result["reasons"].append("sku_line_does_not_match_selected_row")
    m = re.fullmatch(r"\s*幅\s*(\d+)\s*[×xX]\s*丈\s*\d+(?:\.\d+)?\s*cm\s*\(\s*(\d+)\s*枚\s*\)\s*", str(sku_value or ""))
    if not m:
        result["reasons"].append("selected_sku_has_no_explicit_width_and_total")
        return result
    width, total = int(m.group(1)), int(m.group(2))
    if width != proof.get("width_cm") or total != proof.get("total_panel_count_from_selected_sku"):
        result["reasons"].append("reported_width_or_total_differs_from_sku")
    page_path = resolve(str(contents_ref.get("file") or ""))
    if not page_path.is_file() or sha(page_path) != contents_ref.get("sha256"):
        result["reasons"].append("fixed_product_contents_source_hash_mismatch")
        return result
    try:
        page = json.loads(page_path.read_text(encoding="utf-8"))
        source_html = page.get("itemInfo", {}).get("extraItemComment")
    except (json.JSONDecodeError, AttributeError):
        source_html = None
    if not isinstance(source_html, str) or contents_ref.get("json_path") != "$.itemInfo.extraItemComment":
        result["reasons"].append("fixed_product_contents_path_missing")
        return result
    parser = ContentsTableParser()
    parser.feed(source_html)
    contents = [cells for cells in parser.rows if cells and norm(cells[0]) == "内容" and len(cells) >= 2]
    if len(contents) != 1:
        result["reasons"].append("contents_table_not_unique")
        return result
    lines = [line.strip() for line in contents[0][1].splitlines() if line.strip()]
    matching = []
    for i, line in enumerate(lines):
        h = re.fullmatch(r"【幅\s*(\d+)\s*cm】", line)
        if h and int(h.group(1)) == width:
            end = next((k for k in range(i + 1, len(lines)) if re.fullmatch(r"【幅\s*\d+\s*cm】", lines[k])), len(lines))
            matching.append(lines[i + 1:end])
    if len(matching) != 1:
        result["reasons"].append("exact_width_scope_not_unique")
        return result
    drape = lace = 0
    panel_lines = []
    for line in matching[0]:
        if "カーテン" not in line or any(x in line for x in ("タッセル", "フック")):
            continue
        q = re.fullmatch(r".*カーテン\s*(\d+)\s*枚", line)
        if not q:
            result["reasons"].append("unparsed_curtain_panel_line")
            return result
        qty = int(q.group(1)); panel_lines.append(line)
        if "レース" in line:
            lace += qty
        else:
            drape += qty
    if not panel_lines or drape + lace != total:
        result["reasons"].append("panel_inventory_does_not_conserve_total")
    if panel_lines != proof.get("panel_lines") or panel_lines != contents_ref.get("panel_quote_lines"):
        result["reasons"].append("reported_panel_lines_differ_from_raw_contents")
    key = proof.get("semantic_key")
    requested = proof.get("requested_value")
    if key == "lace":
        expected_rel = "entailed" if isinstance(requested, bool) and requested == (lace > 0) else "contradicted"
    elif key == "lace_count":
        expected_rel = "entailed" if isinstance(requested, int) and requested == lace else "contradicted"
    else:
        expected_rel = None
    if proof.get("relation") != expected_rel or residual.get("model_relation") != "unknown":
        result["reasons"].append("resolved_relation_or_model_relation_mismatch")
    result.update({"width_cm": width, "sku_total": total, "drape_count_from_raw": drape,
                   "lace_count_from_raw": lace, "panel_lines_from_raw": panel_lines,
                   "requested_value": requested, "expected_relation": expected_rel})
    result["valid"] = not result["reasons"]
    return result


def walk_refs(o: Any, inherited_quote: str | None = None):
    if isinstance(o, dict):
        q = o.get("quote") or inherited_quote
        f = o.get("file") or o.get("raw_file")
        if f:
            yield str(f), o.get("sha256") or o.get("raw_sha256") or o.get("hash"), q, o.get("json_path")
        for v in o.values():
            yield from walk_refs(v, q)
    elif isinstance(o, list):
        for v in o:
            yield from walk_refs(v, inherited_quote)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--task-dir", type=Path, default=TASK)
    ap.add_argument("--structured-tasks", type=Path, default=STRUCTURED)
    ap.add_argument("--gpu-input", type=Path, default=GPU)
    ap.add_argument("--cached-run-dir", type=Path, default=V11)
    a = ap.parse_args()
    run, td, cached = a.run_dir.resolve(), a.task_dir.resolve(), a.cached_run_dir.resolve()
    raw, freeze_path, summary_path = run / "raw_predictions.jsonl", run / "freeze.json", run / "summary.json"
    for p in (raw, freeze_path, summary_path, td / "tasks.jsonl", td / "products.jsonl", td / "manifest.json"):
        if not p.is_file():
            raise SystemExit(f"Missing v14 source-blind input: {p}")
    freeze, summary = j(freeze_path), j(summary_path)
    raw_sha, freeze_sha = sha(raw), sha(freeze_path)
    if summary.get("raw_predictions_sha256") != raw_sha:
        raise SystemExit("v14 raw SHA differs from summary")
    if summary.get("method_freeze_sha256") != freeze_sha:
        raise SystemExit("v14 freeze SHA differs from summary")
    if freeze.get("labels_used") or freeze.get("model_inference") or not freeze.get("prior_predictions_referenced_for_label_free_diagnostic"):
        raise SystemExit("v14 provenance flags do not describe cached-model, label-free ablation")
    pinned = freeze.get("input_sha256") or {}
    if pinned.get("v11_raw_predictions") != sha(cached / "raw_predictions.jsonl"):
        raise SystemExit("v11 cached raw prediction SHA differs from v14 freeze")
    if pinned.get("v11_raw_residual_outputs") != sha(cached / "raw_residual_outputs.jsonl"):
        raise SystemExit("v11 cached residual SHA differs from v14 freeze")
    if pinned.get("v11_inference_manifest") != sha(cached / "inference-manifest.json"):
        raise SystemExit("v11 inference manifest SHA differs from v14 freeze")
    frozen_paths = {
        "tasks": td / "tasks.jsonl", "products": td / "products.jsonl", "task_manifest": td / "manifest.json",
        "sourcegate": ROOT / ".lab-output/sku-structured-task-trials-20261010-v10/hybrid/predictions.jsonl",
        "sourcegate_summary": ROOT / ".lab-output/sku-structured-task-trials-20261010-v10/hybrid/summary.json",
        "sourcegate_code": run / "code/evaluate_fixed_pool_hybrid.py",
        "sourcegate_gate_code": run / "code/evaluate_structured_skus.py",
        "v11_freeze": cached / "freeze.json", "v11_raw_predictions": cached / "raw_predictions.jsonl",
        "v11_raw_residual_outputs": cached / "raw_residual_outputs.jsonl",
        "v11_inference_manifest": cached / "inference-manifest.json",
        "v2_code": run / "code/trial_cpu_residual_axis_v2.py",
        "v3_code": run / "code/trial_cpu_residual_axis_v3.py",
    }
    run_id = freeze.get("run_id")
    diagnostic_versions = [14] if run_id == "sku-cpu-residual-task-20261010-v15" else [14, 15]
    for version in diagnostic_versions:
        prefix = f"v{version}_diagnostic"
        base = ROOT / f".lab-output/sku-cpu-residual-task-20261010-v{version}/ablation"
        frozen_paths[f"{prefix}_freeze"] = base / "freeze.json"
        frozen_paths[f"{prefix}_raw"] = base / "raw_predictions.jsonl"
        frozen_paths[f"{prefix}_summary"] = base / "summary.json"
    if run_id == "sku-cpu-residual-task-20261010-v16":
        source_paths: set[Path] = set()
        for product in jl(td / "products.jsonl"):
            desc = product.get("description_source_ref", {})
            if desc.get("raw_file"):
                p = resolve(desc["raw_file"]).resolve()
                source_paths.add(p)
            for aurow in product.get("au_sku_rows", []):
                for axis in aurow.get("axes", []):
                    raw_file = (axis.get("source_ref") or {}).get("raw_file")
                    if raw_file:
                        source_paths.add(resolve(raw_file).resolve())
        for index, p in enumerate(sorted(source_paths, key=str)):
            frozen_paths[f"raw_source_{index:02d}"] = p
    frozen_input_checks = {name: {"path": str(path), "expected_sha256": pinned.get(name),
                                   "actual_sha256": sha(path) if path.is_file() else None,
                                   "verified": bool(path.is_file() and pinned.get(name) == sha(path))}
                           for name, path in frozen_paths.items()}
    if not all(x["verified"] for x in frozen_input_checks.values()):
        raise SystemExit("One or more v15 code/source inputs differ from the freeze")

    tasks, products, rows = jl(td / "tasks.jsonl"), jl(td / "products.jsonl"), jl(raw)
    task_by_id = {x["case_id"]: x for x in tasks}
    product_by_id = {x["product_id"]: x for x in products}
    structured = {x["case_id"]: x for x in jl(a.structured_tasks)}
    gpu_ids = {x["case_id"] for x in jl(a.gpu_input)}
    if len(rows) != 1383 or len(task_by_id) != 1383 or {x.get("case_id") for x in rows} != set(task_by_id):
        raise SystemExit("v14 must cover exact frozen 1,383 case IDs")
    if len(gpu_ids) != 196 or {x["case_id"] for x in tasks if x.get("gpu196_cohort") is True} != gpu_ids:
        raise SystemExit("v14 fixed GPU 196 subset mismatch")
    if summary.get("same_gpu196_count") != 196 or summary.get("raw_prediction_count") != 1383:
        raise SystemExit("summary cohort counts mismatch")

    issues: dict[str, Counter[str]] = {v: Counter() for v in ("hybrid_v10_recomputed", "canonical_v2_recomputed")}
    accepted = Counter()
    sourcegate_accepts = Counter()
    source_fact_count = Counter()
    source_fact_failures = []
    count_conservation_count = Counter()
    count_conservation_checks = []
    for outer in rows:
        task = task_by_id[outer["case_id"]]
        prod = product_by_id[task["product_id"]]
        pool = {r.get("row_key") for r in prod.get("au_sku_rows", [])}
        for variant, v in outer.get("variants", {}).items():
            if variant not in issues:
                continue
            decision = v.get("decision")
            if decision == "matched":
                accepted[variant] += 1
                key = v.get("top_row_key")
                if not key or key not in pool:
                    issues[variant]["accepted_row_missing_or_outside_fixed_pool"] += 1
                check = v.get("row_axis_check") or {}
                if check.get("status") != "entailed":
                    issues[variant]["accepted_row_axis_check_not_entailed"] += 1
                if check.get("proven_conflicts"):
                    issues[variant]["accepted_with_proven_axis_conflict"] += 1
                if check.get("missing_fields") or check.get("ambiguous_differences") or check.get("axis_conflicts"):
                    issues[variant]["accepted_with_unresolved_or_conflicting_axis"] += 1
                if check.get("au_only_fields"):
                    issues[variant]["accepted_with_au_only_axis"] += 1
                if v.get("residual_relations") and any(x.get("effective_relation") != "entailed" for x in v["residual_relations"]):
                    issues[variant]["accepted_with_nonentailed_residual"] += 1
                if v.get("reason") == "rakuten_only_condition_unresolved_by_fixed_product_evidence":
                    issues[variant]["accepted_unresolved_rakuten_only_condition"] += 1
                if v.get("reason") == "unique_source_proven_match" and v.get("sourcegate_reason") != "unique_source_proven_match":
                    issues[variant]["reason_mismatch_vs_sourcegate"] += 1
                for residual in v.get("residual_relations", []):
                    proof = residual.get("contents_count_conservation")
                    if proof:
                        count_conservation_count[variant] += 1
                        count_conservation_checks.append(verify_count_proof(task, prod, v, residual, proof))
                    fact = residual.get("source_fact_resolution")
                    if not fact:
                        continue
                    source_fact_count[variant] += 1
                    key = residual.get("semantic_key")
                    entity = v.get("selected_source_entity") or {}
                    task_axis = next((ax for ax in task.get("rakuten", {}).get("axes", [])
                                      if ax.get("semantic_key") == key), None)
                    evidence_ok = bool(fact.get("supporting_evidence"))
                    all_citations_ok = evidence_ok
                    for ev in fact.get("supporting_evidence", []):
                        ref = ev.get("source_ref") or {}
                        p = resolve(str(ref.get("raw_file") or ref.get("file") or ""))
                        expected_hash = ref.get("sha256")
                        qok = quote_is_present(p, ev.get("quote"), ref.get("json_path"))
                        if not p.is_file() or not expected_hash or sha(p) != expected_hash or qok is not True:
                            all_citations_ok = False
                    rule_ok = (fact.get("semantic_key") == key and task_axis is not None and
                               fact.get("normalized_value") == (entity.get("attrs") or {}).get(key) ==
                               task_axis.get("normalized_value") and evidence_ok)
                    if not rule_ok or not all_citations_ok:
                        source_fact_failures.append({"case_id": outer["case_id"], "variant": variant,
                                                     "semantic_key": key, "rule_ok": rule_ok,
                                                     "citations_ok": all_citations_ok, "source_fact": fact})
            sg = v.get("sourcegate_prediction") or {}
            if sg.get("decision") == "matched":
                sourcegate_accepts[variant] += 1
                if sg.get("top_row_key") not in pool:
                    issues[variant]["sourcegate_selected_row_outside_fixed_pool"] += 1
                if variant == "hybrid_v10_recomputed" and (
                        sg.get("proven_match_count") != 1 or (sg.get("gate") or {}).get("decision") != "matched"):
                    issues[variant]["sourcegate_match_not_uniquely_proven"] += 1
            if decision == "matched" and v.get("top_row_key") != sg.get("top_row_key"):
                issues[variant]["final_selected_row_differs_from_sourcegate_row"] += 1
    pool_mismatch = []
    row_refs, row_keys = 0, set()
    for t in tasks:
        p = product_by_id[t["product_id"]]
        rows0 = p.get("au_sku_rows", [])
        row_refs += len(rows0)
        row_keys.update(x.get("row_key") for x in rows0)
        st = structured.get(t["case_id"], {})
        sr = st.get("au_candidates") or st.get("au_sku_rows") or []
        if {x.get("row_key") for x in rows0} != {x.get("row_key") for x in sr}:
            pool_mismatch.append(t["case_id"])

    manifest = j(td / "manifest.json")
    expected = {}
    for d in (manifest.get("source_sha256_pre", {}), manifest.get("source_sha256_post", {})):
        expected.update(d)
    source_checks = []
    for path_text, digest in expected.items():
        if any(k in path_text.lower() for k in ("label", "gold", "prediction")):
            continue
        p = resolve(path_text)
        actual = sha(p) if p.is_file() else None
        source_checks.append({"path": str(p), "expected_sha256": digest, "actual_sha256": actual, "verified": actual == digest})
    # Source refs include evidence nested in both variants. Every original raw ref
    # must resolve to a real input source and carry its matching SHA.
    expected_hash_by_abs = {str(Path(v["path"]).resolve()): v["expected_sha256"]
                            for v in frozen_input_checks.values() if v["expected_sha256"]}
    refs, ref_keys = [], set()
    for outer in rows:
        for variant in outer.get("variants", {}).values():
            for ref in walk_refs(variant):
                ptext, digest, quote, json_path = ref
                p = resolve(ptext)
                digest = digest or expected_hash_by_abs.get(str(p.resolve()))
                key = (str(p), str(digest or ""), str(quote or ""), str(json_path or ""))
                if key in ref_keys:
                    continue
                ref_keys.add(key)
                pt = str(p).replace("\\", "/")
                original = ("/sku-real-au-" in pt or "/sku-real-rakuten-" in pt) and "normalized-v" not in pt and "observed-product-pairs" not in pt
                actual = sha(p) if p.is_file() else None
                quote_ok = quote_is_present(p, quote, json_path) if original else None
                refs.append({"path": str(p), "expected_sha256": digest, "actual_sha256": actual,
                             "hash_verified": bool(digest and actual == digest), "is_original_raw": original,
                             "quote": quote, "json_path": json_path, "quote_verified": quote_ok})
    result = {
        "schema": "sku-cpu-v14-source-blind-audit-v1", "labels_opened": False,
        "run_dir": str(run), "raw_predictions_sha256": raw_sha, "freeze_sha256": freeze_sha,
        "summary_sha256": sha(summary_path), "cached_model_source": str(cached),
        "cached_v11_raw_predictions_sha256": pinned["v11_raw_predictions"],
        "cached_v11_residual_sha256": pinned["v11_raw_residual_outputs"],
        "frozen_code_and_input_hashes": {"verified": sum(x["verified"] for x in frozen_input_checks.values()),
                                         "total": len(frozen_input_checks), "all_verified": all(x["verified"] for x in frozen_input_checks.values()),
                                         "checks": frozen_input_checks},
        "model_inference": False, "prior_predictions_referenced": freeze.get("prior_predictions_referenced_for_label_free_diagnostic"),
        "counts": {"cases": len(rows), "gpu196": len(gpu_ids), "products": len(products),
                   "fixed_au_row_references": row_refs, "unique_au_row_keys": len(row_keys)},
        "accepted_by_variant": dict(accepted), "sourcegate_accepts_by_variant": dict(sourcegate_accepts),
        "guard_issues_by_variant": {k: dict(v) for k, v in issues.items()},
        "source_fact_resolutions_by_variant": dict(source_fact_count),
        "source_fact_resolution_failures": source_fact_failures,
        "curtain_count_conservation_resolutions_by_variant": dict(count_conservation_count),
        "curtain_count_conservation_verified": sum(x["valid"] for x in count_conservation_checks),
        "curtain_count_conservation_failures": [x for x in count_conservation_checks if not x["valid"]],
        "curtain_count_conservation_checks": count_conservation_checks,
        "fixed_row_pool_mismatch_cases": pool_mismatch,
        "input_source_hashes": {"verified": sum(x["verified"] for x in source_checks), "total": len(source_checks),
                                 "all_verified": all(x["verified"] for x in source_checks), "checks": source_checks},
        "source_references": {"distinct": len(refs), "original_raw": sum(x["is_original_raw"] for x in refs),
                               "original_raw_hash_verified": sum(x["is_original_raw"] and x["hash_verified"] for x in refs),
                               "original_raw_hash_failures": [x for x in refs if x["is_original_raw"] and not x["hash_verified"]],
                               "original_raw_quotes_present": sum(bool(x["is_original_raw"] and x["quote"]) for x in refs),
                               "original_raw_quotes_verified": sum(x["is_original_raw"] and x["quote_verified"] is True for x in refs),
                               "original_raw_quote_failures": [x for x in refs if x["is_original_raw"] and x["quote"] and x["quote_verified"] is False],
                               "checks": refs},
        "synthetic_benchmark_cases": freeze.get("synthetic_benchmark_cases"),
        "prior_prediction_diagnostic_note": freeze.get("prior_prediction_diagnostic"),
    }
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k not in {"input_source_hashes", "source_references"}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
