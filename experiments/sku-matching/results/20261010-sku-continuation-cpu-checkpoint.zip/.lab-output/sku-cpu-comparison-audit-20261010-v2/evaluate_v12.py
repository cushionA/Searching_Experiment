#!/usr/bin/env python3
"""Independent row-aware audit for the frozen CPU residual trial."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
TASK_DIR = ROOT / ".lab-output/sku-cpu-residual-task-20261010-v9"
V10_DIR = ROOT / ".lab-output/sku-structured-task-trials-20261010-v10"
GPU_INPUT = ROOT / ".lab-output/sku-kaggle-gpu-20261010-v2/dataset-upload/inputs.jsonl"
LABEL_DIR = ROOT / ".lab-output/sku-real-luna-labels-20261010-v3"
OUT_DIR = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def chosen_keys(row: dict[str, Any], system: str) -> set[str]:
    if system == "cpu":
        vals = row.get("candidate_row_keys_after_legacy_guard") or []
        if not vals and row.get("decision") == "matched":
            vals = (row.get("plan") or {}).get("candidate_row_keys") or []
        return {str(x) for x in vals if x}
    key = row.get("top_row_key")
    return {str(key)} if key else set()


def score(rows: list[dict[str, Any]], system: str) -> dict[str, Any]:
    n = len(rows)
    accepts = [r for r in rows if r[system + "_decision"] == "matched"]
    gold_matched = [r for r in rows if r["gold_decision"] == "matched"]
    correct_accepts = [r for r in accepts if r["gold_decision"] == "matched" and
                       len(r[system + "_keys"]) == 1 and r[system + "_keys"] <= r["gold_keys"]]
    wrong_row = [r for r in accepts if r["gold_decision"] == "matched" and
                 not (len(r[system + "_keys"]) == 1 and r[system + "_keys"] <= r["gold_keys"])]
    multi_row_unsafe = [r for r in accepts if len(r[system + "_keys"]) > 1]
    false_unmatched = [r for r in accepts if r["gold_decision"] == "unmatched"]
    false_review = [r for r in accepts if r["gold_decision"] == "review"]
    negative_gold = [r for r in rows if r["gold_decision"] in {"unmatched", "review"}]
    false_deletions = [r for r in rows if r["gold_decision"] == "matched" and
                       r[system + "_decision"] == "unmatched"]
    reviews = [r for r in rows if r[system + "_decision"] == "review"]
    decided = n - len(reviews)
    return {
        "case_count": n,
        "accepted_count": len(accepts),
        "row_correct_accept_count": len(correct_accepts),
        "accepted_precision_including_gold_review": len(correct_accepts) / len(accepts) if accepts else None,
        "wrong_row_accept_count": len(wrong_row),
        "wrong_row_accept_with_gold_matched_count": len(wrong_row),
        "unsafe_multi_row_accept_count": len(multi_row_unsafe),
        "false_accept_gold_unmatched_count": len(false_unmatched),
        "false_accept_gold_review_count": len(false_review),
        "false_accept_gold_unmatched_or_review_count": len(false_unmatched) + len(false_review),
        "gold_unmatched_or_review_count": len(negative_gold),
        "false_accept_rate_gold_unmatched_or_review": (
            (len(false_unmatched) + len(false_review)) / len(negative_gold) if negative_gold else None),
        "wrong_row_accept_rate_among_gold_matched_accepts": len(wrong_row) / len([r for r in accepts
            if r["gold_decision"] == "matched"]) if any(r["gold_decision"] == "matched" for r in accepts) else None,
        "gold_matched_count": len(gold_matched),
        "matched_recall_row_aware": len(correct_accepts) / len(gold_matched) if gold_matched else None,
        "false_deletion_gold_matched_predicted_unmatched_count": len(false_deletions),
        "false_deletion_rate_among_gold_matched": len(false_deletions) / len(gold_matched) if gold_matched else None,
        "covered_count_decision_not_review": decided,
        "coverage": decided / n if n else None,
        "review_count": len(reviews),
        "review_rate": len(reviews) / n if n else None,
        "decision_counts": {d: sum(r[system + "_decision"] == d for r in rows)
                             for d in ("matched", "unmatched", "review")},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cpu-raw", type=Path, required=True,
                        help="durable raw_predictions.jsonl from the selected CPU run")
    parser.add_argument("--cpu-run-dir", type=Path, required=True,
                        help="run dir containing freeze.json and inference-manifest.json")
    parser.add_argument("--task-dir", type=Path, default=TASK_DIR)
    parser.add_argument("--v10-dir", type=Path, default=V10_DIR)
    parser.add_argument("--gpu-input", type=Path, default=GPU_INPUT)
    parser.add_argument("--labels-dir", type=Path, default=LABEL_DIR)
    args = parser.parse_args()
    raw_path = args.cpu_raw.resolve()
    run_dir = args.cpu_run_dir.resolve()
    inference_path = run_dir / "inference-manifest.json"
    freeze_path = run_dir / "freeze.json"
    if not raw_path.is_file() or not inference_path.is_file() or not freeze_path.is_file():
        raise SystemExit("CPU raw output, inference manifest, and freeze must all be durable first")
    inference = read_json(inference_path)
    raw_sha = sha(raw_path)
    if inference.get("raw_predictions_sha256") != raw_sha:
        raise SystemExit("CPU raw hash does not match the durable inference manifest")

    # Labels are intentionally opened only after the raw file and its recorded hash pass.
    labels_path = args.labels_dir / "labels.jsonl"
    labels_manifest_path = args.labels_dir / "manifest.json"
    label_manifest = read_json(labels_manifest_path)
    labels_sha = sha(labels_path)
    expected_label_sha = label_manifest.get("output_sha256", {}).get("labels.jsonl")
    if labels_sha != expected_label_sha:
        raise SystemExit("Label file hash does not match its manifest")
    labels = read_jsonl(labels_path)
    labels_by_id = {x["case_id"]: x for x in labels}
    if len(labels_by_id) != len(labels):
        raise SystemExit("Duplicate label case_id")

    cpu_rows = read_jsonl(raw_path)
    residual_path = run_dir / "raw_residual_outputs.jsonl"
    residual_rows = read_jsonl(residual_path)
    residual_sha = sha(residual_path)
    if inference.get("raw_residual_outputs_sha256") != residual_sha:
        raise SystemExit("CPU raw residual output hash does not match the durable inference manifest")
    tasks = read_jsonl(args.task_dir / "tasks.jsonl")
    hybrid_rows = read_jsonl(args.v10_dir / "hybrid/predictions.jsonl")
    task_manifest = read_json(args.task_dir / "manifest.json")
    hybrid_summary = read_json(args.v10_dir / "hybrid/summary.json")
    v10_task_manifest = read_json(args.v10_dir / "manifest.json")
    hybrid_sha = sha(args.v10_dir / "hybrid/predictions.jsonl")
    if hybrid_summary.get("predictions_sha256") != hybrid_sha:
        raise SystemExit("v10 hybrid prediction hash does not match its summary")
    task_by_id = {x["case_id"]: x for x in tasks}
    hybrid_by_id = {x["case_id"]: x for x in hybrid_rows}
    expected_ids = set(task_by_id)
    if len(cpu_rows) != 1383 or {x.get("case_id") for x in cpu_rows} != expected_ids:
        raise SystemExit("CPU predictions must cover the exact 1,383 frozen task IDs")
    if set(labels_by_id) != expected_ids or set(hybrid_by_id) != expected_ids:
        raise SystemExit("Labels and v10 hybrid must cover the exact same 1,383 IDs")
    gpu_ids = {x["case_id"] for x in read_jsonl(args.gpu_input)}

    joined = []
    for cpu in cpu_rows:
        cid = cpu["case_id"]
        gold = labels_by_id[cid]
        hybrid = hybrid_by_id[cid]
        task = task_by_id[cid]
        gd = gold.get("decision", gold.get("semantic_label"))
        if gd not in {"matched", "unmatched", "review"}:
            raise SystemExit(f"Unexpected gold decision for {cid}: {gd!r}")
        joined.append({
            "case_id": cid,
            "dossier_id": task.get("dossier_id"),
            "category": (task.get("rakuten") or {}).get("attrs", {}).get("category", "unknown"),
            "gpu196": cid in gpu_ids,
            "gold_decision": gd,
            "gold_keys": set(gold.get("matching_au_row_keys") or []),
            "cpu_decision": cpu.get("decision"),
            "cpu_keys": chosen_keys(cpu, "cpu"),
            "hybrid_decision": hybrid.get("decision"),
            "hybrid_keys": chosen_keys(hybrid, "hybrid"),
            "legacy_decision": cpu.get("legacy_rule_decision"),
            "legacy_keys": set(cpu.get("legacy_rule_row_keys") or []),
            "cpu_residual_results": cpu.get("residual_results") or [],
            "cpu_reason": cpu.get("reason"),
        })

    cohorts: dict[str, list[dict[str, Any]]] = {
        "full1383": joined,
        "same_gpu196": [r for r in joined if r["gpu196"]],
        "curtain": [r for r in joined if r["category"] == "curtain"],
        "noncurtain": [r for r in joined if r["category"] != "curtain"],
    }
    summary = {name: {"cpu": score(rows, "cpu"), "v10_hybrid": score(rows, "hybrid")}
               for name, rows in cohorts.items()}
    for name, rows in cohorts.items():
        summary[name]["legacy_source_gate"] = score(rows, "legacy")

    dossiers: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in joined:
        dossiers[row["dossier_id"]].append(row)
    dossier_rows = []
    for dossier_id, rows in sorted(dossiers.items()):
        c, h, g = score(rows, "cpu"), score(rows, "hybrid"), score(rows, "legacy")
        dossier_rows.append({"dossier_id": dossier_id, **{f"cpu_{k}": v for k, v in c.items()},
                             **{f"hybrid_{k}": v for k, v in h.items()},
                             **{f"legacy_{k}": v for k, v in g.items()}})
    metric_keys = ["accepted_precision_including_gold_review", "matched_recall_row_aware",
                   "coverage", "review_rate", "false_accept_rate_gold_unmatched_or_review",
                   "wrong_row_accept_rate_among_gold_matched_accepts",
                   "false_deletion_rate_among_gold_matched"]
    dossier_macro = {}
    for system in ("cpu", "hybrid", "legacy"):
        dossier_macro[system] = {k: mean([r[f"{system}_{k}"] for r in dossier_rows
                                              if r[f"{system}_{k}"] is not None])
                                 if any(r[f"{system}_{k}"] is not None for r in dossier_rows) else None
                                 for k in metric_keys}
        dossier_macro[system]["dossier_count"] = len(dossier_rows)
    summary["dossier_macro"] = dossier_macro

    # Explicit paired decomposition: retained gate correctness, residual-model gain,
    # and direct incremental gains over the strongest same-row v10 hybrid baseline.
    cpu_correct = [r for r in joined if r["cpu_decision"] == "matched" and
                   r["gold_decision"] == "matched" and len(r["cpu_keys"]) == 1 and
                   r["cpu_keys"] <= r["gold_keys"]]
    hybrid_correct_ids = {r["case_id"] for r in joined if r["hybrid_decision"] == "matched" and
                          r["gold_decision"] == "matched" and len(r["hybrid_keys"]) == 1 and
                          r["hybrid_keys"] <= r["gold_keys"]}
    legacy_correct_ids = {r["case_id"] for r in joined if r["legacy_decision"] == "matched" and
                          r["gold_decision"] == "matched" and len(r["legacy_keys"]) == 1 and
                          r["legacy_keys"] <= r["gold_keys"]}
    decomposition = {
        "cpu_row_correct_accepts": len(cpu_correct),
        "legacy_source_gate_row_correct_accepts": len(legacy_correct_ids),
        "legacy_correct_accepts_retained_by_cpu": sum(
            r["case_id"] in legacy_correct_ids for r in cpu_correct),
        "legacy_correct_accepts_lost_by_cpu": sum(
            r["case_id"] in legacy_correct_ids and r["case_id"] not in {x["case_id"] for x in cpu_correct}
            for r in joined),
        "correct_cpu_accepts_with_entailed_residual_model_evidence": sum(
            any(x.get("relation") == "entailed" for x in r["cpu_residual_results"])
            for r in cpu_correct),
        "correct_cpu_accepts_added_over_v10_hybrid": sum(r["case_id"] not in hybrid_correct_ids for r in cpu_correct),
        "correct_v10_hybrid_accepts_lost_by_cpu": sum(
            r["case_id"] in hybrid_correct_ids and not (r["cpu_decision"] == "matched" and
            r["gold_decision"] == "matched" and len(r["cpu_keys"]) == 1 and
            r["cpu_keys"] <= r["gold_keys"]) for r in joined),
        "v10_hybrid_row_correct_accepts": len(hybrid_correct_ids),
        "cpu_correct_accepts_added_over_legacy_source_gate": sum(
            r["case_id"] not in legacy_correct_ids for r in cpu_correct),
        "interpretation": "Legacy gate is reported as a separate same-task source baseline; CPU residual contribution is correct CPU acceptance beyond it. The direct strongest baseline is the same-row v10 hybrid.",
    }
    guard_causes = Counter((bool((r.get("plan") or {}).get("candidate_common_unknowns")),
                            bool((r.get("plan") or {}).get("au_only_axes"))) for r in cpu_rows)
    fallbacks = [r["fallback"] for r in residual_rows if r.get("fallback")]
    entailed_fallbacks = [r for r in fallbacks if r.get("model_label") == "条件を満たす"]
    model_stage = {
        "unique_residual_prompts": len(residual_rows),
        "title_relation_counts": dict(Counter((r.get("title") or {}).get("relation") for r in residual_rows)),
        "title_label_counts": dict(Counter((r.get("title") or {}).get("model_label") for r in residual_rows)),
        "fallback_count": len(fallbacks),
        "fallback_label_counts": dict(Counter(r.get("model_label") for r in fallbacks)),
        "effective_relation_counts": dict(Counter(r.get("effective_relation") for r in residual_rows)),
        "entailed_fallback_confidence_min": min((r.get("model_confidence") for r in entailed_fallbacks), default=None),
        "entailed_fallback_confidence_max": max((r.get("model_confidence") for r in entailed_fallbacks), default=None),
        "entailed_fallbacks_below_threshold_count": sum(
            float(r.get("model_confidence") or 0) < float(r.get("confidence_threshold") or 0.7)
            for r in entailed_fallbacks),
    }
    decision_reasons = dict(Counter(r.get("reason") for r in cpu_rows))
    detailed = []
    for r in joined:
        detailed.append({k: (sorted(v) if isinstance(v, set) else v)
                         for k, v in r.items()})
    report = {
        "schema": "sku-cpu-row-aware-independent-evaluation-v1",
        "evaluated_at_utc": datetime.now(timezone.utc).isoformat(),
        "cpu_run_dir": str(run_dir), "cpu_raw_path": str(raw_path),
        "cpu_raw_sha256": raw_sha, "labels_path": str(labels_path), "labels_sha256": labels_sha,
        "cpu_raw_residual_outputs_sha256": residual_sha,
        "cpu_freeze_sha256": sha(freeze_path),
        "cpu_inference_manifest_sha256": sha(inference_path),
        "cpu_task_manifest_sha256": sha(args.task_dir / "manifest.json"),
        "cpu_task_reuse_status": (task_manifest.get("test_status") or
                                   v10_task_manifest.get("test_status")),
        "cpu_task_synthetic_data_included": task_manifest.get("synthetic_data_included"),
        "v10_hybrid_predictions_sha256": hybrid_sha,
        "v10_hybrid_reuse_status": hybrid_summary.get("test_status"),
        "v10_hybrid_labels_used_for_prediction": hybrid_summary.get("labels_used_for_prediction"),
        "v10_hybrid_synthetic_input_count": hybrid_summary.get("synthetic_input_count"),
        "labels_annotation_protocol": label_manifest.get("annotation_protocol"),
        "labels_human_verified": label_manifest.get("annotation_protocol", {}).get("human_verified"),
        "labels_independent_external_gold": label_manifest.get("annotation_protocol", {}).get("independent_external_gold"),
        "all_1383_cases_included": True,
        "comparison_baseline": "Primary: v10 hybrid predictions.jsonl on the same 1,383 rows. The v11 same-task legacy source gate is reported separately for decomposition.",
        "metrics": summary,
        "gain_decomposition": decomposition,
        "cpu_decision_reasons": decision_reasons,
        "cpu_early_review_guard_causes": {
            "candidate_common_unknown_only": guard_causes.get((True, False), 0),
            "au_only_axis_only": guard_causes.get((False, True), 0),
            "both": guard_causes.get((True, True), 0),
            "neither": guard_causes.get((False, False), 0),
        },
        "cpu_model_stage": model_stage,
        "limitations": [
            "Labels are machine-annotated and not human verified; scores are agreement with those labels, not validated human accuracy.",
            "CPU trial reused a previously inspected test set and must be described as exploratory.",
            "The v9 run is diagnostic only if its known source/citation/fallback issues remain; use the named final repaired run for a final report.",
            "Precision numerator requires both gold matched and a returned selected AU row in matching_au_row_keys; gold review stays in the denominator.",
        ],
    }
    (OUT_DIR / "evaluation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (OUT_DIR / "cohort-metrics.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["cohort", "system", "case_count", "accepted_count", "row_correct_accept_count",
                    "accepted_precision_including_gold_review", "wrong_row_accept_count",
                    "unsafe_multi_row_accept_count",
                    "false_accept_gold_unmatched_count", "false_accept_gold_review_count",
                    "false_accept_rate_gold_unmatched_or_review",
                    "wrong_row_accept_rate_among_gold_matched_accepts",
                    "false_deletion_gold_matched_predicted_unmatched_count",
                    "false_deletion_rate_among_gold_matched", "matched_recall_row_aware",
                    "coverage", "review_count", "review_rate"])
        for cohort, systems in summary.items():
            if cohort == "dossier_macro":
                continue
            for system, m in systems.items():
                w.writerow([cohort, system, m["case_count"], m["accepted_count"], m["row_correct_accept_count"],
                            m["accepted_precision_including_gold_review"], m["wrong_row_accept_count"],
                            m["unsafe_multi_row_accept_count"],
                            m["false_accept_gold_unmatched_count"], m["false_accept_gold_review_count"],
                            m["false_accept_rate_gold_unmatched_or_review"],
                            m["wrong_row_accept_rate_among_gold_matched_accepts"],
                            m["false_deletion_gold_matched_predicted_unmatched_count"],
                            m["false_deletion_rate_among_gold_matched"],
                            m["matched_recall_row_aware"], m["coverage"], m["review_count"], m["review_rate"]])
        for system, m in dossier_macro.items():
            w.writerow(["dossier_macro", system, m["dossier_count"], "", "",
                        m["accepted_precision_including_gold_review"], "", "", "", "",
                        m["false_accept_rate_gold_unmatched_or_review"],
                        m["wrong_row_accept_rate_among_gold_matched_accepts"], "",
                        m["false_deletion_rate_among_gold_matched"], m["matched_recall_row_aware"],
                        m["coverage"], "", m["review_rate"]])
    with (OUT_DIR / "dossier-metrics.csv").open("w", newline="", encoding="utf-8") as f:
        fields = list(dossier_rows[0]) if dossier_rows else []
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(dossier_rows)
    with (OUT_DIR / "case-results.jsonl").open("w", encoding="utf-8") as f:
        for row in detailed:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    print(json.dumps({"status": "evaluated", "raw_sha256": raw_sha,
                      "cohort_metrics": summary, "gain_decomposition": decomposition}, ensure_ascii=False))


if __name__ == "__main__":
    main()
