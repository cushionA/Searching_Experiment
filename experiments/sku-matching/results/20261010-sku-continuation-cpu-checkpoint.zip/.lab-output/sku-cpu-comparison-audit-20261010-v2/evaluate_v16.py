#!/usr/bin/env python3
"""Row-aware label-agreement audit of cached-model v16 count-proof ablation."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DEFAULT_RUN = ROOT / ".lab-output/sku-cpu-residual-task-20261010-v16/ablation"
DEFAULT_TASK = ROOT / ".lab-output/sku-cpu-residual-task-20261010-v10"
DEFAULT_V10 = ROOT / ".lab-output/sku-structured-task-trials-20261010-v10"
DEFAULT_LABELS = ROOT / ".lab-output/sku-real-luna-labels-20261010-v3"
DEFAULT_GPU = ROOT / ".lab-output/sku-kaggle-gpu-20261010-v2/dataset-upload/inputs.jsonl"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def j(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def jl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def keys_for(decision: str | None, key: str | None) -> set[str]:
    return {str(key)} if decision == "matched" and key else set()


def score(rows: list[dict[str, Any]], system: str) -> dict[str, Any]:
    n = len(rows)
    accepts = [r for r in rows if r[system + "_decision"] == "matched"]
    gold_matched = [r for r in rows if r["gold_decision"] == "matched"]
    gold_negative = [r for r in rows if r["gold_decision"] in {"unmatched", "review"}]
    correct = [r for r in accepts if r["gold_decision"] == "matched" and
               len(r[system + "_keys"]) == 1 and r[system + "_keys"] <= r["gold_keys"]]
    wrong_row = [r for r in accepts if r["gold_decision"] == "matched" and
                 not (len(r[system + "_keys"]) == 1 and r[system + "_keys"] <= r["gold_keys"])]
    false_u = [r for r in accepts if r["gold_decision"] == "unmatched"]
    false_r = [r for r in accepts if r["gold_decision"] == "review"]
    false_del = [r for r in rows if r["gold_decision"] == "matched" and
                 r[system + "_decision"] == "unmatched"]
    reviews = [r for r in rows if r[system + "_decision"] == "review"]
    matched_gold_accepts = [r for r in accepts if r["gold_decision"] == "matched"]
    return {
        "case_count": n, "accepted_count": len(accepts), "row_correct_accept_count": len(correct),
        "accepted_precision_including_gold_review": len(correct) / len(accepts) if accepts else None,
        "wrong_row_accept_count": len(wrong_row), "unsafe_multi_row_accept_count": 0,
        "false_accept_gold_unmatched_count": len(false_u), "false_accept_gold_review_count": len(false_r),
        "false_accept_gold_unmatched_or_review_count": len(false_u) + len(false_r),
        "gold_unmatched_or_review_count": len(gold_negative),
        "false_accept_rate_gold_unmatched_or_review": (len(false_u) + len(false_r)) / len(gold_negative) if gold_negative else None,
        "wrong_row_accept_rate_among_gold_matched_accepts": len(wrong_row) / len(matched_gold_accepts) if matched_gold_accepts else None,
        "gold_matched_count": len(gold_matched), "matched_recall_row_aware": len(correct) / len(gold_matched) if gold_matched else None,
        "false_deletion_gold_matched_predicted_unmatched_count": len(false_del),
        "false_deletion_rate_among_gold_matched": len(false_del) / len(gold_matched) if gold_matched else None,
        "covered_count_decision_not_review": n - len(reviews), "coverage": (n - len(reviews)) / n if n else None,
        "review_count": len(reviews), "review_rate": len(reviews) / n if n else None,
        "decision_counts": {d: sum(r[system + "_decision"] == d for r in rows) for d in ("matched", "unmatched", "review")},
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", type=Path, default=DEFAULT_RUN)
    ap.add_argument("--task-dir", type=Path, default=DEFAULT_TASK)
    ap.add_argument("--v10-dir", type=Path, default=DEFAULT_V10)
    ap.add_argument("--labels-dir", type=Path, default=DEFAULT_LABELS)
    ap.add_argument("--gpu-input", type=Path, default=DEFAULT_GPU)
    ap.add_argument("--source-blind-audit", type=Path, default=OUT / "v16-source-blind-audit.json")
    args = ap.parse_args()
    run, task_dir, v10_dir, label_dir = (x.resolve() for x in (args.run_dir, args.task_dir, args.v10_dir, args.labels_dir))
    raw, freeze_path, summary_path = run / "raw_predictions.jsonl", run / "freeze.json", run / "summary.json"
    if not all(p.is_file() for p in (raw, freeze_path, summary_path, args.source_blind_audit.resolve())):
        raise SystemExit("v16 raw, freeze, summary, and completed source-blind audit are required")
    freeze, summary = j(freeze_path), j(summary_path)
    raw_sha, freeze_sha = sha(raw), sha(freeze_path)
    if summary.get("raw_predictions_sha256") != raw_sha or summary.get("method_freeze_sha256") != freeze_sha:
        raise SystemExit("v16 raw/freeze SHA does not match durable summary")
    source_audit = j(args.source_blind_audit.resolve())
    if source_audit.get("labels_opened") is not False or source_audit.get("raw_predictions_sha256") != raw_sha:
        raise SystemExit("Source-blind audit is not complete for this exact raw file")
    if (source_audit.get("fixed_row_pool_mismatch_cases") or source_audit.get("source_fact_resolution_failures") or
            source_audit.get("curtain_count_conservation_failures")):
        raise SystemExit("Source-blind row pool/source-fact verification has failures")
    if not source_audit.get("input_source_hashes", {}).get("all_verified"):
        raise SystemExit("Source-blind audit did not verify all frozen input source hashes")
    original_refs = source_audit.get("source_references", {})
    if original_refs.get("original_raw_hash_failures"):
        raise SystemExit("Original raw citation hash failures")
    if source_audit.get("counts", {}).get("cases") != 1383 or source_audit.get("counts", {}).get("gpu196") != 196:
        raise SystemExit("Source-blind audit cohort verification mismatch")
    if not source_audit.get("frozen_code_and_input_hashes", {}).get("all_verified"):
        raise SystemExit("Frozen code/input hash checks are incomplete")
    if source_audit.get("curtain_count_conservation_verified", 0) != sum(
            source_audit.get("curtain_count_conservation_resolutions_by_variant", {}).values()):
        raise SystemExit("Not all count-conservation resolutions were independently verified")

    labels_path, labels_manifest_path = label_dir / "labels.jsonl", label_dir / "manifest.json"
    labels_manifest, labels_sha = j(labels_manifest_path), sha(labels_path)
    if labels_sha != labels_manifest.get("output_sha256", {}).get("labels.jsonl"):
        raise SystemExit("Label file SHA does not match label manifest")
    # Labels are not read until CPU raw, freeze, source audit, and label hashes pass.
    labels = jl(labels_path)
    labels_by_id = {x["case_id"]: x for x in labels}
    tasks = jl(task_dir / "tasks.jsonl")
    task_by_id = {x["case_id"]: x for x in tasks}
    cpu_rows = jl(raw)
    hybrid_rows = jl(v10_dir / "hybrid/predictions.jsonl")
    hybrid_by_id = {x["case_id"]: x for x in hybrid_rows}
    expected_ids = set(task_by_id)
    if len(cpu_rows) != 1383 or set(labels_by_id) != expected_ids or {x["case_id"] for x in cpu_rows} != expected_ids or set(hybrid_by_id) != expected_ids:
        raise SystemExit("CPU, labels, v10 hybrid, and frozen tasks must cover the exact same 1,383 IDs")
    hybrid_sha = sha(v10_dir / "hybrid/predictions.jsonl")
    if j(v10_dir / "hybrid/summary.json").get("predictions_sha256") != hybrid_sha:
        raise SystemExit("v10 hybrid baseline SHA mismatch")
    gpu_ids = {x["case_id"] for x in jl(args.gpu_input.resolve())}
    if len(gpu_ids) != 196 or {x["case_id"] for x in tasks if x.get("gpu196_cohort") is True} != gpu_ids:
        raise SystemExit("Exact fixed GPU 196 subset mismatch")

    joined = []
    for outer in cpu_rows:
        cid = outer["case_id"]
        task = task_by_id[cid]
        gold = labels_by_id[cid]
        gd = gold.get("decision", gold.get("semantic_label"))
        if gd not in {"matched", "unmatched", "review"}:
            raise SystemExit(f"Unexpected label decision for {cid}: {gd!r}")
        row = {"case_id": cid, "dossier_id": task.get("dossier_id"),
               "category": (task.get("rakuten") or {}).get("attrs", {}).get("category", "unknown"),
               "gpu196": cid in gpu_ids, "gold_decision": gd,
               "gold_keys": set(gold.get("matching_au_row_keys") or [])}
        h = hybrid_by_id[cid]
        row.update({"v10_hybrid_decision": h.get("decision"), "v10_hybrid_keys": keys_for(h.get("decision"), h.get("top_row_key"))})
        for variant, short in (("hybrid_v10_recomputed", "v16_hybrid"), ("canonical_v2_recomputed", "v16_canonical")):
            v = outer.get("variants", {}).get(variant)
            if not v:
                raise SystemExit(f"Missing v15 variant {variant} in {cid}")
            sg = v.get("sourcegate_prediction") or {}
            gate_name = short + "_sourcegate"
            row[gate_name + "_decision"] = sg.get("decision")
            row[gate_name + "_keys"] = keys_for(sg.get("decision"), sg.get("top_row_key"))
            row[short + "_decision"] = v.get("decision")
            row[short + "_keys"] = keys_for(v.get("decision"), v.get("top_row_key"))
            row[short + "_reason"] = v.get("reason")
            row[short + "_residual_relations"] = v.get("residual_relations", [])
        joined.append(row)

    systems = ["v10_hybrid", "v16_hybrid_sourcegate", "v16_hybrid", "v16_canonical_sourcegate", "v16_canonical"]
    cohorts: dict[str, list[dict[str, Any]]] = {
        "full1383": joined, "same_gpu196": [r for r in joined if r["gpu196"]],
        "curtain": [r for r in joined if r["category"] == "curtain"],
        "noncurtain": [r for r in joined if r["category"] != "curtain"],
    }
    metrics = {name: {system: score(rows, system) for system in systems} for name, rows in cohorts.items()}
    dossiers: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in joined:
        dossiers[r["dossier_id"]].append(r)
    dossier_rows = []
    metric_fields = ["accepted_precision_including_gold_review", "matched_recall_row_aware", "coverage", "review_rate",
                     "false_accept_rate_gold_unmatched_or_review", "wrong_row_accept_rate_among_gold_matched_accepts",
                     "false_deletion_rate_among_gold_matched"]
    for did, rows in sorted(dossiers.items()):
        d = {"dossier_id": did, "case_count": len(rows)}
        for system in systems:
            sm = score(rows, system)
            for f in metric_fields:
                d[f"{system}_{f}"] = sm[f]
        dossier_rows.append(d)
    dossier_macro = {system: {f: mean([r[f"{system}_{f}"] for r in dossier_rows if r[f"{system}_{f}"] is not None])
                              if any(r[f"{system}_{f}"] is not None for r in dossier_rows) else None
                              for f in metric_fields} for system in systems}
    for system in systems:
        dossier_macro[system]["dossier_count"] = len(dossier_rows)

    # Transition accounting distinguishes source-gate retention from actual model change.
    decompositions = {}
    for short in ("v16_hybrid", "v16_canonical"):
        sg = short + "_sourcegate"
        baseline_correct = {r["case_id"] for r in joined if r[sg + "_decision"] == "matched" and
                            r["gold_decision"] == "matched" and len(r[sg + "_keys"]) == 1 and r[sg + "_keys"] <= r["gold_keys"]}
        final_correct = {r["case_id"] for r in joined if r[short + "_decision"] == "matched" and
                         r["gold_decision"] == "matched" and len(r[short + "_keys"]) == 1 and r[short + "_keys"] <= r["gold_keys"]}
        v10_correct = {r["case_id"] for r in joined if r["v10_hybrid_decision"] == "matched" and
                       r["gold_decision"] == "matched" and len(r["v10_hybrid_keys"]) == 1 and r["v10_hybrid_keys"] <= r["gold_keys"]}
        transitions = Counter((r[sg + "_decision"], r[short + "_decision"]) for r in joined)
        decompositions[short] = {
            "sourcegate_row_correct_accepts": len(baseline_correct),
            "final_row_correct_accepts": len(final_correct),
            "model_added_correct_accepts_vs_recomputed_sourcegate": len(final_correct - baseline_correct),
            "sourcegate_correct_accepts_lost_after_residual": len(baseline_correct - final_correct),
            "v10_hybrid_correct_accepts": len(v10_correct),
            "final_correct_accepts_added_vs_v10_hybrid": len(final_correct - v10_correct),
            "v10_hybrid_correct_accepts_lost": len(v10_correct - final_correct),
            "sourcegate_to_residual_decision_transitions": {f"{a}->{b}": n for (a, b), n in transitions.items()},
        }
    model_evidence = {}
    for short in ("v16_hybrid", "v16_canonical"):
        accepted_rows = [r for r in cpu_rows if r["variants"]["hybrid_v10_recomputed" if short == "v16_hybrid" else "canonical_v2_recomputed"]["decision"] == "matched"]
        residuals = [x for r in accepted_rows for x in r["variants"]["hybrid_v10_recomputed" if short == "v16_hybrid" else "canonical_v2_recomputed"].get("residual_relations", [])]
        model_evidence[short] = {"accepted_count": len(accepted_rows),
                                 "accepted_with_model_entailed_residual": sum(any(x.get("model_relation") == "entailed" for x in r["variants"]["hybrid_v10_recomputed" if short == "v16_hybrid" else "canonical_v2_recomputed"].get("residual_relations", [])) for r in accepted_rows),
                                 "source_fact_resolved_residual_count": sum(bool(x.get("source_fact_resolution")) for x in residuals),
                                 "count_conservation_resolved_residual_count": sum(bool(x.get("contents_count_conservation")) for x in residuals),
                                 "model_entailed_residual_count": sum(x.get("model_relation") == "entailed" for x in residuals)}

    label_protocol = labels_manifest.get("annotation_protocol", {})
    result = {
        "schema": "sku-cpu-v16-row-aware-evaluation-v1", "evaluated_at_utc": datetime.now(timezone.utc).isoformat(),
        "cpu_method": "cached v11 model outputs + v16 recomputed full-pool gates, direct source evidence, and strict width-scoped contents count conservation; no new inference",
        "cpu_model_inference": False, "prior_predictions_referenced_label_free": True,
        "prior_prediction_source_sha256": freeze.get("input_sha256", {}).get("sourcegate"),
        "raw_predictions_sha256": raw_sha, "freeze_sha256": freeze_sha, "summary_sha256": sha(summary_path),
        "labels_sha256": labels_sha, "labels_annotation_protocol": label_protocol,
        "labels_human_verified": label_protocol.get("human_verified"),
        "labels_independent_external_gold": label_protocol.get("independent_external_gold"),
        "labels_status": "Luna machine annotations, not human-verified; previously inspected/reused diagnostic set; metrics are development agreement only.",
        "task_manifest_sha256": sha(task_dir / "manifest.json"),
        "v10_hybrid_predictions_sha256": hybrid_sha,
        "source_blind_audit_sha256": sha(args.source_blind_audit.resolve()),
        "cohorts": metrics, "dossier_macro": dossier_macro,
        "model_gain_decomposition": decompositions, "accepted_residual_evidence": model_evidence,
        "curtain_count_conservation_resolutions": source_audit.get("curtain_count_conservation_resolutions_by_variant"),
        "curtain_count_conservation_verified": source_audit.get("curtain_count_conservation_verified"),
        "case_count": len(joined), "dossier_count": len(dossiers),
        "interpretation": "v10 hybrid is the primary same-row baseline. Recomputed source gate separates retained evidence from changes after residual model/source-evidence adjudication. Zero model-added accepts means no new correct matches were created by residual inference; decreases are sourcegate matches moved to review/unmatched.",
        "limitations": ["No new model inference was run; v11 cached raw/residual outputs were reused.",
                        "Machine-generated Luna labels are unverified and the diagnostic set was previously inspected/reused; do not present metrics as human accuracy or independent generalization.",
                        "Matched is row-correct only when exactly one returned AU row key is present in the label's matching_au_row_keys; gold review is included in accepted precision denominator."],
    }
    (OUT / "v16-evaluation.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (OUT / "v16-cohort-metrics.csv").open("w", newline="", encoding="utf-8") as f:
        cols = ["cohort", "system", "case_count", "accepted_count", "row_correct_accept_count", "accepted_precision_including_gold_review",
                "wrong_row_accept_count", "false_accept_gold_unmatched_count", "false_accept_gold_review_count",
                "false_accept_rate_gold_unmatched_or_review", "false_deletion_gold_matched_predicted_unmatched_count",
                "false_deletion_rate_among_gold_matched", "matched_recall_row_aware", "coverage", "review_count", "review_rate"]
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader()
        for cohort, smap in metrics.items():
            for system, m in smap.items():
                w.writerow({"cohort": cohort, "system": system, **{k: m.get(k) for k in cols[2:]}})
        for system, m in dossier_macro.items():
            w.writerow({"cohort": "dossier_macro", "system": system, "case_count": m["dossier_count"],
                        "accepted_precision_including_gold_review": m["accepted_precision_including_gold_review"],
                        "false_accept_rate_gold_unmatched_or_review": m["false_accept_rate_gold_unmatched_or_review"],
                        "false_deletion_rate_among_gold_matched": m["false_deletion_rate_among_gold_matched"],
                        "matched_recall_row_aware": m["matched_recall_row_aware"], "coverage": m["coverage"], "review_rate": m["review_rate"]})
    with (OUT / "v16-dossier-metrics.csv").open("w", newline="", encoding="utf-8") as f:
        fields = list(dossier_rows[0])
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(dossier_rows)
    with (OUT / "v16-case-results.jsonl").open("w", encoding="utf-8") as f:
        for r in joined:
            f.write(json.dumps({k: sorted(v) if isinstance(v, set) else v for k, v in r.items()}, ensure_ascii=False, sort_keys=True) + "\n")
    print(json.dumps({"status": "evaluated", "raw_sha256": raw_sha, "cohorts": metrics["full1383"],
                      "dossier_macro": dossier_macro, "gain_decomposition": decompositions}, ensure_ascii=False))


if __name__ == "__main__":
    main()
