# CPU残差モデル独立監査 v2

このフォルダーはv14/v15/v16のsource-blind監査と、v15/v16の行対応評価を保存します。v16は厳格なsource-count保存条件をraw原本から独立再計算して監査しました。

- [最終レポート v16](report.md)
- [v16 source-blind監査](v16-source-blind-audit.json)
- [v16 行対応評価](v16-evaluation.json)
- [v16 コホート指標CSV](v16-cohort-metrics.csv)
- [v16 dossier指標CSV](v16-dossier-metrics.csv)
- [v16 ケース別行対応結果](v16-case-results.jsonl)
- [v15 診断評価](v15-evaluation.json)
- [source-blind監査器](audit_v14_source_blind.py)
- [v16 評価器](evaluate_v16.py)
- [v15 評価器](evaluate_v15.py)

v14/v15は診断用ablationです。v16はv11 cached model raw/residual outputsを使っており、新規推論ではありません。v10 hybrid予測もsource-gate比較のためlabel-blindで参照済みです。ラベルはLuna機械注釈で人手確認されておらず、診断集合も再利用済みです。数値はラベルとの開発一致率として扱ってください。
