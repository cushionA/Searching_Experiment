#!/usr/bin/env python3
"""Check v12 raw decisions, gates, and source citations without opening labels."""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
GPU_INPUT = ROOT / ".lab-output/sku-kaggle-gpu-20261010-v2/dataset-upload/inputs.jsonl"
STRUCTURED_TASKS = ROOT / ".lab-output/sku-structured-task-trials-20261010-v10/tasks.jsonl"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def resolve(path_text: str) -> Path:
    path = Path(path_text)
    return path if path.is_absolute() else ROOT / path


def iter_dicts(obj: Any):
    if isinstance(obj, dict):
        yield obj
        for value in obj.values():
            yield from iter_dicts(value)
    elif isinstance(obj, list):
        for value in obj:
            yield from iter_dicts(value)


def simple_json_path(doc: Any, path: str) -> Any:
    """Resolve ordinary $.a.b[0] paths; unsupported selectors return None."""
    if not path.startswith("$." ):
        return None
    cur = doc
    rest = path[2:]
    token = ""
    i = 0
    while i < len(rest):
        c = rest[i]
        if c == ".":
            if token:
                if not isinstance(cur, dict) or token not in cur:
                    return None
                cur, token = cur[token], ""
            i += 1
        elif c == "[":
            if token:
                if not isinstance(cur, dict) or token not in cur:
                    return None
                cur, token = cur[token], ""
            end = rest.find("]", i)
            if end < 0:
                return None
            try:
                idx = int(rest[i + 1:end])
                cur = cur[idx]
            except (ValueError, IndexError, TypeError):
                return None
            i = end + 1
        else:
            token += c
            i += 1
    if token:
        if not isinstance(cur, dict) or token not in cur:
            return None
        cur = cur[token]
    return cur


class VisibleHTML(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def normalize_quote(text: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def quote_matches(raw: bytes, path: Path, json_path: str | None, quote: str) -> bool:
    try:
        text = raw.decode("utf-8", errors="replace")
    except Exception:
        text = ""
    qnorm = normalize_quote(quote)
    if qnorm and qnorm in normalize_quote(text):
        return True
    if path.suffix.lower() in {".html", ".htm"}:
        parser = VisibleHTML()
        try:
            parser.feed(text)
            visible = normalize_quote(" ".join(parser.parts))
            if qnorm and qnorm in visible:
                return True
        except Exception:
            pass
    if path.suffix.lower() == ".json" and json_path:
        try:
            value = simple_json_path(json.loads(raw.decode("utf-8")), json_path)
            if isinstance(value, str):
                return qnorm == normalize_quote(value) or (qnorm and qnorm in normalize_quote(value))
        except (UnicodeDecodeError, json.JSONDecodeError):
            pass
    return False


def selected_keys(row: dict[str, Any]) -> set[str]:
    for key in ("candidate_row_keys_after_legacy_guard", "selected_au_row_keys",
                "returned_au_row_keys", "selected_row_keys"):
        value = row.get(key)
        if isinstance(value, list):
            return {str(x) for x in value if x}
    for key in ("selected_au_row_key", "selected_row_key", "top_row_key"):
        if row.get(key):
            return {str(row[key])}
    return set()


def row_compat(row: dict[str, Any], common: dict[str, Any], fields: list[str]) -> tuple[bool, bool]:
    """Return (definite compatible, possible compatible) for a fixed AU row."""
    entity = row.get("current_entity") or {}
    attrs = entity.get("attrs") or row.get("attrs") or {}
    unknown = set(entity.get("unknown_fields") or row.get("unknown_fields") or [])
    conflicts = set(entity.get("source_conflicts") or row.get("source_conflicts") or [])
    definite = True
    possible = True
    for field in fields:
        value = attrs.get(field)
        if field in unknown or value is None:
            definite = False
            continue
        if value != common.get(field):
            possible = False
            definite = False
    if conflicts:
        definite = False
    return definite, possible


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cpu-raw", type=Path, required=True)
    ap.add_argument("--cpu-run-dir", type=Path, required=True)
    ap.add_argument("--task-dir", type=Path, required=True)
    ap.add_argument("--gpu-input", type=Path, default=GPU_INPUT)
    ap.add_argument("--structured-tasks", type=Path, default=STRUCTURED_TASKS)
    ap.add_argument("--runner-code", type=Path)
    ap.add_argument("--prepare-code", type=Path)
    ap.add_argument("--output", type=Path, default=OUT / "source-blind-audit.json")
    args = ap.parse_args()
    run_dir = args.cpu_run_dir.resolve()
    raw_path = args.cpu_raw.resolve()
    freeze_path = run_dir / "freeze.json"
    inference_path = run_dir / "inference-manifest.json"
    task_manifest_path = args.task_dir / "manifest.json"
    products_path = args.task_dir / "products.jsonl"
    task_path = args.task_dir / "tasks.jsonl"
    residual_path = run_dir / "raw_residual_outputs.jsonl"
    for path in (freeze_path, inference_path, task_manifest_path, products_path, task_path,
                 residual_path, raw_path):
        if not path.is_file():
            raise SystemExit(f"Missing durable source-blind input: {path}")

    freeze = read_json(freeze_path)
    inference = read_json(inference_path)
    manifest = read_json(task_manifest_path)
    raw_hash, residual_hash = sha(raw_path), sha(residual_path)
    if inference.get("raw_predictions_sha256") != raw_hash:
        raise SystemExit("Raw prediction SHA differs from inference manifest")
    if inference.get("raw_residual_outputs_sha256") != residual_hash:
        raise SystemExit("Raw residual SHA differs from inference manifest")
    if freeze.get("tasks_sha256") != sha(task_path) or freeze.get("products_sha256") != sha(products_path):
        raise SystemExit("Frozen task/product SHA mismatch")
    if freeze.get("task_manifest_sha256") != sha(task_manifest_path):
        raise SystemExit("Frozen task manifest SHA mismatch")
    if args.runner_code and freeze.get("trial_code_sha256") != sha(args.runner_code):
        raise SystemExit("Frozen runner code SHA mismatch")
    if args.prepare_code and freeze.get("prepare_code_sha256") != sha(args.prepare_code):
        raise SystemExit("Frozen preparer code SHA mismatch")

    tasks, products = read_jsonl(task_path), read_jsonl(products_path)
    predictions, residuals = read_jsonl(raw_path), read_jsonl(residual_path)
    structured_tasks = read_jsonl(args.structured_tasks)
    structured_by_id = {x["case_id"]: x for x in structured_tasks}
    task_by_id = {x["case_id"]: x for x in tasks}
    prediction_ids = [x.get("case_id") for x in predictions]
    if len(task_by_id) != len(tasks) or len(set(prediction_ids)) != len(predictions):
        raise SystemExit("Duplicate task or prediction IDs")
    if set(task_by_id) != set(prediction_ids):
        raise SystemExit("Raw prediction IDs differ from frozen task IDs")
    product_by_id = {x["product_id"]: x for x in products}
    gpu_ids = {x["case_id"] for x in read_jsonl(args.gpu_input)}
    flagged_gpu_ids = {x["case_id"] for x in tasks if x.get("gpu196_cohort") is True}
    if len(tasks) != 1383 or len(gpu_ids) != 196 or flagged_gpu_ids != gpu_ids:
        raise SystemExit("Expected exact 1,383 cases and exact fixed 196-case subset")

    selected_issue_counts: Counter[str] = Counter()
    accepted = [r for r in predictions if r.get("decision") == "matched"]
    for r in accepted:
        keys = selected_keys(r)
        plan = r.get("plan") or {}
        if len(keys) != 1:
            selected_issue_counts["matched_not_exactly_one_row"] += 1
        product = product_by_id.get(r.get("product_id"))
        rows = (product or {}).get("au_sku_rows", [])
        row_by_key = {x.get("row_key"): x for x in rows}
        key = next(iter(keys), None) if len(keys) == 1 else None
        if key not in row_by_key:
            selected_issue_counts["selected_row_not_in_fixed_au_pool"] += 1
            selected_row = None
        else:
            selected_row = row_by_key[key]
        common = plan.get("common_values") or {}
        fields = plan.get("common_fields") or list(common)
        if selected_row is not None:
            definite, _ = row_compat(selected_row, common, fields)
            if not definite:
                selected_issue_counts["selected_row_fails_known_common_axis"] += 1
        definite_rows, possible_rows = [], []
        for candidate in rows:
            definitely, possibly = row_compat(candidate, common, fields)
            if definitely:
                definite_rows.append(candidate.get("row_key"))
            if possibly:
                possible_rows.append(candidate.get("row_key"))
        if len(definite_rows) != 1:
            selected_issue_counts["common_axis_definite_rows_not_unique"] += 1
        if len(possible_rows) != 1:
            selected_issue_counts["possible_common_axis_alternative_remains"] += 1
        if plan.get("au_only_axes"):
            selected_issue_counts["accepted_with_au_only_axis"] += 1
        if plan.get("r_axis_conflicts"):
            selected_issue_counts["accepted_with_rakuten_axis_conflict"] += 1
        residual_results = r.get("residual_results") or []
        by_sem = {x.get("semantic_key"): x.get("relation") for x in residual_results}
        for axis in plan.get("residual_axes") or []:
            if by_sem.get(axis.get("semantic_key")) != "entailed":
                selected_issue_counts["accepted_without_entailed_extra_axis"] += 1
        task = task_by_id[r["case_id"]]
        task_conflicts = task.get("rakuten", {}).get("source_conflicts", [])
        page_conflicts = (task.get("current_page_context") or {}).get("internal_source_conflicts", [])
        entity_conflicts = ((selected_row or {}).get("current_entity") or {}).get("source_conflicts", [])
        if task_conflicts or page_conflicts or entity_conflicts:
            selected_issue_counts["accepted_with_source_conflict"] += 1

    # Verify every declared input-source hash, then every source reference carried
    # by tasks/products/predictions/residual outputs. No labels are opened here.
    expected_sources = {}
    for mapping in (manifest.get("source_sha256_pre", {}), manifest.get("source_sha256_post", {})):
        expected_sources.update(mapping)
    expected_sources_by_abs = {str(resolve(path).resolve()): value for path, value in expected_sources.items()}
    expected_sources_by_basename: dict[str, list[tuple[str, str]]] = {}
    for source_path, digest in expected_sources.items():
        expected_sources_by_basename.setdefault(Path(source_path).name, []).append((source_path, digest))
    source_manifest_checks = []
    for ptext, expected in expected_sources.items():
        if any(word in ptext.lower() for word in ("label", "gold", "prediction")):
            continue
        p = resolve(ptext)
        actual = sha(p) if p.is_file() else None
        source_manifest_checks.append({"path": str(p), "expected_sha256": expected,
                                       "actual_sha256": actual, "verified": actual == expected})

    source_ref_records = {}
    docs = [("tasks", tasks), ("products", products), ("predictions", predictions),
            ("residuals", residuals)]
    def collect_refs(obj: Any, doc_name: str, inherited_quote: str | None = None) -> None:
        if isinstance(obj, dict):
            # Only a quote explicitly attached to a reference, or inherited from its
            # containing evidence object, is evidence text. Generic `text` fields
            # commonly contain unrelated titles and must not be treated as quotes.
            quote = obj.get("quote") or inherited_quote
            file_text = obj.get("file") or obj.get("raw_file")
            if file_text:
                p = resolve(str(file_text))
                if not p.is_file():
                    candidates = expected_sources_by_basename.get(Path(str(file_text)).name, [])
                    if len(candidates) == 1:
                        p = resolve(candidates[0][0])
                expected = obj.get("sha256") or obj.get("raw_sha256") or obj.get("hash")
                expected = expected or expected_sources.get(str(p)) or expected_sources.get(str(file_text))
                expected = expected or expected_sources_by_abs.get(str(p.resolve()))
                if not expected:
                    candidates = expected_sources_by_basename.get(Path(str(file_text)).name, [])
                    if len(candidates) == 1:
                        expected = candidates[0][1]
                json_path = obj.get("json_path")
                key = (str(p), str(expected or ""), str(quote or ""), str(json_path or ""))
                ptext = str(p).replace("\\", "/")
                original_raw = ("/sku-real-au-" in ptext or "/sku-real-rakuten-" in ptext) and \
                               "normalized-v" not in ptext and "observed-product-pairs" not in ptext
                source_ref_records.setdefault(key, {"path": str(p), "expected_sha256": expected,
                                                   "quote": quote, "json_path": json_path,
                                                   "documents": set(),
                                                   "is_original_raw": original_raw})["documents"].add(doc_name)
                source_ref_records[key]["is_original_raw"] |= original_raw
            for value in obj.values():
                collect_refs(value, doc_name, quote)
        elif isinstance(obj, list):
            for value in obj:
                collect_refs(value, doc_name, inherited_quote)

    for doc_name, doc in docs:
        collect_refs(doc, doc_name)
    source_ref_checks = []
    for rec in source_ref_records.values():
        p = Path(rec["path"])
        actual = sha(p) if p.is_file() else None
        raw = p.read_bytes() if p.is_file() and rec["quote"] else b""
        quote_ok = None
        if rec["quote"]:
            quote_ok = quote_matches(raw, p, rec["json_path"], str(rec["quote"]))
        source_ref_checks.append({"path": rec["path"], "expected_sha256": rec["expected_sha256"],
                                  "actual_sha256": actual,
                                  "hash_verified": bool(rec["expected_sha256"] and actual == rec["expected_sha256"]),
                                  "is_original_raw": rec["is_original_raw"],
                                  "quote": rec["quote"], "json_path": rec["json_path"],
                                  "quote_verified": quote_ok,
                                  "documents": sorted(rec["documents"])})

    # The frozen fixed AU candidate rows must remain identical to the 1,383 task rows.
    all_row_keys, refs, pool_mismatches = set(), 0, []
    for task in tasks:
        product = product_by_id.get(task.get("product_id"))
        product_rows = (product or {}).get("au_sku_rows", [])
        refs += len(product_rows)
        all_row_keys.update(x.get("row_key") for x in product_rows)
        expected_task = structured_by_id.get(task.get("case_id"))
        structured = (expected_task or {}).get("au_candidates") or (expected_task or {}).get("au_sku_rows")
        if structured is None or {x.get("row_key") for x in structured} != {x.get("row_key") for x in product_rows}:
            pool_mismatches.append(task.get("case_id"))

    result = {
        "schema": "sku-cpu-source-blind-audit-v1",
        "run_dir": str(run_dir), "task_dir": str(args.task_dir.resolve()),
        "raw_predictions_sha256": raw_hash, "raw_residual_outputs_sha256": residual_hash,
        "freeze_sha256": sha(freeze_path), "inference_manifest_sha256": sha(inference_path),
        "task_manifest_sha256": sha(task_manifest_path),
        "labels_opened": False,
        "counts": {"tasks": len(tasks), "predictions": len(predictions), "accepted": len(accepted),
                   "review": sum(r.get("decision") == "review" for r in predictions),
                   "unmatched": sum(r.get("decision") == "unmatched" for r in predictions),
                   "gpu196": len(gpu_ids), "products": len(products),
                   "fixed_au_row_references": refs, "unique_au_row_keys": len(all_row_keys),
                   "unique_residual_outputs": len(residuals)},
        "decision_counts": dict(Counter(r.get("decision") for r in predictions)),
        "reason_counts": dict(Counter(r.get("reason") for r in predictions)),
        "source_blind_matched_guard_failures": dict(selected_issue_counts),
        "possible_source_ambiguity_risk": sum(v for k, v in selected_issue_counts.items()
                                                if k in {"possible_common_axis_alternative_remains",
                                                         "common_axis_definite_rows_not_unique"}),
        "fixed_row_pool_mismatch_cases": pool_mismatches,
        "structured_task_count": len(structured_tasks),
        "input_source_hashes": {"verified": sum(x["verified"] for x in source_manifest_checks),
                                "total": len(source_manifest_checks),
                                "all_verified": all(x["verified"] for x in source_manifest_checks),
                                "checks": source_manifest_checks},
        "source_references": {"distinct_references": len(source_ref_checks),
                              "hash_verified": sum(x["hash_verified"] for x in source_ref_checks),
                              "hash_missing_or_mismatch": sum(not x["hash_verified"] for x in source_ref_checks),
                              "original_raw_references": sum(x["is_original_raw"] for x in source_ref_checks),
                              "original_raw_hash_verified": sum(x["is_original_raw"] and x["hash_verified"]
                                                                 for x in source_ref_checks),
                              "quotes_present": sum(x["quote"] is not None for x in source_ref_checks),
                              "quotes_verified": sum(x["quote_verified"] is True for x in source_ref_checks),
                              "verbatim_quote_failures": sum(x["quote_verified"] is False for x in source_ref_checks
                                                              if x.get("quote")),
                              "checks": source_ref_checks},
        "task_manifest_synthetic_data_included": manifest.get("synthetic_data_included"),
        "limitations": ["This report is source-blind: labels and gold were not opened.",
                        "A missing selected key, unresolved candidate, non-entailed residual, AU-only axis, or source conflict is flagged as unsafe for a matched decision."],
    }
    out_path = args.output.resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    source_ref_summary = {k: v for k, v in result["source_references"].items() if k != "checks"}
    source_hash_summary = {k: v for k, v in result["input_source_hashes"].items() if k != "checks"}
    print(json.dumps({"counts": result["counts"], "decision_counts": result["decision_counts"],
                      "reason_counts": result["reason_counts"],
                      "source_blind_matched_guard_failures": result["source_blind_matched_guard_failures"],
                      "source_references": source_ref_summary,
                      "input_source_hashes": source_hash_summary}, ensure_ascii=False))


if __name__ == "__main__":
    main()
