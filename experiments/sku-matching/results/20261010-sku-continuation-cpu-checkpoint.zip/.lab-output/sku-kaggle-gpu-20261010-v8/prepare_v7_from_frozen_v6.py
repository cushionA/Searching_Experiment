"""Reproducible label-blind v7 bundle derivation; refuses to overwrite a run."""
from __future__ import annotations
import hashlib, json, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
V6 = ROOT / ".lab-output/sku-kaggle-gpu-20261010-v6/dataset-upload"
V7 = ROOT / ".lab-output/sku-kaggle-gpu-20261010-v7/dataset-upload"
RUNNER = ROOT / "experiments/sku-matching/kaggle_gpu_sku_runner_v2.py"

def digest(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main() -> None:
    if V7.exists():
        raise FileExistsError(f"Refusing to overwrite frozen v7: {V7}")
    parent = json.loads((V6 / "manifest.json").read_text())
    if digest(V6 / "inputs.jsonl") != parent["inputs_sha256"]:
        raise ValueError("v6 source input hash mismatch")
    V7.mkdir(parents=True)
    for name in ("inputs.jsonl", "source-cases.jsonl"):
        shutil.copy2(V6 / name, V7 / name)
    shutil.copy2(RUNNER, V7 / "kaggle_gpu_sku_runner_v2.py")
    config = json.loads((V6 / "config.json").read_text())
    config.update(max_new_tokens=256, reason_char_range_japanese=[20, 40], runner_version="v7")
    (V7 / "config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n")
    # The canonical manifest and upload hashes are finalized by the freeze checklist.
    print("Copied frozen v6 source cases; output tokens 256; no source reconstruction or labels read.")

if __name__ == "__main__":
    main()
