# v8 private Kaggle transfer (root submits)

Dataset payload: `.lab-output/sku-kaggle-gpu-20261010-v8/dataset-upload/`. Create private dataset slug `superbigzabuton/sku-gpu-qwen35-4b-nf4-v8`; attach it to the private notebook in `notebook-upload/kernel-metadata.json`. This package has not been submitted.

The 14 frozen cases and full AU pools are byte-for-byte inherited from v6. v8 changes only the output-reason contract from v7: the prompt asks for a reason of at most 40 Japanese characters, while validation accepts any nonempty reason up to 80 characters. `max_new_tokens` remains 256. The notebook verifies uploaded hashes, creates a clean venv with `with_pip=False, system_site_packages=False`, installs pinned CUDA 12.6 and Transformers packages via base pip `--python`, and caps the run at 3600 seconds. HF cache stays under `/tmp`; outputs go to `/kaggle/working/sku-v8-results`.
