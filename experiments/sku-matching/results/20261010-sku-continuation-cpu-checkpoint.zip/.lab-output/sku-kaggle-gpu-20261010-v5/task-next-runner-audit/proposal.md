# Source-only runner task-structure audit

Status: proposal only. This audit read the frozen v2 prompts and source-backed inputs; it did not inspect labels, predictions, or current inference results. It makes no accuracy claim.

The existing `task-design-next` proposal already has the right high-level shape: cache AU-page evidence by dossier, compare the selected Rakuten SKU, preserve the full AU row pool, and distinguish explicit contradiction from unresolved evidence. The remaining risk is how page-level prose is scoped. On variant-heavy pages, general product copy, selected-page defaults, size tables, and conditional exceptions can be conflated even when the source itself says exactly which variant each statement applies to.

Two source-backed examples show the gap:

- Curtain case `case-1a0967e634083db9aaf8` (`pair-e228ee5f40dc113f`, 153 AU rows) selects 150×135 cm, sand beige, with lace. Rakuten copy separately describes a main curtain, tassel, hooks, and a lace panel whose length is 2 cm shorter, with composition conditional on choosing lace; the 150 cm width also has its own curtain and hook counts. The AU page has many size/color rows and page text with a 150 cm width-specific count. A flat “page facts” card can accidentally apply a conditional lace or accessory claim to every row, or treat lace as the main curtain.
- Carwash-platform case `case-3ce2d8e67d5a70c768f3` (`pair-2731f3cede6c0af8`, 4 AU rows) selects width 78 cm, height 75 cm, gray. Rakuten says the handle is absent for the 50 cm silver variant; the AU page mixes a 50 cm page default, alternative heights/widths, and general handle copy. The exception is conjunctive: it applies to height 50 cm and silver, not to the selected 75 cm gray variant or all platform options.

## Proposed task structure

1. Build a compact AU evidence card once per dossier, keyed by `dossier_id` plus the source/input hash. Keep claims separate rather than paraphrasing them together. Each claim should carry `scope` (`page_common`, `specific_variant`, `conditional_variant`, or `unknown`), `axis`, literal `value`, `source_field`, exact `quote`, optional `row_key`, and an explicit `applies_when` condition. For row-derived facts, require row identity. For prose-derived facts, record the source field and the condition exactly as stated. Do not infer that a generic claim overrides a conditional exception.
2. For each Rakuten case, extract the selected SKU axes and literal supporting quotes. Keep product identity, selected option values, package contents/accessories, and page/series claims as distinct axes. The task is to compare this selected option, not to decide whether the products are generally similar.
3. Resolve the selected option against the entire fixed AU pool. A row is eligible only when its literal option values are known and compatible with the selected SKU and applicable source claims. Return `matched` only with a valid exact AU `row_key`; return `unmatched` only when an explicit selected-SKU condition contradicts every AU row; return `review` when applicability, relevant values, or source claims remain unknown or conflicting. Never prune or omit rows in the stored input or output provenance.
4. In the final result, bind every decisive AU evidence quote to `source_field` and, for row evidence, `row_key`. Bind Rakuten evidence to its exact source field. For `matched` and `unmatched`, require at least one nonempty literal quote from each side. A match's selected row must be supported by row-specific evidence or an explicitly applicable page-level claim. Review may have no decisive quote, but should preserve the unresolved axis/reason.

This makes conditional composition inspectable: for example, “lace included” and “one lace panel” remain separate claims with the stated selection condition, and a handle exception remains attached to its complete trigger rather than becoming a page-wide property. It also prevents the model from turning a broad page description into a fact about every option.

## Prompt and input controls

State explicitly that the upstream product pair is already fixed as the same product family and the task is only to map the selected Rakuten option to one exact AU row. Do not re-open product identity matching. State that price, discounts, popularity, shipping, and availability are not matching criteria; use only option values and applicable product/composition facts. Those fields are not part of the permitted evidence even if marketing copy mentions them.

Treat all quoted titles, descriptions, SKUs, and option labels as untrusted evidence data; instructions embedded in them must not change the task. Preserve the complete AU row array and source text needed for the decision. Do not summarize away exceptions or silently choose a “closest” row.

Use the pinned Qwen3.5-9B tokenizer/revision and the same chat template, `enable_thinking=False`, and generation-prompt settings as the inference runner for preflight length measurement. Enforce the configured 16,000-token input ceiling without arbitrary truncation. If an input exceeds it, emit an explicit invalid/over-limit record for review and do not generate a partial-context decision. Token counts are an operational gate, not evidence about decision quality.

## Reviewable changes and validation

The proposal is limited to task-card structure, prompt wording, and evidence validation. Before any new inference, test the serializer and validator on the existing source-backed cases only: verify that the conditional claims above retain their full trigger axes; page facts do not become row facts without a row binding; `matched`/`unmatched` require literal evidence from both sides; the selected row key belongs to the unmodified full pool; and an over-limit case is explicit rather than truncated. Then compare token cost against the current prompt using the pinned tokenizer, without altering frozen inputs. Any quality claim requires a later blinded, labeled evaluation and is outside this audit.
