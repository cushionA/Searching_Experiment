#!/usr/bin/env python3
"""Collect a complete fixed main108 full control. No labels, grading, or inference."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
REPO = Path('/workspace/Searching_Experiment-model-gates-20261010')
sys.path.insert(0, str(REPO / 'experiments/sku-matching'))
import run_nextdata_table_experiment_v1 as EXP

V = EXP.VOLUME
OLD = REPO / '.lab-output/sku-nextdata-table-20261013-v1/prepared-v1'
EXPECTED_INPUT_SHA = 'c2328ef6fa16e5f8c10a5520764df7d97986db6f693eb23e568a0ebeb25bd65a'


def verify_original(path: Path, receipt: dict) -> None:
    if path.is_file() != receipt['exists']:
        raise ValueError('Frozen original output presence differs: ' + str(path))
    if receipt['exists'] and (path.stat().st_size != receipt['bytes']
                              or V.sha_file(path) != receipt['sha256']):
        raise ValueError('Frozen original output bytes differ: ' + str(path))


def collect(new_outputs: Path, new_outputs_sha: str, output: Path) -> dict:
    freeze_path = BASE / 'prepared-v1/input-freeze.json'
    if V.sha_file(freeze_path) != EXPECTED_INPUT_SHA:
        raise ValueError('Fresh full control input freeze differs')
    prepared = V.read_json(freeze_path)
    EXP.verify_pins(prepared['files'])
    EXP.verify_pins(prepared['dependencies'])
    old_frozen = V.read_json(OLD / 'input-freeze.json')
    EXP.verify_pins(old_frozen['files'])
    EXP.verify_pins(old_frozen['dependencies'])
    bundle = V.Bundle(Path(old_frozen['runner_config']))
    public = {r['pair_ref']: r for r in V.read_rows(OLD / 'public-paired-inputs.jsonl')}
    root_meta = V.read_json(BASE / 'public-original-main172-closure-receipt.json')
    main_products = root_meta['main_product_ids']
    membership = bundle.source['cohort_rows']['membership.jsonl']
    if main_products != EXP.ordered_products(membership, 12):
        raise ValueError('Original label-blind main hash selection differs')
    selected = [r for r in membership if r['au_product_id'] in set(main_products)]
    case_ids = {r['case_id'] for r in selected}
    if len(case_ids) != 108 or len(selected) != 108:
        raise ValueError('Original main108 membership no longer complete')
    subset = EXP.subset_source(bundle, case_ids)
    expected_refs = set(json.loads((BASE / 'public-original-main172-pair-refs.json').read_text()))
    dispatched = {r['pair_id'] for r in public.values()}
    required_pair_ids = {b['pair_id'] for b in subset['bindings'] if b.get('pair_id') in dispatched}
    if required_pair_ids != {public[ref]['pair_id'] for ref in expected_refs}:
        raise ValueError('Public main172 refs do not equal complete whole-case closure')
    reuse = V.read_json(BASE / 'prepared-v1/existing-full-reuse-manifest.json')
    if set(reuse['main_refs']) != expected_refs or reuse['new_ref_count'] != 167:
        raise ValueError('Existing/new firstpass partition differs')
    if V.sha_file(new_outputs) != new_outputs_sha:
        raise ValueError('ROOT-pinned new firstpass output freeze differs')
    fresh = V.read_json(new_outputs)
    if fresh.get('input_freeze_sha256') != EXPECTED_INPUT_SHA:
        raise ValueError('New firstpass output freeze has a different input freeze')
    if fresh.get('no_semantic_redispatch_or_original_output_repair') is not True or fresh.get('active') != []:
        raise ValueError('New firstpass freeze is incomplete or allows retry')
    # The new coordinator freeze enumerates these new packet assignments only.
    new_assignments = fresh['assignments']
    assigned = [ref for a in new_assignments for ref in a['pair_refs']]
    if len(assigned) != len(set(assigned)) or set(assigned) != set(reuse['new_refs']):
        raise ValueError('New firstpass refs do not cover exactly unassigned main full controls')
    merged = []
    for item in reuse['existing_firstpasses']:
        merged.append({'origin': 'existing_same_experiment_full_firstpass',
                       'packet_key': item['old_packet_key'],
                       'all_assigned_refs': item['all_original_assigned_refs'],
                       'selected_refs': item['selected_main_refs'],
                       'path': Path(item['original_output_path']),
                       'receipt': item['original_output']})
    for item in new_assignments:
        merged.append({'origin': 'new_unassigned_main_full_firstpass',
                       'packet_key': item['packet_key'], 'all_assigned_refs': item['pair_refs'],
                       'selected_refs': item['pair_refs'], 'path': Path(item['output_path']),
                       'receipt': item['original_output']})
    selected_refs = [ref for item in merged for ref in item['selected_refs']]
    if len(selected_refs) != len(set(selected_refs)) or set(selected_refs) != expected_refs:
        raise ValueError('Merged old/new outputs do not form complete unique main172 coverage')
    for item in merged:
        verify_original(item['path'], item['receipt'])
    output = EXP.fresh_dir(output)
    bodies = V.unique_index(bundle.source['scoped_rows']['source-bodies.jsonl'],
                            'document_sha256', 'bodies')
    validated, issues, raw_receipts, rendered_rows, citations = [], [], [], [], []
    for item in merged:
        refs, path = item['selected_refs'], item['path']
        if not path.is_file():
            issues.extend({'pair_ref': ref, 'status': 'missing_unknown', 'origin': item['origin']}
                          for ref in refs)
            continue
        raw = path.read_bytes()
        dest = output / 'raw' / item['origin'] / path.name
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open('xb') as stream:
            stream.write(raw)
        raw_receipts.append({'packet_key': item['packet_key'], 'origin': item['origin'],
                             'original_path': str(path), 'all_assigned_refs': item['all_assigned_refs'],
                             'selected_main_refs': refs, **EXP.pin(dest)})
        try:
            rows = EXP.parse_assigned_draft(raw, item['all_assigned_refs'])
        except (ValueError, TypeError, UnicodeError) as exc:
            issues.extend({'pair_ref': ref, 'status': 'invalid_packet_unknown',
                           'origin': item['origin'], 'error': str(exc)} for ref in refs)
            continue
        for response in rows:
            ref = response['pair_ref']
            if ref not in refs:
                continue
            pub = public[ref]
            pair = bundle.source['pair_by_id'][pub['pair_id']]
            try:
                rendered, evidence = EXP.validate_luna_response(response, pair, pub, ref, {},
                                                               bundle, bodies, 'full')
                if evidence.get('source_citations_verified') is not True:
                    raise ValueError('Source citations not verified')
                judgments = [{**d, 'citations_verified': 2 * len(d.get('target_fact_indices', []))
                              + len(d.get('body_quote_refs', []))} for d in rendered['decisions']]
                validated.append({'pair_id': pair['pair_id'], 'cache_key': pair['cache_key'],
                                  'judgments': judgments, 'source_citations_verified': True,
                                  'semantic_truth_verified': False, 'sourceproof_certified': False,
                                  'production_adoption_allowed': False})
                rendered_rows.append(rendered)
                citations.extend(evidence.get('citations', []))
            except (KeyError, ValueError, TypeError, OSError, V.JsonSchemaValidationError) as exc:
                issues.append({'pair_ref': ref, 'status': 'invalid_response_unknown',
                               'origin': item['origin'], 'error': str(exc)})
    if len(validated) + len(issues) != 172:
        raise ValueError('Validated plus missing/invalid outputs do not account for all172 refs')
    EXP.write_rows(output / 'pair-failures.jsonl', issues)
    EXP.write_rows(output / 'original-firstpass-receipts.jsonl', raw_receipts)
    EXP.write_rows(output / 'validated-pairs.jsonl', validated)
    EXP.write_rows(output / 'rendered-v3-responses.jsonl', rendered_rows)
    EXP.write_rows(output / 'verified-source-citation-metadata.jsonl', citations)
    resolutions = V.EVAL.build_choice_nli_task_resolutions(subset['tasks'], subset['bindings'],
                                                         validated, subset['proofs'], subset['receipts'])
    if {r['task_id'] for r in resolutions} != {r['task_id'] for r in subset['tasks']}:
        raise ValueError('Whole-case task inventory lost during unchanged resolver')
    gate = EXP.save_gate(output, subset, resolutions, 'unchanged_full_source_scope_and_whole_sku_gate')
    decisions = V.read_rows(output / 'case-decisions.jsonl')
    rows = V.read_rows(output / 'all-row-results.jsonl')
    if ({r['case_id'] for r in decisions} != case_ids or len(decisions) != len(case_ids)
            or len(rows) != len(subset['rows'])
            or {(r['case_id'], r['au_row_key']) for r in rows}
               != {(r['case_id'], r['au_row_key']) for r in subset['rows']}):
        raise ValueError('Whole-case/row inventory lost during unchanged gate')
    EXP.write_json(output / 'original-main-inventory-receipt.json',
                   {'case_count': 108, 'product_count': 12, 'pair_count': 172,
                    'row_count': len(subset['rows']), 'task_count': len(subset['tasks']),
                    'main_hash_membership_unchanged': True, 'all_original_rows_tasks_retained': True})
    EXP.write_json(output / 'new-firstpass-output-freeze-receipt.json', EXP.pin(new_outputs))
    EXP.write_json(output / 'new-control-input-freeze-receipt.json', EXP.pin(freeze_path))
    return EXP.freeze_collection(output, OLD, {'cohort': 'original_label_blind_main108',
           'model_route': 'hosted-gpt-6-luna', 'variant': 'full',
           'control': 'fresh_full_main_control',
           'assigned_pair_count': 172, 'existing_full_firstpass_refs_reused': 5,
           'new_full_firstpass_refs': 167, 'validated_pair_count': len(validated),
           'missing_or_invalid_pair_count': len(issues), 'semantic_retries': 0,
           'new_control_input_freeze': EXP.pin(freeze_path),
           'new_firstpass_output_freeze': EXP.pin(new_outputs),
           'all_predictions_and_gates_frozen_before_new_grade': True, 'gate': gate})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--new-output-freeze', type=Path, required=True)
    parser.add_argument('--new-output-freeze-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(collect(args.new_output_freeze, args.new_output_freeze_sha256, args.output))
