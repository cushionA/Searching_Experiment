#!/usr/bin/env python3
"""Bookkeeping only. Does not interpret or rewrite classifier decisions."""
import argparse
import base64
import datetime
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def exclusive(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def event(value):
    with (BASE / 'events.jsonl').open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n')


def save(state):
    tmp = BASE / 'state.json.tmp'
    with tmp.open('w', encoding='utf-8') as stream:
        json.dump(state, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    tmp.replace(BASE / 'state.json')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('go', 'predispatch', 'spawn', 'terminal', 'complete'))
    inputs = parser.add_mutually_exclusive_group(required=True)
    inputs.add_argument('--payload-b64')
    inputs.add_argument('--payload-json')
    args = parser.parse_args()
    payload = json.loads(base64.b64decode(args.payload_b64) if args.payload_b64 else args.payload_json)
    state = json.loads((BASE / 'state.json').read_text())
    at = now()
    if args.action == 'go':
        if state['status'] != 'waiting_explicit_root_go':
            raise RuntimeError('GO is not repeatable')
        freeze = Path(payload['freeze_path']).resolve()
        if sha(freeze) != payload['freeze_sha256']:
            raise RuntimeError('ROOT freeze SHA mismatch')
        indices = payload.get('packet_indices', [])
        if not indices and payload.get('packet_index_path'):
            indices = [{'path': payload['packet_index_path'],
                        'sha256': payload['packet_index_sha256']}]
        if not indices:
            raise RuntimeError('No public packet index pins')
        for index in indices:
            if sha(Path(index['path']).resolve()) != index['sha256']:
                raise RuntimeError('Packet index SHA mismatch')
        state['input_freeze'] = payload
        state['status'] = 'running'
        state['root_go_at_utc'] = at
        state['max_parallel'] = payload.get('max_parallel', 3)
        exclusive(BASE / 'receipts' / 'root-go.json', dict(payload, observed_at_utc=at))
        event({'event': 'root_go', 'at_utc': at, **payload})
    elif args.action == 'predispatch':
        if state['status'] != 'running':
            raise RuntimeError('No active explicit GO')
        key = str(payload['packet_key'])
        if key not in set(map(str, state['input_freeze']['allowed_packet_keys'])):
            raise RuntimeError('Packet not authorized by ROOT GO')
        if key in state['assignments']:
            raise RuntimeError('Packet already assigned; no retry')
        if len(state['active']) >= state['max_parallel']:
            raise RuntimeError('Parallelism cap exceeded')
        packet = Path(payload['packet_path']).resolve()
        if sha(packet) != payload['packet_sha256']:
            raise RuntimeError('Packet SHA mismatch')
        output = Path(payload['output_path']).resolve()
        if not output.is_relative_to((BASE / 'drafts').resolve()) or output.exists():
            raise RuntimeError('Output must be exclusive absent path in owned drafts dir')
        record = dict(payload, predispatch_at_utc=at, output_absent_before_spawn=True,
                      packet_bytes=packet.stat().st_size, status='reserved')
        exclusive(BASE / 'receipts' / (key + '-predispatch.json'), record)
        state['assignments'][key] = record
        state['active'].append(key)
        state['dispatch_order'].append(key)
        event({'event': 'predispatch', 'at_utc': at, **record})
    elif args.action == 'spawn':
        key = str(payload['packet_key'])
        record = state['assignments'][key]
        if record['status'] != 'reserved':
            raise RuntimeError('Spawn receipt already recorded')
        # The response is the actual collaboration tool result, not a guessed model identity.
        raw = payload['actual_spawn_tool_response']
        observed = dict(payload, observed_at_utc=at)
        exclusive(BASE / 'receipts' / (key + '-spawn.json'), observed)
        record.update(status='spawned', agent_name=payload['agent_name'],
                      actual_spawn_tool_response=raw, spawn_observed_at_utc=at,
                      requested_model='gpt-6-luna', fork_turns='none')
        for pin in ('transport_wrapper_sha256', 'transport_writer_sha256'):
            if pin in payload:
                record[pin] = payload[pin]
        event({'event': 'actual_spawn_response', 'at_utc': at, **observed})
    elif args.action == 'terminal':
        key = str(payload['packet_key'])
        record = state['assignments'][key]
        if record['status'] not in ('spawned', 'reserved'):
            raise RuntimeError('Terminal is not repeatable')
        if record['status'] == 'reserved' and payload['terminal_kind'] != 'spawn_error':
            raise RuntimeError('Reserved packet may only end as actual spawn error')
        path = Path(record['output_path'])
        output = {'exists': path.exists()}
        if path.exists():
            data = path.read_bytes()
            output.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                          mtime_ns=path.stat().st_mtime_ns,
                          ends_with_lf=data.endswith(b'\n'), empty=not data)
            try:
                lines = data.decode('utf-8').splitlines()
                values = [json.loads(line) for line in lines if line.strip()]
                output.update(jsonl_syntax_valid=True, nonblank_json_lines=len(values))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                output.update(jsonl_syntax_valid=False, syntax_error=str(exc))
        receipt = dict(payload, observed_at_utc=at, original_output=output,
                       semantic_review_performed=False, output_rewritten=False)
        exclusive(BASE / 'receipts' / (key + '-terminal.json'), receipt)
        record.update(status='terminal', terminal_observed_at_utc=at, original_output=output,
                      terminal_kind=payload['terminal_kind'])
        state['active'].remove(key)
        state['terminal'].append(key)
        event({'event': 'worker_terminal', 'at_utc': at, **receipt})
    else:
        if state['active']:
            raise RuntimeError('Active workers remain')
        allowed = set(map(str, state['input_freeze']['allowed_packet_keys']))
        if set(state['terminal']) != allowed:
            raise RuntimeError('Terminal coverage does not equal permitted packet set')
        state['status'] = 'complete'
        state['completed_at_utc'] = at
        event({'event': 'dispatch_complete', 'at_utc': at, 'packets': len(allowed)})
        exclusive(BASE / 'receipts' / 'completion.json',
                  {'completed_at_utc': at, 'packet_count': len(allowed),
                   'dispatch_order': state['dispatch_order'], 'active': [],
                   'assignments': state['assignments'], 'requested_model': 'gpt-6-luna',
                   'fork_turns': 'none', 'no_semantic_redispatch_or_output_repair': True,
                   'model_selector_is_not_weights_attestation': True})
    save(state)
    print(json.dumps({'action': args.action, 'status': state['status'],
                      'assigned': len(state['assignments']), 'active': state['active'],
                      'terminal_count': len(state['terminal'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()
