#!/usr/bin/env python3
"""Prepare previously unassigned full controls without labels or semantic decisions."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
REPO = Path('/workspace/Searching_Experiment-model-gates-20261010')
sys.path.insert(0, str(REPO / 'experiments/sku-matching'))
import run_nextdata_table_experiment_v1 as EXP

OLD = REPO / '.lab-output/sku-nextdata-table-20261013-v1'
EXPECTED = {'prepared-v1/input-freeze.json': '137709cf0295a8e1bf07126d681c4f1cdf5195b84e01b8514141cea70ed6d6ad',
            'prepared-v1/public-paired-inputs.jsonl': '49e1892ecf6de7d7091cf8ca233e336f8e142951e5ce8f78429a84e8826d9e51',
            'prepared-v1/packets/full/index.json': '6960d967b0e8a093c3e839be54c0c44033be9e9ef2519a9e347049aa08eb0914',
            'luna-dispatch-v1/receipts/all194-original-output-freeze-v1.json': 'a360f42efb5c270e696fb209ae0cc94996d9c7d5479e9a4a8fa1d469b281e5bd'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write(chr(10))


def read_refs(path):
    value = json.loads(path.read_text())
    if isinstance(value, dict):
        found = [value[key] for key in ('pair_refs', 'main_pair_refs') if key in value]
        if len(found) != 1:
            raise ValueError('ROOT public closure must provide exactly one ref list')
        refs = found[0]
    else:
        refs = value
    if not isinstance(refs, list) or any(type(x) is not int for x in refs):
        raise ValueError('Public closure refs must be integer list')
    if len(refs) != len(set(refs)) or len(refs) != 172:
        raise ValueError('ROOT main public closure must have exactly 172 unique refs')
    return refs


def prepare(ref_path, ref_sha):
    if sha(ref_path) != ref_sha:
        raise ValueError('ROOT blinded public closure SHA mismatch')
    refs = read_refs(ref_path)
    closure_path = BASE / 'public-original-main172-closure-receipt.json'
    if sha(closure_path) != 'ae6956175860d4a3dc33d9978c3096f5113fe4ec351e28eafb232cdaf67cb2fa':
        raise ValueError('ROOT original label-blind main closure receipt SHA mismatch')
    closure = json.loads(closure_path.read_text())
    if (closure['pair_ref_array_sha256'] != ref_sha or closure['main_case_count'] != 108
            or closure['main_product_count'] != 12 or closure['contains_labels'] is not False
            or closure['contains_case_ids'] is not False
            or closure['source_input_freeze_sha256'] != EXPECTED['prepared-v1/input-freeze.json']):
        raise ValueError('ROOT initial main membership metadata differs')
    for name, expected in EXPECTED.items():
        if sha(OLD / name) != expected:
            raise ValueError('Frozen old dependency SHA differs: ' + name)
    freeze = json.loads((OLD / 'luna-dispatch-v1/receipts/all194-original-output-freeze-v1.json').read_text())
    old_full = [a for a in freeze['assignments'] if a['variant'] == 'full']
    all_old_refs = [ref for a in old_full for ref in a['pair_refs']]
    if len(all_old_refs) != 18 or len(all_old_refs) != len(set(all_old_refs)):
        raise ValueError('Existing full firstpass is not exact unique 18-ref coverage')
    overlap = set(refs) & set(all_old_refs)
    new = set(refs) - set(all_old_refs)
    if sorted(overlap) != closure['original_full_firstpass_reuse_refs'] or len(new) != 167:
        raise ValueError('ROOT reused/new full partition differs')
    reuse = []
    for a in old_full:
        selected = [r for r in a['pair_refs'] if r in overlap]
        if not selected:
            continue
        path = Path(a['output_path'])
        observed = a['original_output']
        if path.exists() != observed['exists']:
            raise ValueError('Old full firstpass output presence changed')
        if path.exists() and (sha(path) != observed['sha256'] or path.stat().st_size != observed['bytes']):
            raise ValueError('Old full firstpass bytes changed')
        reuse.append({'old_packet_key': a['packet_key'], 'all_original_assigned_refs': a['pair_refs'],
                      'selected_main_refs': selected, 'original_output_path': a['output_path'],
                      'original_output': observed, 'agent_name': a['agent_name'],
                      'old_raw_bytes_are_not_reserialized_or_repaired': True,
                      'old_missing_or_invalid_is_not_redispatched': True})
    rows = EXP.VOLUME.read_rows(OLD / 'prepared-v1/public-paired-inputs.jsonl')
    public = {r['pair_ref']: r for r in rows}
    if len(public) != 971 or not set(refs) <= set(public):
        raise ValueError('Closure refs not covered by original frozen paired inputs')
    output = BASE / 'prepared-v1'
    output.mkdir(exist_ok=False)
    index = EXP.make_packets(output, 'full', rows, new)
    covered = [r for p in index['packets'] for r in p['pair_refs']]
    if len(covered) != len(set(covered)) or set(covered) != new:
        raise ValueError('New packet coverage does not equal previously unassigned main full refs')
    old_packet = json.loads(Path(json.loads((OLD / 'prepared-v1/packets/full/index.json').read_text())['packets'][0]['path']).read_text())
    options = 0
    for packet in index['packets']:
        content = json.loads(Path(packet['path']).read_text())
        if content['protocol'] != old_packet['protocol'] or content['instructions'] != old_packet['instructions']:
            raise ValueError('Frozen full classifier protocol/guidance changed')
        for row in content['pairs']:
            if row['payload'] != public[row['pair_ref']]['full_payload']:
                raise ValueError('New full payload differs from original JSON values')
            options += len(row['payload']['candidate_vector'])
    reuse_manifest = {'schema': 'fresh-full-main-existing-firstpass-reuse-v1',
                      'main_ref_count': 172, 'main_refs': refs, 'existing_full_assigned_ref_count': 18,
                      'reuse_ref_count': len(overlap), 'reuse_refs': sorted(overlap),
                      'new_ref_count': len(new), 'new_refs': sorted(new), 'existing_firstpasses': reuse,
                      'old_all194_output_freeze': EXP.pin(OLD / 'luna-dispatch-v1/receipts/all194-original-output-freeze-v1.json'),
                      'no_existing_full_semantic_retry': True, **EXP.FLAGS}
    write(output / 'existing-full-reuse-manifest.json', reuse_manifest)
    dependencies = {str((OLD / name).resolve()): EXP.pin(OLD / name) for name in EXPECTED}
    dependencies[str(ref_path.resolve())] = EXP.pin(ref_path)
    dependencies[str(closure_path.resolve())] = EXP.pin(closure_path)
    dependencies[str(EXP.GUIDANCE.resolve())] = EXP.pin(EXP.GUIDANCE)
    dependencies[str(Path(EXP.__file__).resolve())] = EXP.pin(Path(EXP.__file__))
    dependencies[str(Path(EXP.PACKETS.__file__).resolve())] = EXP.pin(Path(EXP.PACKETS.__file__))
    result = {'schema': 'fresh-full-main-control-input-freeze-v1', **EXP.FLAGS,
              'new_root_go_required_before_classifier': True, 'classifier_spawned': 0,
              'main_case_count': 108, 'main_product_count': 12, 'main_closure_pair_count': 172,
              'reused_old_full_ref_count': len(overlap), 'new_full_ref_count': len(new),
              'new_full_packet_count': index['packet_count'], 'new_full_option_judgment_count': options,
              'original_full_payloads_byte_equivalent_as_json_values': True,
              'semantic_guidance_protocol_schema_unchanged': True,
              'original_option_families_selected_facts_or_body_trimmed': False,
              'new_cold_model_selector': 'gpt-6-luna', 'new_fork_turns': 'none',
              'old_missing_invalid_remain_unknown': True, 'root_public_main_refs': EXP.pin(ref_path),
              'packet_index': EXP.pin(output / 'packets/full/index.json'),
              'reuse_manifest': EXP.pin(output / 'existing-full-reuse-manifest.json'),
              'dependencies': dependencies,
              'files': {str(p.resolve()): EXP.pin(p) for p in sorted(output.rglob('*')) if p.is_file()},
              'preparer_code': EXP.pin(Path(__file__))}
    write(output / 'input-freeze.json', result)
    print(json.dumps({'new_namespace': str(BASE), 'main_ref_count': 172,
                      'reuse_ref_count': len(overlap), 'reuse_refs': sorted(overlap),
                      'new_ref_count': len(new), 'new_packet_count': index['packet_count'],
                      'new_option_judgment_count': options,
                      'input_freeze': EXP.pin(output / 'input-freeze.json'),
                      'packet_index': EXP.pin(output / 'packets/full/index.json'),
                      'reuse_manifest': EXP.pin(output / 'existing-full-reuse-manifest.json')}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root-public-main-refs', type=Path, required=True)
    parser.add_argument('--root-public-main-refs-sha256', required=True)
    args = parser.parse_args()
    prepare(args.root_public_main_refs, args.root_public_main_refs_sha256)
