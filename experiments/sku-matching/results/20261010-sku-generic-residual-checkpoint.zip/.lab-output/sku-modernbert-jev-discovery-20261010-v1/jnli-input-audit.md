# JNLI input-format follow-up

Read-only HTTP inspection on 2026-10-10 UTC. The model card links to `Argos1111/jev_local` without a commit; `main` resolved at inspection to `4047ac113ebc1446c5cfae06dd7d1de741d04f66` (2026-09-23 01:09:07 UTC). Saved the GitHub commit API response and exact source files `modernbert/data.py` and `modernbert/prompting.py` under this directory. No clone or code execution.

At that source revision, `build_jnli` uses each JNLI example as:

- `state`: `{"前提": sentence1, "仮説": sentence2}`
- `question`: `前提が正しいとき、仮説との論理的な関係を判定してください。前提から分からない情報を補わないでください。`
- choices, in order: `entailment`, `contradiction`, `neutral`
- choice descriptions: `含意：前提から仮説が正しいと必ず言える`; `矛盾：前提から仮説が誤りだと必ず言える`; `中立：前提だけでは仮説が正しいとも誤りとも判断できない`

For half of examples (random 0.5 draw), the code adds a true/false rephrasing with question `前提が正しいとき、仮説も必ず正しいと言えるか？`, choices `[True, False]`, answer `True` only for entailment. `drop_descriptions(..., 0.3)` means 30% of rows have bare labels without descriptions.

`prompting.py` serializes non-string state as JSON with Japanese preserved and renders the context exactly as `質問: {question}\n状況: {state}`. Candidate is label alone or `{label} — {description}`. Its comment says question-first ordering is intended so right-side truncation preserves the question; candidate pairs are scored independently.

## Implication for residual SKU conditions

The closest supported task shape is NLI: use the AU title and full description as the premise, and the single residual SKU condition as the hypothesis. Keep the short NLI question above and pass the three trained labels with their Japanese descriptions. This tests whether the full AU text entails, contradicts, or leaves the residual condition unstated. It also gives `neutral` a concrete role for conditions absent from the text. This is a better grounded first format than a long free-form instruction with the AU copy placed in the hypothesis or an unrelated generic question: NLI is explicitly part of the training conversion, and these labels/descriptions are the conversion's target. The model still has domain transfer risk; JNLI scores do not establish SKU accuracy.

The model metadata's 512-token maximum applies to the paired sequence. README inference uses `truncation="only_first", max_length=512`; the question and state share the first sequence, with the question first, so long descriptions can be right-truncated. This may remove evidence from the AU description and must not be mistaken for full-description coverage. The user-required no-prefilter policy can be preserved, but full text beyond the model's limit requires a separately designed windowing/aggregation evaluation; no such behavior is established by the model card.

## Provenance limit

This confirms the linked repository's current source at the pin above, not necessarily the exact training code used for the model weights uploaded 2026-09-19. The card links to mutable `main`, which currently points to a 2026-09-23 commit; the model's `jev_modernbert.json` records the base-model revision but no training-code commit. Thus the exact conversion format is strong current-source evidence, but the artifact does not cryptographically or metadata-wise guarantee that these precise files produced the pinned weights.
