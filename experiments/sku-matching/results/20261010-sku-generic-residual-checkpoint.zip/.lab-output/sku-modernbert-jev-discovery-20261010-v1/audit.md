# ModernBERT-Ja-310M-jev read-only artifact audit

Lookup date: 2026-10-10 UTC. Public Hugging Face metadata and files were retrieved at the pinned revision below. No model weights were downloaded; `model-safetensors-header.bin` is only the 64 KiB HTTP range containing the safetensors header.

- Repository: `argos1111/modernbert-ja-310m-jev`
- Pinned revision: `07cda23579443e7a33c0f474114279fa032340d6`
- HF API/tree initial commit: 2026-09-19 16:35:01 UTC; model card added 16:35:38 UTC.
- Architecture: `ModernBertForSequenceClassification`, ModernBERT, 25 layers, hidden size 768; one scalar logit (`num_labels=1`, config `id2label` only `LABEL_0`). Safetensors header has 315,203,329 parameter elements.
- Weights: `model.safetensors`, 1,260,829,436 bytes (FP32 config); tokenizer JSON 6,718,745 bytes. Header plus full file metadata are in the evidence files; no weights fetched.
- Contract: cross-encoder, one `(question + state, candidate)` pair per sequence. README's trained rendering is `質問: {question}\n状況: {state}` and candidate text rendered `label — description`; tokenizer receives `(context, candidate)`. Score the scalar logits across the candidate set with softmax. It is not a fixed 3-class NLI head and has no entailment/neutral/contradiction ID ordering. For this use, candidate labels/descriptions may express `支持 / 矛盾 / 不明`; aggregate those scores as choice scores, not calibrated probabilities.
- For residual SKU comparison, preserve one condition per question. Suggested input: question asks whether that one residual condition applies to the AU offer; state contains the exact fixed AU title plus full description; candidates are the three described outcomes. Avoid accessory/type prefilters. The card requires its prompt rendering to match training.
- Token limit: training metadata says max_length 512. README truncates only the first sequence/state (`truncation="only_first"`) and retains candidates; set `max_length=512` explicitly. Tokenizer's `model_max_length` sentinel is not the usable limit.
- Training/evaluation report: 94,384 questions, about 345k pairs, two epochs, 5,386 steps, with JNLI train included. README reports JNLI test 2,323/2,508 = 92.62%; this is not SKU evidence. Metadata's JNLI validation is a separate 546 examples / 94.32%.
- CPU: conventional Transformers/PyTorch inference is possible on CPU; no minimum CPU/RAM, CPU throughput, or CPU accuracy benchmark is specified by the card. The reported training environment is Radeon AI PRO R9700 and Transformers 5.17.0; checkpoint is 1.26 GB on disk. Do not represent CPU speed as measured.
- License: `cc-by-sa-4.0` / CC BY-SA 4.0; card says preserve dataset attribution. Base is `sbintuitions/modernbert-ja-310m` and card cites data from JGLUE, JCoLA, commonsense morality and MASSIVE.
- Safe load: installed `.deps/sku-gliner-venv` has Transformers 5.17.0, CPU PyTorch 2.7.1+cpu; `ModernBertConfig`, `ModernBertModel`, `ModernBertForSequenceClassification` and AutoConfig's `modernbert` mapping are present. Repository contains no Python/model code files, only config, tokenizer, safetensors, card. Use pinned `revision`, `use_safetensors=True`, and `trust_remote_code=False` (the default); no remote code is needed.

## Claim corrections / limits

- The report's `~315M`, 2026-09-19, 512-token, CC BY-SA 4.0 and reported JNLI 92.62% claims check out, with the distinctions above.
- Describing it as Japanese NLI-trained is broadly correct, but it is not a standard 3-way NLI classifier. It was trained as a single-logit candidate scorer across several task families, including JNLI. The score meaning/order comes from the supplied candidate texts and setwise softmax.
- The report's use of “CPU” as a selection criterion is not supported by published CPU performance or hardware requirements. Only local Transformers use is shown; CPU is technically available but throughput/RAM are unmeasured.
- Its prompt is structured `question + state` against `candidate`, so a direct arbitrary premise/hypothesis pair does not by itself reproduce the trained input format.
