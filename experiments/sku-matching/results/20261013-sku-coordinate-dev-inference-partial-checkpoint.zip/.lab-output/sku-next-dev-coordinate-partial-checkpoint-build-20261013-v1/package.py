#!/usr/bin/env python3
"""Build a source-and-initial-response partial DEV checkpoint, never a score."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
import zipfile
import zlib
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / ".lab-output/sku-next-dev-coordinate-partial-checkpoint-build-20261013-v1"
OUT = ROOT / "experiments/sku-matching/results/20261013-sku-coordinate-dev-inference-partial-checkpoint.zip"
FREEZE = ROOT / ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/experiment-freeze.json"
EXEC = ROOT / ".lab-output/sku-next-dev-coordinate-execution-20261013-v1"
SNAPSHOT = EXEC / "initial-response-snapshot-v1"
SOURCE_ROOT = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source"
SOURCE_INDEX = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source-index.json"
SOURCE_BASE = ROOT / ".lab-output/sku-next-dev-coordinate-refids-20261013-v1"
PROOF_BASE = ROOT / ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2"
CHECKS = ROOT / ".lab-output/sku-next-dev-coordinate-required-checks-20261013-v1"
SOURCE_HISTORY_FILES = [
    ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/source-only-report.json",
    ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/source-only-report-v2.json",
    ".lab-output/sku-next-dev-coordinate-refids-20261013-v1/source-only-report-v3.json",
]

EXPECTED_PREML_FREEZE_SHA = "fd00b9bf05bb5c90d36439540a89a3350cc85d46a2690b2bd46d9e1c44167b2e"
EXPECTED_SOURCE_NLI_V3_FREEZE_SHA = "681026e353b595644d66631afcd7f324ee237e973b584c3f7090795f9705c6ec"
EXPECTED_PROOF_FUNCTION_SHA = "ef00e3eae0f985f8293a6369fc79311d82118b33c7cfa7c5a44d5b74f11d47e1"
EXPECTED_SNAPSHOT_SHA = "e7aa1a32add6fc05ca8411309b91a63f9d75720b4437b5ff5ea1222dd71f06cb"
EXPECTED_PREML_PIN_COUNT = 202

EXTERNAL_ARCHIVES = [
    {"name": "full-reference-archive-v2", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261011-sku-independent-real-eval-v2.zip", "sha256": "6f65d988222c79c758614592340ba28565a51fa8891317724ba354c5fc38b457", "bundled": False, "contents_opened": False},
    {"name": "full-reference-archive-v3", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261012-sku-independent-real-eval-v3.zip", "sha256": "52f6faa51127a9c12250a3cdb5eb3d1818a36461a8c09323e481748aeed1f37b", "bundled": False, "contents_opened": False},
    {"name": "label-free-token-source-inputs-v2-v3", "path": ".lab-output/sku-claude-dev-input-share-20261012-v1/20261012-sku-independent-real-eval-v2-v3-token-inputs.zip", "sha256": "db2815a3d5c726e45f996ad07e73cdcf1cdff0610de53ad84af8a4a0a880488f", "bundled": False, "contents_opened": False},
]
EXTRA_EXECUTION_FILES = [
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/root-classification-go.json",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/dispatch-inventory.json",
    ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/bounded-dispatch-and-serialization-supplement.json",
    *[f".lab-output/sku-next-dev-coordinate-execution-20261013-v1/worker-{i}-assignments.json" for i in range(6)],
]
FORBIDDEN_PARTS = {".deps", "models", "model", "weights", "secrets", "credentials", ".venv", "venv", "labels", "labels-token", "gold", "answer-shards", "predictions", "worker-responses", "__pycache__"}
FORBIDDEN_SUFFIXES = {".zip", ".safetensors", ".pt", ".pth", ".ckpt", ".bin", ".env", ".pyc", ".pyo"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe(rel: str) -> bool:
    p = Path(rel)
    if p.is_absolute() or ".." in p.parts:
        return False
    if {x.lower() for x in p.parts} & FORBIDDEN_PARTS or p.suffix.lower() in FORBIDDEN_SUFFIXES:
        return False
    if p.name.lower().startswith(("answer-", "label-", "gold-")):
        return False
    return True


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            obj = json.loads(line)
            if not isinstance(obj, dict):
                raise ValueError(f"expected JSON object in {path}")
            out.append(obj)
    return out


def collect_refs(files: dict[str, Path]) -> dict[str, dict[str, Any]]:
    refs: dict[str, dict[str, Any]] = {}
    for arc, path in files.items():
        if not arc.endswith((".json", ".jsonl")) or path.stat().st_size > 10_000_000:
            continue
        raw_data = path.read_bytes()
        lines = raw_data.splitlines() if arc.endswith(".jsonl") else [raw_data]
        for line_no, line in enumerate(lines, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            stack = [obj]
            while stack:
                value = stack.pop()
                if isinstance(value, dict):
                    raw = value.get("raw_file")
                    expected = value.get("sha256")
                    if isinstance(raw, str) and isinstance(expected, str) and len(expected) == 64:
                        raw = raw.replace("\\", "/")
                        entry = refs.setdefault(raw, {"sha256": expected, "origins": []})
                        if entry["sha256"] != expected:
                            entry.setdefault("conflicts", []).append({"sha256": expected, "file": arc, "line": line_no})
                        entry["origins"].append({"file": arc, "line": line_no})
                    stack.extend(value.values())
                elif isinstance(value, list):
                    stack.extend(value)
    return refs


def load_freeze() -> dict[str, Any]:
    if not FREEZE.is_file() or sha256(FREEZE) != EXPECTED_PREML_FREEZE_SHA:
        raise SystemExit("pre-ML freeze missing or SHA-256 changed")
    receipt = json.loads(FREEZE.read_text(encoding="utf-8"))
    pins = receipt.get("frozen_files")
    if not isinstance(pins, dict) or len(pins) != EXPECTED_PREML_PIN_COUNT:
        raise SystemExit("pre-ML frozen file inventory is not the expected 202 pins")
    return receipt


def build_sources() -> tuple[dict[str, Path], list[dict[str, Any]], list[str], dict[str, Any], dict[str, Any]]:
    receipt = load_freeze()
    pins = receipt["frozen_files"]
    files: dict[str, Path] = {}
    problems: list[str] = []

    def add(path: Path, archive_path: str | None = None, required: bool = True) -> None:
        rel = archive_path or path.relative_to(ROOT).as_posix()
        if not safe(rel):
            problems.append(f"forbidden-package-path:{rel}")
            return
        if not path.is_file() or path.is_symlink():
            if required:
                problems.append(f"missing-or-symlink:{rel}")
            return
        if rel in files and files[rel] != path:
            problems.append(f"archive-path-collision:{rel}")
            return
        files[rel] = path

    frozen_paths: dict[str, Path] = {}
    for rel, pin in sorted(pins.items()):
        if "worker-responses" in Path(rel).parts:
            problems.append(f"live-worker-response-path-in-freeze:{rel}")
            continue
        if not safe(rel):
            problems.append(f"forbidden-frozen-path:{rel}")
            continue
        path = ROOT / rel
        if not path.is_file() or path.is_symlink():
            problems.append(f"frozen-file-missing:{rel}")
            continue
        if type(pin.get("bytes")) is not int or pin.get("bytes") != path.stat().st_size or pin.get("sha256") != sha256(path):
            problems.append(f"frozen-file-pin-mismatch:{rel}")
            continue
        frozen_paths[rel] = path
        add(path, rel)
    # The freeze receipt and required-check logs are part of the checkpoint provenance.
    add(FREEZE)
    add(SOURCE_INDEX)
    if sha256(SOURCE_BASE / "source-nli-v3/freeze.json") != EXPECTED_SOURCE_NLI_V3_FREEZE_SHA:
        problems.append("source-nli-v3-freeze-sha-mismatch")
    if pins.get("experiments/sku-matching/sku_literal_family_proof_v1.py", {}).get("sha256") != EXPECTED_PROOF_FUNCTION_SHA:
        problems.append("literal-family-proof-function-sha-mismatch")

    # Preserve source-only v1/v2/v3 reports. They retain historical source prep
    # receipts without claiming that every old builder byte is reconstructable.
    for rel in SOURCE_HISTORY_FILES:
        path = ROOT / rel
        add(path)
        if path.is_file():
            history = json.loads(path.read_text(encoding="utf-8"))
            if history.get("labels_read") is not False or history.get("test_split_read") is not False or history.get("scores_created") is not False:
                problems.append(f"source-history-report-scope-mismatch:{rel}")

    # Required checks are frozen source/test evidence, not model outputs.
    if not CHECKS.is_dir():
        problems.append("required-checks-directory-missing")
    else:
        for path in sorted(CHECKS.rglob("*")):
            if path.is_file() and not path.is_symlink():
                add(path)
    for rel in EXTRA_EXECUTION_FILES:
        add(ROOT / rel)

    # Package only the immutable first-response snapshot. No live worker-responses path is opened.
    if not SNAPSHOT.is_dir():
        problems.append("initial-response-snapshot-missing")
        snapshot_receipt: dict[str, Any] = {}
        snapshot_files: list[Path] = []
    else:
        snapshot_files = sorted(p for p in SNAPSHOT.rglob("*") if p.is_file() and not p.is_symlink())
        for path in snapshot_files:
            add(path)
        snap_receipt_path = SNAPSHOT / "snapshot-receipt.json"
        try:
            snapshot_receipt = json.loads(snap_receipt_path.read_text(encoding="utf-8"))
        except Exception:
            snapshot_receipt = {}
            problems.append("snapshot-receipt-invalid")
        if sha256(snap_receipt_path) != EXPECTED_SNAPSHOT_SHA:
            problems.append("snapshot-receipt-sha-mismatch")
        if (snapshot_receipt.get("schema_version") != "sku-next-dev-coordinate-partial-inference-checkpoint-v1"
                or snapshot_receipt.get("inference_complete") is not False
                or snapshot_receipt.get("source_split") != "dev"
                or snapshot_receipt.get("labels_read") is not False
                or snapshot_receipt.get("test_labels_read") is not False
                or snapshot_receipt.get("independent_test") is not False
                or snapshot_receipt.get("completed_original_packets") != [0, 3, 7, 9, 11, 12, 22, 32, 35, 36, 38, 44, 48, 50, 58]
                or snapshot_receipt.get("response_pair_count") != 47
                or snapshot_receipt.get("expected_dispatched_pairs") != 189
                or snapshot_receipt.get("option_decision_count") != 738
                or snapshot_receipt.get("expected_whole_option_count") != 2510):
            problems.append("snapshot-receipt-scope-or-count-mismatch")
        for original_path, pin in snapshot_receipt.get("raw_first_output_pins", {}).items():
            # Validate only the snapshot target. Never open the original worker-responses path.
            target = pin.get("snapshot")
            if not isinstance(target, str) or "worker-responses" in Path(target).parts or "initial-response-snapshot-v1" not in Path(target).parts:
                problems.append("invalid-snapshot-source-map")
                continue
            snapshot_file = ROOT / target
            if (not snapshot_file.is_file() or snapshot_file.is_symlink()
                    or snapshot_file.stat().st_size != pin.get("bytes")
                    or sha256(snapshot_file) != pin.get("sha256")):
                problems.append(f"snapshot-raw-output-pin-mismatch:{Path(target).name}")

    # Resolve exact raw source citations from the 202 frozen pre-ML files against the source index.
    raw_refs = collect_refs(frozen_paths)
    try:
        index_rows = json.loads(SOURCE_INDEX.read_text(encoding="utf-8"))
        source_index = {row["path"]: row for row in index_rows if isinstance(row, dict) and isinstance(row.get("path"), str)}
    except Exception as exc:
        source_index = {}
        problems.append(f"source-index-invalid:{type(exc).__name__}")
    raw_sources = []
    for raw_path, pin in sorted(raw_refs.items()):
        if not safe(raw_path) or pin.get("conflicts"):
            problems.append(f"unsafe-or-conflicting-raw-source:{raw_path}")
            continue
        indexed = source_index.get(raw_path)
        if not indexed or indexed.get("sha256") != pin["sha256"] or type(indexed.get("bytes")) is not int:
            problems.append(f"raw-source-not-index-pinned:{raw_path}")
            continue
        source = SOURCE_ROOT / raw_path
        if not source.is_file() or source.is_symlink():
            problems.append(f"selected-raw-source-missing:{raw_path}")
            continue
        size, actual = source.stat().st_size, sha256(source)
        if size != indexed["bytes"] or actual != indexed["sha256"]:
            problems.append(f"selected-raw-source-byte-or-sha-mismatch:{raw_path}")
            continue
        raw_sources.append({"path": raw_path, "bytes": size, "sha256": actual, "origins": pin["origins"]})
        add(source, raw_path)

    # Full originals remain external: check input files against selected-source-manifest pins without bundling them.
    selected_manifest_rel = ".lab-output/sku-next-dev-coordinate-literal-proofs-20261013-v2/inputs/selected-source-manifest.jsonl"
    selected_manifest_path = ROOT / selected_manifest_rel
    source_input_pins: dict[str, str] = {}
    if selected_manifest_path.is_file():
        for row in read_jsonl(selected_manifest_path):
            for path_key, hash_key in (("case_source_input", "case_source_sha256"), ("product_source_input", "product_source_sha256")):
                rel, expected = row.get(path_key), row.get(hash_key)
                if not isinstance(rel, str) or not isinstance(expected, str):
                    problems.append("malformed-selected-source-manifest")
                    continue
                if rel in source_input_pins and source_input_pins[rel] != expected:
                    problems.append(f"source-input-pin-conflict:{rel}")
                source_input_pins[rel] = expected
    else:
        problems.append("selected-source-manifest-missing")
    external = []
    for dependency in EXTERNAL_ARCHIVES:
        path = ROOT / dependency["path"]
        item = dict(dependency, present=path.is_file(), bytes=path.stat().st_size if path.is_file() else None,
                    actual_sha256=sha256(path) if path.is_file() else None)
        item["sha256_matches"] = item["actual_sha256"] == dependency["sha256"]
        if item["sha256_matches"] is not True:
            problems.append(f"external-archive-pin-mismatch:{dependency['name']}")
        external.append(item)
    for rel, expected in sorted(source_input_pins.items()):
        source = SOURCE_ROOT / rel
        item = {"name": "external-full-source-input", "path": rel, "sha256": expected,
                "bundled": False, "present": source.is_file(), "bytes": source.stat().st_size if source.is_file() else None,
                "actual_sha256": sha256(source) if source.is_file() else None}
        item["sha256_matches"] = item["actual_sha256"] == expected
        if item["sha256_matches"] is not True:
            problems.append(f"external-source-input-pin-mismatch:{rel}")
        external.append(item)

    # Source status and exact evidence receipts.
    checks_receipt = CHECKS / "receipt.json"
    try:
        checks = json.loads(checks_receipt.read_text(encoding="utf-8"))
    except Exception:
        checks = {}
        problems.append("required-checks-receipt-invalid")
    snapshot_inventory = [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size, "sha256": sha256(p)} for p in snapshot_files]
    aux = {
        "freeze": receipt,
        "snapshot_receipt": snapshot_receipt,
        "snapshot_inventory": snapshot_inventory,
        "required_checks": checks,
        "raw_sources": raw_sources,
        "external": external,
        "selected_source_input_pin_count": len(source_input_pins),
    }
    return files, raw_sources, problems, aux, receipt


def write_docs(aux: dict[str, Any], builder_sha: str) -> None:
    snap = aux["snapshot_receipt"]
    readme = """# Coordinate DEV inference partial checkpoint\n\nThis archive preserves frozen source preparation and an immutable first-response snapshot for a development-set inference run. It is a partial progress checkpoint, not a completed evaluation.\n\nThe pre-ML dispatch contains 65 packets, 189 paired comparisons, and 2,510 whole-option decisions. The included initial snapshot has 15 completed original packets, 47 pairs, and 738 option decisions. Only that immutable snapshot is included; live worker-response directories are excluded.\n\nThe canonical source-bound NLI preparation is source-nli-v3 (freeze SHA-256 `681026e353b595644d66631afcd7f324ee237e973b584c3f7090795f9705c6ec`). The literal-family proof function is pinned at `ef00e3eae0f985f8293a6369fc79311d82118b33c7cfa7c5a44d5b74f11d47e1`. The 202-file pre-ML freeze is pinned at `fd00b9bf05bb5c90d36439540a89a3350cc85d46a2690b2bd46d9e1c44167b2e`. The source-only v1/v2/v3 reports preserve recorded source preparation history. This package does not claim byte-for-byte replay of every historical builder revision; some original builder bytes may be unavailable.\n\nFull reference archives and full v2/v3 case/product inputs are listed as hash-pinned external dependencies and are not bundled. The checkpoint includes only the selected raw source captures referenced by the frozen pre-ML inputs, verified against the source index.\n\nNo labels or gold were read; no score or accuracy metric was produced. Inference remains in progress.\n"""
    status = f"""# Partial status\n\n- Split: dev. Inference complete: no. Scoring performed: no. Labels/gold read: no.\n- First-response snapshot: {len(snap.get('completed_original_packets', []))} of 65 packets; {snap.get('response_pair_count')} of {snap.get('expected_dispatched_pairs')} pairs; {snap.get('option_decision_count')} of {snap.get('expected_whole_option_count')} whole-option decisions.\n- Packet 022 and packet 040 reported model semantic errors in first-pass outputs; the raw snapshot is preserved without semantic edits.\n- Packet 007 remains short of whole-pair coverage after first-time continuations. Packet 038's original serialization-recovery script limitation remains unresolved; the snapshot receipt records the raw-first/continuation separation, and no recovery output was substituted here.\n- Packet 050's relation-enum serializer alias is disclosed in the snapshot receipt.\n- Source prep, proof inputs, pre-ML worker inputs, assignments, root GO, dispatch supplement, exact selected raw captures, and required checks are pinned.\n- Required suite: 1,347 tests, 14 historical missing-fixture errors, 37 skips; focused coordinate/ref-ID/grader checks: 25 passed. These are recorded receipts; packaging did not rerun the suite.\n- This partial archive makes no accuracy, quality, or performance claim.\n"""
    (BUILD / "README.md").write_text(readme, encoding="utf-8")
    (BUILD / "PARTIAL_STATUS.md").write_text(status, encoding="utf-8")


def gather(aux: dict[str, Any]) -> tuple[list[tuple[Path, str]], list[str]]:
    files: dict[str, Path] = {}
    missing: list[str] = []
    def add(path: Path, arc: str | None = None):
        rel = arc or path.relative_to(ROOT).as_posix()
        if not safe(rel):
            missing.append(f"forbidden:{rel}")
        elif not path.is_file() or path.is_symlink():
            missing.append(f"missing:{rel}")
        else:
            files[rel] = path
    # Freshly re-verify only deterministic source/snapshot paths. No live response path is inspected.
    receipt = load_freeze(); pins = receipt["frozen_files"]
    for rel, pin in sorted(pins.items()):
        path = ROOT / rel
        if not path.is_file() or path.is_symlink() or path.stat().st_size != pin["bytes"] or sha256(path) != pin["sha256"]:
            missing.append(f"frozen-pin-changed:{rel}")
        else:
            add(path, rel)
    add(FREEZE)
    add(SOURCE_INDEX)
    for rel in SOURCE_HISTORY_FILES:
        add(ROOT / rel)
    for rel in EXTRA_EXECUTION_FILES:
        add(ROOT / rel)
    for path in sorted(CHECKS.rglob("*")):
        if path.is_file() and not path.is_symlink(): add(path)
    for path in sorted(SNAPSHOT.rglob("*")):
        if path.is_file() and not path.is_symlink(): add(path)
    for row in aux["raw_sources"]:
        add(SOURCE_ROOT / row["path"], row["path"])
    # Generated metadata / narrative / builder are part of the checkpoint.
    for path in (BUILD / "package.py", BUILD / "package-code-receipt.json", BUILD / "raw-source-pins.json",
                 BUILD / "external-source-pins.json", BUILD / "README.md", BUILD / "PARTIAL_STATUS.md", BUILD / "preflight.json"):
        if path.is_file(): add(path, path.relative_to(ROOT).as_posix())
    return sorted(((p, arc) for arc, p in files.items()), key=lambda x: x[1]), missing


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--build", action="store_true")
    args = parser.parse_args()
    BUILD.mkdir(parents=True, exist_ok=True)
    files, raw_sources, problems, aux, receipt = build_sources()
    builder_sha = sha256(Path(__file__))
    write_docs(aux, builder_sha)
    (BUILD / "raw-source-pins.json").write_text(json.dumps({
        "schema_version": "sku-next-dev-coordinate-partial-raw-source-pins-v1",
        "source_index_path": SOURCE_INDEX.relative_to(ROOT).as_posix(),
        "source_index_sha256": sha256(SOURCE_INDEX),
        "raw_capture_count": len(raw_sources),
        "raw_captures": raw_sources,
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (BUILD / "external-source-pins.json").write_text(json.dumps({
        "schema_version": "sku-next-dev-coordinate-partial-external-pins-v1",
        "dependencies": aux["external"],
        "selected_full_source_input_pin_count": aux["selected_source_input_pin_count"],
        "bundled_full_source_inputs": False,
        "reference_archive_members_opened": False,
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (BUILD / "package-code-receipt.json").write_text(json.dumps({
        "schema_version": "sku-next-dev-coordinate-partial-package-code-receipt-v1",
        "builder_path": Path(__file__).relative_to(ROOT).as_posix(),
        "builder_sha256": builder_sha,
        "pre_ml_freeze_sha256": EXPECTED_PREML_FREEZE_SHA,
        "source_nli_v3_freeze_sha256": EXPECTED_SOURCE_NLI_V3_FREEZE_SHA,
        "literal_family_proof_function_sha256": EXPECTED_PROOF_FUNCTION_SHA,
        "pre_ml_frozen_file_count": len(receipt["frozen_files"]),
        "raw_capture_count": len(raw_sources),
        "snapshot_path": SNAPSHOT.relative_to(ROOT).as_posix(),
        "snapshot_model_outputs_included": True,
        "live_worker_responses_opened_or_included": False,
        "labels_or_gold_read": False,
        "score_or_accuracy_created": False,
        "inference_complete": False,
        "problems": problems,
    }, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    files, gather_problems = gather(aux)
    problems.extend(gather_problems)
    checks = aux["required_checks"]
    report = {
        "schema_version": "sku-next-dev-coordinate-partial-checkpoint-preflight-v1",
        "phase": "partial_checkpoint_build" if args.build else "source_and_snapshot_preflight",
        "source_split": "dev",
        "independent_test": False,
        "inference_complete": False,
        "labels_or_gold_read": False,
        "score_or_accuracy_created": False,
        "live_worker_responses_opened": False,
        "immutable_initial_response_snapshot_included": True,
        "snapshot_packet_count": len(aux["snapshot_receipt"].get("completed_original_packets", [])),
        "snapshot_pair_count": aux["snapshot_receipt"].get("response_pair_count"),
        "snapshot_option_decision_count": aux["snapshot_receipt"].get("option_decision_count"),
        "pre_ml_frozen_file_count": len(receipt["frozen_files"]),
        "raw_capture_count": len(raw_sources),
        "required_suite_tests": checks.get("required_suite", {}).get("tests_run"),
        "required_suite_historical_missing_fixture_errors": checks.get("required_suite", {}).get("historical_missing_fixture_errors"),
        "required_suite_skips": checks.get("required_suite", {}).get("skipped"),
        "focused_test_passes": checks.get("focused_checks", {}).get("tests_passed"),
        "external_dependency_count": len(aux["external"]),
        "external_pin_mismatches": [d["name"] if "name" in d else d["path"] for d in aux["external"] if d.get("sha256_matches") is not True],
        "selected_file_count": len(files),
        "uncompressed_bytes": sum(p.stat().st_size for p, _ in files),
        "missing_or_invalid": sorted(set(problems)),
        "build_ready": not problems,
    }
    (BUILD / "preflight.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    files, gather_problems = gather(aux)
    problems.extend(gather_problems)
    report["selected_file_count"] = len(files)
    report["uncompressed_bytes"] = sum(p.stat().st_size for p, _ in files)
    report["missing_or_invalid"] = sorted(set(problems))
    report["build_ready"] = not problems
    (BUILD / "preflight.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if problems:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 2
    if not args.build:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 0

    files, gather_problems = gather(aux)
    if gather_problems:
        raise SystemExit("source/snapshot inputs changed after preflight: " + "; ".join(gather_problems[:10]))
    file_rows = []
    crc_ok = True
    OUT.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=OUT.name + ".", suffix=".tmp", dir=OUT.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    checkpoint = {
        "schema_version": "sku-next-dev-coordinate-inference-partial-checkpoint-v1",
        "partial": True,
        "source_split": "dev",
        "inference_complete": False,
        "labels_or_gold_read": False,
        "score_or_accuracy_created": False,
        "pre_ml_freeze_sha256": EXPECTED_PREML_FREEZE_SHA,
        "snapshot_receipt_sha256": EXPECTED_SNAPSHOT_SHA,
        "raw_capture_count": len(raw_sources),
        "pre_ml_frozen_file_count": len(receipt["frozen_files"]),
        "external_dependencies": aux["external"],
        "members": [],
    }
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path, arc in files:
            data = path.read_bytes()
            z.writestr(arc, data)
            file_rows.append({"path": arc, "bytes": len(data), "sha256": sha_bytes(data)})
        checkpoint["members"] = file_rows
        z.writestr("CHECKPOINT_MANIFEST.json", json.dumps(checkpoint, indent=2, sort_keys=True) + "\n")
    with zipfile.ZipFile(tmp, "r") as z:
        bad = z.testzip()
        if bad:
            raise SystemExit(f"ZIP CRC verification failed: {bad}")
        actual_names = set(z.namelist())
        if len(actual_names) != len(z.infolist()) or len(file_rows) != len(files):
            raise SystemExit("duplicate archive path")
        for row in file_rows:
            data = z.read(row["path"])
            info = z.getinfo(row["path"])
            if len(data) != row["bytes"] or sha_bytes(data) != row["sha256"] or (zlib.crc32(data) & 0xffffffff) != info.CRC:
                raise SystemExit(f"member verification failed: {row['path']}")
    os.replace(tmp, OUT)
    zip_hash = sha256(OUT)
    manifest = {
        "schema_version": "sku-next-dev-coordinate-partial-checkpoint-zip-manifest-v1",
        "archive": OUT.relative_to(ROOT).as_posix(),
        "archive_bytes": OUT.stat().st_size,
        "archive_sha256": zip_hash,
        "payload_member_count": len(file_rows),
        "crc_verified": True,
        "all_member_bytes_and_sha256_verified": True,
        "members": file_rows,
    }
    manifest_path = OUT.with_suffix(OUT.suffix + ".manifest.json")
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    OUT.with_suffix(OUT.suffix + ".sha256").write_text(f"{zip_hash}  {OUT.name}\n", encoding="utf-8")
    print(json.dumps({**report, "archive": str(OUT), "archive_bytes": OUT.stat().st_size, "archive_sha256": zip_hash,
                      "manifest": str(manifest_path), "payload_member_count": len(file_rows), "crc_verified": crc_ok,
                      "all_member_bytes_and_sha256_verified": True}, indent=2, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
