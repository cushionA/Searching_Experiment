# Coordinate DEV inference partial checkpoint

This archive preserves frozen source preparation and an immutable first-response snapshot for a development-set inference run. It is a partial progress checkpoint, not a completed evaluation.

The pre-ML dispatch contains 65 packets, 189 paired comparisons, and 2,510 whole-option decisions. The included initial snapshot has 15 completed original packets, 47 pairs, and 738 option decisions. Only that immutable snapshot is included; live worker-response directories are excluded.

The canonical source-bound NLI preparation is source-nli-v3 (freeze SHA-256 `681026e353b595644d66631afcd7f324ee237e973b584c3f7090795f9705c6ec`). The literal-family proof function is pinned at `ef00e3eae0f985f8293a6369fc79311d82118b33c7cfa7c5a44d5b74f11d47e1`. The 202-file pre-ML freeze is pinned at `fd00b9bf05bb5c90d36439540a89a3350cc85d46a2690b2bd46d9e1c44167b2e`. The source-only v1/v2/v3 reports preserve recorded source preparation history. This package does not claim byte-for-byte replay of every historical builder revision; some original builder bytes may be unavailable.

Full reference archives and full v2/v3 case/product inputs are listed as hash-pinned external dependencies and are not bundled. The checkpoint includes only the selected raw source captures referenced by the frozen pre-ML inputs, verified against the source index.

No labels or gold were read; no score or accuracy metric was produced. Inference remains in progress.
