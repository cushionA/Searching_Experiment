#!/usr/bin/env python3
"""Assemble a checksum-only freeze receipt; never reads labels or scores data."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
GRADER = "experiments/sku-matching/grade_next_dev_coordinate_refids_v1.py"
PARSER = "experiments/sku-matching/route_mixed_sku_references_v1.py"
SCORER = "experiments/sku-matching/grade_final_test_subset_v1.py"
TESTS = "tests/test_lab_next_dev_coordinate_refids_grade.py"
SELF = ".lab-output/sku-next-dev-coordinate-execution-20261013-v1/assemble_grade_freeze.py"
COHORT = ".lab-output/sku-next-dev-coordinate-refids-20261013-v1"
SOURCE_KEYS = {"source_only_report", "source_manifest", "nli_freeze", "model_pairs", "paired_contexts", "source_documents", "validation_bindings", "preparation_errors"}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def relfile(value: str) -> tuple[str, Path]:
    p = Path(value)
    if p.is_absolute() or ".." in p.parts or not p.is_file() or p.is_symlink():
        raise ValueError(f"expected existing safe repo-relative file: {value}")
    rel = p.as_posix()
    if p.parts and p.parts[0] != ".lab-output" and rel not in {GRADER, PARSER, SCORER, TESTS, SELF}:
        if not rel.startswith("experiments/") and not rel.startswith("tests/"):
            raise ValueError(f"artifact is outside expected source/run/code areas: {rel}")
    low = {x.lower() for x in p.parts}
    if low & {"labels", "gold", "truth", "answers", "answer-shards", "labels-token"}:
        raise ValueError(f"label-bearing path cannot enter pre-grade freeze: {rel}")
    if p.name.lower() in {"resolved.jsonl", "label-manifest.json", "answers.jsonl"}:
        raise ValueError(f"label-bearing artifact cannot enter pre-grade freeze: {rel}")
    if "test" in low and rel != ".lab-output/sku-full-condition-adapter-20261013-v2/test/case-plans.jsonl":
        raise ValueError(f"TEST results/artifacts cannot enter pre-grade freeze: {rel}")
    return rel, p


def assemble(spec: dict[str, Any]) -> dict[str, Any]:
    if spec.get("all_predictions_frozen") is not True or spec.get("all_gates_frozen") is not True:
        raise ValueError("freeze spec must attest all prediction and gate outputs frozen")
    if spec.get("labels_read") is not False or spec.get("test_split_read") is not False:
        raise ValueError("labels and test split must remain unread until root GO")
    if spec.get("policy_or_threshold_changed") is not False or spec.get("classifier_outputs_changed_after_freeze") is not False:
        raise ValueError("policy and classifier outputs must be unchanged after freeze")
    variants = spec.get("variants")
    if not isinstance(variants, dict) or set(variants) != {"coordinate-refids-choice-nli", "literal-only"}:
        raise ValueError("spec must freeze primary coordinate-refids and genuine literal-only variants")
    source = spec.get("prepared_source_artifacts")
    if not isinstance(source, dict) or set(source) != SOURCE_KEYS:
        raise ValueError("spec must identify the canonical prepared source artifact set")
    if (source["source_only_report"] != f"{COHORT}/source-only-report.json"
            or source["source_manifest"] != f"{COHORT}/manifest.json"):
        raise ValueError("source-only inputs must identify this exact frozen cohort")
    nli_names = {"nli_freeze": "freeze.json", "model_pairs": "model-pairs.jsonl",
                 "paired_contexts": "paired-contexts.jsonl", "source_documents": "source-documents.jsonl",
                 "validation_bindings": "validation-bindings.jsonl", "preparation_errors": "preparation-errors.jsonl"}
    nli_dirs = set()
    for key, basename in nli_names.items():
        path = Path(source[key])
        if path.name != basename or not path.parent.name.startswith("source-nli-") or path.parent.name == "source-nli-v1":
            raise ValueError("use the new canonical prepared source-NLI directory")
        nli_dirs.add(path.parent.as_posix())
    if len(nli_dirs) != 1:
        raise ValueError("prepared source-NLI files must share one directory")
    groups = spec.get("frozen_artifact_groups")
    group_keys = {"model_outputs", "runtime", "proofs", "code"}
    if not isinstance(groups, dict) or set(groups) != group_keys or any(
            not isinstance(groups.get(k), list) or not groups[k] or any(not isinstance(x, str) for x in groups[k])
            for k in group_keys):
        raise ValueError("spec must separately enumerate model outputs, runtime, proofs, and code")
    required = sorted(set().union(*(set(groups[k]) for k in group_keys)))
    gate_files = spec.get("gate_files")
    if not isinstance(gate_files, list) or not gate_files or len(gate_files) != len(set(gate_files)):
        raise ValueError("spec must enumerate every final gate artifact once")
    inputs = {
        "membership": f"{COHORT}/membership.jsonl",
        "case_plans": f"{COHORT}/case-plans.jsonl",
        "row_plans": f"{COHORT}/row-plans.jsonl",
        "selection_plan": f"{COHORT}/selection-plan.json",
    }
    all_paths = set(inputs.values()) | set(gate_files) | set(required) | set(source.values())
    all_paths.add(f"{COHORT}/manifest.json")
    all_paths.add(f"{COHORT}/source-only-report.json")
    all_paths.add(f"{COHORT}/selection-policy.json")
    all_paths.add(".lab-output/sku-full-condition-adapter-20261013-v2/test/case-plans.jsonl")
    all_paths.add(".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/membership.jsonl")
    for entry in variants.values():
        if not isinstance(entry, dict) or not isinstance(entry.get("predictions"), str):
            raise ValueError("each variant needs its frozen predictions path")
        vg = entry.get("gate_files")
        if not isinstance(vg, list) or not vg or not set(vg) <= set(gate_files):
            raise ValueError("each variant needs its subset of the complete gate inventory")
        all_paths.add(entry["predictions"])
        if not any("decision" in Path(x).name.lower() for x in vg) or not any("row" in Path(x).name.lower() and "result" in Path(x).name.lower() for x in vg):
            raise ValueError("each variant gate set must include case decisions and all-row results")
    all_paths.update({GRADER, PARSER, SCORER, TESTS, SELF})
    pins = {}
    for item in sorted(all_paths):
        rel, path = relfile(item)
        pins[rel] = {"bytes": path.stat().st_size, "sha256": sha(path)}
    return {
        "schema_version": "sku-next-dev-coordinate-refids-grading-freeze-v1",
        "freeze_status": "all_dev_predictions_and_gates_frozen",
        "source_split": "dev", "independent_test": False, "production_adoption_allowed": False,
        "all_predictions_frozen": True, "all_gates_frozen": True,
        "labels_read": False, "test_split_read": False,
        "test_identity_membership_read_for_disjointness": True,
        "test_identity_use": "disjointness_only",
        "test_labels_or_details_read_for_classification_or_selection": False,
        "test_split_read_scope": "original full-source TEST case-plan identities read solely for case/product disjointness; no TEST details, labels, or outcomes read",
        "policy_or_threshold_changed": False, "classifier_outputs_changed_after_freeze": False,
        "membership_sha256": "436d9c078f944a0265ebc6bedbaae42712c958f079a492387259f149385e2f32",
        "variants": variants, "gate_files": gate_files, "input_files": inputs,
        "prepared_source_artifacts": source, "frozen_artifact_groups": groups,
        "required_artifact_paths": required,
        "full_test_identity_case_plans": ".lab-output/sku-full-condition-adapter-20261013-v2/test/case-plans.jsonl",
        "prior_dev20_identity_membership": ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/membership.jsonl",
        "frozen_files": pins,
        "grader_code_sha256": pins[GRADER]["sha256"],
        "reference_parser_helper_sha256": pins[PARSER]["sha256"],
        "score_helper_sha256": pins[SCORER]["sha256"],
        "grader_tests_sha256": pins[TESTS]["sha256"],
        "freeze_assembler_sha256": pins[SELF]["sha256"],
    }


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--spec", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite freeze receipt: {args.output}")
    spec = json.loads(args.spec.read_text(encoding="utf-8"))
    if not isinstance(spec, dict):
        raise ValueError("freeze spec must be a JSON object")
    receipt = assemble(spec)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as f:
        json.dump(receipt, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write("\n")
    print(json.dumps({"freeze_receipt": str(args.output), "pinned_file_count": len(receipt["frozen_files"]), "scores_created": False, "labels_read": False}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
