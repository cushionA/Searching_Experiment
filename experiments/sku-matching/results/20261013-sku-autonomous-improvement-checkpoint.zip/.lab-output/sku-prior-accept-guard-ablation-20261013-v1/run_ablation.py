from __future__ import annotations
from copy import deepcopy
import hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
import evaluate_mixed_gpu_sku_v1 as E
import evaluate_keyword_filtered_product_v1 as REFERENCES
import trial_composition_evidence_v1 as T
import trial_keyword_filtered_product_v1 as VERIFY

OUT = Path(__file__).resolve().parent
PREP = T.PREP
BASE = ROOT / '.lab-output/sku-composition-language-model-20261013-v1/complete-sku-evaluation/complete-sku-fallback'
CTX = ROOT / '.lab-output/sku-composition-context-20261013-v1/evaluation'
DERIVED_PATH = CTX / 'derived-predictions.jsonl'
CURRENT = CTX / 'complete-context-fallback'


def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def sha(path): return E.sha(Path(path))
def snapshot(paths): return {str(Path(p).resolve()): {'path': str(Path(p).resolve()), 'sha256': sha(p)} for p in paths}
def verify_snap(s):
    for p, v in s.items():
        if sha(p) != v['sha256']: raise ValueError('frozen source changed: ' + p)
def write_json(path, value): E.write_json(path, value)

def run():
    if (OUT / 'all-gates-frozen.json').exists(): raise FileExistsError(OUT / 'all-gates-frozen.json')
    contract = read(OUT / 'predeclared-contract.json')
    if contract['status'] != 'predeclared_before_gate_generation_and_reference_scoring': raise ValueError('contract not predeclared')
    # Pin every baseline, candidate source, evaluator and gate artifact used in this comparison.
    tracked = [BASE/'predictions.jsonl', BASE/'gates/decisions.jsonl', BASE/'gates/row_results.jsonl', BASE/'gates/condition_results.jsonl', BASE/'gates/diff_vs_upstream.jsonl', BASE/'gates/manifest.json',
      DERIVED_PATH, CTX/'execution-freeze.json', CTX/'all-gates-frozen.json', CURRENT/'predictions.jsonl', CURRENT/'gates/decisions.jsonl', CURRENT/'gates/row_results.jsonl', CURRENT/'gates/condition_results.jsonl', CURRENT/'gates/diff_vs_upstream.jsonl', CURRENT/'gates/manifest.json',
      PREP/'manifest.json', PREP/'requests.jsonl', PREP/'documents.jsonl', PREP/'tasks.jsonl', PREP/'row_plans.jsonl',
      Path(T.CURRENT_PRED), Path(T.CURRENT/'gates/decisions.jsonl'), Path(T.OLD_EVAL/'summary.json'), Path(T.OLD_EVAL/'references-for-scoring.jsonl'), Path(T.OLD_EVAL/'reference-routes.jsonl'),
      Path(E.__file__), Path(REFERENCES.__file__), Path(T.__file__), Path(VERIFY.__file__), ROOT/'experiments/sku-matching/composition_context_policy_v1.py', ROOT/'.lab-output/sku-composition-context-resume-20261013-v1/code-history/composition_context_policy_v1_initial_reconstructed.py', Path(__file__), OUT/'predeclared-contract.json']
    # Routes may be directory-selected by the framework; include its pinned route manifest and actual route file.
    tracked = [p for p in tracked if p.is_file()]
    before = snapshot(tracked)
    write_json(OUT/'source-freeze-before.json', {'source_snapshot': before, 'baseline_count': len(before), 'new_inference': False, 'references_read': False})

    manifest, requests, documents, tasks, cases, membership, hosts = E.load_mixed_prepared(PREP)
    baseline = E.GATE.indexed(BASE/'predictions.jsonl', 'request_id')
    derived = E.GATE.indexed(DERIVED_PATH, 'request_id')
    if len(requests) != 134 or set(baseline) != set(requests) or set(derived) != set(requests): raise ValueError('frozen request coverage differs')
    E.GATE.validate_predictions(requests, documents, tasks, baseline, baseline, 'baseline')
    E.GATE.validate_predictions(requests, documents, tasks, derived, baseline, 'baseline')
    proofs = {rid for rid, p in baseline.items() if p.get('verified_value_equivalence')}
    if len(proofs) != 1: raise ValueError('typed proof coverage differs')
    rows = list(E.rows(PREP/'row_plans.jsonl'))
    baseline_gates = E.GATE.indexed(BASE/'gates/decisions.jsonl', 'case_id')
    if len(cases) != 83 or set(baseline_gates) != set(cases): raise ValueError('gate coverage differs')

    # Full current policy, recomputed from the exact same frozen inputs.
    from composition_context_policy_v1 import complete_predictions
    full, full_audit = complete_predictions(baseline, derived, requests, rows, baseline_gates, proofs)
    # Declared ablation of only accepted_case_bound_requests behavior. Alternative abstention,
    # proof preservation, complete-row eligibility, and nonaccepted-case rollback stay intact.
    ablated = deepcopy(baseline)
    alternatives = set()
    for rid, cand in derived.items():
        if rid in proofs: continue
        win, selected = cand.get('winning_value'), requests[rid]['selected_value']
        if win is not None and win != selected:
            p = deepcopy(cand); p['state'] = 'unknown'; p['reason'] = 'coherent_model_alternative_abstention'
            ablated[rid] = p; alternatives.add(rid)
        elif baseline[rid].get('state') != 'support' and cand.get('state') == 'support':
            ablated[rid] = deepcopy(cand)
    full_rows, row_bound = {}, set()
    for row in rows:
        bind = row['condition_bindings']
        supported = all(b.get('kind') == 'upstream_identical' or derived[b['request_id']].get('state') == 'support' for b in bind)
        key = (row['case_id'], row['au_row_key'])
        full_rows[key] = bool(row.get('all_original_axes_covered')) and bool(bind) and supported
        row_bound.update(b['request_id'] for b in bind if b.get('request_id') is not None)
    for rid in set(requests) - proofs - row_bound:
        if ablated[rid].get('state') == 'support' and baseline[rid].get('state') != 'support': ablated[rid] = deepcopy(baseline[rid])
    for row in rows:
        if baseline_gates[row['case_id']].get('decision') == 'accept' or full_rows[(row['case_id'], row['au_row_key'])]: continue
        for b in row['condition_bindings']:
            rid = b.get('request_id')
            if rid is not None and rid not in proofs and ablated[rid].get('state') == 'support' and baseline[rid].get('state') != 'support':
                ablated[rid] = deepcopy(baseline[rid])
    for rid in proofs: ablated[rid] = deepcopy(baseline[rid])

    # Audit immutable raw bindings and typed proofs before gating.
    binding_fields = ('request_id','request_sha256','selected_value','direction','source_request','source_task_bindings')
    for rid in requests:
        if any(ablated[rid].get(k) != baseline[rid].get(k) for k in binding_fields): raise ValueError('raw original binding changed: '+rid)
    if any(ablated[rid] != baseline[rid] for rid in proofs): raise ValueError('typed proof changed')
    E.GATE.validate_predictions(requests, documents, tasks, full, baseline, 'baseline')
    E.GATE.validate_predictions(requests, documents, tasks, ablated, baseline, 'baseline')
    E.write_rows(OUT/'full-policy-predictions.jsonl', full.values())
    E.write_rows(OUT/'without-prior-accept-guard-predictions.jsonl', ablated.values())
    E.write_json(OUT/'policy-audit.json', {'full_policy': full_audit, 'ablation_alternative_request_ids': sorted(alternatives), 'typed_proof_request_ids': sorted(proofs), 'all_raw_original_bindings_preserved': True})
    for name, predictions in [('full-policy', full), ('without-prior-accept-guard', ablated)]:
        dest = OUT/name; dest.mkdir(exist_ok=False)
        E.GATE.finish(PREP, dest/'predictions.jsonl', dest/'gates') if False else None
        E.write_rows(dest/'predictions.jsonl', predictions.values())
        E.GATE.finish(PREP, dest/'predictions.jsonl', dest/'gates')
    # Freeze both prediction sets and all gate outputs before opening any scoring references.
    gate_files = [p for name in ('full-policy','without-prior-accept-guard') for p in (OUT/name).rglob('*') if p.is_file()]
    gate_snapshot = snapshot([OUT/'full-policy-predictions.jsonl', OUT/'without-prior-accept-guard-predictions.jsonl', *gate_files])
    write_json(OUT/'all-gates-frozen.json', {'status':'predictions_and_gates_frozen_before_reference_scoring','references_read':False,'independent_test_read':False,'candidate_case_count':83,'source_snapshot':gate_snapshot})
    # Verify the candidate inputs and exact source/code freeze at the gate boundary.
    verify_snap(before)
    after_gates = snapshot(tracked)
    if after_gates != before: raise ValueError('tracked source/evaluator hash changed before scoring')
    write_json(OUT/'source-freeze-after-gates.json', {'source_snapshot':after_gates,'matches_before':True})

    _, _, _, refs, _ = REFERENCES.verify_original_sources(T.PREP, T.OLD_EVAL, T.ROUTES)
    ids = {r['case_id'] for r in E.eligibility_rows(membership, hosts)[0] if r['primary_score_eligible']}
    scored = {k:v for k,v in refs.items() if k in ids and not v.get('reference_uncertain',False)}
    if len(scored) != 73: raise ValueError('expected exactly 73 certain dev references')
    metrics, detail = {}, {}
    for name in ('full-policy','without-prior-accept-guard'):
        gates = E.GATE.indexed(OUT/name/'gates/decisions.jsonl','case_id')
        if set(gates) != set(cases): raise ValueError('candidate gate case coverage differs')
        value = E.metrics_for(gates, scored)
        metrics[name] = {k:v for k,v in value.items() if k != 'case_results'}
        detail[name] = value['case_results']
        E.write_rows(OUT/name/'case-results.jsonl', value['case_results'])
    current = E.GATE.indexed(CURRENT/'gates/decisions.jsonl','case_id')
    if metrics['full-policy']['tp'] != 39 or metrics['full-policy']['fp'] != 1: raise ValueError('full recomputed policy does not reproduce 39/1')
    changes = []
    byfull = {x['case_id']:x for x in detail['full-policy']}
    byabl = {x['case_id']:x for x in detail['without-prior-accept-guard']}
    for case_id in sorted(set(byfull)|set(byabl)):
        if byfull[case_id] != byabl[case_id]: changes.append({'case_id':case_id,'full_policy':byfull[case_id],'without_prior_accept_guard':byabl[case_id]})
    E.write_rows(OUT/'case-changes.jsonl', changes)
    # Retake hashes after scoring and verify unchanged original baseline/latest source/evaluator artifacts.
    after = snapshot(tracked)
    if after != before: raise ValueError('tracked source/evaluator hash changed after scoring')
    write_json(OUT/'source-freeze-after-scoring.json', {'source_snapshot':after,'matches_before':True})
    write_json(OUT/'summary.json', {'schema_version':'prior-accept-guard-ablation-summary-v1','experiment_status':'cached_exploratory_dev_informed','independent_test':False,'new_inference':False,'request_count':134,'case_count':83,'scored_reference_count':73,'full_policy_metrics':metrics['full-policy'],'without_prior_accept_guard_metrics':metrics['without-prior-accept-guard'],'case_decisions_changed':len(changes),'references_read_after_all_gates_frozen':True,'baseline_latest_source_and_evaluator_hashes_match_before_after':True,'all_raw_original_bindings_preserved':True,'typed_proof_preserved':True,'source_file_sha256':{str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file() and p.name not in ('summary.json',)}})
    print(json.dumps({'full':metrics['full-policy'],'without_guard':metrics['without-prior-accept-guard'],'changed_cases':len(changes)},ensure_ascii=False))

if __name__ == '__main__': run()
