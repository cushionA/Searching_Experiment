from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import zlib
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
BUILD_ROOT = ROOT / ".lab-output/sku-autonomous-improvement-checkpoint-build-20261013-v1"
RESULTS = ROOT / "experiments/sku-matching/results"
STEM = "20261013-sku-autonomous-improvement-checkpoint"
ARCHIVE = RESULTS / f"{STEM}.zip"
MANIFEST_PATH = RESULTS / f"{STEM}.manifest.json"
PREFLIGHT_PATH = BUILD_ROOT / "preflight.json"

RUN_ROOTS = (
    ".lab-output/sku-prior-accept-guard-ablation-20261013-v1",
    ".lab-output/sku-context-next-diagnosis-20261013-v1",
    ".lab-output/sku-missing-composition-sources-20261013-v1",
    ".lab-output/sku-composition-title-context-20261013-v1",
    ".lab-output/sku-composition-source-restoration-20261013-v3",
    ".lab-output/sku-composition-source-restoration-20261013-v3-v2",
    ".lab-output/sku-composition-source-restoration-review-20261013-v1",
    ".lab-output/sku-scoped-request-independent-review-20261013-v1",
    ".lab-output/sku-restored-composition-context-20261013-v1",
    ".lab-output/sku-restored-composition-context-resume-20261013-v1",
    ".lab-output/sku-scoped-request-composition-20261013-v1",
    ".lab-output/sku-scoped-request-composition-resume-20261013-v1",
)

# Exact code pins used by the frozen runs. Test-preparation files are carried by
# their separate checkpoint and deliberately are not part of this package.
SOURCE_FILES = (
    "experiments/sku-matching/composition_scoped_units_v1.py",
    "experiments/sku-matching/composition_source_blocks_v3.py",
    "experiments/sku-matching/composition_title_context_v1.py",
    "experiments/sku-matching/prepare_full_condition_inputs_v2.py",
    "experiments/sku-matching/trial_composition_title_context_v1.py",
    "experiments/sku-matching/trial_restored_composition_context_v1.py",
    "experiments/sku-matching/trial_scoped_request_composition_v1.py",
    "experiments/sku-matching/composition_context_policy_v1.py",
    "experiments/sku-matching/composition_language_model_v1.py",
    "experiments/sku-matching/trial_composition_context_v1.py",
    "experiments/sku-matching/evaluate_mixed_gpu_sku_v1.py",
    "experiments/sku-matching/evaluate_keyword_filtered_product_v1.py",
    "experiments/sku-matching/trial_composition_evidence_v1.py",
    "experiments/sku-matching/trial_keyword_filtered_product_v1.py",
    ".lab-output/sku-composition-context-resume-20261013-v1/code-history/composition_context_policy_v1_initial_reconstructed.py",
)
REPORT = "experiments/sku-matching/autonomous-improvement-result-20261013.txt"
EXACT_FILES = SOURCE_FILES + (
    REPORT,
    "experiments/sku-matching/session-result-20261012.txt",
    ".lab-output/sku-autonomous-improvement-checkpoint-build-20261013-v1/package.py",
    ".lab-output/sku-scoped-request-composition-resume-20261013-v1/composition-tests.log",
    ".lab-output/sku-scoped-request-composition-resume-20261013-v1/required-tests.log",
    ".lab-output/sku-scoped-request-composition-resume-20261013-v1/required-tests-network-enabled.log",
)

DEPENDENCIES = (
    ("experiments/sku-matching/results/20261013-sku-composition-context-checkpoint.zip", "a02d43c79e6cc79117ee2219e108185d3ee653db059eb1bb607811195d8f1808"),
    ("experiments/sku-matching/results/20261013-sku-composition-evidence-checkpoint.zip", "13de386a769383a2828fd6b78ef941d393810c282c415dc770dd14bcbd2aa139"),
    ("experiments/sku-matching/results/20261012-sku-mixed-cpu-checkpoint.zip", "f55928415f5028f6b110e44e68f936b03adbad177da1be58da3d3ee58fc4a951"),
    ("experiments/sku-matching/results/20261012-sku-mixed-gates-improvement-checkpoint.zip", "26ddd2289ea44072a37f7aa677bd078372644fbb7e59b063c84b18f9c182c11c"),
    ("experiments/sku-matching/results/20261012-sku-followup-checkpoint.zip", "3d013ed382adc4467d97575ae3602d162e2a8a1ea84d3087a622bdcadf186cf5"),
    ("experiments/sku-matching/results/20261012-sku-option-context-checkpoint.zip", "beeb336a455a32d324dec03c103ee412e06e236ff1aed92353d0a7ff389567a0"),
    ("experiments/sku-matching/results/20261012-sku-value-equivalence-integration-checkpoint.zip", "a0579182143d6d496e1acb95af46e741b47f3f2e2a15f0986ad81ab2642fe747"),
)

SKIP_PARTS = {
    "__pycache__", "models", ".deps", ".aws", ".codex", ".git", ".env",
    "secrets", "credentials", "cache", "caches", "weights", "model_weights",
    "venv", ".venv", "node_modules", "test-labels", "test_labels", "gold",
}
WEIGHT_SUFFIXES = (".safetensors", ".pt", ".pth", ".ckpt", ".bin")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_relative(name: str) -> Path:
    path = Path(name)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError(f"unsafe archive path: {name}")
    return path


def require_file(name: str) -> Path:
    path = ROOT / safe_relative(name)
    if not path.is_file() or path.is_symlink():
        raise FileNotFoundError(name)
    if any(part.lower() in SKIP_PARTS for part in path.relative_to(ROOT).parts):
        raise ValueError(f"excluded path in allowlist: {name}")
    return path


def collect_paths() -> list[str]:
    result = set(EXACT_FILES)
    for root_name in RUN_ROOTS:
        root = ROOT / safe_relative(root_name)
        if not root.is_dir() or root.is_symlink():
            raise FileNotFoundError(f"required run directory missing: {root_name}")
        for current, dirs, files in os.walk(root, followlinks=False):
            base = Path(current)
            kept = []
            for dirname in dirs:
                child = base / dirname
                if dirname.lower() in SKIP_PARTS:
                    continue
                if child.is_symlink():
                    raise ValueError(f"symlink in source tree: {child.relative_to(ROOT)}")
                kept.append(dirname)
            dirs[:] = kept
            for filename in files:
                path = base / filename
                rel = path.relative_to(ROOT).as_posix()
                low = filename.lower()
                if low == ".env" or low.startswith(".env.") or "secret" in low or "credential" in low:
                    continue
                if any(term in low for term in ("test-label", "test_label", "gold-label", "gold_label")):
                    continue
                # Only the explicitly allowlisted scoped-resume test logs belong
                # here; any other test preparation remains in its own checkpoint.
                if low.endswith(("test.log", "tests.log", "required-tests.log", "composition-tests.log")) and rel not in EXACT_FILES:
                    continue
                if path.is_symlink():
                    raise ValueError(f"symlink in source tree: {rel}")
                result.add(rel)
    # Preserve and verify exactly the Python source files named by inference
    # freezes. Do not parse evaluation case/label artifacts to discover pins.
    for root_name in RUN_ROOTS:
        root = ROOT / safe_relative(root_name)
        for current, _, files in os.walk(root, followlinks=False):
            for filename in files:
                if filename != "freeze.json" and not filename.startswith("source-freeze"):
                    continue
                freeze_path = Path(current) / filename
                freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
                snapshot = freeze.get("source_snapshot", {})
                if not isinstance(snapshot, dict):
                    continue
                for recorded, entry in snapshot.items():
                    if not str(recorded).endswith(".py"):
                        continue
                    prefix = str(ROOT) + "/"
                    rel = str(recorded)[len(prefix):] if str(recorded).startswith(prefix) else str(recorded)
                    source = require_file(rel)
                    expected = entry.get("sha256") if isinstance(entry, dict) else None
                    if not expected or sha(source.read_bytes()) != expected:
                        raise ValueError(f"source snapshot code SHA mismatch: {rel}")
                    result.add(rel)
    for name in sorted(result):
        require_file(name)
    if any(Path(name).suffix.lower() in WEIGHT_SUFFIXES for name in result):
        raise ValueError("model-weight file found in package allowlist")
    return sorted(result)


def verify_summary_outputs(summary_path: Path) -> None:
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    outputs = summary.get("output_sha256")
    if not isinstance(outputs, dict) or not outputs:
        raise ValueError(f"summary missing output_sha256: {summary_path.relative_to(ROOT)}")
    for rel, expected in outputs.items():
        relative = safe_relative(rel)
        target = summary_path.parent / relative
        if not target.is_file() or target.is_symlink():
            raise FileNotFoundError(f"summary output missing: {target.relative_to(ROOT)}")
        if sha(target.read_bytes()) != expected:
            raise ValueError(f"summary output SHA mismatch: {target.relative_to(ROOT)}")


def verify_restoration_manifests() -> dict:
    root = ROOT / RUN_ROOTS[4]
    revised_root = ROOT / RUN_ROOTS[5]
    current = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    revised = json.loads((revised_root / "manifest.json").read_text(encoding="utf-8"))
    lifecycle = revised.get("prior_artifact_lifecycle")
    if not isinstance(lifecycle, dict):
        raise ValueError("v3-v2 manifest does not preserve deleted-first-v3 lifecycle record")
    expected_lifecycle = {
        "first_observed_run_removed_by_agent": True,
        "removed_run_code_sha256_recovered_from_stdout": "ad611347fe181f5ba5af975ff52ee19bbb2e681d6553f31d006dfdcf900f06a4",
        "currently_preserved_v3_counts": {
            "addition_block_count": current.get("addition_block_count"),
            "excluded_block_or_route_count": current.get("excluded_block_or_route_count"),
            "verified_source_span_receipt_count": current.get("verified_source_span_receipt_count"),
        },
        "recoverable_counts": lifecycle.get("removed_run_recoverable_counts"),
    }
    if expected_lifecycle["currently_preserved_v3_counts"] != {
        "addition_block_count": 403,
        "excluded_block_or_route_count": 1026,
        "verified_source_span_receipt_count": 5398,
    } or expected_lifecycle["recoverable_counts"] != {
        "addition_block_count": 234,
        "excluded_block_or_route_count": 857,
        "verified_source_span_receipt_count": 4891,
    }:
        raise ValueError("source-restoration lifecycle counts differ from the recorded history")
    # Each restoration run's own manifest binds every emitted tabular artifact.
    for base in (root, revised_root):
        manifest = json.loads((base / "manifest.json").read_text(encoding="utf-8"))
        for rel, expected in manifest.get("output_sha256", {}).items():
            target = base / safe_relative(rel)
            if not target.is_file() or sha(target.read_bytes()) != expected:
                raise ValueError(f"restoration output hash mismatch: {target.relative_to(ROOT)}")
    return {
        "current_v3_counts": expected_lifecycle["currently_preserved_v3_counts"],
        "deleted_first_v3_recoverable_counts": expected_lifecycle["recoverable_counts"],
        "deleted_first_v3_code_sha256_from_stdout": expected_lifecycle["removed_run_code_sha256_recovered_from_stdout"],
        "deleted_first_v3_recoverable": False,
    }


def dependency_records() -> list[dict]:
    records = []
    for name, expected in DEPENDENCIES:
        path = require_file(name)
        actual = sha(path.read_bytes())
        if actual != expected:
            raise ValueError(f"dependency ZIP SHA mismatch: {name}")
        records.append({"path": name, "bytes": path.stat().st_size, "sha256": actual, "included_in_checkpoint": False})
    return records


def verify_raw_dependency_refs() -> dict:
    expected: dict[str, set[str]] = {}
    for root_name in (RUN_ROOTS[4], RUN_ROOTS[5]):
        raw_pins = ROOT / root_name / "raw-pins.jsonl"
        for line in raw_pins.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            raw_sha = row.get("sha256")
            raw_file = row.get("raw_file")
            if not isinstance(raw_sha, str) or len(raw_sha) != 64 or not isinstance(raw_file, str):
                raise ValueError(f"malformed raw pin in {raw_pins.relative_to(ROOT)}")
            expected.setdefault(raw_sha, set()).add(raw_file)
    # Freeze source snapshots also pin raw captures. Read only freeze metadata,
    # never evaluation cases or any label-bearing file.
    for root_name in RUN_ROOTS:
        root = ROOT / root_name
        for current, _, files in os.walk(root, followlinks=False):
            for filename in files:
                if filename != "freeze.json" and not filename.startswith("source-freeze"):
                    continue
                freeze_path = Path(current) / filename
                freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
                for recorded, entry in freeze.get("source_snapshot", {}).items():
                    if "raw-captures" not in str(recorded):
                        continue
                    raw_sha = entry.get("sha256") if isinstance(entry, dict) else None
                    if not isinstance(raw_sha, str) or len(raw_sha) != 64:
                        raise ValueError(f"malformed raw capture pin in {freeze_path.relative_to(ROOT)}")
                    expected.setdefault(raw_sha, set()).add(str(recorded))

    matched = {}
    for archive_name, _ in DEPENDENCIES:
        with zipfile.ZipFile(ROOT / archive_name) as zf:
            for member in zf.namelist():
                if "raw-captures" not in member:
                    continue
                for raw_sha in expected:
                    if raw_sha in member:
                        body = zf.read(member)
                        if sha(body) != raw_sha:
                            raise ValueError(f"raw capture member hash mismatch: {archive_name}:{member}")
                        matched.setdefault(raw_sha, []).append({"archive": archive_name, "member": member})
    missing = sorted(set(expected) - set(matched))
    if missing:
        raise FileNotFoundError(f"raw capture hashes absent from validated dependency ZIPs: {missing[:5]}")
    return {
        "unique_raw_capture_sha256_count": len(expected),
        "raw_reference_count": sum(len(paths) for paths in expected.values()),
        "all_raw_captures_reconstructed_from_dependencies": True,
        "resolved_sha256": {
            key: {"references": sorted(expected[key]), "dependency_members": matched[key]}
            for key in sorted(expected)
        },
    }


def estimate(files: list[str]) -> dict:
    raw_total = 0
    compressed_total = 0
    rows = []
    for name in files:
        body = require_file(name).read_bytes()
        size = len(body)
        packed = len(zlib.compress(body, level=9))
        raw_total += size
        compressed_total += packed
        rows.append({"path": name, "bytes": size, "sha256": sha(body)})
    # ZIP local/central directory headers and embedded manifest add a small margin.
    estimate_bytes = compressed_total + len(rows) * 160 + 8192
    return {"files": rows, "file_count": len(rows), "payload_bytes": raw_total,
            "estimated_zip_bytes": estimate_bytes}


def git_value(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True, stderr=subprocess.DEVNULL).strip()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--build", action="store_true", help="write final ZIP after review authorization")
    args = parser.parse_args()

    missing = []
    files = []
    try:
        files = collect_paths()
    except FileNotFoundError as exc:
        missing.append(str(exc))
    # Report output is intentionally required before final packaging; preflight
    # remains useful while the report is still being written.
    if not (ROOT / REPORT).is_file():
        missing.append(f"pending final report: {REPORT}")
    deps = dependency_records()
    raw_dependencies = verify_raw_dependency_refs()
    restoration = verify_restoration_manifests()
    if files:
        for name in files:
            if Path(name).name == "summary.json":
                verify_summary_outputs(ROOT / name)
        estimates = estimate(files)
    else:
        estimates = {"files": [], "file_count": 0, "payload_bytes": 0, "estimated_zip_bytes": 0}
    preflight = {
        "schema_version": "sku-autonomous-improvement-checkpoint-preflight-v1",
        "branch": git_value("branch", "--show-current"),
        "head": git_value("rev-parse", "HEAD"),
        "test_labels_opened": False,
        "independent_test_included": False,
        "full_test_preparation_included": False,
        "model_weights_included": False,
        "secret_env_or_deps_included": False,
        "dependencies": deps,
        "raw_dependency_resolution": raw_dependencies,
        "restoration_lifecycle": restoration,
        "allowlisted_payload": estimates,
        "missing_saved_artifacts": missing,
        "archive_written": False,
        "archive_target": ARCHIVE.relative_to(ROOT).as_posix(),
    }
    BUILD_ROOT.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_PATH.write_text(json.dumps(preflight, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if not args.build:
        print(json.dumps({"preflight": str(PREFLIGHT_PATH.relative_to(ROOT)),
                          "file_count": estimates["file_count"],
                          "payload_bytes": estimates["payload_bytes"],
                          "estimated_zip_bytes": estimates["estimated_zip_bytes"],
                          "missing_saved_artifacts": missing}, ensure_ascii=False))
        return
    if missing:
        raise FileNotFoundError("cannot build checkpoint; missing saved artifacts are listed in preflight.json")
    if ARCHIVE.exists() or MANIFEST_PATH.exists():
        raise FileExistsError("refusing to overwrite existing checkpoint or manifest")
    payloads = {name: require_file(name).read_bytes() for name in files}
    manifest = {
        "schema_version": "sku-autonomous-improvement-checkpoint-v1",
        "branch": preflight["branch"], "head": preflight["head"],
        "independent_test_read": False, "production_adoption_allowed": False,
        "model_weights_included": False, "test_labels_opened": False,
        "dependencies": deps, "restoration_lifecycle": restoration,
        "raw_dependency_resolution": raw_dependencies,
        "files": estimates["files"], "file_count": len(files),
        "excluded_content": ["test labels", "models", ".deps", ".env", "secrets", "credentials", "model weights"],
        "restore_rule": "verify exact member set, CRC, bytes and SHA256 before extraction",
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
    RESULTS.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for row in estimates["files"]:
            body = payloads[row["path"]]
            if sha(body) != row["sha256"]:
                raise ValueError(f"source changed before archive write: {row['path']}")
            zf.writestr(row["path"], body)
        zf.writestr("CHECKPOINT_MANIFEST.json", manifest_bytes)
    with zipfile.ZipFile(ARCHIVE) as zf:
        expected = {r["path"] for r in estimates["files"]} | {"CHECKPOINT_MANIFEST.json"}
        if zf.testzip() is not None or len(zf.namelist()) != len(expected) or set(zf.namelist()) != expected:
            raise ValueError("archive CRC or member-set verification failed")
        for row in estimates["files"]:
            body = zf.read(row["path"])
            if len(body) != row["bytes"] or sha(body) != row["sha256"]:
                raise ValueError(f"archive member verification failed: {row['path']}")
    for row in estimates["files"]:
        body = require_file(row["path"]).read_bytes()
        if len(body) != row["bytes"] or sha(body) != row["sha256"]:
            raise ValueError(f"source changed during packaging: {row['path']}")
    manifest["archive"] = {"path": ARCHIVE.relative_to(ROOT).as_posix(),
                            "bytes": ARCHIVE.stat().st_size,
                            "sha256": sha(ARCHIVE.read_bytes())}
    MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"archive": str(ARCHIVE.relative_to(ROOT)),
                      "bytes": ARCHIVE.stat().st_size,
                      "sha256": manifest["archive"]["sha256"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
