#!/usr/bin/env python3
"""Build the post-grade restore ZIP from frozen pins and a sanitized aggregate.

This helper deliberately refuses to run until grading is explicitly complete.
It never opens test40-score-v1.json or any per-case gold/diagnosis artifact.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path('/workspace/Searching_Experiment-model-gates-20261010')
EXEC = ROOT / '.lab-output/sku-final-body-indexed-test-execution-20261013-v1'
FREEZE = EXEC / 'root-all-artifacts-pregrade-freeze-v2.json'
OUTPUT = ROOT / 'experiments/sku-matching/results/20261013-sku-final-indexed-test40-firstpass-checkpoint.zip'
PRE_INPUT = ROOT / 'experiments/sku-matching/results/20261013-sku-final-test-pre-inference-checkpoint.zip'
PRE_INPUT_SHA256 = 'cff43d2b83bcede9719072ccf0c09e2c94d655c486dd3702bff017912863a610'
PACKER = Path(__file__).resolve()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--grade-complete', action='store_true', help='explicit root authorization to create final archive')
    ap.add_argument('--aggregate', type=Path, required=True, help='path to root-provided sanitized numeric aggregate')
    ap.add_argument('--generic-freeze', type=Path, required=True, help='generic runner pre-grade freeze receipt')
    ap.add_argument('--root-go', type=Path, required=True, help='freeze-bound root grading authorization')
    ap.add_argument('--grading-freeze', type=Path, required=True, help='generic grading-freeze receipt')
    ap.add_argument('--external-note', type=Path, help='Japanese explanatory note; defaults beside the ZIP')
    args = ap.parse_args()
    if not args.grade_complete:
        raise SystemExit('refusing to build: wait for explicit grade-complete authorization')
    aggregate = args.aggregate.resolve()
    if not aggregate.is_file():
        raise SystemExit(f'sanitized aggregate not found: {aggregate}')
    # Reject obvious raw score/gold paths without opening those files.
    forbidden = ('test40-score-v1', 'private-gold', 'per-case-gold', 'gold-diagnosis')
    if any(part in str(aggregate).lower() for part in forbidden):
        raise SystemExit('aggregate path names a prohibited raw score or private-gold artifact')
    generic_freeze = args.generic_freeze.resolve()
    root_go = args.root_go.resolve()
    grading_freeze = args.grading_freeze.resolve()
    if not FREEZE.is_file() or not generic_freeze.is_file() or not root_go.is_file() or not grading_freeze.is_file():
        raise SystemExit('required all-artifacts, generic, root GO, or grading freeze receipt is missing')
    pre = PRE_INPUT
    if not pre.is_file() or sha256(pre) != PRE_INPUT_SHA256:
        raise SystemExit('pre-inference checkpoint missing or SHA-256 mismatch')
    # Read only freeze metadata. Never inspect the raw score or per-case gold.
    frozen = json.loads(FREEZE.read_text(encoding='utf-8'))
    generic = json.loads(generic_freeze.read_text(encoding='utf-8'))
    go = json.loads(root_go.read_text(encoding='utf-8'))
    grading = json.loads(grading_freeze.read_text(encoding='utf-8'))
    if frozen.get('labels_read') is not False or frozen.get('scores_created') is not False:
        raise SystemExit('pre-grade freeze metadata is inconsistent')
    if not isinstance(frozen.get('pins'), dict) or not frozen['pins']:
        raise SystemExit('pre-grade freeze has no artifact pins')
    if (generic.get('schema_version') != 'indexed-next-body-test-pregrade-freeze-v1'
            or generic.get('status') != 'all_source_predictions_gates_code_and_qa_frozen_before_labels'
            or generic.get('labels_read') is not False or generic.get('scores_created') is not False):
        raise SystemExit('generic freeze schema/status is not the required blind pre-grade receipt')
    if (go.get('root_go_for_indexed_test_grading') is not True
            or go.get('independent_test') is not True or go.get('test_split_read') is not True
            or go.get('freeze_receipt_sha256') != sha256(generic_freeze)):
        raise SystemExit('RootGO does not authorize grading against this exact generic freeze')
    if not all(isinstance(grading.get(k), dict) and grading[k] for k in
               ('frozen_output_files', 'source_code_pins', 'source_artifact_pins')):
        raise SystemExit('generic grading-freeze is missing its frozen file/code/source pin maps')
    pins: dict[str, str] = {}
    # Preserve the raw inputs and model packets, but omit any post-grade private files
    # that may have been produced after the pre-grade freeze receipt.
    for rel, expected in frozen['pins'].items():
        low = rel.lower()
        if any(s in low for s in ('test40-score-v1', 'private-gold', 'per-case-gold', 'gold-diagnosis')):
            raise SystemExit(f'prohibited artifact appears in freeze pin list: {rel}')
        path = ROOT / rel
        expected_sha = expected.get('sha256') if isinstance(expected, dict) else expected
        expected_bytes = expected.get('bytes') if isinstance(expected, dict) else None
        if (not path.is_file() or sha256(path) != expected_sha
                or (expected_bytes is not None and path.stat().st_size != expected_bytes)):
            raise SystemExit(f'frozen artifact missing or changed: {rel}')
        pins[rel] = expected_sha
    for rel in ('experiments/sku-matching/results/20261013-sku-final-test-pre-inference-checkpoint.zip',):
        pins.setdefault(rel, PRE_INPUT_SHA256)
    aggregate_member = (aggregate.relative_to(ROOT).as_posix()
                        if aggregate.is_relative_to(ROOT)
                        else f'sanitized-aggregate/{aggregate.name}')
    pins[aggregate_member] = sha256(aggregate)
    for path in (generic_freeze, root_go, grading_freeze):
        if not path.is_relative_to(ROOT):
            raise SystemExit(f'receipt must be inside workspace: {path}')
        pins[path.relative_to(ROOT).as_posix()] = sha256(path)
    pins[PACKER.relative_to(ROOT).as_posix()] = sha256(PACKER)
    note = args.external_note or OUTPUT.with_name('20261013-sku-final-indexed-test40-firstpass-checkpoint-externalJapanese.txt')
    note_text = (
        '復元用チェックポイントです。独立テスト40ケースの原文入力、全firstpass応答、'
        'ゲート、凍結記録、検証ログ、実行コードと、許可された数値集計を含みます。\n'
        'test40-score-v1.jsonおよびケース別の非公開gold診断は含みません。\n'
        '旧FINAL detailsの一部は現存物から復元できず、その欠落は同梱履歴に記録されています。\n'
    )
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    # The note is external to the archive by request; include its hash in the manifest.
    note.write_text(note_text, encoding='utf-8')
    entries = sorted(pins.items())
    manifest = {
        'schema_version': 'sku-final-indexed-test40-firstpass-checkpoint-v1',
        'archive': OUTPUT.name,
        'member_count': len(entries) + 2,
        'excluded': ['raw test40-score-v1.json', 'private per-case gold diagnosis'],
        'generic_freeze_sha256': sha256(generic_freeze),
        'root_go_sha256': sha256(root_go),
        'grading_freeze_sha256': sha256(grading_freeze),
        'members': [{'path': rel, 'sha256': digest} for rel, digest in entries],
        'externalJapanese': {'path': note.name, 'sha256': sha256(note)},
    }
    manifest_path = OUTPUT.with_suffix('.zip.manifest.json')
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    with zipfile.ZipFile(OUTPUT, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for rel, _digest in entries:
            src = aggregate if rel == aggregate_member else (ROOT / rel)
            zf.write(src, rel)
        zf.writestr('MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        zf.write(note, note.name)
    archive_digest = sha256(OUTPUT)
    OUTPUT.with_suffix('.zip.sha256').write_text(f'{archive_digest}  {OUTPUT.name}\n', encoding='ascii')
    print(json.dumps({'archive': str(OUTPUT), 'sha256': archive_digest,
                      'manifest': str(manifest_path), 'externalJapanese': str(note),
                      'members': len(entries) + 2}, ensure_ascii=False))


if __name__ == '__main__':
    main()
