"""Collect original first drafts; no semantic fields are edited or generated."""
import json
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path('/workspace/Searching_Experiment-model-gates-20261010')
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
import run_next_body_indexed_test_generic_v1 as M
import prepare_body_indexed_test_packets_v1 as PACKET

E = ROOT / '.lab-output/sku-final-body-indexed-test-execution-20261013-v1'
P = ROOT / '.lab-output/sku-final-body-indexed-test-20261013-v1/pre-model-preflight-v2'

def main():
    index = json.loads((E / 'packet-index.json').read_text())
    freeze = json.loads((E / 'root-pre-inference-freeze-v1.json').read_text())
    assert all(M.pin(ROOT / n) == pin for n, pin in freeze['pins'].items())
    out = E / 'firstpass-snapshot-v1'
    out.mkdir()
    records, failures, drafts, checks = [], [], {}, []
    refs = {r['pair_ref']: r['pair_id'] for r in M.read_rows(P / 'pair-ref-index.jsonl')}
    for packet in index['packets']:
        name = Path(packet['file']).stem + '.jsonl'
        path = E / 'drafts' / name
        if path.is_file():
            data = path.read_bytes()
            drafts[path.relative_to(ROOT).as_posix()] = M.pin(path)
            (out / name).write_bytes(data)
            try:
                rows = [PACKET.strict_loads(line) for line in data.splitlines()]
                actual = [r.get('pair_ref') for r in rows]
                if any(type(r) is not int for r in actual) or actual != packet['pair_refs']:
                    raise ValueError('first draft pair refs differ from its assigned packet')
                if not data.endswith(b'\n'):
                    raise ValueError('first draft cannot be concatenated byte-for-byte without a delimiter')
                records.extend(zip(actual, data.splitlines(keepends=True)))
                checks.append((path, packet['file']))
                continue
            except (ValueError, TypeError, AttributeError) as exc:
                reason = str(exc)
        else:
            reason = 'assigned first draft file is absent'
        for ref in packet['pair_refs']:
            failures.append({'pair_id': refs[ref], 'pair_ref': ref,
                'status': 'missing_firstpass_response_unknown',
                'semantic_retry_performed': False, 'reason': reason,
                'unaccepted_raw_draft_present': path.is_file(),
                'classifier_was_dispatched': True,
                'unknown_means_no_registered_response_not_no_model_judgment': True})
    records.sort(key=lambda r: r[0])
    assert len({r[0] for r in records}) == len(records)
    raw = out / 'raw-indexed-responses.jsonl'
    raw.write_bytes(b''.join(data for _, data in records))
    fail = out / 'missing-firstpass-ledger.jsonl'
    M.write_rows(fail, failures)
    def check(item):
        path, file = item
        result = subprocess.run([sys.executable, '-B', str(ROOT / 'experiments/sku-matching/prepare_body_indexed_test_packets_v1.py'),
            'validate-packet', '--raw-jsonl', str(path), '--index-dir', str(E), '--packet-file', file], capture_output=True, text=True)
        log = out / ('validation-' + Path(file).stem + '.log')
        log.write_text(result.stdout + result.stderr)
        return {'packet_file': file, 'exit_code': result.returncode, 'log_sha256': M.sha_file(log)}
    with ThreadPoolExecutor(max_workers=4) as pool:
        checked = list(pool.map(check, checks))
    dispatch = sorted(r['pair_id'] for r in M.read_rows(P / 'dispatch-pair-ids.jsonl'))
    protected = sorted(r['pair_id'] for r in M.read_rows(P / 'literal-protected-pair-ids.jsonl'))
    receipt = {'schema_version': 'indexed-test-raw-snapshot-v1',
        'status': 'complete_firstpass_snapshot_frozen',
        'dataset': 'sku-next-body-indexed-test-20261013-v1',
        'independent_test': True, 'test_split_read': True,
        'identity_plan_manifest_sha256': M.IDENTITY_MANIFEST_SHA256,
        'selected_membership_sha256': M.IDENTITY_MEMBERSHIP_SHA256,
        'raw_path': raw.relative_to(ROOT).as_posix(),
        'raw_bytes': raw.stat().st_size, 'raw_sha256': M.sha_file(raw),
        'partition_receipt_sha256': M.sha_file(P / 'source-partition-receipt.json'),
        'preflight_inventory_sha256': M.sha_file(P / 'preflight-inventory.json'),
        'dispatch_pair_count': len(dispatch), 'dispatch_pair_ids_sha256': M.digest_canonical(dispatch),
        'literal_protected_pair_count': len(protected), 'literal_protected_pair_ids_sha256': M.digest_canonical(protected),
        'response_count': len(records), 'response_pair_ids_sha256': M.digest_canonical(sorted(refs[r] for r, _ in records)),
        'failure_count': len(failures), 'failure_ledger_bytes': fail.stat().st_size,
        'failure_ledger_sha256': M.sha_file(fail),
        'labels_read': False, 'scores_created': False, 'all_predictions_frozen': True,
        'semantic_retry_performed': False, 'draft_pins': drafts,
        'packet_checks': checked, 'collector_sha256': M.sha_file(Path(__file__))}
    M.write_json(out / 'snapshot-receipt.json', receipt)
    assert all(M.pin(ROOT / n) == pin for n, pin in freeze['pins'].items())
    print(json.dumps({'responses': len(records), 'missing_registered_responses': len(failures),
        'raw_sha256': M.sha_file(raw), 'snapshot_sha256': M.sha_file(out / 'snapshot-receipt.json')}))

if __name__ == '__main__':
    main()
