"""Pin all blind execution artifacts; never inspect or open reference labels."""
import json
import sys
from pathlib import Path

ROOT = Path('/workspace/Searching_Experiment-model-gates-20261010')
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
import run_next_body_indexed_test_generic_v1 as M

E = ROOT / '.lab-output/sku-final-body-indexed-test-execution-20261013-v1'
B = ROOT / '.lab-output/sku-final-body-indexed-test-20261013-v1'

def main():
    target = E / 'root-all-artifacts-pregrade-freeze-v2.json'
    assert not target.exists()
    assert not (E / 'test40-score-v1.json').exists()
    original = M.read_json(E / 'root-pre-inference-freeze-v1.json')
    assert all(M.pin(ROOT / name) == pin for name, pin in original['pins'].items())
    snapshot = M.read_json(E / 'firstpass-snapshot-v2/snapshot-receipt.json')
    assert snapshot['all_predictions_frozen'] is True
    assert all(M.pin(ROOT / name) == pin for name, pin in snapshot['draft_pins'].items())
    assert M.pin(E / 'supervisor-dispatch-ledger.jsonl') == snapshot['supervisor_ledger_pin']
    assembly = M.read_json(E / 'final-gate-run-v2/assembly-receipt.json')
    assert assembly['status'] == 'complete_both_whole_gate_variants_frozen'
    assert assembly['labels_read'] is False and assembly['scores_created'] is False
    count_receipt = M.read_json(E / 'execution-event-count-clarification-v1.json')
    files = dict(original['pins'])
    for directory in (B, E, M.IDENTITY_PLAN_DIR):
        for path in sorted(directory.rglob('*')):
            assert not path.is_symlink(), str(path)
            if path.is_file():
                files[path.relative_to(ROOT).as_posix()] = M.pin(path)
    receipt = {'schema_version': 'root-indexed-test-all-artifacts-pregrade-freeze-v1',
        'status': 'all_source_firstpass_responses_and_gates_frozen_before_reference_access',
        'independent_test': True, 'test_split_read': True,
        'selected_product_count': 20, 'selected_case_count': 40,
        'identity_plan_manifest_sha256': M.IDENTITY_MANIFEST_SHA256,
        'selected_membership_sha256': M.IDENTITY_MEMBERSHIP_SHA256,
        'labels_read': False, 'scores_created': False,
        'semantic_retry_performed': False,
        'model_spawn_attempt_count': count_receipt['unique_spawn_attempt_task_names'],
        'spawn_ledger_record_count': count_receipt['spawn_record_count'],
        'snapshot_spawn_count_metadata_clarification': 'see execution-event-count-clarification-v1.json; snapshot count includes duplicate ledger rows',
        'unique_assigned_packet_count': snapshot['unique_assigned_packet_count'],
        'pins': files}
    M.write_json(target, receipt)
    assert all(M.pin(ROOT / name) == pin for name, pin in files.items())
    print(json.dumps({'frozen_artifact_count': len(files), 'receipt_sha256': M.sha_file(target)}))

if __name__ == '__main__':
    main()
