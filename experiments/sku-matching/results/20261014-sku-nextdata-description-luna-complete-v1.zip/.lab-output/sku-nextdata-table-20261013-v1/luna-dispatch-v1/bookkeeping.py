#!/usr/bin/env python3
"""Record directly observed collaboration events. No inference or semantic edits."""
import base64
import json
from pathlib import Path
import subprocess
import sys

B = Path(__file__).resolve().parent


def call(action, data):
    encoded = base64.b64encode(json.dumps(data, ensure_ascii=False).encode()).decode()
    subprocess.run([sys.executable, str(B / 'supervisor_io.py'), action,
                    '--payload-b64', encoded], check=True, stdout=subprocess.DEVNULL)


def main():
    operations = json.loads(sys.argv[1])
    for op in operations:
        state = json.loads((B / 'state.json').read_text())
        action, key = op[:2]
        if action == 'spawn':
            a = state['assignments'][key]
            suffix = ('t' if a['variant'] == 'table' else 'f') + key.split('-')[1]
            short = 'nextdesc_' + suffix
            name = '/root/next_description_dispatch_supervisor/' + short
            msg = (f"Instructions: {B / 'worker-transport-instructions-v4.txt'} . "
                   f"Assigned public packet: {a['packet_path']} . "
                   f"Assigned packet-key: {key} . "
                   f"Exclusive immutable output: {a['output_path']} . "
                   "Read both instructions and entire assigned packet; author all judgments once. "
                   "No other files or retries. Final first-write result only.")
            # These names/arguments are supplied only after the actual tool has returned this name.
            if len(op) > 2 and op[2] != name:
                raise RuntimeError('Actual returned name mismatch')
            call('spawn', {'packet_key': key, 'agent_name': name,
                          'transport_wrapper_sha256': __import__('hashlib').sha256(
                              (B / 'worker-transport-instructions-v4.txt').read_bytes()).hexdigest(),
                          'transport_writer_sha256': __import__('hashlib').sha256(
                              (B / 'write_first_jsonl_v2.py').read_bytes()).hexdigest(),
                          'actual_spawn_tool_response': {'task_name': name},
                          'actual_spawn_tool_request': {'task_name': short, 'model': 'gpt-6-luna',
                                                       'fork_turns': 'none', 'message': msg}})
        elif action == 'terminal':
            call('terminal', {'packet_key': key, 'terminal_kind': 'worker_final',
                              'agent_name': state['assignments'][key]['agent_name'],
                              'actual_terminal_message': op[2]})
        else:
            raise RuntimeError('Unsupported actual observation')
    state = json.loads((B / 'state.json').read_text())
    queue = json.loads((B / 'dispatch-queue.json').read_text())
    new = [p for p in queue if p['packet_key'] not in state['assignments']][
          :max(0, state['max_parallel'] - len(state['active']))]
    for p in new:
        call('predispatch', p)
    state = json.loads((B / 'state.json').read_text())
    print(json.dumps({'assigned': len(state['assignments']), 'terminal': len(state['terminal']),
                      'active': state['active'],
                      'reserved_need_actual_spawn': [p['packet_key'] for p in new]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
