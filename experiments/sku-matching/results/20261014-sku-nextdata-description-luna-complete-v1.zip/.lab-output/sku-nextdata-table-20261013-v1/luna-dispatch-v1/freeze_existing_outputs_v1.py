#!/usr/bin/env python3
"""Read-only byte/assignment audit followed by exclusive creation of its receipt."""
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path

B = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(path):
    path = path.resolve()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def main():
    state = json.loads((B / 'state.json').read_text())
    queue = json.loads((B / 'dispatch-queue.json').read_text())
    allowed = set(state['input_freeze']['allowed_packet_keys'])
    assert state['status'] == 'complete' and not state['active']
    assert len(allowed) == 194
    assert set(state['assignments']) == set(state['terminal']) == allowed
    assert len(state['terminal']) == len(set(state['terminal'])) == 194
    assert [x['packet_key'] for x in queue] == state['dispatch_order']
    events = [json.loads(x) for x in (B / 'events.jsonl').read_text().splitlines()]
    event_counts = Counter(e['event'] for e in events)
    for name in ('predispatch', 'actual_spawn_response', 'worker_terminal'):
        assert event_counts[name] == 194
        assert len({e['packet_key'] for e in events if e['event'] == name}) == 194
    go = state['input_freeze']
    assert digest(Path(go['freeze_path'])) == go['freeze_sha256']
    assert digest(Path(go['root_go_path'])) == go['root_go_sha256']
    assert digest(Path(go['root_population_freeze_path'])) == go['root_population_freeze_sha256']
    input_pins = [pin(Path(go[k])) for k in ('freeze_path', 'root_go_path', 'root_population_freeze_path')]
    for entry in go['packet_indices']:
        assert digest(Path(entry['path'])) == entry['sha256']
        input_pins.append(pin(Path(entry['path'])))
    files = []
    assignments = []
    issues = []
    v4 = []
    seen_outputs = set()
    seen_agents = set()
    for planned in queue:
        key = planned['packet_key']
        a = state['assignments'][key]
        assert a['status'] == 'terminal'
        assert a['requested_model'] == 'gpt-6-luna' and a['fork_turns'] == 'none'
        assert a['actual_spawn_tool_response'] == {'task_name': a['agent_name']}
        assert a['agent_name'] not in seen_agents
        seen_agents.add(a['agent_name'])
        assert a['output_path'] not in seen_outputs
        seen_outputs.add(a['output_path'])
        assert a['output_absent_before_spawn'] is True
        assert a['pair_refs'] == planned['pair_refs']
        assert digest(Path(a['packet_path'])) == a['packet_sha256'] == planned['packet_sha256']
        output = Path(a['output_path'])
        observed = a['original_output']
        assert output.exists() == observed['exists']
        if output.exists():
            assert output.stat().st_size == observed['bytes'] and digest(output) == observed['sha256']
            files.append(pin(output))
            if not observed['jsonl_syntax_valid']:
                issues.append({'packet_key': key, 'kind': 'original_jsonl_syntax_invalid',
                               'error': observed.get('syntax_error'), 'preserved_unchanged': True})
            if not observed['ends_with_lf']:
                issues.append({'packet_key': key, 'kind': 'original_final_physical_lf_absent',
                               'preserved_unchanged': True})
        else:
            issues.append({'packet_key': key, 'kind': 'original_draft_missing',
                           'redispatched': False})
        raw = output.with_suffix('.authored-input.raw')
        framing = B / 'receipts' / (key + '-first-framing.json')
        writer_audit = None
        if 'transport_writer_sha256' in a:
            v4.append(key)
            writer_audit = {'raw_exists': raw.exists(), 'framing_receipt_exists': framing.exists()}
            if output.exists():
                assert raw.exists() and framing.exists(), 'Expected byte-preserving writer artifacts missing'
            if raw.exists() and framing.exists():
                r = json.loads(framing.read_text())
                raw_bytes = raw.read_bytes()
                framed = raw_bytes + (bytes([10]) if r['physical_trailing_lf_added'] else b'')
                assert framed == output.read_bytes()
                assert r['raw_sha256'] == digest(raw) and r['output_sha256'] == digest(output)
                assert r['raw_bytes'] == len(raw_bytes) and r['output_bytes'] == len(framed)
                assert r['helper_sha256'] == a['transport_writer_sha256']
                assert r['json_parsed_or_fixed'] is False and r['semantic_bytes_modified'] is False
                files.extend((pin(raw), pin(framing)))
                writer_audit.update(raw_sha256=digest(raw), framed_sha256=digest(output),
                                    physical_trailing_lf_added=r['physical_trailing_lf_added'],
                                    raw_and_framed_match_first_writer_receipt=True)
        for suffix in ('predispatch', 'spawn', 'terminal'):
            files.append(pin(B / 'receipts' / (key + '-' + suffix + '.json')))
        assignments.append({'packet_key': key, 'variant': a['variant'], 'pair_refs': a['pair_refs'],
                            'agent_name': a['agent_name'], 'output_path': a['output_path'],
                            'packet_sha256': a['packet_sha256'], 'original_output': observed,
                            'spawn_observed_at_utc': a['spawn_observed_at_utc'],
                            'terminal_observed_at_utc': a['terminal_observed_at_utc'],
                            'requested_model': 'gpt-6-luna', 'fork_turns': 'none',
                            'writer_audit': writer_audit})
    for path in (B / 'state.json', B / 'events.jsonl', B / 'dispatch-queue.json',
                 B / 'receipts' / 'completion.json', B / 'write_first_jsonl_v2.py',
                 B / 'worker-transport-instructions-v4.txt', B / 'supervisor_io.py',
                 B / 'bookkeeping.py', Path(__file__)):
        files.append(pin(path))
    first = min(a['spawn_observed_at_utc'] for a in state['assignments'].values())
    last = max(a['terminal_observed_at_utc'] for a in state['assignments'].values())
    seconds = (datetime.datetime.fromisoformat(last) - datetime.datetime.fromisoformat(first)).total_seconds()
    receipt = {'schema': 'all194-original-output-freeze-v1',
               'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'status': 'all_assigned_jobs_terminal_original_bytes_verified',
               'packet_count': 194, 'variant_packet_counts': dict(Counter(x['variant'] for x in assignments)),
               'variant_pair_counts': dict(Counter(v for x in assignments for v in [x['variant']] * len(x['pair_refs']))),
               'actual_spawn_tool_response_count': event_counts['actual_spawn_response'],
               'terminal_event_count': event_counts['worker_terminal'], 'active': [],
               'original_output_present': sum(x['original_output']['exists'] for x in assignments),
               'original_output_missing': sum(not x['original_output']['exists'] for x in assignments),
               'original_jsonl_syntax_invalid': sum(x['original_output']['exists'] and not x['original_output']['jsonl_syntax_valid'] for x in assignments),
               'final_physical_lf_absent': sum(x['original_output']['exists'] and not x['original_output']['ends_with_lf'] for x in assignments),
               'byte_preserving_writer_assigned': len(v4),
               'byte_preserving_writer_original_raw_present': sum(Path(state['assignments'][k]['output_path']).with_suffix('.authored-input.raw').exists() for k in v4),
               'first_spawn_observed_at_utc': first, 'last_terminal_observed_at_utc': last,
               'observed_hosted_dispatch_wall_seconds': seconds,
               'is_local_gpu_or_cpu_weights_benchmark': False,
               'input_freeze_sha256': go['freeze_sha256'], 'root_go_sha256': go['root_go_sha256'],
               'input_pins': input_pins, 'files': files, 'assignments': assignments, 'protocol_issues': issues,
               'no_semantic_redispatch_or_original_output_repair': True,
               'classifier_semantic_review_performed_by_supervisor': False,
               'requested_model': 'gpt-6-luna', 'fork_turns': 'none',
               'model_selector_is_not_weights_attestation': True,
               'complete_worker_tool_histories_independently_available': False,
               'no_private_selection_bindings_or_grades_read_from_files': True,
               'final_integrity_audit_is_not_semantic_truth_validation': True}
    dest = B / 'receipts' / 'all194-original-output-freeze-v1.json'
    with dest.open('x', encoding='utf-8') as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write(chr(10))
    print(json.dumps({'path': str(dest), 'bytes': dest.stat().st_size, 'sha256': digest(dest),
                      'packet_count': 194, 'original_output_present': receipt['original_output_present'],
                      'original_output_missing': receipt['original_output_missing'],
                      'original_jsonl_syntax_invalid': receipt['original_jsonl_syntax_invalid'],
                      'final_physical_lf_absent': receipt['final_physical_lf_absent'],
                      'byte_preserving_writer_assigned': len(v4),
                      'byte_preserving_writer_original_raw_present': receipt['byte_preserving_writer_original_raw_present'],
                      'observed_hosted_dispatch_wall_seconds': seconds,
                      'protocol_issues': issues}, ensure_ascii=False))


if __name__ == '__main__':
    main()
