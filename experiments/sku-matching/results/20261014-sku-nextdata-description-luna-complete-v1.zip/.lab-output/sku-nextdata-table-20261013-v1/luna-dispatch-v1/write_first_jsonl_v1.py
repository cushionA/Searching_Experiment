#!/usr/bin/env python3
"""Exclusive serialization transport only; every JSON field comes from the model."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job-json', required=True)
    args = parser.parse_args()
    descriptor = Path(args.job_json).resolve()
    if not descriptor.is_relative_to(BASE):
        raise RuntimeError('Assigned job descriptor must be within this dispatch directory')
    job = json.loads(descriptor.read_text(encoding='utf-8'))
    output = Path(job['output_path']).resolve()
    if not output.is_relative_to(BASE) or not output.parent.is_dir():
        raise RuntimeError('Pinned output parent must already exist within dispatch directory')
    # No state/scope/citation/schema defaults and no changes to model-authored field values.
    authored = json.loads(sys.stdin.read())
    if not isinstance(authored, list) or not authored or not all(isinstance(x, dict) for x in authored):
        raise RuntimeError('Model must author a nonempty JSON array of complete response objects')
    payload = ''.join(json.dumps(record, ensure_ascii=False, separators=(',', ':')) + chr(10)
                      for record in authored).encode('utf-8')
    with output.open('xb') as stream:
        stream.write(payload)
    print(json.dumps({'exclusive_first_write': True, 'path': str(output), 'bytes': len(payload),
                      'sha256': hashlib.sha256(payload).hexdigest(), 'ends_with_actual_lf': True,
                      'model_authored_record_count': len(authored), 'semantic_fields_added': 0,
                      'semantic_values_changed': 0}))


if __name__ == '__main__':
    main()
