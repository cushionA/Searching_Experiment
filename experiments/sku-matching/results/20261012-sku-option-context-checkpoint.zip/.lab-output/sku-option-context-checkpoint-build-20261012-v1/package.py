from __future__ import annotations

import hashlib
import json
import subprocess
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "experiments/sku-matching/results"
STEM = "20261012-sku-option-context-checkpoint"
ARCHIVE = RESULTS / f"{STEM}.zip"
MANIFEST_PATH = RESULTS / f"{STEM}.manifest.json"

# Only these named run roots are traversed. Refuse links and any prohibited
# paths so weights, caches, and credentials cannot enter the package.
RUN_ROOTS = (
    ".lab-output/sku-compound-product-choices-20261012-v1",
    ".lab-output/sku-all-options-context-20261012-v1",
    ".lab-output/sku-all-options-context-wrapper-20261012-v1",
    ".lab-output/sku-compound-product-choices-resume-20261012-v1",
    ".lab-output/sku-all-options-context-resume-20261012-v1",
    ".lab-output/sku-option-prompt-consensus-20261012-v1",
    ".lab-output/sku-option-prompt-consensus-plan-20261012-v1",
)
EXACT_FILES = (
    "experiments/sku-matching/compound_product_choices_v1.py",
    "experiments/sku-matching/trial_compound_product_choices_v1.py",
    "experiments/sku-matching/all_options_context_v1.py",
    "experiments/sku-matching/trial_all_options_context_v1.py",
    "tests/test_lab_sku_compound_product_choices.py",
    "tests/test_lab_sku_all_options_context.py",
    "experiments/sku-matching/claude-safe-option-equivalence-request-20261012.txt",
    "experiments/sku-matching/session-result-20261012.txt",
    "experiments/sku-matching/claude-followup-20261012.txt",
    "experiments/sku-matching/option-context-result-20261012.txt",
    "experiments/sku-matching/option_prompt_consensus_v1.py",
    "tests/test_lab_sku_option_prompt_consensus.py",
    ".lab-output/sku-option-context-checkpoint-build-20261012-v1/package.py",
)
DEPENDENCIES = (
    "experiments/sku-matching/results/20261012-sku-mixed-cpu-checkpoint.zip",
    "experiments/sku-matching/results/20261012-sku-mixed-gates-improvement-checkpoint.zip",
    "experiments/sku-matching/results/20261012-sku-followup-checkpoint.zip",
)
DENIED_PARTS = {
    ".aws", ".codex", ".git", ".deps", "node_modules", "venv", ".venv",
    "cache", "caches", "weights", "model_weights", "credentials",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def repo_value(*args: str) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=ROOT, text=True, stderr=subprocess.DEVNULL
    ).strip()


def safe_relative(name: str) -> Path:
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"invalid archive path: {name}")
    if any(part.lower() in DENIED_PARTS for part in relative.parts):
        raise ValueError(f"prohibited archive path: {name}")
    return relative


def collect_paths() -> list[str]:
    names: set[str] = set()
    for root_name in RUN_ROOTS:
        root = ROOT / safe_relative(root_name)
        if not root.is_dir() or root.is_symlink():
            raise FileNotFoundError(f"required run directory missing or unsafe: {root_name}")
        for path in root.rglob("*"):
            relative_name = path.relative_to(ROOT).as_posix()
            safe_relative(relative_name)
            if path.is_symlink():
                raise ValueError(f"symlink in required run directory: {relative_name}")
            if path.is_file():
                names.add(relative_name)
    names.update(EXACT_FILES)
    for name in names:
        path = ROOT / safe_relative(name)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"required file missing or unsafe: {name}")
    return sorted(names)


def main() -> None:
    if ARCHIVE.exists() or MANIFEST_PATH.exists():
        raise FileExistsError("refusing to overwrite an existing checkpoint or manifest")
    RESULTS.mkdir(parents=True, exist_ok=True)

    dependencies = []
    for name in DEPENDENCIES:
        path = ROOT / safe_relative(name)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"required dependency archive missing: {name}")
        dependencies.append({"path": name, "sha256": digest(path.read_bytes())})

    files = []
    payloads: dict[str, bytes] = {}
    for name in collect_paths():
        body = (ROOT / name).read_bytes()
        payloads[name] = body
        files.append({"path": name, "bytes": len(body), "sha256": digest(body)})

    manifest = {
        "schema_version": "sku-option-context-checkpoint-v1",
        "experiment_status": "exploratory_dev_informed",
        "labels": ["machine labels", "no independent test"],
        "branch": repo_value("branch", "--show-current"),
        "head": repo_value("rev-parse", "HEAD"),
        "independent_test_read": False,
        "model_weights_included": False,
        "excluded_content": ["model weights", "caches", "credential directories"],
        "dependencies": dependencies,
        "file_count": len(files),
        "files": files,
        "restore_rule": "verify archive CRC and every member byte count and SHA256 before extraction; never overwrite a different existing source",
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
    if any(Path(name).name.lower().endswith((".safetensors", ".pt", ".pth", ".ckpt", ".bin"))
           for name in payloads):
        raise ValueError("weight-like files are prohibited in this checkpoint")

    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for row in files:
            body = payloads[row["path"]]
            if len(body) != row["bytes"] or digest(body) != row["sha256"]:
                raise ValueError(f"source changed while packaging: {row['path']}")
            zipped.writestr(row["path"], body)
        zipped.writestr("CHECKPOINT_MANIFEST.json", manifest_bytes)

    with zipfile.ZipFile(ARCHIVE, "r") as zipped:
        expected = {row["path"] for row in files} | {"CHECKPOINT_MANIFEST.json"}
        names = zipped.namelist()
        if (zipped.testzip() is not None or set(names) != expected
                or len(names) != len(expected)):
            raise ValueError("archive CRC or member-name verification failed")
        for row in files:
            body = zipped.read(row["path"])
            if len(body) != row["bytes"] or digest(body) != row["sha256"]:
                raise ValueError(f"archive member verification failed: {row['path']}")
        if zipped.read("CHECKPOINT_MANIFEST.json") != manifest_bytes:
            raise ValueError("embedded manifest verification failed")

    for row in files:
        current = (ROOT / row["path"]).read_bytes()
        if len(current) != row["bytes"] or digest(current) != row["sha256"]:
            raise ValueError(f"source changed during packaging: {row['path']}")

    # The adjacent manifest can record the archive hash without making the
    # archive self-referential; the embedded copy records all member hashes.
    archive_sha = digest(ARCHIVE.read_bytes())
    adjacent_manifest = dict(manifest)
    adjacent_manifest["archive"] = {
        "path": ARCHIVE.relative_to(ROOT).as_posix(),
        "bytes": ARCHIVE.stat().st_size,
        "sha256": archive_sha,
    }
    MANIFEST_PATH.write_text(
        json.dumps(adjacent_manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "archive": str(ARCHIVE),
        "manifest": str(MANIFEST_PATH),
        "archive_bytes": ARCHIVE.stat().st_size,
        "archive_sha256": archive_sha,
        "verified_members": len(files),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
