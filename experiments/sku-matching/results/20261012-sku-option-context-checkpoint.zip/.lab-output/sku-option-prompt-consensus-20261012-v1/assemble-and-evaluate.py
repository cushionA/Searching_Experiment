from pathlib import Path
from copy import deepcopy
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
import evaluate_mixed_gpu_sku_v1 as E
import evaluate_keyword_filtered_product_v1 as REFERENCES
import trial_keyword_filtered_product_v1 as VERIFY
import trial_product_condition_models_v1 as PRODUCT
import product_condition_sharing_v1 as SHARING
import option_prompt_consensus_v1 as CONSENSUS

OUT = Path(__file__).resolve().parent
PREP = ROOT / '.lab-output/sku-mixed-gpu-prep-20261012-v5'
CPU = ROOT / '.lab-output/sku-mixed-cpu-run-20261012-v1'
OLD_EVAL = ROOT / '.lab-output/sku-mixed-cpu-evaluation-20261012-v4'
ROUTES = ROOT / '.lab-output/sku-mixed-cpu-reference-routes-20261012-v2'
CURRENT = ROOT / '.lab-output/sku-baseline-ablation-20261012-v2'
PROTOCOL = ROOT / '.lab-output/sku-option-prompt-consensus-plan-20261012-v1/protocol.json'
COMPONENTS = {
    'original-product-top3-jev': CPU / 'product-model',
    'compound-product-choices-v1': ROOT / '.lab-output/sku-compound-product-choices-20261012-v1',
    'all-options-context-v1': ROOT / '.lab-output/sku-all-options-context-20261012-v1',
}

def read_json(p): return json.loads(Path(p).read_text())
def index(p, k): return E.GATE.indexed(Path(p), k)
def rows(p): return list(E.rows(Path(p)))
def group_key(g): return tuple(sorted(g['request_ids']))

assert not (OUT / 'summary.json').exists()
protocol = read_json(PROTOCOL)
assert protocol['components'] == list(COMPONENTS)
assert protocol['minimum_distinct_prompt_votes'] == 2
source = VERIFY.verify_source(CPU / 'product-model')
manifest, requests, documents, tasks, cases, membership, hosts = E.load_mixed_prepared(PREP)
cpu_summary, _ = E.verify_cpu_run(PREP, CPU, manifest, requests)
fusion, _, eligible = E.check_prediction_coverage(PREP, CPU, requests, documents, tasks, cpu_summary)
saved = {v: index(CPU / 'baseline-refresh/baseline-model' / (v + '-predictions.jsonl'), 'request_id') for v in ('jev', 'nli')}
baseline = {rid: saved['nli' if r['direction'] == 'rakuten_to_au' else 'jev'][rid] for rid, r in requests.items()}
E.GATE.validate_predictions(requests, documents, tasks, baseline, baseline, 'baseline')
assert len(eligible) == 80 and len(requests) == 134
component_groups, component_results, component_choices = {}, {}, {}
frozen_files = [PROTOCOL, Path(__file__), Path(CONSENSUS.__file__), Path(E.__file__), Path(REFERENCES.__file__),
                Path(VERIFY.__file__), *(PREP / n for n in ('manifest.json', *E.PREP_FILES)),
                CPU / 'summary.json', CPU / 'cpu-source-freeze.json', CPU / 'execution-freeze.json',
                *(CPU / 'baseline-refresh/baseline-model' / (v + '-predictions.jsonl') for v in ('jev', 'nli'))]
component_sha = {}
for name, directory in COMPONENTS.items():
    summary = read_json(directory / 'summary.json')
    assert PRODUCT.JEV._same_pins(summary['verified_jev_pin'])
    for member, want in summary['output_sha256'].items():
        assert E.sha(directory / member) == want, (name, member)
    if name != 'original-product-top3-jev':
        VERIFY.verify_snapshot(read_json(directory / 'execution-freeze.json')['source_snapshot'], phase='before consensus')
    groups = rows(directory / 'product-groups.jsonl')
    results_name = 'product-top3-jev-group-results.jsonl' if name == 'original-product-top3-jev' else 'group-results.jsonl'
    results = index(directory / results_name, 'group_id')
    scored = rows(directory / 'jev-classification-options.jsonl')
    VERIFY.validated_jev_cache(rows(directory / 'jev-unique-scores.jsonl'))
    rebuilt = PRODUCT.group_results(groups, scored, [], documents, source['blocks'], 'product-top3-jev')
    assert rebuilt == results
    component_groups[name] = {group_key(g): g for g in groups}
    component_results[name] = results
    component_choices[name] = {(r['group_id'], r['block_id']): r for r in rows(directory / 'model-requests.jsonl')}
    assert len(component_groups[name]) == 29
    members = ('summary.json', 'product-groups.jsonl', 'sharing-plan.json', results_name,
               'model-requests.jsonl', 'jev-unique-scores.jsonl', 'jev-classification-options.jsonl', 'retrieval-selections.jsonl')
    frozen_files.extend(directory / member for member in members)
    component_sha[name] = {member: E.sha(directory / member) for member in members}
wrapper = ROOT / '.lab-output/sku-all-options-context-wrapper-20261012-v1'
wrapper_summary = read_json(wrapper / 'summary.json')
for member, want in wrapper_summary['wrapper_sha256'].items(): assert E.sha(wrapper / member) == want
VERIFY.verify_snapshot(read_json(wrapper / 'execution-freeze.json')['source_snapshot'], phase='before consensus')
frozen_files.extend(p for p in wrapper.rglob('*') if p.is_file())
assert set.intersection(*(set(g) for g in component_groups.values())) == set(next(iter(component_groups.values())))
identity = {'model_id': 'sku-whole-option-prompt-consensus', 'revision': 'three-prompts/two-exact-raw-options-v1',
            'jev': source['summary']['verified_jev_pin'], 'components': component_sha,
            'protocol_sha256': E.sha(PROTOCOL), 'consensus_code_sha256': E.sha(Path(CONSENSUS.__file__)),
            'scope': 'wording stability only; same model and same source evidence'}
plan = SHARING.build_groups(requests, documents, {rid: p['source_task_bindings'] for rid, p in fusion.items()},
                            model_identity=identity, content_version=identity['revision'], invariance_contract=source['contract'])
assert set(plan['request_to_group']) == eligible and len(plan['groups']) == 29
results, audits = {}, []
fields = ('axis_name', 'option_values', 'canonical_au_url', 'target_document_id', 'target_document_sha256', 'title', 'description')
for group in plan['groups']:
    key = group_key(group)
    original = component_groups['original-product-top3-jev'][key]
    block_ids = source['selections'][original['group_id']]['ordered_block_ids'][:3]
    outcomes = []
    for name in COMPONENTS:
        other = component_groups[name][key]
        assert all(group[f] == other[f] for f in fields)
        scored = component_choices[name]
        assert set(bid for gid, bid in scored if gid == other['group_id']) == set(block_ids)
        for bid in block_ids:
            request = scored[other['group_id'], bid]
            old = component_choices['original-product-top3-jev'][original['group_id'], bid]
            assert request['state'] == old['state'] and request['block_rank'] == old['block_rank']
            assert request['all_original_option_values'] == group['option_values']
            assert [c['label'] for c in request['choices']] == group['option_values'] + [SHARING.UNKNOWN]
        value = deepcopy(component_results[name][other['group_id']])
        winner, refs, reason, tie = SHARING._group_outcome(other, value, documents)
        value.update(component_name=name, status='ok' if winner is not None else 'unknown',
                     winning_value=winner, quote_refs=refs, tie=tie, validated_reason=reason)
        assert all(bid in block_ids for bid in value['supporting_block_ids'])
        outcomes.append(value)
    result = CONSENSUS.combine(group, outcomes)
    result.update(reason='two_distinct_prompts_agree' if result['status'] == 'ok' else 'fewer_than_two_prompt_votes',
                  variant='whole-option-prompt-consensus')
    results[group['group_id']] = result
    audits.append({'group_id': group['group_id'], 'request_ids': group['request_ids'],
                   'source_group_ids': {name: component_groups[name][key]['group_id'] for name in COMPONENTS},
                   'original_top3_block_ids': block_ids, 'component_outcomes': result['component_outcomes']})
E.write_json(OUT / 'sharing-plan.json', plan)
E.write_json(OUT / 'protocol.json', protocol)
E.write_rows(OUT / 'product-groups.jsonl', plan['groups'])
E.write_rows(OUT / 'group-results.jsonl', results.values())
E.write_rows(OUT / 'component-audit.jsonl', audits)
predictions = SHARING.fan_out(plan, results, baseline)
predicted = {p['request_id']: p for p in predictions}
E.SHARED.validate_shared_predictions(requests, documents, tasks, predicted, baseline, eligible, 'product-top3-jev')
assert all(predicted[k] == baseline[k] for k in set(requests) - eligible)
E.write_rows(OUT / 'predictions.jsonl', predictions)
E.GATE.finish(PREP, OUT / 'predictions.jsonl', OUT / 'gates')
gates = index(OUT / 'gates/decisions.jsonl', 'case_id')
assert set(gates) == set(cases)
frozen_files.extend(p for p in OUT.rglob('*') if p.is_file())
snapshot = VERIFY.snapshot_paths({str(p): p for p in frozen_files})
E.write_json(OUT / 'all-gates-frozen.json', {'references_opened_for_scoring': False, 'all_gates_frozen': True,
             'experiment_status': 'exploratory_dev_informed', 'new_model_inference': False,
             'no_reference_contents_used_in_aggregation': True, 'case_count': 83, 'request_count': 134,
             'source_and_output_snapshot': snapshot, 'component_output_sha256': component_sha})
_, _, _, references, _ = REFERENCES.verify_original_sources(PREP, OLD_EVAL, ROUTES)
score_ids = {r['case_id'] for r in E.eligibility_rows(membership, hosts)[0] if r['primary_score_eligible']}
scored = {k: v for k, v in references.items() if k in score_ids and not v.get('reference_uncertain', False)}
assert len(scored) == 73
current = index(CURRENT / 'forward-nli-reverse-jev/gates/decisions.jsonl', 'case_id')
metrics, details = {}, []
for stratum in E.STRATA:
    value = E.metrics_for(gates, {k: v for k, v in scored.items() if membership[k]['membership_strata'] == [stratum]})
    metrics[stratum] = {k: v for k, v in value.items() if k != 'case_results'}
    details.extend({'stratum': stratum, **r} for r in value['case_results'])
value = E.metrics_for(gates, scored)
metrics['scored_primary_reference_union'] = {k: v for k, v in value.items() if k != 'case_results'}
before = {r['case_id']: r for r in E.metrics_for(current, scored)['case_results']}
changes = [{'case_id': r['case_id'], 'before': before[r['case_id']], 'after': r}
           for r in value['case_results'] if r != before[r['case_id']]]
E.write_rows(OUT / 'case-results.jsonl', details)
E.write_rows(OUT / 'changes-vs-current-candidate.jsonl', changes)
VERIFY.verify_snapshot(snapshot, phase='after consensus scoring')
E.verify_cpu_run(PREP, CPU, manifest, requests)
summary = {'schema_version': 'sku-option-prompt-consensus-v1', 'experiment_status': 'exploratory_dev_informed',
           'independent_test': False, 'production_adoption_allowed': False, 'new_model_inference': False,
           'reference_kind': 'existing machine labels', 'scored_case_count': 73, 'all_case_count': 83,
           'labels_read_after_all_gates_frozen': True, 'source_and_output_hashes_verified_after_scoring': True,
           'metrics': metrics, 'changed_scored_case_count': len(changes),
           'output_sha256': {str(p.relative_to(OUT)): E.sha(p) for p in OUT.rglob('*') if p.is_file()}}
E.write_json(OUT / 'summary.json', summary)
print(json.dumps({'stage': 'consensus-scored', 'metrics': metrics['scored_primary_reference_union']}, ensure_ascii=False))
