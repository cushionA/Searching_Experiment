# Claude v2c source-preserving CPU gate audit

This is a read-only replay of the v2c gate logic from `/workspace/Searching_Experiment-claude-share-20261010/experiments/sku-matching`, using the packaged v2 `products.jsonl` / `cases.jsonl` inputs and raw files under the original checkout. The v2c archive does not include the row JSONLs, but its manifest states that the v2c predictions are byte-identical to v2. I replayed A/B `full` and `full_no_closed_list`; all four outputs reproduce the archived prediction bytes exactly. The replay source code is retained in `reproduce.py` and `finalize.py`; generated rows are under `predictions/`.

## Reproduction and diagnostics

- 1,383 cases and 29 product pairs; A `full`: 435 matched, 910 unmatched, 38 review. B `full`: 251 matched, 906 unmatched, 226 review.
- A/B full unmatched decisions all use the respective explicit all-row-conflict reason. Derived conflicts may be present in row detail but are not by themselves sufficient for `unmatched`.
- All 98 A matches that were v10 `review` have complete requirement decomposition and the selected A row supports every selected requirement. Targeted source facts, spans, offsets and JSONPaths are in `a98-v10-delta-source-facts.json`; 1,189 cited spans across 17 raw files passed SHA/offset/quote verification.
- Among those 98 cases, evidence scope counts (per evidence occurrence) include selected AU row 159, AU title 108, closed contents list 31, AU contents 31, page declarations 33 and other typed specification/size scopes. No selected evidence cited `series_or_sibling_context`; no condition-bearing evidence was used by these 98 new accepts. Multi-atom selections stay separate requirement cards, but all are evaluated against one candidate AU row.
- The 98 A rows all match the reused Luna labels, including the same AU row key. This is a machine-label development diagnostic only. It is neither human-verified gold nor independent holdout. The full A/B/v10 aggregate comparison is in `reused-label-diagnostics.json`.

## Six fabric atoms flagged by the gate

Six accepted cases expose an uncovered feature path: AU-only extra atom `fabric=パイル` had status `unverified`, because v2c's selected Rakuten attribute fact parser only handles body dimensions. Targeted raw-source reconciliation in `six-fabric-reconciliation.json` found the same fabric on both sides at selected-SKU scope: each AU `rowNames[i]` contains the selected color plus `（パイル）`, and each selected Rakuten variant has `attributes[7]` titled `素材（生地・毛糸）` with value `パイル・タオル`. The AU title omits fabric; AU descriptive text also says `パイル生地` at product-page scope. All source spans are SHA-verified. This is supported evidence the frozen gate omitted, not a reason to downgrade those six accepts.

## Reusable schemas and API

`sku_gates.run_method(method, case_input, PairFacts(product_context), config)` returns an output with:

- top-level `candidate_row_keys`: rows supporting every selected requirement; `matched` requires exactly one candidate for A, while B also requires every other AU row to be excluded by verified conflict.
- `requirements`: selected typed atoms with `requirement_id`, type/value, source quote/span, scope, `decomposition`, and residue. A residual exporter should retain every atom and treat incomplete decomposition as unresolved.
- `rows`: each entry has `row_key`, `status` (`full`, `conflict`, `derived_conflict`, `ambiguous`, or `partial`), supported counts, and `first_blocker`. Full-detail focus rows also include `atom_results` (per-requirement support/conflict/unknown with quoted evidence), `au_only_atoms`, and `derived_conflicts`. Non-focus rows omit detail in the primary `full` config; all rows have metadata-only output under ablations.
- Evidence `span` records raw file, SHA-256, locator (`json_path` or HTML path), character offsets and quote; conditional facts may also have a `condition`. AU row evidence uses the original row's JSONPath. `series_or_sibling_context` is deliberately scoped separately.

Safe construction/reuse chain: `sku_gate_sources.RawStore(root)` → `sku_gates.build_product_context(...)` / `build_case_input(...)` if rebuilding inputs → `PairFacts(context)` → `selected_atoms(case_input, facts)` → `run_method(...)`. For residual export, use the matched top row as focus when accepted; for review use rows with most direct support / candidate status and preserve blockers. Keep conditional scope attached to its condition, ignore series/sibling facts for selected-SKU assertions, and retain unknowns for manual or model review. Do not let model output alone establish identity.
