#!/usr/bin/env python3
"""Preserve authored stdin bytes; exclusive creation plus physical LF framing only."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import sys

BASE = Path('/workspace/Searching_Experiment-model-gates-20261010/.lab-output/sku-nextdata-full-main-control-20261014-v1/luna-dispatch-v1')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--packet-key', required=True)
    args = parser.parse_args()
    if Path(__file__).resolve().parent != BASE:
        raise RuntimeError('Verified fixed dispatch directory mismatch')
    match = re.fullmatch(r'(full)-([0-9]{3})', args.packet_key)
    if not match:
        raise RuntimeError('Invalid public packet key')
    variant, number = match.groups()
    if not 1 <= int(number) <= 166:
        raise RuntimeError('Public packet key outside frozen population')
    parent = BASE / 'drafts' / variant
    raw_path = parent / f'packet-{number}.authored-input.raw'
    output_path = parent / f'packet-{number}.jsonl'
    receipt_path = BASE / 'receipts' / f'{args.packet_key}-first-framing.json'
    if not parent.is_dir():
        raise RuntimeError('Verified fixed draft parent does not exist')
    if any(p.exists() for p in (raw_path, output_path, receipt_path)):
        raise FileExistsError('Original authored stdin/output/receipt already exists; no retry')
    authored = sys.stdin.buffer.read()
    # Never parse, reserialize, validate/fix JSON, inject properties, or modify semantic bytes.
    with raw_path.open('xb') as stream:
        stream.write(authored)
    added_lf = not authored.endswith(bytes([10]))
    framed = authored + (bytes([10]) if added_lf else b'')
    with output_path.open('xb') as stream:
        stream.write(framed)
    receipt = {'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'packet_key': args.packet_key, 'raw_path': str(raw_path),
               'raw_bytes': len(authored), 'raw_sha256': hashlib.sha256(authored).hexdigest(),
               'output_path': str(output_path), 'output_bytes': len(framed),
               'output_sha256': hashlib.sha256(framed).hexdigest(),
               'physical_trailing_lf_added': added_lf, 'json_parsed_or_fixed': False,
               'semantic_bytes_modified': False, 'raw_and_output_create_exclusive': True,
               'helper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    with receipt_path.open('x', encoding='utf-8') as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write(chr(10))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__':
    main()
