#!/usr/bin/env python3
"""Freeze both source-metadata assembly views before unused TEST gold access."""
from pathlib import Path
from collections import Counter
import datetime,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
BASE=ROOT/'.lab-output/sku-unused-holdout-choice-20261013-v1'
PROOF=ROOT/'.lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1'
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import sku_directional_choice_nli_v1 as N
import evaluate_dev_source_bound_whole_sku_gate_v1 as E
import grade_unused_holdout_sku_gate_v1 as G
def pin(p):return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def write(p,x):
    with p.open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def main():
    original=json.loads((HERE/'experiment-freeze.json').read_text())
    for rel,v in original['frozen_files'].items():assert pin(ROOT/rel)==v,rel
    # Source+semantic classifier/proof policy unchanged after inference.
    policy=json.loads((BASE/'selection-policy.json').read_text())['frozen_classification_and_proof_policy']
    for name,key in [('sku_directional_choice_nli_v1.py','choice_nli_module_sha256'),('normalize_source_nli_citations_v1.py','citation_normalizer_sha256'),
                     ('evaluate_dev_source_bound_whole_sku_gate_v1.py','whole_sku_evaluator_sha256'),('sku_literal_family_proof_v1.py','literal_proof_module_sha256')]:
        assert pin(ROOT/'experiments/sku-matching'/name)['sha256']==policy[key]
    source=BASE/'source-inputs';tasks=N.read_rows(source/'tasks.jsonl');cases=N.read_rows(source/'case-plans.jsonl');rows=N.read_rows(source/'row-plans.jsonl')
    assert (len(tasks),len(cases),len(rows))==(1598,40,394)
    bindings=N.read_rows(BASE/'prepared-choice-nli/validation-bindings.jsonl')
    taskproofs=N.read_rows(PROOF/'task-proof-states.jsonl');receipts=N.read_rows(PROOF/'task-source-verification.jsonl')
    out=HERE/'final-gate-run';out.mkdir();variants={};gatefiles=[];summaries={}
    for name,version in [('strict-source-metadata','v1'),('explicit-choice-nli-experimental','v2')]:
        vdir=HERE/f'source-validation-{version}';valid=N.read_rows(vdir/'validated-pairs.jsonl');statuses=N.read_rows(vdir/'validation-statuses.jsonl')
        assert len(statuses)==256 and {x['pair_id'] for x in valid}=={x['pair_id'] for x in statuses if x['status']=='source_metadata_valid'}
        resolved=E.build_choice_nli_task_resolutions(tasks,bindings,valid,taskproofs,receipts)
        result=E.finish_whole_sku_gate('choice_nli_full',cases,rows,tasks,resolved)
        d=out/name;d.mkdir()
        for filename,items in [('task-resolutions.jsonl',resolved),('all-row-results.jsonl',result['rows']),('case-decisions.jsonl',result['decisions'])]:
            p=d/filename;N.write_rows(p,items);gatefiles.append(str(p.relative_to(ROOT)))
        variants[name]={'predictions':str((d/'case-decisions.jsonl').relative_to(ROOT)),
                        'gate_files':[str((d/f).relative_to(ROOT)) for f in ('task-resolutions.jsonl','all-row-results.jsonl','case-decisions.jsonl')]}
        summaries[name]={k:result[k] for k in ('task_state_counts','row_state_counts','decision_counts')}
        summaries[name]['task_sources']=dict(Counter(x['source'] for x in resolved))
    write(out/'gate-summary.json',{'labels_read':False,'source_split':'test','independent_test':True,'variants':summaries})
    files={ROOT/rel for rel in original['frozen_files']}
    for tree in [BASE,PROOF,HERE,ROOT/'.lab-output/sku-unused-holdout-required-checks-20261013-v3',
                 ROOT/'.lab-output/sku-unused-holdout-citation-test-path-fix-20261013-v1']:
        assert tree.exists(),tree
        files.update(p for p in tree.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc'})
    files.update([ROOT/'experiments/sku-matching/canonicalize_source_citation_table_v1.py',ROOT/'tests/test_lab_sku_source_citation_table_v1.py',
                  ROOT/'experiments/sku-matching/source_citation_table_synthetic_original_v1.py',Path(__file__)])
    inputs={'membership':BASE/'selection-membership.jsonl','case_plans':source/'case-plans.jsonl','row_plans':source/'row-plans.jsonl',
            'selection_policy':BASE/'selection-policy.json','original_case_receipts':BASE/'original-case-line-receipts.jsonl',
            'old_membership':G.OLD_MEMBERSHIP,'source_manifest':source/'manifest.json'}
    files.update(inputs.values())
    receipt={'schema_version':'sku-unused-holdout-grading-freeze-v1','freeze_status':'all_predictions_and_gates_frozen',
             'created_at_utc':datetime.datetime.now(datetime.UTC).isoformat(),'source_split':'test','independent_test':True,
             'labels_read':False,'gold_or_references_read':False,'all_predictions_frozen':True,'all_gates_frozen':True,
             'membership_sha256':G.EXPECTED_MEMBERSHIP_SHA256,'selection_policy_sha256':G.EXPECTED_POLICY_SHA256,
             'policy_or_threshold_changed':False,'classifier_outputs_changed_after_freeze':False,
             'variants':variants,'gate_files':gatefiles,'input_files':{k:str(v.relative_to(ROOT)) for k,v in inputs.items()},
             'required_artifact_paths':sorted(str(p.relative_to(ROOT)) for p in files),
             'frozen_files':{str(p.relative_to(ROOT)):pin(p) for p in sorted(files)},
             'source_metadata_parser_repair_before_gold_disclosed':True,
             'semantic_classifier_and_literal_and_whole_row_policy_unchanged':True,'production_adoption_allowed':False}
    target=out/'grading-freeze.json';write(target,receipt)
    G.validate_freeze_receipt(target,membership_path=G.MEMBERSHIP,case_plans_path=G.CASE_PLANS,row_plans_path=G.ROW_PLANS,
        selection_policy_path=G.SELECTION_POLICY,old_membership_path=G.OLD_MEMBERSHIP,original_case_receipts_path=G.ORIGINAL_CASE_RECEIPTS,
        source_manifest_path=G.SOURCE_INPUT_MANIFEST,expected_variants=set(variants))
    G.validate_selection(G.MEMBERSHIP,G.CASE_PLANS,G.ROW_PLANS,G.SELECTION_POLICY,G.OLD_MEMBERSHIP,G.ORIGINAL_CASE_RECEIPTS)
    print(json.dumps({'freeze_sha256':pin(target)['sha256'],'frozen_files':len(files),'variants':summaries}),flush=True)
if __name__=='__main__':main()
