#!/usr/bin/env python3
"""Snapshot and source-validate unused TEST answers without semantic retries."""
from pathlib import Path
from collections import Counter
import copy
import datetime
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PREPARED=ROOT/'.lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli'
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import normalize_source_nli_citations_v1 as N

def pin(p):return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def write(p,x):
    with p.open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def rwrite(p,rows):N.write_rows(p,rows)
def main():
    freeze=json.loads((HERE/'experiment-freeze.json').read_text())
    for rel,expected in freeze['frozen_files'].items():assert pin(ROOT/rel)==expected,rel
    expectedids=set()
    for i in range(4):expectedids.update(json.loads((HERE/f'worker-inputs/worker-{i}-assignment.json').read_text())['pair_ids'])
    snapshot=HERE/'completed-response-snapshot-v1';snapshot.mkdir();responses=[];workerpins={}
    files=[HERE/'worker-responses'/f'worker-{i}.jsonl' for i in (1,2,3)]
    files+=[HERE/'worker-responses'/f'worker-0-part-{i}.jsonl' for i in range(8)]
    assert set(files)==set((HERE/'worker-responses').glob('*.jsonl'))
    for source in files:
        q=snapshot/source.name;q.write_bytes(source.read_bytes());items=N.read_rows(q)
        assert len(items)==(8 if 'part' in q.name else 64),source
        responses.extend(items);workerpins[str(q.relative_to(ROOT))]={**pin(q),'response_count':len(items)}
    assert len(responses)==len({x['pair_id'] for x in responses})==len(expectedids)==256
    assert {x['pair_id'] for x in responses}==expectedids
    merged=snapshot/'all-dispatched-responses.jsonl';rwrite(merged,responses)
    receipt={'schema_version':'sku-unused-holdout-completed-response-snapshot-v1','created_at_utc':datetime.datetime.now(datetime.UTC).isoformat(),
             'source_split':'test','independent_test':True,'labels_read':False,'response_count':256,
             'all_original_dispatched_pair_ids_present_once':True,'source_response_files_overwritten':False,
             'semantic_retry_performed':False,'empty_judgment_pair_ids':[x['pair_id'] for x in responses if not x.get('judgments')],
             'excluded_no_response_attempts':[
                 {'agent':'/root/holdout_choice_nli_worker_0','reason':'64 contexts exceeded reported observation budget; no response created; original64 unchanged packets repartitioned into8x8'},
                 {'agent':'/root/holdout_part_0','reason':'Worker reported broad search beyond assigned packets and model-identity confusion; no response created; attempt excluded, fresh fork_none Luna-routed classifier used'}],
             'model_routing_evidence':'Trusted collaboration.spawn_agent calls explicitly set model=gpt-6-luna,fork_turns=none. Assignment/self-report alone is not model identity verification; hosted weights revision independently unverified.',
             'worker_first_pass_cleanup_reported':False,
             'frozen_files':{**workerpins,str(merged.relative_to(ROOT)):pin(merged)}}
    write(snapshot/'snapshot-receipt.json',receipt)
    N.normalize_file(PREPARED,merged,HERE/'citation-normalization-v1')
    normalized=HERE/'citation-normalization-v1/normalized-responses.jsonl';items=N.read_rows(normalized)
    canonicaldir=HERE/'protocol-canonicalization-v1';canonicaldir.mkdir();changes=[];canonical=[]
    contract=json.loads((PREPARED/'design/response-contract.json').read_text())
    _,pairs,_=N.load_source_contexts(PREPARED)
    for row in items:
        q=copy.deepcopy(row);pair=pairs[q['pair_id']];assert q['cache_key']==pair['cache_key']
        if q.get('protocol')==contract['schema_version'] and contract['schema_version']==pair['protocol']+'/response':
            changes.append({'pair_id':q['pair_id'],'previous_protocol':q['protocol'],'canonical_protocol':pair['protocol']});q['protocol']=pair['protocol']
        a=copy.deepcopy(row);b=copy.deepcopy(q);a.pop('protocol',None);b.pop('protocol',None);assert N.canonical(a)==N.canonical(b)
        canonical.append(q)
    output=canonicaldir/'canonical-responses.jsonl';rwrite(output,canonical);rwrite(canonicaldir/'protocol-changes.jsonl',changes)
    write(canonicaldir/'canonicalization-receipt.json',{'schema_version':'sku-response-protocol-identifier-canonicalization-v1','labels_read':False,'source_split':'test',
          'independent_test':True,'root_go':'root-classification-go.json permits exact schema alias only','changed_response_count':len(changes),
          'semantic_fields_changed':False,'only_changed_field':'protocol','source_sha256':pin(normalized)['sha256'],'output_sha256':pin(output)['sha256']})
    validation=HERE/'source-validation-v1';validation.mkdir();valid=[];statuses=[]
    for i,row in enumerate(canonical):
        try:
            v=N.validate_normalized_response(PREPARED,row);valid.append(v)
            statuses.append({'pair_id':row['pair_id'],'status':'source_metadata_valid','judgment_count':v['judgment_count'],'semantic_truth_verified':False})
        except (KeyError,TypeError,ValueError,OSError) as exc:
            statuses.append({'pair_id':row['pair_id'],'status':'invalid_unknown','error':str(exc),'semantic_retry_performed':False,'original_response_changed':False})
        if (i+1)%40==0:print(json.dumps({'checked':i+1,'valid':len(valid)}),flush=True)
    rwrite(validation/'validated-pairs.jsonl',valid);rwrite(validation/'validation-statuses.jsonl',statuses)
    result={'schema_version':'sku-unused-holdout-source-validation-completion-v1','source_split':'test','independent_test':True,'labels_read':False,
            'response_count':256,'status_counts':dict(Counter(x['status'] for x in statuses)),
            'invalid_error_counts':dict(Counter(x['error'] for x in statuses if 'error' in x)),
            'semantic_truth_verified':False,'production_adoption_allowed':False,
            'frozen_files':{str(p.relative_to(ROOT)):pin(p) for p in [Path(__file__),output,validation/'validated-pairs.jsonl',validation/'validation-statuses.jsonl',
                ROOT/'experiments/sku-matching/sku_directional_choice_nli_v1.py',ROOT/'experiments/sku-matching/normalize_source_nli_citations_v1.py']}}
    write(validation/'validation-receipt.json',result);print(json.dumps({k:result[k] for k in ('response_count','status_counts','invalid_error_counts')}),flush=True)

if __name__=='__main__':main()
