#!/usr/bin/env python3
"""Freeze unused TEST transport before actual source-only Luna classification."""
from pathlib import Path
import datetime
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
BASE=ROOT/'.lab-output/sku-unused-holdout-choice-20261013-v1'
PREPARED=BASE/'prepared-choice-nli'
PROOF=ROOT/'.lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1'
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import sku_directional_choice_nli_v1 as NLI
import evaluate_dev_source_bound_whole_sku_gate_v1 as EVAL
import grade_unused_holdout_sku_gate_v1 as GRADE

def pin(p):return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def canon(x):return NLI.canonical(x)
def read(p):return json.loads(p.read_text())
def write(p,x):
    with p.open('xb') as f:f.write(canon(x)+b'\n')
def main():
    GRADE.validate_selection(BASE/'selection-membership.jsonl',BASE/'source-inputs/case-plans.jsonl',
        BASE/'source-inputs/row-plans.jsonl',BASE/'selection-policy.json',GRADE.OLD_MEMBERSHIP,
        BASE/'original-case-line-receipts.jsonl')
    selection=read(BASE/'selection-policy.json');freeze,pairs,contexts,docs,bindings=NLI._load_prepared(PREPARED)
    assert freeze['builder_sha256']==pin(Path(NLI.__file__))['sha256']
    assert freeze['split']=='test' and freeze['test_split_read'] is True and freeze['independent_test'] is True
    m=read(PROOF/'manifest.json')
    for rel,p in m['canonical_output_hashes'].items():assert pin(PROOF/rel)==p,rel
    taskrows=NLI.read_rows(BASE/'source-inputs/tasks.jsonl')
    tasks=EVAL.index(taskrows,'task_id','original task')
    proofs=EVAL.index(NLI.read_rows(PROOF/'task-proof-states.jsonl'),'task_id','proof task')
    receipts=EVAL.index(NLI.read_rows(PROOF/'task-source-verification.jsonl'),'task_id','source receipt')
    assert set(tasks)==set(proofs)==set(receipts) and len(tasks)==1598
    protection=EVAL.index(NLI.read_rows(PROOF/'nli-v2-context-protection.jsonl'),'pair_id','protection context')
    assert set(protection)==set(pairs) and len(pairs)==494
    skipped=[];selected=[]
    for pid in sorted(pairs):
        bs=bindings[pid]
        literal=[EVAL.source_literal_state(tasks[b['task_binding']['task_id']],proofs[b['task_binding']['task_id']],receipts[b['task_binding']['task_id']]) for b in bs]
        protected=bool(literal) and all(x is not None for x in literal)
        assert protected==protection[pid]['skip_classification']
        (skipped if protected else selected).append(pid)
    assert (len(skipped),len(selected))==(238,256)
    payloads=NLI.build_model_payloads(PREPARED,selected)
    by_id={p['pair_id']:p for p in payloads};assert set(by_id)==set(selected)
    worker_units=[[] for _ in range(4)];sizes=[0]*4
    for pid in sorted(selected,key=lambda p:(-len(canon(by_id[p])),p)):
        i=min(range(4),key=lambda i:(sizes[i],len(worker_units[i]),i))
        worker_units[i].append(by_id[pid]);sizes[i]+=len(canon(by_id[pid]))
    (HERE/'worker-inputs').mkdir();(HERE/'worker-responses').mkdir()
    for i,units in enumerate(worker_units):
        batch=[];paths=[]
        for unit in units:
            if batch and len(canon({'payloads':batch+[unit]}))>100000:
                q=HERE/'worker-inputs'/f'worker-{i}-batch-{len(paths):03d}.json';write(q,{'payloads':batch});paths.append(str(q.relative_to(ROOT)));batch=[]
            batch.append(unit)
        if batch:
            q=HERE/'worker-inputs'/f'worker-{i}-batch-{len(paths):03d}.json';write(q,{'payloads':batch});paths.append(str(q.relative_to(ROOT)))
        write(HERE/'worker-inputs'/f'worker-{i}-assignment.json',{
            'worker':i,'model':'gpt-6-luna','fork_turns':'none','pair_ids':[p['pair_id'] for p in units],
            'pair_count':len(units),'batch_files':paths,'output_path':str((HERE/'worker-responses'/f'worker-{i}.jsonl').relative_to(ROOT)),
            'protocol_file':str((PREPARED/'design/response-contract.json').relative_to(ROOT)),
            'actual_model_inference_required':True,'source_only':True,'body_or_full_option_truncation_forbidden':True,
            'semantic_retry_after_answer_persistence_forbidden':True,'response_overwrite_or_cleanup_forbidden':True})
    files=set()
    for tree in [BASE,PROOF,HERE/'worker-inputs']:
        for q in tree.rglob('*'):
            if q.is_file() and '__pycache__' not in q.parts:files.add(q)
    code=[Path(__file__),Path(NLI.__file__),Path(EVAL.__file__),Path(GRADE.__file__),
          ROOT/'experiments/sku-matching/normalize_source_nli_citations_v1.py',
          ROOT/'experiments/sku-matching/sku_literal_family_proof_v1.py',
          ROOT/'experiments/sku-matching/build_sku_literal_family_proofs_v1.py',
          ROOT/'experiments/sku-matching/prepare_dev_literal_family_proofs_v1.py',
          ROOT/'experiments/sku-matching/route_mixed_sku_references_v1.py',
          ROOT/'experiments/sku-matching/grade_final_test_subset_v1.py',GRADE.OLD_MEMBERSHIP]
    code+=[ROOT/'experiments/sku-matching'/f for f in ('prepare_unused_holdout_choice_nli_v1.py','prepare_unused_holdout_literal_family_proofs_v1.py')]
    code+=[ROOT/'tests'/f for f in ('test_lab_unused_holdout_choice_nli_v1.py','test_lab_unused_holdout_literal_family_proofs.py','test_lab_unused_holdout_sku_gate.py')]
    files.update(code)
    write(HERE/'experiment-freeze.json',{
        'schema_version':'sku-unused-holdout-choice-nli-root-freeze-v1','created_at_utc':datetime.datetime.now(datetime.UTC).isoformat(),
        'source_split':'test','independent_test':True,'labels_read':False,'gold_or_references_read':False,
        'membership_sha256':GRADE.EXPECTED_MEMBERSHIP_SHA256,'selection_policy_sha256':GRADE.EXPECTED_POLICY_SHA256,
        'case_count':40,'product_count':20,'row_count':394,'task_count':1598,'request_count':1042,
        'prepared_context_count':494,'literal_protected_context_count':238,'dispatch_context_count':256,
        'source_contextless_abstention_task_count':18,'worker_counts':[len(a) for a in worker_units],
        'worker_payload_bytes':sizes,'dispatched_whole_option_count':sum(len(p['candidate_vector']) for p in payloads),
        'model':'gpt-6-luna','hosted_weight_revision_verified':False,
        'primary_policy':'explicit-choice-nli-experimental','comparison_policy':None,
        'policy_scope':'Exact DEV-frozen whole-option semantic rules and protected literal proof. All original both-direction tasks and every captured AU row. No baseline fallback, upstream hints, category or case exceptions.',
        'semantic_evidence_is_not_source_proof':True,'selected_source_wanted_value_visible_to_classifier':False,
        'any_choice_nli_inference_started':False,'production_adoption_allowed':False,
        'frozen_files':{str(q.relative_to(ROOT)):pin(q) for q in sorted(files)}})
    print(json.dumps({'dispatch':len(selected),'skipped':len(skipped),'workers':[len(x) for x in worker_units],
                      'payload_bytes':sum(sizes),'frozen_file_count':len(files),'freeze_sha256':pin(HERE/'experiment-freeze.json')['sha256']}),flush=True)

if __name__=='__main__':main()
