#!/usr/bin/env python3
"""Validate unambiguous citation-container view with the unchanged NLI rules."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PREPARED=ROOT/'.lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli'
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import normalize_source_nli_citations_v1 as N
def pin(p):return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def main():
    source=HERE/'citation-container-canonicalization-v1/responses.jsonl'
    receipt=json.loads((HERE/'root-citation-container-canonicalization-go.json').read_text())
    for rel,v in receipt['frozen_files'].items():assert pin(ROOT/rel)==v,rel
    N.normalize_file(PREPARED,source,HERE/'citation-normalization-v2')
    normalized=HERE/'citation-normalization-v2/normalized-responses.jsonl'
    rows=N.read_rows(normalized);assert len(rows)==len({x['pair_id'] for x in rows})==256
    # All actual first responses use the original v2 protocol; do not edit protocol.
    assert all(x['protocol']==N.PROTOCOL for x in rows)
    out=HERE/'source-validation-v2';out.mkdir();valid=[];statuses=[]
    for i,row in enumerate(rows):
        try:
            v=N.validate_normalized_response(PREPARED,row);valid.append(v)
            statuses.append({'pair_id':row['pair_id'],'status':'source_metadata_valid','judgment_count':v['judgment_count'],'semantic_truth_verified':False})
        except (KeyError,TypeError,ValueError,OSError) as exc:
            statuses.append({'pair_id':row['pair_id'],'status':'invalid_unknown','error':str(exc),'semantic_retry_performed':False})
        if (i+1)%40==0:print(json.dumps({'checked':i+1,'valid':len(valid)}),flush=True)
    N.write_rows(out/'validated-pairs.jsonl',valid);N.write_rows(out/'validation-statuses.jsonl',statuses)
    result={'schema_version':'sku-unused-holdout-source-validation-completion-v2','labels_read':False,'source_split':'test','independent_test':True,
            'response_count':256,'status_counts':dict(Counter(x['status'] for x in statuses)),
            'invalid_error_counts':dict(Counter(x['error'] for x in statuses if 'error' in x)),
            'semantic_truth_verified':False,'production_adoption_allowed':False,
            'frozen_files':{str(p.relative_to(ROOT)):pin(p) for p in [Path(__file__),source,normalized,out/'validated-pairs.jsonl',out/'validation-statuses.jsonl',
                ROOT/'experiments/sku-matching/sku_directional_choice_nli_v1.py',ROOT/'experiments/sku-matching/normalize_source_nli_citations_v1.py',
                ROOT/'experiments/sku-matching/canonicalize_source_citation_table_v1.py']}}
    with (out/'validation-receipt.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({k:result[k] for k in ('response_count','status_counts','invalid_error_counts')}),flush=True)
if __name__=='__main__':main()
