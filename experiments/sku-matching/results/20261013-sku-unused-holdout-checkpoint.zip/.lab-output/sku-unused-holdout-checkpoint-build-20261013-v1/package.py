#!/usr/bin/env python3
"""Prepare and later build the frozen unused-holdout checkpoint.

Default mode is a source-only preflight. It does not enumerate or read current
worker responses, predictions, gates, scores, or selected references. Final
ZIP creation requires --root-go --build after the holdout grading freeze is
written and all source, prediction, gate, and score pins are stable.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
import zipfile
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / ".lab-output/sku-unused-holdout-checkpoint-build-20261013-v1"
OUT = ROOT / "experiments/sku-matching/results/20261013-sku-unused-holdout-checkpoint.zip"
SHA_PATH = OUT.with_suffix(OUT.suffix + ".sha256")
REPORT = ROOT / "experiments/sku-matching/unused-holdout-choice-nli-result-20261013.txt"
SCORE = BUILD / "holdout-score.json"
REFERENCES = BUILD / "selected-holdout-references.jsonl"
SCORING_RECEIPT = BUILD / "scoring-completion-receipt.json"
FREEZE_RECEIPT = ROOT / ".lab-output/sku-unused-holdout-choice-execution-20261013-v1/final-gate-run/grading-freeze.json"
EXECUTION = ROOT / ".lab-output/sku-unused-holdout-choice-execution-20261013-v1"
SOURCE_ROOT = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source"
SOURCE_INDEX = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source-index.json"
MEMBERSHIP = ROOT / ".lab-output/sku-unused-holdout-choice-20261013-v1/selection-membership.jsonl"
OLD_MEMBERSHIP = ROOT / ".lab-output/sku-final-composition-subset-20261013-v1/plan/subset-membership.jsonl"

MEMBERSHIP_SHA256 = "717c3403c11a7f00aa5e66ee03402717214744fe689ecee209354c7e0fac6da7"
SELECTION_POLICY_SHA256 = "66fb8338069130e1c4b24dbde463291ccee3f8ebcd5708144a260da67b35256d"
OLD_MEMBERSHIP_SHA256 = "212123b8851168a8895e8a035f8a1a032c173c496b76024b707030efca93778d"

SOURCE_TREES = [
    ".lab-output/sku-unused-holdout-choice-20261013-v1",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1",
    ".lab-output/sku-unused-holdout-required-checks-20261013-v1",
    ".lab-output/sku-unused-holdout-required-checks-20261013-v2",
    ".lab-output/sku-unused-holdout-required-checks-20261013-v3",
]

FROZEN_DIAGNOSTIC_LOGS = {
    ".lab-output/sku-unused-holdout-choice-execution-20261013-v1/source-validation-console.log",
    ".lab-output/sku-unused-holdout-choice-execution-20261013-v1/source-validation-v2-console.log",
}

EXECUTION_METADATA = [
    ".lab-output/sku-unused-holdout-choice-execution-20261013-v1/experiment-freeze.json",
    ".lab-output/sku-unused-holdout-choice-execution-20261013-v1/prepare_dispatch.py",
    ".lab-output/sku-unused-holdout-choice-execution-20261013-v1/root-classification-go.json",
    ".lab-output/sku-unused-holdout-choice-execution-20261013-v1/worker-0-small-dispatch-receipt.json",
]

FILES = [
    # Holdout selection, all-row source inputs, wrapper inputs, and exact old exclusion membership.
    ".lab-output/sku-unused-holdout-choice-20261013-v1/manifest.json",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/selection-membership.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/selection-policy.json",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/original-case-line-receipts.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/source-inputs/manifest.json",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/source-inputs/case-plans.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/source-inputs/documents.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/source-inputs/requests.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/source-inputs/row-plans.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/source-inputs/tasks.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/test-source-metadata-supplement.json",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/design/contract-origin-receipt.json",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/design/response-contract.json",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/freeze.json",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/model-pairs.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/paired-contexts.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/preparation-errors.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/source-documents.jsonl",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/summary.json",
    ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/validation-bindings.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/manifest.json",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/inputs/manifest.json",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/inputs/row-plans.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/inputs/selected-source-manifest.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/inputs/source-input-manifests.json",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/inputs/source-cases.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/inputs/source-products.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/inputs/tasks.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/nli-v2-context-protection.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/nli-v2-task-protection.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/proof-bundle/manifest.json",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/proof-bundle/proofs.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/protected-nli-contexts.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/protected-requests.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/request-proof-statuses.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/task-proof-states.jsonl",
    ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/task-source-verification.jsonl",
    ".lab-output/sku-unused-holdout-required-checks-20261013-v1/RESULTS.txt",
    ".lab-output/sku-unused-holdout-required-checks-20261013-v1/focused-tests.log",
    ".lab-output/sku-unused-holdout-required-checks-20261013-v1/required-suite.log",
    ".lab-output/sku-unused-holdout-required-checks-20261013-v1/source-test-hashes.sha256",
    ".lab-output/sku-unused-holdout-citation-test-path-fix-20261013-v1/path-fix-receipt.json",
    ".lab-output/sku-unused-holdout-postscore-diagnosis-20261013-v1/diagnosis.json",
    ".lab-output/sku-unused-holdout-postscore-diagnosis-20261013-v1/diagnosis-v2.json",
    ".lab-output/sku-unused-holdout-postscore-diagnosis-20261013-v1/diagnosis-ja.txt",
    ".lab-output/sku-unused-holdout-postscore-diagnosis-20261013-v1/diagnosis-v2-ja.txt",
    ".lab-output/sku-unused-holdout-postscore-diagnosis-20261013-v1/correction-receipt.json",
    ".lab-output/sku-full-evaluation-prepare-20261013-v1/source-index.json",
    ".lab-output/sku-final-composition-subset-20261013-v1/plan/subset-membership.jsonl",
    # Holdout and transitive source/evaluator/grader code and their focused tests.
    "experiments/sku-matching/prepare_unused_holdout_choice_nli_v1.py",
    "experiments/sku-matching/prepare_unused_holdout_literal_family_proofs_v1.py",
    "experiments/sku-matching/grade_unused_holdout_sku_gate_v1.py",
    "experiments/sku-matching/sku_directional_choice_nli_v1.py",
    "experiments/sku-matching/normalize_source_nli_citations_v1.py",
    "experiments/sku-matching/canonicalize_source_citation_table_v1.py",
    "experiments/sku-matching/source_citation_table_synthetic_original_v1.py",
    "experiments/sku-matching/evaluate_dev_source_bound_whole_sku_gate_v1.py",
    "experiments/sku-matching/prepare_dev_literal_family_proofs_v1.py",
    "experiments/sku-matching/validate_dev_literal_family_proofs_v1.py",
    "experiments/sku-matching/build_sku_literal_family_proofs_v1.py",
    "experiments/sku-matching/sku_literal_family_proof_v1.py",
    "experiments/sku-matching/claude_v9_gate/sku_gate_sources.py",
    "experiments/sku-matching/build_scoped_html_blocks_v1.py",
    "experiments/sku-matching/prepare_scoped_html_trial_v1.py",
    "experiments/sku-matching/route_mixed_sku_references_v1.py",
    "experiments/sku-matching/grade_final_test_subset_v1.py",
    "tests/test_lab_unused_holdout_choice_nli_v1.py",
    "tests/test_lab_unused_holdout_literal_family_proofs.py",
    "tests/test_lab_unused_holdout_sku_gate.py",
    "tests/test_lab_normalize_source_nli_citations_v1.py",
    "tests/test_lab_sku_source_citation_table_v1.py",
    "tests/test_lab_dev_source_bound_whole_sku_gate.py",
    "tests/test_lab_dev_literal_family_proofs.py",
    "tests/test_lab_sku_literal_family_proof.py",
    "tests/test_lab_mixed_sku_reference_router.py",
    "tests/test_lab_final_test_subset_grader.py",
    "tests/test_lab_sku_directional_choice_nli_v1.py",
    "tests/test_lab_sku_scoped_html_evidence_choice.py",
    "tests/test_lab_sku_scoped_html_blocks.py",
    "tests/test_lab_sku_scoped_html_trial_evaluation.py",
    "tests/test_lab_sku_scoped_html_preparation.py",
    "tests/test_lab_sku_scoped_html_evidence.py",
]

EXTERNAL = [
    {"name": "v2-full-reference-archive", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261011-sku-independent-real-eval-v2.zip", "sha256": "6f65d988222c79c758614592340ba28565a51fa8891317724ba354c5fc38b457", "label_members_external": True},
    {"name": "v3-full-reference-archive", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261012-sku-independent-real-eval-v3.zip", "sha256": "52f6faa51127a9c12250a3cdb5eb3d1818a36461a8c09323e481748aeed1f37b", "label_members_external": True},
    {"name": "v2-v3-label-free-source-inputs", "path": ".lab-output/sku-claude-dev-input-share-20261012-v1/20261012-sku-independent-real-eval-v2-v3-token-inputs.zip", "sha256": "db2815a3d5c726e45f996ad07e73cdcf1cdff0610de53ad84af8a4a0a880488f"},
    {"name": "prior-dev-checkpoint", "path": "experiments/sku-matching/results/20261013-sku-next-dev-checkpoint.zip", "sha256": "b585408001f7755fb6bec6cd167fec119f6ed3bbb00724b4fba91a7b4c76b19c", "commit": "1c4632985005cd1e456d67b26ca1a9977dc7b445"},
]

FORBIDDEN_PARTS = {".deps", "models", "model", "weights", "secrets", "credentials", ".venv", "venv", "labels-token", "private", "__pycache__", "answer-shards"}
FORBIDDEN_SUFFIXES = {".safetensors", ".pt", ".pth", ".ckpt", ".bin", ".env", ".pyc", ".pyo", ".zip"}


@dataclass(frozen=True)
class RawSource:
    path: Path
    archive_path: str
    sha256: str
    bytes: int
    origins: list[dict[str, Any]]


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe(rel: str) -> bool:
    p = Path(rel)
    if p.is_absolute() or ".." in p.parts:
        return False
    parts = {x.lower() for x in p.parts}
    name = p.name.lower()
    if parts & FORBIDDEN_PARTS or p.suffix.lower() in FORBIDDEN_SUFFIXES:
        return False
    if name.startswith(("answer-", "label-", "gold-")) or name in {"answers.jsonl", "labels.jsonl", "gold.jsonl", "resolved.jsonl", "label-manifest.json"}:
        return False
    return True


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    values = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"expected JSON object in {path}")
            values.append(value)
    return values


def _collect_raw_refs(files: dict[str, Path]) -> dict[str, dict[str, Any]]:
    refs: dict[str, dict[str, Any]] = {}
    for arc, path in files.items():
        if not arc.endswith((".jsonl", ".json")):
            continue
        if path.stat().st_size > 350_000_000:
            continue
        try:
            data = path.read_bytes()
        except OSError:
            continue
        lines = data.splitlines() if arc.endswith(".jsonl") else [data]
        for line_no, line in enumerate(lines, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            stack = [obj]
            while stack:
                value = stack.pop()
                if isinstance(value, dict):
                    raw = value.get("raw_file")
                    expected = value.get("sha256")
                    if isinstance(raw, str) and isinstance(expected, str) and len(expected) == 64:
                        raw = raw.replace("\\", "/")
                        entry = refs.setdefault(raw, {"sha256": expected, "origins": []})
                        if entry["sha256"] != expected:
                            entry.setdefault("conflicts", []).append({"sha256": expected, "origin": arc, "line": line_no})
                        entry["origins"].append({"file": arc, "line": line_no})
                    stack.extend(value.values())
                elif isinstance(value, list):
                    stack.extend(value)
    return refs


def gather(*, full: bool = False) -> tuple[list[tuple[Path, str]], list[RawSource], list[str]]:
    """Collect a safe source-only set, or the frozen set after a validated root GO."""
    files: dict[str, Path] = {}
    missing: list[str] = []

    def add_file(rel: str) -> None:
        path = ROOT / rel
        if path.is_file() and safe(rel) and not path.is_symlink():
            files[rel] = path
        else:
            missing.append(rel)

    for rel in FILES:
        add_file(rel)
    for rel in EXECUTION_METADATA:
        add_file(rel)
    for rel in SOURCE_TREES:
        base = ROOT / rel
        if not base.is_dir():
            missing.append(rel + "/")
            continue
        for path in base.rglob("*"):
            if path.is_file() and not path.is_symlink():
                arc = path.relative_to(ROOT).as_posix()
                if safe(arc):
                    files[arc] = path

    # Verify the original v2/v3 cases/products input pins referenced by the
    # literal-proof source manifest. The exact selected 40-case/20-product
    # wrapper inputs are already included above; do not package all-source
    # inputs because they expand raw capture coverage beyond the selected set.
    selected_manifest = ROOT / ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/inputs/selected-source-manifest.jsonl"
    if selected_manifest.is_file():
        for row in read_jsonl(selected_manifest):
            for path_key, hash_key in (("case_source_input", "case_source_sha256"), ("product_source_input", "product_source_sha256")):
                rel, expected = row.get(path_key), row.get(hash_key)
                if not isinstance(rel, str) or not isinstance(expected, str):
                    missing.append(f"bad-selected-source-manifest-entry:{path_key}")
                    continue
                source = SOURCE_ROOT / rel
                if not safe(rel) or not source.is_file() or digest(source) != expected:
                    missing.append(f"source-input-missing-or-hash-mismatch:{rel}")
                # Keep the full-source input files external. Their exact input
                # pins are retained in selected-source-manifest.jsonl and the
                # selected wrapper case/product records are packaged above.
    else:
        missing.append("selected-source-manifest-missing")

    # The source index is metadata only. Resolve only raw captures actually
    # referenced by prepared source spans and literal-family proof inputs.
    if not SOURCE_INDEX.is_file():
        missing.append("source-index-missing")
        source_index: dict[str, dict[str, Any]] = {}
    else:
        try:
            rows = json.loads(SOURCE_INDEX.read_text(encoding="utf-8"))
            source_index = {row["path"]: row for row in rows if isinstance(row, dict) and isinstance(row.get("path"), str)}
        except Exception as exc:
            missing.append(f"source-index-invalid:{type(exc).__name__}")
            source_index = {}

    # Only raw captures cited by the frozen prepared source documents and
    # literal-family proof evidence are required for replay. Raw references
    # embedded in the full source inputs are intentionally out of scope.
    raw_ref_origins = {
        ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/source-documents.jsonl",
        ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/task-source-verification.jsonl",
        ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/proof-bundle/proofs.jsonl",
    }
    raw_ref_files = {arc: path for arc, path in files.items() if arc in raw_ref_origins}
    absent_raw_ref_origins = raw_ref_origins - set(raw_ref_files)
    missing.extend(f"raw-reference-origin-missing:{rel}" for rel in sorted(absent_raw_ref_origins))
    raw_refs = _collect_raw_refs(raw_ref_files)
    raw_sources: list[RawSource] = []
    for raw_path, pin in sorted(raw_refs.items()):
        if not safe(raw_path):
            missing.append(f"raw-source-path-forbidden:{raw_path}")
            continue
        if pin.get("conflicts"):
            missing.append(f"raw-source-reference-conflict:{raw_path}")
            continue
        indexed = source_index.get(raw_path)
        if not indexed or indexed.get("sha256") != pin["sha256"] or type(indexed.get("bytes")) is not int:
            missing.append(f"raw-source-not-pinned-by-source-index:{raw_path}")
            continue
        source = SOURCE_ROOT / raw_path
        if not source.is_file() or source.is_symlink():
            missing.append(f"raw-source-missing:{raw_path}")
            continue
        size = source.stat().st_size
        actual = digest(source)
        if size != indexed["bytes"] or actual != indexed["sha256"]:
            missing.append(f"raw-source-byte-or-sha-mismatch:{raw_path}")
            continue
        raw_sources.append(RawSource(source, raw_path, actual, size, pin["origins"]))

    # This branch is only reached after the final grading freeze has been
    # validated by main(); it is intentionally skipped by default preflight.
    if full:
        for base in (EXECUTION, FREEZE_RECEIPT.parent):
            if not base.is_dir():
                missing.append(base.relative_to(ROOT).as_posix() + "/")
                continue
            for path in base.rglob("*"):
                if not path.is_file() or path.is_symlink():
                    continue
                arc = path.relative_to(ROOT).as_posix()
                if path.suffix.lower() == ".log" and arc not in FROZEN_DIAGNOSTIC_LOGS:
                    continue
                if safe(arc):
                    files[arc] = path
        for rel in (
            SCORE.relative_to(ROOT).as_posix(),
            REFERENCES.relative_to(ROOT).as_posix(),
            SCORING_RECEIPT.relative_to(ROOT).as_posix(),
            REPORT.relative_to(ROOT).as_posix(),
        ):
            add_file(rel)

    # Include this builder, its durable receipts, and source-only preflight.
    add_file(".lab-output/sku-unused-holdout-checkpoint-build-20261013-v1/package.py")
    for rel in (
        ".lab-output/sku-unused-holdout-checkpoint-build-20261013-v1/package-code-receipt.json",
        ".lab-output/sku-unused-holdout-checkpoint-build-20261013-v1/raw-source-pins.json",
    ):
        path = ROOT / rel
        if path.is_file() and not path.is_symlink() and safe(rel):
            files[rel] = path

    return [(path, arc) for arc, path in sorted(files.items())], raw_sources, missing


def write_raw_ledger(raw_sources: list[RawSource]) -> Path:
    path = BUILD / "raw-source-pins.json"
    obj = {
        "schema_version": "sku-unused-holdout-raw-source-pins-v1",
        "source_index": SOURCE_INDEX.relative_to(ROOT).as_posix(),
        "source_index_sha256": digest(SOURCE_INDEX),
        "source_tree": SOURCE_ROOT.relative_to(ROOT).as_posix(),
        "capture_scope": "exact-raw-captures-cited-by-frozen-source-documents-and-proof-evidence",
        "raw_reference_origins": [
            ".lab-output/sku-unused-holdout-choice-20261013-v1/prepared-choice-nli/source-documents.jsonl",
            ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/task-source-verification.jsonl",
            ".lab-output/sku-unused-holdout-literal-family-proofs-20261013-v1/proof-bundle/proofs.jsonl",
        ],
        "raw_captures": [
            {"path": row.archive_path, "bytes": row.bytes, "sha256": row.sha256, "origins": row.origins}
            for row in raw_sources
        ],
    }
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def verify_freeze_metadata() -> dict[str, Any]:
    if not FREEZE_RECEIPT.is_file():
        raise SystemExit(f"refusing frozen build: missing grading freeze receipt: {FREEZE_RECEIPT}")
    receipt = json.loads(FREEZE_RECEIPT.read_text(encoding="utf-8"))
    required_true = ("all_predictions_frozen", "all_gates_frozen")
    if (receipt.get("schema_version") != "sku-unused-holdout-grading-freeze-v1"
            or receipt.get("freeze_status") != "all_predictions_and_gates_frozen"
            or any(receipt.get(key) is not True for key in required_true)
            or receipt.get("source_split") != "test"
            or receipt.get("independent_test") is not True
            or receipt.get("labels_read") is not False
            or receipt.get("gold_or_references_read") is not False
            or receipt.get("membership_sha256") != MEMBERSHIP_SHA256
            or receipt.get("selection_policy_sha256") != SELECTION_POLICY_SHA256
            or receipt.get("policy_or_threshold_changed") is not False
            or receipt.get("classifier_outputs_changed_after_freeze") is not False):
        raise SystemExit("refusing frozen build: grading freeze receipt does not meet the grader contract")
    variants = receipt.get("variants")
    gates = receipt.get("gate_files")
    pins = receipt.get("frozen_files")
    required = receipt.get("required_artifact_paths")
    inputs = receipt.get("input_files")
    if not isinstance(variants, dict) or not variants or not isinstance(gates, list) or not gates:
        raise SystemExit("refusing frozen build: missing frozen variants/gates")
    if not isinstance(pins, dict) or not pins or not isinstance(required, list) or not required or not isinstance(inputs, dict):
        raise SystemExit("refusing frozen build: incomplete frozen pin inventory")
    return receipt


def verify_score_outputs() -> tuple[bool, list[str]]:
    problems: list[str] = []
    for path in (SCORE, REFERENCES, SCORING_RECEIPT, REPORT):
        if not path.is_file():
            problems.append(f"missing-score-or-report:{path.relative_to(ROOT)}")
    if problems:
        return False, problems
    score = json.loads(SCORE.read_text(encoding="utf-8"))
    completion = json.loads(SCORING_RECEIPT.read_text(encoding="utf-8"))
    if (score.get("schema_version") != "sku-unused-holdout-test-score-v1"
            or score.get("phase") != "independent_test_score"
            or score.get("source_split") != "test"
            or score.get("independent_test") is not True
            or score.get("membership_sha256") != MEMBERSHIP_SHA256
            or score.get("selection_policy_sha256") != SELECTION_POLICY_SHA256
            or score.get("selected_case_count") != 40
            or score.get("selected_product_count") != 20
            or score.get("selected_reference_count") != 40):
        problems.append("holdout-score-schema-or-cohort-mismatch")
    if (completion.get("root_go") is not True or completion.get("scoring_completed") is not True
            or completion.get("source_split") != "test" or completion.get("independent_test") is not True
            or completion.get("membership_sha256") != MEMBERSHIP_SHA256):
        problems.append("holdout-score-completion-receipt-invalid")
    frozen = completion.get("frozen_files", {})
    for path in (SCORE, REFERENCES):
        rel = path.relative_to(ROOT).as_posix()
        pin = frozen.get(rel)
        if not isinstance(pin, dict) or pin.get("bytes") != path.stat().st_size or pin.get("sha256") != digest(path):
            problems.append(f"score-output-pin-mismatch:{rel}")
    rows = read_jsonl(REFERENCES)
    ids = [row.get("case_id") for row in rows]
    if len(rows) != 40 or any(not isinstance(cid, str) for cid in ids) or len(set(ids)) != 40:
        problems.append("selected-holdout-references-not-40-unique-cases")
    report = REPORT.read_text(encoding="utf-8")
    if not ("source_split: test" in report or "独立テスト" in report or "TEST" in report):
        problems.append("final-report-does-not-identify-holdout-test-result")
    return not problems, problems


def validate_freeze_pins(receipt: dict[str, Any], files: list[tuple[Path, str]]) -> list[str]:
    actual = {arc: (path.stat().st_size, digest(path)) for path, arc in files}
    problems = []
    pins = receipt["frozen_files"]
    # A frozen test may retain its pre-discovery path. Reconcile that immutable
    # pin through the path-fix receipt and preserved byte-identical original;
    # do not edit the frozen manifest or pretend the renamed test is its copy.
    fix_rel = ".lab-output/sku-unused-holdout-citation-test-path-fix-20261013-v1/path-fix-receipt.json"
    fix_path = ROOT / fix_rel
    fix = None
    try:
        fix = json.loads(fix_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        problems.append("historical-test-path-fix-receipt-missing-or-invalid")
    if isinstance(fix, dict):
        old_path = fix.get("historical_original_path")
        preserved_path = fix.get("preserved_original_path")
        expected_hash = fix.get("historical_original_sha256")
        if (fix.get("schema_version") != "sku-citation-test-path-fix-v1"
                or fix.get("frozen_helper_changed") is not False
                or fix.get("response_or_label_data_moved") is not False
                or fix.get("model_semantics_changed") is not False
                or not isinstance(old_path, str) or not isinstance(preserved_path, str)
                or not isinstance(expected_hash, str) or len(expected_hash) != 64
                or actual.get(preserved_path, (None, None))[1] != expected_hash):
            problems.append("historical-test-path-fix-receipt-does-not-match-preserved-bytes")
        elif old_path not in actual:
            actual[old_path] = actual[preserved_path]

    for rel, pin in pins.items():
        if not safe(rel):
            problems.append(f"frozen-path-forbidden:{rel}")
            continue
        if not isinstance(pin, dict) or type(pin.get("bytes")) is not int or not isinstance(pin.get("sha256"), str):
            problems.append(f"frozen-pin-malformed:{rel}")
            continue
        if actual.get(rel) != (pin["bytes"], pin["sha256"]):
            problems.append(f"frozen-pin-not-in-checkpoint-or-mismatch:{rel}")
        if isinstance(fix, dict) and rel == fix.get("historical_original_path") and pin.get("sha256") != fix.get("historical_original_sha256"):
            problems.append(f"historical-test-pin-does-not-match-path-fix-receipt:{rel}")
    for rel in receipt.get("required_artifact_paths", []):
        if rel not in pins:
            problems.append(f"required-artifact-unpinned:{rel}")
    return problems


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--root-go", action="store_true", help="required for final frozen holdout packaging")
    parser.add_argument("--frozen-preflight", action="store_true", help="inspect the full frozen set after root GO without building ZIP")
    args = parser.parse_args()

    full = args.build or args.frozen_preflight
    if full and not args.root_go:
        raise SystemExit("refusing to inspect frozen worker/gate/score outputs without explicit --root-go")
    freeze_receipt = verify_freeze_metadata() if full else None

    BUILD.mkdir(parents=True, exist_ok=True)
    files, raw_sources, missing = gather(full=full)
    ledger = write_raw_ledger(raw_sources)
    code_receipt_path = BUILD / "package-code-receipt.json"
    code_receipt = {
        "schema_version": "sku-unused-holdout-checkpoint-package-code-receipt-v1",
        "builder": ".lab-output/sku-unused-holdout-checkpoint-build-20261013-v1/package.py",
        "builder_sha256": digest(Path(__file__)),
        "membership_sha256": MEMBERSHIP_SHA256,
        "selection_policy_sha256": SELECTION_POLICY_SHA256,
        "prior_dev_checkpoint_sha256": EXTERNAL[-1]["sha256"],
        "source_index_sha256": digest(SOURCE_INDEX),
        "source_only_preflight": not full,
        "classifier_outputs_read": bool(full),
        "label_archive_members_opened": False,
        "score_or_selected_references_opened": bool(args.build),
        "source_tree_paths": SOURCE_TREES,
        "required_scripts_and_tests": [x for x in FILES if x.startswith(("experiments/sku-matching/", "tests/"))],
    }
    code_receipt_path.write_text(json.dumps(code_receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    files, raw_sources, missing = gather(full=full)

    dependencies = []
    for dependency in EXTERNAL:
        path = ROOT / dependency["path"]
        item = dict(dependency, present=path.is_file())
        if path.is_file():
            item.update(bytes=path.stat().st_size, actual_sha256=digest(path), sha256_matches=digest(path) == dependency["sha256"])
        dependencies.append(item)
    score_valid, score_problems = verify_score_outputs() if full else (False, ["score-not-opened-before-final-build"])
    freeze_pin_problems = validate_freeze_pins(freeze_receipt, files) if full else []
    source_ready = not missing and all(item.get("sha256_matches") is True for item in dependencies)
    report = {
        "schema_version": "sku-unused-holdout-checkpoint-preflight-v1",
        "phase": "frozen_build_preflight" if full else "source_only_preflight",
        "source_only_preflight": not full,
        "classifier_outputs_or_gate_contents_opened": bool(full),
        "score_or_selected_references_opened": bool(args.build),
        "label_archives_or_contents_opened": False,
        "source_capture_pins_verified": not any("raw-source-" in item for item in missing),
        "raw_capture_count": len(raw_sources),
        "selected_file_count": len(files),
        "uncompressed_payload_bytes": sum(path.stat().st_size for path, _ in files) + sum(x.bytes for x in raw_sources),
        "missing_expected_files_or_pins": missing,
        "external_dependencies": dependencies,
        "selected_dev_checkpoint_commit": EXTERNAL[-1]["commit"],
        "freeze_receipt_path": FREEZE_RECEIPT.relative_to(ROOT).as_posix() if full else None,
        "frozen_file_pin_count": len(freeze_receipt["frozen_files"]) if full else None,
        "frozen_pin_problems": freeze_pin_problems,
        "score_problems": score_problems,
        "selected_holdout_score_ready": score_valid,
        "excluded": "full reference archives and members, model weights, secrets, .env, .deps; selected 40 references enter only after root GO",
        "source_build_ready": source_ready,
        "build_ready": bool(full and source_ready and score_valid and not freeze_pin_problems and all(item.get("sha256_matches") is True for item in dependencies)),
    }
    # Estimate compression only for the selected source/frozen files and exact
    # source captures. Default mode never gathers active classifier outputs.
    compressed = 0
    for path, _ in files:
        co = zlib.compressobj(6, zlib.DEFLATED, -15)
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                compressed += len(co.compress(block))
        compressed += len(co.flush())
    for source in raw_sources:
        co = zlib.compressobj(6, zlib.DEFLATED, -15)
        with source.path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                compressed += len(co.compress(block))
        compressed += len(co.flush())
    report["deflate_payload_estimate_bytes"] = compressed
    report["estimated_zip_bytes"] = compressed + (len(files) + len(raw_sources)) * 220 + 8000
    report["github_100mb_headroom_bytes"] = 100_000_000 - report["estimated_zip_bytes"]
    preflight_path = BUILD / "preflight.json"
    preflight_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))

    if not args.build:
        return 0
    if not report["build_ready"]:
        raise SystemExit("refusing final ZIP: frozen source pins, score/report, external archive pins, or size readiness failed")
    if OUT.exists() or SHA_PATH.exists() or OUT.with_suffix(OUT.suffix + ".manifest.json").exists():
        raise SystemExit(f"refusing overwrite of an existing holdout checkpoint or sidecar: {OUT}")

    manifest_path = OUT.with_suffix(OUT.suffix + ".manifest.json")
    members = []
    tmp_archive = OUT.with_name(OUT.name + f".partial-{os.getpid()}")
    tmp_manifest = manifest_path.with_name(manifest_path.name + f".partial-{os.getpid()}")
    tmp_sha = SHA_PATH.with_name(SHA_PATH.name + f".partial-{os.getpid()}")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(tmp_archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as target:
            for path, arc in files:
                if not safe(arc):
                    raise RuntimeError(f"unsafe checkpoint path: {arc}")
                target.write(path, arc)
                members.append({"path": arc, "bytes": path.stat().st_size, "sha256": digest(path)})
            for source in raw_sources:
                data = source.path.read_bytes()
                if len(data) != source.bytes or sha_bytes(data) != source.sha256:
                    raise RuntimeError(f"raw source changed during build: {source.archive_path}")
                target.writestr(source.archive_path, data)
                members.append({"path": source.archive_path, "bytes": source.bytes, "sha256": source.sha256,
                                "source_tree": SOURCE_ROOT.relative_to(ROOT).as_posix()})
            if len({item["path"] for item in members}) != len(members):
                raise RuntimeError("duplicate holdout checkpoint member path")
            target.writestr("CHECKPOINT_MANIFEST.json", json.dumps({**report, "members": members,
                                                                     "external_dependencies": dependencies,
                                                                     "archive": OUT.name}, indent=2, sort_keys=True) + "\n")
        with zipfile.ZipFile(tmp_archive) as archive:
            if archive.testzip() is not None:
                raise RuntimeError("ZIP CRC verification failed")
            names = archive.namelist()
            expected = {item["path"] for item in members} | {"CHECKPOINT_MANIFEST.json"}
            if len(names) != len(set(names)) or set(names) != expected:
                raise RuntimeError("ZIP member set differs from the allowlisted payload")
        if tmp_archive.stat().st_size >= 100_000_000:
            raise RuntimeError("checkpoint exceeds the 100 MB artifact limit")
        sha = digest(tmp_archive)
        with zipfile.ZipFile(tmp_archive) as archive:
            embedded = json.loads(archive.read("CHECKPOINT_MANIFEST.json"))
            for item in embedded["members"]:
                payload = archive.read(item["path"])
                if len(payload) != item["bytes"] or sha_bytes(payload) != item["sha256"]:
                    raise RuntimeError(f"member verification failed: {item['path']}")
        tmp_manifest.write_text(json.dumps({"schema_version": "sku-unused-holdout-checkpoint-archive-manifest-v1",
                                            "archive": OUT.name, "archive_bytes": tmp_archive.stat().st_size,
                                            "archive_sha256": sha, "payload_member_count": len(members),
                                            "crc_verified": True, "all_member_bytes_and_sha256_verified": True,
                                            "members": members}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        tmp_sha.write_text(f"{sha}  {OUT.name}\n", encoding="ascii")
        os.replace(tmp_archive, OUT)
        os.replace(tmp_manifest, manifest_path)
        os.replace(tmp_sha, SHA_PATH)
    except Exception:
        for path in (tmp_archive, tmp_manifest, tmp_sha):
            try:
                path.unlink()
            except FileNotFoundError:
                pass
        raise
    print(json.dumps({"archive": str(OUT), "bytes": OUT.stat().st_size, "sha256": sha,
                      "manifest": str(manifest_path), "sha256_file": str(SHA_PATH),
                      "payload_member_count": len(members), "crc_verified": True,
                      "all_member_bytes_and_sha256_verified": True}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
