#!/usr/bin/env python3
"""Metadata-only scoped-source manifest adapter; copies all source artifacts byte-for-byte."""
from __future__ import annotations
import hashlib, json, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / ".lab-output/sku-final-body-indexed-test-20261013-v1"
PREPARED = BASE / "prepared-source-v1"
OLD = BASE / "scoped-native-source-v1"
NEW = BASE / "scoped-native-source-v2"
CANDIDATE = BASE / "candidate-policy-freeze-v1.json"
RECEIPT = BASE / "scoped-source-metadata-adaptation-v1.json"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def pin(path: Path) -> dict:
    return {"bytes": path.stat().st_size, "sha256": sha(path)}


def main() -> None:
    if NEW.exists() or RECEIPT.exists():
        raise FileExistsError("metadata adapter output already exists; preserve and inspect it")
    candidate = read(CANDIDATE)
    for name, expected in candidate["source_code_and_identity_pins"].items():
        path = ROOT / name
        if not path.is_file() or pin(path) != expected:
            raise ValueError(f"frozen candidate policy pin mismatch: {name}")
    prepared = read(PREPARED / "manifest.json")
    old = read(OLD / "manifest.json")
    for name, digest in old.get("artifact_sha256", {}).items():
        path = OLD / name
        if not path.is_file() or sha(path) != digest:
            raise ValueError(f"original scoped artifact hash mismatch: {name}")
    required = {
        "identity_plan_manifest_sha256": prepared["identity_plan_manifest_sha256"],
        "selected_membership_sha256": prepared["selected_membership_sha256"],
        "raw_source_capture_inventory_sha256": prepared["raw_source_capture_inventory_sha256"],
    }
    if (prepared.get("selected_case_count") != 40 or prepared.get("selected_product_count") != 20
            or prepared.get("row_count") != 474 or prepared.get("task_count") != 1922
            or prepared.get("derived_request_count") != 1228 or prepared.get("document_count") != 40
            or old.get("prepared_pair_count") != 590 or old.get("payload_count") != 590
            or old.get("private_validation_binding_count") != 1922
            or old.get("preparation_error_count") != 0):
        raise ValueError("frozen source population differs from requested TEST metadata adaptation")
    shutil.copytree(OLD, NEW)
    new_manifest = dict(old)
    for key, value in required.items():
        new_manifest[key] = value
    (NEW / "manifest.json").write_text(json.dumps(new_manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    copied = {}
    for name, digest in old["artifact_sha256"].items():
        original, adapted = OLD / name, NEW / name
        if sha(original) != sha(adapted) or sha(adapted) != digest or original.stat().st_size != adapted.stat().st_size:
            raise ValueError(f"source artifact changed during metadata adaptation: {name}")
        copied[name] = {"bytes": adapted.stat().st_size, "sha256": sha(adapted), "byte_equal_to_v1": True}
    for name in ("model-pairs-v3.jsonl", "model-payloads-v3.jsonl", "validation-bindings.jsonl"):
        if sha(OLD / name) != sha(NEW / name):
            raise ValueError(f"pair, payload, or binding bytes differ: {name}")
    receipt = {
        "schema_version": "sku-final-body-indexed-test-scoped-source-metadata-adaptation-v1",
        "status": "metadata_only_provenance_fields_added_source_bytes_preserved",
        "candidate_policy_freeze_sha256": sha(CANDIDATE),
        "candidate_policy_pin_count": len(candidate["source_code_and_identity_pins"]),
        "prepared_manifest_sha256": sha(PREPARED / "manifest.json"),
        "original_scoped_manifest_sha256": sha(OLD / "manifest.json"),
        "adapted_scoped_manifest_sha256": sha(NEW / "manifest.json"),
        "metadata_fields_added": required,
        "source_artifact_count": len(copied), "source_artifacts": copied,
        "private_binding_count": old["private_validation_binding_count"],
        "pair_count": old["prepared_pair_count"], "payload_count": old["payload_count"],
        "labels_read": False, "predictions_read": False, "model_inference_run": False,
        "scores_created": False, "semantic_content_changed": False,
        "production_adoption_allowed": False,
    }
    receipt["receipt_sha256"] = hashlib.sha256(json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    RECEIPT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": receipt["status"], "artifact_count": len(copied),
        "pair_count": 590, "payload_count": 590, "binding_count": 1922,
        "labels_read": False, "model_inference_run": False}, sort_keys=True))


if __name__ == "__main__":
    main()
