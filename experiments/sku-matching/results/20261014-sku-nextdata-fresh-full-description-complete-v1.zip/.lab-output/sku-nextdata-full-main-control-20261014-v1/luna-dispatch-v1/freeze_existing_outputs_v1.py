#!/usr/bin/env python3
"""Audit assignment/byte metadata and create an exclusive final freeze. No grading."""
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path

B = Path(__file__).resolve().parent
N = B.parent
EXPECTED = {
    N / 'root-model-go-v1.json': '8d858de438ef8506542f8494602274b2ea6ea014c94a5ee79c211f7ac93de0e5',
    N / 'root-execution-code-go-v1.json': 'aabd00aea80b8494e810c522c362c0e8f32df519935521ef25da0eea643bfde8',
    N / 'root-short-alias-go-v1.json': 'c914ad78c05f26c20cb4126ef3f974a82d1cf28d42a71bfd61478cc2c6baa4d5',
    N / 'prepared-v1/input-freeze.json': 'c2328ef6fa16e5f8c10a5520764df7d97986db6f693eb23e568a0ebeb25bd65a',
    N / 'prepared-v1/packets/full/index.json': 'ff4d8d55d5f61236edab733a886afe5611363a6296e2479c7576532dddcc3009',
    N / 'prepared-v1/existing-full-reuse-manifest.json': 'd92d0f4df24edf5d1a771edc377bbab9cf4fdcbb3fa7af99d176fc2e44872bda',
    N / 'public-original-main172-pair-refs.json': 'd3dde414397eda9e269d4e3311e811a5750844448304ca1ed3930782ca6a9bcd',
    N / 'public-original-main172-closure-receipt.json': 'ae6956175860d4a3dc33d9978c3096f5113fe4ec351e28eafb232cdaf67cb2fa',
    N / 'collect_full_control_v1.py': 'bb4cd2a8c76ce18dcc933870e7ef8c27805ab499aad3de6ed8cab9609550fde3',
    N / 'preparation-supplement-root-collector-fix-v1.json': 'f43045cef65b64e8f2e53ff04543805a21bbe04b1201e0aa27360c94459fb92a',
    B / 'write_first_jsonl_v1.py': '87a596e117dde57cb79279f65a38106264de3e9e772ebf495ceb97de8aecf4e6',
    B / 'worker-transport-instructions-v1.txt': '6af4480b12e61008dd96b44291927f0785365e989429096ed46e5f3811413d85',
    B / 'worker-transport-instructions-v2.txt': '714092c75724f75667b033a95ce45b66c4d996dd63e2da90a4bc53513831fa6a',
}


def read(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        h = hashlib.sha256()
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def pin(path):
    path = path.resolve()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def verify_pin(entry):
    path = Path(entry['path'])
    assert path.stat().st_size == entry['bytes'], str(path)
    assert digest(path) == entry['sha256'], str(path)


def verify_original(path, observed):
    assert path.is_file() == observed['exists'], str(path)
    if observed['exists']:
        assert path.stat().st_size == observed['bytes'], str(path)
        assert digest(path) == observed['sha256'], str(path)


def main():
    state = read(B / 'state.json')
    queue = read(B / 'dispatch-queue.json')
    allowed = set(state['input_freeze']['allowed_packet_keys'])
    assert state['status'] == 'complete' and state['active'] == []
    assert len(allowed) == 166
    assert set(state['assignments']) == set(state['terminal']) == allowed
    assert len(state['terminal']) == len(set(state['terminal'])) == 166
    assert [x['packet_key'] for x in queue] == state['dispatch_order']
    events = [json.loads(x) for x in (B / 'events.jsonl').read_text().splitlines()]
    event_counts = Counter(e['event'] for e in events)
    for event in ('predispatch', 'actual_spawn_response', 'worker_terminal'):
        assert event_counts[event] == 166
        assert len({e['packet_key'] for e in events if e['event'] == event}) == 166
    for path, expected in EXPECTED.items():
        assert digest(path) == expected, str(path)
    input_pins = [pin(path) for path in EXPECTED]
    prepared = read(N / 'prepared-v1/input-freeze.json')
    for group in ('files', 'dependencies'):
        for entry in prepared[group].values():
            verify_pin(entry)
    execution_go = read(N / 'root-execution-code-go-v1.json')
    for field in ('final_collector', 'preparation_supplement', 'input_freeze', 'root_model_go'):
        verify_pin(execution_go[field])
    aliases = {
        '/workspace/sku_full_write.py': B / 'write_first_jsonl_v1.py',
        '/workspace/sku_full_packets': N / 'prepared-v1/packets/full',
        '/workspace/sku_full_worker.txt': B / 'worker-transport-instructions-v2.txt',
        '/workspace/sku_full_drafts': B / 'drafts/full',
    }
    for alias, target in aliases.items():
        assert Path(alias).is_symlink() and Path(alias).resolve() == target.resolve()
    reuse = read(N / 'prepared-v1/existing-full-reuse-manifest.json')
    old_freeze_pin = reuse['old_all194_output_freeze']
    verify_pin(old_freeze_pin)
    old_freeze = read(Path(old_freeze_pin['path']))
    # These are the original coordinator's own raw output and provenance files.
    # Hashing verifies bytes without reading labels or interpreting decisions.
    for entry in old_freeze['files']:
        verify_pin(entry)
    for entry in old_freeze['assignments']:
        verify_original(Path(entry['output_path']), entry['original_output'])
    for item in reuse['existing_firstpasses']:
        verify_original(Path(item['original_output_path']), item['original_output'])
    main_refs = read(N / 'public-original-main172-pair-refs.json')
    assert len(main_refs) == len(set(main_refs)) == 172
    assert set(reuse['main_refs']) == set(main_refs)
    assert reuse['reuse_refs'] == [426, 431, 551, 1144, 1397]
    assert len(reuse['new_refs']) == len(set(reuse['new_refs'])) == 167
    assert not set(reuse['reuse_refs']) & set(reuse['new_refs'])
    assert set(reuse['reuse_refs']) | set(reuse['new_refs']) == set(main_refs)
    index = read(N / 'prepared-v1/packets/full/index.json')
    assert len(index['packets']) == 166
    indexed_refs = [ref for p in index['packets'] for ref in p['pair_refs']]
    assert len(indexed_refs) == len(set(indexed_refs)) == 167
    assert set(indexed_refs) == set(reuse['new_refs'])
    files, assignments, issues = [], [], []
    seen_outputs, seen_agents = set(), set()
    for planned in queue:
        key = planned['packet_key']
        a = state['assignments'][key]
        assert a['status'] == 'terminal'
        assert a['requested_model'] == 'gpt-6-luna' and a['fork_turns'] == 'none'
        assert a['actual_spawn_tool_response'] == {'task_name': a['agent_name']}
        assert a['agent_name'] not in seen_agents and a['output_path'] not in seen_outputs
        seen_agents.add(a['agent_name'])
        seen_outputs.add(a['output_path'])
        assert a['output_absent_before_spawn'] is True
        assert a['pair_refs'] == planned['pair_refs']
        assert digest(Path(a['packet_path'])) == a['packet_sha256'] == planned['packet_sha256']
        assert a['transport_writer_sha256'] == EXPECTED[B / 'write_first_jsonl_v1.py']
        expected_wrapper = B / ('worker-transport-instructions-v1.txt' if int(key[-3:]) <= 25
                                else 'worker-transport-instructions-v2.txt')
        assert a['transport_wrapper_sha256'] == EXPECTED[expected_wrapper]
        output = Path(a['output_path'])
        observed = a['original_output']
        verify_original(output, observed)
        if observed['exists']:
            files.append(pin(output))
            if not observed['jsonl_syntax_valid']:
                issues.append({'packet_key': key, 'kind': 'original_jsonl_syntax_invalid',
                               'error': observed.get('syntax_error'), 'preserved_unchanged': True})
            if not observed['ends_with_lf']:
                issues.append({'packet_key': key, 'kind': 'original_final_physical_lf_absent',
                               'preserved_unchanged': True})
        else:
            issues.append({'packet_key': key, 'kind': 'original_draft_missing', 'redispatched': False})
        raw = output.with_suffix('.authored-input.raw')
        framing = B / 'receipts' / (key + '-first-framing.json')
        assert raw.exists() == framing.exists() == output.exists(), key
        writer_audit = {'raw_exists': raw.exists(), 'framing_receipt_exists': framing.exists()}
        if output.exists():
            r = read(framing)
            raw_bytes = raw.read_bytes()
            assert r['physical_trailing_lf_added'] == (not raw_bytes.endswith(bytes([10])))
            framed = raw_bytes + (bytes([10]) if r['physical_trailing_lf_added'] else b'')
            assert framed == output.read_bytes()
            assert r['raw_sha256'] == digest(raw) and r['output_sha256'] == digest(output)
            assert r['raw_bytes'] == len(raw_bytes) and r['output_bytes'] == len(framed)
            assert r['helper_sha256'] == a['transport_writer_sha256']
            assert r['json_parsed_or_fixed'] is False and r['semantic_bytes_modified'] is False
            files.append(pin(raw))
            writer_audit.update(raw_sha256=digest(raw), framed_sha256=digest(output),
                                physical_trailing_lf_added=r['physical_trailing_lf_added'],
                                raw_and_framed_match_first_writer_receipt=True)
        assignments.append({k: a[k] for k in ('packet_key', 'variant', 'pair_refs', 'agent_name',
                           'output_path', 'packet_sha256', 'original_output', 'predispatch_at_utc',
                           'spawn_observed_at_utc', 'terminal_observed_at_utc', 'requested_model',
                           'fork_turns', 'transport_wrapper_sha256', 'transport_writer_sha256')}
                           | {'writer_audit': writer_audit})
    assert sum(len(a['pair_refs']) for a in assignments) == 167
    assert set(ref for a in assignments for ref in a['pair_refs']) == set(reuse['new_refs'])
    expected_draft_files = {Path(a['output_path']).name for a in assignments if a['original_output']['exists']}
    expected_draft_files |= {Path(a['output_path']).with_suffix('.authored-input.raw').name
                            for a in assignments if a['original_output']['exists']}
    assert {p.name for p in (B / 'drafts/full').iterdir() if p.is_file()} == expected_draft_files
    files.extend(pin(path) for path in sorted((B / 'receipts').glob('*.json')))
    for path in (B / 'state.json', B / 'events.jsonl', B / 'dispatch-queue.json',
                 B / 'write_first_jsonl_v1.py', B / 'worker-transport-instructions-v1.txt',
                 B / 'worker-transport-instructions-v2.txt', B / 'supervisor_io.py',
                 B / 'bookkeeping.py', Path(__file__)):
        files.append(pin(path))
    first = min(a['spawn_observed_at_utc'] for a in assignments)
    last = max(a['terminal_observed_at_utc'] for a in assignments)
    seconds = (datetime.datetime.fromisoformat(last) - datetime.datetime.fromisoformat(first)).total_seconds()
    receipt = {
        'schema': 'fresh-full-main166-original-output-freeze-v1',
        'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'all_assigned_jobs_terminal_original_bytes_verified',
        'variant': 'full', 'cohort': 'original_label_blind_main108_fresh_full_control',
        'packet_count': 166, 'new_pair_count': 167, 'reuse_pair_count': 5, 'closure_pair_count': 172,
        'closure_new_reuse_disjoint_and_complete': True,
        'old_all194_original_bytes_and_provenance_unchanged': True,
        'old_all194_output_freeze': old_freeze_pin,
        'existing_full_reuse_manifest': pin(N / 'prepared-v1/existing-full-reuse-manifest.json'),
        'actual_spawn_tool_response_count': event_counts['actual_spawn_response'],
        'terminal_event_count': event_counts['worker_terminal'], 'active': [],
        'original_output_present': sum(a['original_output']['exists'] for a in assignments),
        'original_output_missing': sum(not a['original_output']['exists'] for a in assignments),
        'original_jsonl_syntax_invalid': sum(a['original_output']['exists'] and not a['original_output']['jsonl_syntax_valid'] for a in assignments),
        'byte_preserving_writer_assigned': 166,
        'byte_preserving_writer_original_raw_present': sum(a['writer_audit']['raw_exists'] for a in assignments),
        'first_spawn_observed_at_utc': first, 'last_terminal_observed_at_utc': last,
        'observed_hosted_dispatch_wall_seconds': seconds, 'is_local_gpu_or_cpu_weights_benchmark': False,
        'input_freeze_sha256': EXPECTED[N / 'prepared-v1/input-freeze.json'],
        'root_go_sha256': EXPECTED[N / 'root-model-go-v1.json'],
        'input_pins': input_pins, 'files': files, 'assignments': assignments, 'protocol_issues': issues,
        'runtime_path_correction_packet': 'full-021',
        'runtime_path_correction_before_first_write_order_independently_proven': False,
        'rejected_spawn_call_without_returned_thread_packet': 'full-004',
        'no_semantic_redispatch_or_original_output_repair': True,
        'classifier_semantic_review_performed_by_supervisor': False,
        'requested_model': 'gpt-6-luna', 'fork_turns': 'none',
        'model_selector_is_not_weights_attestation': True,
        'complete_worker_tool_histories_independently_available': False,
        'no_private_selection_bindings_or_grades_read_from_files': True,
        'final_integrity_audit_is_not_semantic_truth_validation': True,
    }
    dest = B / 'receipts/all166-original-output-freeze-v1.json'
    with dest.open('x', encoding='utf-8') as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write(chr(10))
    print(json.dumps({k: receipt[k] for k in ('packet_count', 'new_pair_count', 'reuse_pair_count',
                     'closure_pair_count', 'original_output_present', 'original_output_missing',
                     'original_jsonl_syntax_invalid', 'observed_hosted_dispatch_wall_seconds')}
                     | pin(dest) | {'protocol_issues': issues}, ensure_ascii=False))


if __name__ == '__main__':
    main()
