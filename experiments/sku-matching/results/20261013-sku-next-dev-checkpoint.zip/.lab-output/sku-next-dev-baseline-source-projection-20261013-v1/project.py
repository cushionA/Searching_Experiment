#!/usr/bin/env python3
"""Source-only fresh baseline projection through the unchanged quote resolver."""
from __future__ import annotations
import hashlib, json
from collections import Counter
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "experiments/sku-matching"))
import integrate_claude_description_v1 as GATE
INPUT = ROOT / ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8"
BASE = ROOT / ".lab-output/sku-next-dev-fresh-baseline-20261013-v1/model-run/model-run"
OUT = HERE

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
def rows(path): return [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
def idx(rs,k):
    d={}
    for r in rs:
        if r[k] in d: raise ValueError('duplicate '+k)
        d[r[k]]=r
    return d
requests=idx(rows(INPUT/'requests.jsonl'),'request_id')
documents=idx(rows(INPUT/'documents.jsonl'),'document_id')
predictions=idx(rows(BASE/'fusion-predictions.jsonl'),'request_id')
if set(requests)!=set(predictions): raise ValueError('baseline does not cover exact request set')
projected=[]; reasons=Counter(); raw_states=Counter(); out_states=Counter(); alternate=0; citations=0
for rid,req in requests.items():
    pred=predictions[rid]
    state,reason,quotes=GATE.resolve_prediction(pred,req,documents)
    raw_states[str(pred.get('state'))]+=1
    winner=pred.get('winning_value')
    if winner is not None and winner != req['selected_value']: alternate+=1
    verified=bool(quotes)
    if verified: citations+=1
    if state in {'support','conflict'} and not verified: raise ValueError('resolver returned decisive state without verified quotes')
    out_states[state]+=1; reasons[reason]+=1
    projected.append({'request_id':rid,'state':state,
      'winning_value': (winner if state=='support' else None),
      'source':'fresh_baseline_quote_resolver','reason':reason,
      'source_citations_verified':verified,
      'verified_quote_refs':quotes,
      'production_adoption_allowed':False})
with (OUT/'request-states.jsonl').open('x',encoding='utf-8') as f:
    for r in projected: f.write(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
used=[INPUT/'requests.jsonl',INPUT/'documents.jsonl',INPUT/'manifest.json',BASE/'fusion-predictions.jsonl']
manifest={'schema_version':'dev-baseline-source-projection-v1','phase':'source_only_projection',
 'request_count':len(projected),'state_counts':dict(out_states),'resolver_reason_counts':dict(reasons),
 'raw_baseline_state_counts':dict(raw_states),'resolver_verified_citation_count':citations,
 'raw_alternate_winner_count':alternate,'unknown_fallback_count':out_states['unknown'],
 'unknown_fallback_reasons':{k:v for k,v in reasons.items() if k not in {'experimental_quoted_model_support','experimental_quoted_model_conflict'}},
 'resolver':'experiments/sku-matching/integrate_claude_description_v1.py:resolve_prediction',
 'resolver_sha256':sha(ROOT/'experiments/sku-matching/integrate_claude_description_v1.py'),
 'projector_sha256':sha(Path(__file__)),
 'input_sha256':{str(p.relative_to(ROOT)):sha(p) for p in used},
 'output_sha256':sha(OUT/'request-states.jsonl'),
 'labels_read':False,'scores_created':False,'gold_read':False,'semantic_truth_verified':False,
 'thresholds_changed':False,'production_adoption_allowed':False}
with (OUT/'manifest.json').open('x',encoding='utf-8') as f: json.dump(manifest,f,ensure_ascii=False,indent=2); f.write('\n')
print(json.dumps({k:manifest[k] for k in ('request_count','state_counts','resolver_reason_counts','raw_alternate_winner_count','unknown_fallback_count','unknown_fallback_reasons','resolver_sha256','projector_sha256','output_sha256')},ensure_ascii=False,indent=2))
