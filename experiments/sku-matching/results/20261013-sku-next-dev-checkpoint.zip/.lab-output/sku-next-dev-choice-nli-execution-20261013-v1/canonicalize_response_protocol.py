#!/usr/bin/env python3
"""Preserve semantic responses; map exact response schema alias to packet protocol."""
from pathlib import Path
from collections import Counter
import copy
import hashlib
import json
import sys
import datetime

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import normalize_source_nli_citations_v1 as N

def pin(p):return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def write(p,data):
    with p.open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
def rwrite(p,data):
    with p.open('x') as f:
        for x in data:f.write(N.canonical(x).decode()+'\n')
def main():
    prepared=ROOT/'.lab-output/sku-next-dev-choice-nli-20261013-v2'
    contract=json.loads((prepared/'design/response-contract.json').read_text())
    assert contract['schema_version']==N.PROTOCOL+'/response'
    original=json.loads((HERE/'experiment-freeze.json').read_text())
    dispatched={}
    for i in range(4):
        a=json.loads((HERE/f'worker-inputs/worker-{i}-assignment.json').read_text())
        for filename in a['batch_files']:
            path=ROOT/filename;assert pin(path)==original['frozen_files'][filename]
            for payload in json.loads(path.read_text())['payloads']:
                dispatched[payload['pair_id']]=payload
    assert len(dispatched)==238
    source=HERE/'citation-normalization-v1/normalized-responses.jsonl'
    responses=N.read_rows(source)
    out=HERE/'protocol-canonicalization-v1';out.mkdir()
    changes=[];updated=[]
    for row in responses:
        packet=dispatched[row['pair_id']]
        assert row['cache_key']==packet['cache_key'] and packet['protocol']==N.PROTOCOL
        item=copy.deepcopy(row)
        if item['protocol']==contract['schema_version']:
            # Only an exact contract-schema alias, with a unique frozen actual dispatch.
            item['protocol']=packet['protocol']
            changes.append({'pair_id':row['pair_id'],'previous_protocol':row['protocol'],'canonical_protocol':item['protocol']})
        before=copy.deepcopy(row);after=copy.deepcopy(item);before.pop('protocol');after.pop('protocol')
        assert N.canonical(before)==N.canonical(after)
        updated.append(item)
    rwrite(out/'canonical-responses.jsonl',updated);rwrite(out/'protocol-changes.jsonl',changes)
    receipt={'schema_version':'sku-response-protocol-identifier-canonicalization-v1','root_go':True,
             'created_at_utc':datetime.datetime.now(datetime.UTC).isoformat(),'labels_read':False,'source_split':'dev',
             'independent_test':False,'inference_run':False,'changed_response_count':len(changes),
             'semantic_fields_changed':False,'quotes_or_offsets_changed':False,'source_ids_or_cache_keys_changed':False,
             'original_responses_overwritten':False,'only_changed_field':'protocol',
             'exact_alias_origin':'Frozen response-contract schema_version, not an inferred or newer classifier revision',
             'actual_dispatch_payloads_and_pair_cache_verified':True,
             'first_validation_preserved':'source-validation-v1/validation-receipt.json',
             'first_gate_run_preserved_unscored':'.lab-output/sku-next-dev-v7-adapter-20261013-v1/final-gate-run',
             'frozen_files':{str(p.relative_to(ROOT)):pin(p) for p in [Path(__file__),source,out/'canonical-responses.jsonl',out/'protocol-changes.jsonl',prepared/'design/response-contract.json',HERE/'experiment-freeze.json']}}
    write(out/'canonicalization-receipt.json',receipt)
    # Frozen v2 state/scope/whole-option/citation validator remains unchanged.
    vdir=HERE/'source-validation-v2';vdir.mkdir();valid=[];statuses=[]
    for i,row in enumerate(updated):
        try:
            v=N.validate_normalized_response(prepared,row);valid.append(v)
            statuses.append({'pair_id':row['pair_id'],'status':'source_metadata_valid','judgment_count':v['judgment_count'],'semantic_truth_verified':False})
        except (KeyError,TypeError,ValueError,OSError) as exc:
            statuses.append({'pair_id':row['pair_id'],'status':'invalid_unknown','error':str(exc),'semantic_retry_performed':False})
        if (i+1)%40==0:print(json.dumps({'checked':i+1,'valid':len(valid)}),flush=True)
    rwrite(vdir/'validated-pairs.jsonl',valid);rwrite(vdir/'validation-statuses.jsonl',statuses)
    receipt2={'schema_version':'sku-choice-nli-source-validation-completion-v2','source_split':'dev','labels_read':False,
              'independent_test':False,'response_count':len(updated),'status_counts':dict(Counter(x['status'] for x in statuses)),
              'invalid_error_counts':dict(Counter(x['error'] for x in statuses if 'error' in x)),
              'semantic_truth_verified':False,'production_adoption_allowed':False,
              'frozen_files':{str(p.relative_to(ROOT)):pin(p) for p in [out/'canonical-responses.jsonl',out/'canonicalization-receipt.json',vdir/'validated-pairs.jsonl',vdir/'validation-statuses.jsonl',ROOT/'experiments/sku-matching/sku_directional_choice_nli_v1.py',ROOT/'experiments/sku-matching/normalize_source_nli_citations_v1.py']}}
    write(vdir/'validation-receipt.json',receipt2)
    print(json.dumps({k:receipt2[k] for k in ('response_count','status_counts','invalid_error_counts')}),flush=True)

if __name__=='__main__':main()
