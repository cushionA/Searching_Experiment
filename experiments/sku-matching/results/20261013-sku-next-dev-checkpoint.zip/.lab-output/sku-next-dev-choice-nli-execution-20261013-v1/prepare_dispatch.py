from __future__ import annotations
import datetime
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PREPARED = ROOT / '.lab-output/sku-next-dev-choice-nli-20261013-v2'
PROOFS = ROOT / '.lab-output/sku-next-dev-literal-family-proofs-20261013-v1'
SOURCE = ROOT / '.lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8'
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
import sku_directional_choice_nli_v1 as NLI

def canonical(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()

def pin(p):
    return {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size}

def write(path, value):
    with path.open('xb') as f:
        f.write(canonical(value) + b'\n')

def run():
    for name in ('worker-inputs', 'worker-responses'):
        directory = HERE / name
        if directory.exists() and any(directory.iterdir()):
            raise FileExistsError(directory)
        directory.mkdir(exist_ok=True)
    freeze, pairs, _contexts, _docs, bindings = NLI._load_prepared(PREPARED)
    if freeze['builder_sha256'] != pin(Path(NLI.__file__))['sha256']:
        raise ValueError('Current NLI code does not match reviewed preparation freeze')
    statuses = {r['request_id']: r for r in NLI.read_rows(PROOFS / 'request-proof-statuses.jsonl')}
    original_requests = {r['request_id']: r for r in NLI.read_rows(SOURCE / 'requests.jsonl')}
    if set(statuses) != set(original_requests):
        raise ValueError('Proof request coverage differs from original source')
    skipped, selected = [], []
    for pair_id in sorted(pairs):
        bound = bindings[pair_id]
        states = []
        for b in bound:
            rid = b['task_binding']['request_id']
            status, req = statuses[rid], original_requests[rid]
            if status['request_sha256'] != req['request_sha256']:
                raise ValueError('Proof and original request identity disagree')
            states.append(status.get('eligible') is True and status.get('status') in ('support', 'conflict'))
        if states and all(states):
            skipped.append(pair_id)
        else:
            selected.append(pair_id)
    if (len(pairs), len(skipped), len(selected)) != (543, 305, 238):
        raise ValueError('Reviewed source-only dispatch counts changed')
    payloads = NLI.build_model_payloads(PREPARED, selected)
    if isinstance(payloads, dict):
        payloads = [payloads[p] for p in selected]
    by_id = {p['pair_id']: p for p in payloads}
    if set(by_id) != set(selected):
        raise ValueError('Model payload set differs from exact selected set')
    assignments = [[] for _ in range(4)]
    totals = [0] * 4
    for pair_id in sorted(selected, key=lambda p: (-len(canonical(by_id[p])), p)):
        worker = min(range(4), key=lambda i: (totals[i], len(assignments[i]), i))
        assignments[worker].append(by_id[pair_id])
        totals[worker] += len(canonical(by_id[pair_id]))
    worker_files = []
    for worker, units in enumerate(assignments):
        batch_files, batch = [], []
        for unit in units:
            if batch and len(canonical({'payloads': batch + [unit]})) > 100_000:
                path = HERE / 'worker-inputs' / f'worker-{worker}-batch-{len(batch_files):03d}.json'
                write(path, {'payloads': batch})
                batch_files.append(path.relative_to(ROOT).as_posix())
                batch = []
            batch.append(unit)
        if batch:
            path = HERE / 'worker-inputs' / f'worker-{worker}-batch-{len(batch_files):03d}.json'
            write(path, {'payloads': batch})
            batch_files.append(path.relative_to(ROOT).as_posix())
        path = HERE / 'worker-inputs' / f'worker-{worker}-assignment.json'
        write(path, {'worker': worker, 'model': 'gpt-6-luna', 'fork_turns': 'none',
                     'pair_ids': [p['pair_id'] for p in units], 'pair_count': len(units),
                     'batch_files': batch_files,
                     'output_path': (HERE / 'worker-responses' / f'worker-{worker}.jsonl').relative_to(ROOT).as_posix(),
                     'protocol_file': (PREPARED / 'design/response-contract.json').relative_to(ROOT).as_posix(),
                     'actual_model_inference_required': True, 'source_only': True,
                     'body_or_full_option_truncation_forbidden': True,
                     'semantic_retry_after_answer_persistence_forbidden': True})
        worker_files.append(path)
    pins = {p.relative_to(ROOT).as_posix(): pin(p) for p in HERE.joinpath('worker-inputs').glob('*.json')}
    inputs = [Path(NLI.__file__), ROOT / 'tests/test_lab_sku_directional_choice_nli_v1.py',
              HERE / 'prepare_dispatch.py', SOURCE / 'manifest.json', SOURCE / 'membership.jsonl',
              PROOFS / 'manifest.json', PREPARED / 'freeze.json', PREPARED / 'design/response-contract.json',
              ROOT / '.lab-output/sku-next-dev-fresh-baseline-20261013-v1/model-run/runtime-source-freeze.json']
    inputs += [PREPARED / n for n in freeze['output_sha256']]
    inputs += [PROOFS / n for n in ('request-proof-statuses.jsonl', 'task-proof-states.jsonl',
                                  'task-source-verification.jsonl', 'proof-bundle/manifest.json',
                                  'proof-bundle/proofs.jsonl')]
    for p in inputs:
        if not p.is_file():
            raise FileNotFoundError(p)
        pins[p.relative_to(ROOT).as_posix()] = pin(p)
    write(HERE / 'experiment-freeze.json', {
        'schema_version': 'sku-next-dev-choice-nli-root-freeze-v1',
        'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_split': 'dev', 'independent_test': False, 'labels_read': False,
        'membership_sha256': 'ab90d19dc4065be564acb8fe7d57d966d9c82f8018b1482de515083ab39f3a58',
        'case_count': 40, 'product_count': 20, 'row_count': 504, 'task_count': 1924,
        'request_count': 1045, 'prepared_context_count': 543,
        'literal_protected_context_count': 305, 'dispatch_context_count': 238,
        'dispatched_whole_option_count': sum(len(p['candidate_vector']) for p in payloads),
        'worker_counts': [len(a) for a in assignments], 'worker_payload_bytes': totals,
        'model': 'gpt-6-luna', 'hosted_weight_revision_verified': False,
        'primary_policy': 'explicit-choice-nli-experimental',
        'comparison_policy': 'baseline-literal-overlay',
        'projection': 'verified unanimous exact literal states take precedence; otherwise source-validated direct per-whole-option NLI states, support/explicit_conflict/unknown, projected to hidden task raw value; every bound task required',
        'semantic_nli_evidence_is_not_source_proof': True,
        'same_axis_name_required_for_literal_proof_only': True,
        'model_same_condition_scope_and_valid_target_axis_value_and_whole_option_citations_required': True,
        'alternate_winner_or_raw_inequality_is_not_conflict': True,
        'gate_contract': 'same AU row all original conditions; exactly one support row; every competing original row explicit conflict; unknown never conflict',
        'all_au_rows_and_sold_out_rows_retained': True,
        'v7_hints_or_decisions_used_as_gate_proof': False,
        'old_baseline_support_fallback_or_prior_accept_guard': False,
        'selected_source_wanted_value_visible_to_classifier': False,
        'any_choice_nli_inference_started': False,
        'cpu_baseline_inference_started_before_root_classification_freeze': True,
        'baseline_has_its_own_pre_inference_freeze': True,
        'production_adoption_allowed': False,
        'frozen_files': pins,
    })
    print(json.dumps({'selected': len(selected), 'skipped': len(skipped),
                      'worker_counts': [len(a) for a in assignments],
                      'payload_bytes': sum(totals)}, ensure_ascii=False))

def finalize_existing_transport():
    # The previous attempt finished all immutable model batches/assignments, then
    # stopped at a wrapper freeze-path mismatch. Rebind existing transport bytes;
    # do not rebuild, overwrite, filter, or change any model payload.
    assignments = [json.loads((HERE / 'worker-inputs' / f'worker-{i}-assignment.json').read_text()) for i in range(4)]
    payloads = []
    for assignment in assignments:
        local = []
        for rel in assignment['batch_files']:
            values = json.loads((ROOT / rel).read_text())['payloads']
            local.extend(values)
        if [p['pair_id'] for p in local] != assignment['pair_ids']:
            raise ValueError('Existing transport assignment set differs from batches')
        payloads.extend(local)
    if len(payloads) != 238 or len({p['pair_id'] for p in payloads}) != 238:
        raise ValueError('Existing transport membership is incomplete or duplicated')
    expected = NLI.build_model_payloads(PREPARED, [p['pair_id'] for p in payloads])
    if not isinstance(expected, dict):
        expected = {p['pair_id']: p for p in expected}
    if any(canonical(p) != canonical(expected[p['pair_id']]) for p in payloads):
        raise ValueError('Existing transport bytes differ from canonical reviewed source payload')
    # Execute only the freeze-writing tail of the reviewed preparation function.
    # It retains the exact policy/inputs; assignment generation is deliberately skipped.
    source = Path(__file__).read_text()
    tail = source.split('    pins = {p.relative_to(ROOT).as_posix(): pin(p) for p in HERE.joinpath', 1)[1]
    tail = '    pins = {p.relative_to(ROOT).as_posix(): pin(p) for p in HERE.joinpath' + tail.split('\ndef finalize_existing_transport', 1)[0]
    namespace = dict(globals())
    namespace.update({'assignments': [[None] * a['pair_count'] for a in assignments],
                      'totals': [sum(len(canonical(p)) for p in payloads if p['pair_id'] in set(a['pair_ids'])) for a in assignments],
                      'payloads': payloads, 'selected': list(expected), 'skipped': [None] * 305,
                      'freeze': json.loads((PREPARED / 'freeze.json').read_text())})
    exec('def _freeze_tail():\n' + tail, namespace)
    namespace['_freeze_tail']()

if __name__ == '__main__':
    if '--finalize-existing-transport' in sys.argv:
        finalize_existing_transport()
    else:
        run()
