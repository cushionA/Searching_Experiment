#!/usr/bin/env python3
"""One-time fail-closed source validation; no semantic retry or label access."""
from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
import normalize_source_nli_citations_v1 as NORMALIZE

def pin(p):
    return {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size}

def write_rows(p, rows):
    with p.open('x', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(',', ':'))+'\n')

def main():
    prepared = ROOT / '.lab-output/sku-next-dev-choice-nli-20261013-v2'
    source = HERE / 'citation-normalization-v1/normalized-responses.jsonl'
    responses = NORMALIZE.read_rows(source)
    assignment_ids = set()
    for i in range(4):
        a = json.loads((HERE / f'worker-inputs/worker-{i}-assignment.json').read_text())
        assignment_ids.update(a['pair_ids'])
    assert len(responses) == len({r['pair_id'] for r in responses}) == len(assignment_ids) == 238
    assert {r['pair_id'] for r in responses} == assignment_ids
    out = HERE / 'source-validation-v1'
    out.mkdir()
    statuses, valid = [], []
    for i, response in enumerate(responses):
        try:
            v = NORMALIZE.validate_normalized_response(prepared, response)
            valid.append(v)
            statuses.append({'pair_id':response['pair_id'], 'status':'source_metadata_valid',
                             'judgment_count':v['judgment_count'], 'semantic_truth_verified':False})
        except (KeyError, TypeError, ValueError, OSError) as exc:
            statuses.append({'pair_id':response['pair_id'], 'status':'invalid_unknown', 'error':str(exc),
                             'semantic_response_changed':False, 'semantic_retry_performed':False})
        if (i+1) % 40 == 0:
            print(json.dumps({'checked':i+1, 'valid':len(valid)}), flush=True)
    write_rows(out/'validated-pairs.jsonl', valid)
    write_rows(out/'validation-statuses.jsonl', statuses)
    files=[source, HERE/'root-citation-metadata-normalization-go.json', HERE/'completed-response-snapshot-v1/snapshot-receipt.json',
           Path(__file__), ROOT/'experiments/sku-matching/normalize_source_nli_citations_v1.py',
           ROOT/'experiments/sku-matching/sku_directional_choice_nli_v1.py', out/'validated-pairs.jsonl', out/'validation-statuses.jsonl']
    receipt={'schema_version':'sku-choice-nli-source-validation-completion-v1',
             'created_at_utc':datetime.datetime.now(datetime.UTC).isoformat(), 'source_split':'dev', 'labels_read':False,
             'independent_test':False, 'response_count':len(responses), 'status_counts':dict(Counter(x['status'] for x in statuses)),
             'invalid_error_counts':dict(Counter(x['error'] for x in statuses if 'error' in x)),
             'semantic_truth_verified':False, 'production_adoption_allowed':False,
             'invalid_handling':'No validated pair is supplied; downstream task resolution becomes unknown unless an independent strict literal proof covers that task.',
             'frozen_files':{str(p.relative_to(ROOT)):pin(p) for p in files}}
    (out/'validation-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ('response_count','status_counts','invalid_error_counts')}),flush=True)

if __name__=='__main__':
    main()
