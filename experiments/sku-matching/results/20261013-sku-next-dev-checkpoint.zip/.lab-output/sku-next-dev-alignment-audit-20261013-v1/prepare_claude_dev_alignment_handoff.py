#!/usr/bin/env python3
"""Prepare a pinned, source-backed DEV-only Claude alignment handoff.

Default mode is a dry run: validate the frozen DEV identities and print the
exact ZIP member inventory and byte counts. --write creates the requested ZIP
and sidecars, but must only be used after the root review/GO.

This is packaging only. It does not invoke an aligner, read labels, infer,
score, normalize semantic values, or use test membership as a selection rule.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PREP = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1"
SOURCE_ROOT = ROOT / ".lab-output/sku-independent-real-20261011"
RAW_ROOT = PREP / "source"
ADAPTER = ROOT / ".lab-output/sku-full-condition-adapter-20261013-v2"
RESULT = ROOT / "experiments/sku-matching/results"
ZIP_PATH = RESULT / "20261013-sku-claude-frozen-dev-alignment-inputs.zip"
EXTERNAL_MANIFEST = ZIP_PATH.with_suffix(".zip.manifest.json")
SHA_SIDECAR = ZIP_PATH.with_suffix(".zip.sha256")

VERSIONS = ("v2", "v3")
DEV_CASE_COUNTS = {"v2": 1295, "v3": 75}
DEV_PRODUCTS = 107
DEV_CASES = 1370
ADAPTER_FILES = (
    "case-plans.jsonl", "row-plans.jsonl", "tasks.jsonl", "requests.jsonl",
    "documents.jsonl", "composition-units.jsonl",
    "composition-unit-bindings.jsonl", "request-model-input-map.jsonl",
    "manifest.json",
)
CODE_FILES = (
    "experiments/sku-matching/prepare_full_condition_inputs_v2.py",
    "experiments/sku-matching/prepare_generic_model_sku_v1.py",
    "experiments/sku-matching/prepare_claude_alignment_v7.py",
    "experiments/sku-matching/sku_literal_family_proof_v1.py",
    "experiments/sku-matching/claude_v9_gate/sku_gate_sources.py",
)
FORBIDDEN_KEYS = {"gold", "gold_label", "prediction",
                  "predictions", "score", "scores", "expected_match"}
V7_ARCHIVE = ROOT / ".lab-output/sku-claude-v7-integration-review-20261012-v1/20261012-sku-align-v6-v7-outputs.zip"
V7_ARCHIVE_SHA256 = "f5522952c8a67d5a7289cdb6f9cdcb5f2d093026a79360b704c08fd68dd5503c"
V7_CODE_MEMBER = "code/v7-7fd8e17/align_sku_conditions.py"
V7_CODE_SHA256 = "173c9c90157278147740f3c885ba5fae9144152b0d20493a19056eb3efba5a7e"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def jsonl_records(data: bytes, label: str):
    for line_no, line in enumerate(data.splitlines(), 1):
        if line.strip():
            try:
                yield line_no, json.loads(line)
            except Exception as exc:
                raise ValueError(f"invalid JSONL in {label} line {line_no}") from exc


def selected_jsonl_records(data: bytes, selected_values: set[str], key: str, label: str):
    """Decode only selected DEV records; skip all other source rows as bytes."""
    field = re.compile(rb'"' + re.escape(key.encode("ascii")) + rb'"\s*:\s*"([^"\\]*)"')
    for line_no, line in enumerate(data.splitlines(), 1):
        if not line.strip():
            continue
        match = field.search(line)
        if not match:
            continue
        try:
            identity = match.group(1).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError(f"invalid identity in {label} line {line_no}") from exc
        if identity not in selected_values:
            continue
        try:
            yield line_no, json.loads(line)
        except Exception as exc:
            raise ValueError(f"invalid JSONL in selected DEV {label} line {line_no}") from exc


def put_json(members: dict[str, bytes], name: str, value) -> None:
    members[name] = json.dumps(value, ensure_ascii=False, sort_keys=True,
                               indent=2, allow_nan=False).encode("utf-8") + b"\n"


def safe_member(name: str) -> str:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name or not path.parts:
        raise ValueError("unsafe bundle member path")
    return str(path)


def recursive_raw_refs(value):
    if isinstance(value, dict):
        if isinstance(value.get("raw_file"), str) and isinstance(value.get("sha256"), str):
            yield value["raw_file"].replace("\\", "/"), value["sha256"]
        for child in value.values():
            yield from recursive_raw_refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from recursive_raw_refs(child)


def read_pins():
    inventory_path = PREP / "inventory.json"
    source_index_path = PREP / "source-index.json"
    inventory_bytes = inventory_path.read_bytes()
    inventory = json.loads(inventory_bytes)
    if inventory.get("status") != "source_bundle_ready":
        raise ValueError("frozen source inventory is not ready")
    if inventory.get("source_provenance", {}).get("missing_referenced_sources"):
        raise ValueError("frozen inventory reports missing source files")
    source_index = json.loads(source_index_path.read_text(encoding="utf-8"))
    return inventory, source_index, inventory_bytes, source_index_path.read_bytes()


def selected_adapter_cases():
    path = ADAPTER / "dev/case-plans.jsonl"
    manifest = json.loads((ADAPTER / "dev/manifest.json").read_text(encoding="utf-8"))
    if manifest.get("split") != "dev" or manifest.get("independent_test") is not False:
        raise ValueError("adapter manifest is not the frozen DEV preparation")
    result = []
    for line_no, row in jsonl_records(path.read_bytes(), str(path)):
        if row.get("split") != "dev":
            raise ValueError("non-DEV case plan in DEV artifact")
        row["_handoff_plan_line"] = line_no
        result.append(row)
    if len(result) != DEV_CASES or len({r.get("case_id") for r in result}) != DEV_CASES:
        raise ValueError("unexpected full DEV case population")
    return manifest, result


def gather_source_members(members, inventory, adapter_case_plans):
    wanted = {version: {} for version in VERSIONS}
    for plan in adapter_case_plans:
        version = plan.get("source_version")
        if version not in wanted:
            raise ValueError("DEV case plan has unknown source version")
        case_id = plan.get("case_id")
        if not isinstance(case_id, str) or case_id in wanted[version]:
            raise ValueError("duplicate/malformed DEV case identity")
        wanted[version][case_id] = plan

    case_records, product_records, group_records = {}, {}, {}
    case_lines, product_lines, group_lines = {}, {}, {}
    mapping = []
    raw_pins: dict[str, str] = {}
    source_archives = inventory["archive_verification"]
    for version in VERSIONS:
        input_dir = SOURCE_ROOT / f"eval-{version}/run-token/inputs"
        group_path = SOURCE_ROOT / f"eval-{version}/groups-token/groups.jsonl"
        entry = inventory["splits"][version]
        devplans = wanted[version]
        if len(devplans) != DEV_CASE_COUNTS[version]:
            raise ValueError("DEV case-plan source-version count differs")

        verified_inputs = {}
        for member in ("cases.jsonl", "products.jsonl", "manifest.json"):
            path = input_dir / member
            data = path.read_bytes()
            spec = entry["input_members"][member]
            if len(data) != spec["bytes"] or sha(data) != spec["sha256"]:
                raise ValueError(f"frozen {version} {member} pin mismatch")
            verified_inputs[member] = data

        group_data = group_path.read_bytes()
        source_index = {x.get("path"): x for x in json.loads((PREP / "source-index.json").read_text())}
        rel_group = group_path.relative_to(ROOT).as_posix()
        if source_index.get(rel_group, {}).get("sha256") != sha(group_data):
            raise ValueError(f"frozen {version} group-map SHA mismatch")
        dev_dossiers = {str(plan["dossier_id"]) for plan in devplans.values()}
        group_map = {}
        for line_no, group_row in selected_jsonl_records(group_data, dev_dossiers, "dossier_id", str(group_path)):
            obj = group_row.get("group", group_row)
            dossier = str(obj.get("dossier_id", group_row.get("dossier_id", "")))
            if not dossier or dossier in group_map:
                raise ValueError("frozen group map has a duplicate/missing dossier")
            group_map[dossier] = (line_no, group_row, obj)
        for dossier in dev_dossiers:
            found = group_map.get(dossier)
            if not found or found[2].get("split") != "dev" or found[2].get("excluded"):
                raise ValueError("DEV case plan disagrees with frozen group map")
            group_lines[dossier] = found[0]
            group_records[dossier] = found[1]

        case_by_id = {}
        for line_no, case in selected_jsonl_records(verified_inputs["cases.jsonl"], set(devplans), "case_id", version + " cases"):
            case_id = case.get("case_id")
            plan = devplans.get(case_id)
            if plan is None:
                continue
            if str(case.get("dossier_id")) not in dev_dossiers:
                raise ValueError("case plan dossier does not bind selected DEV dossier")
            if case_id in case_by_id:
                raise ValueError("duplicate case ID in frozen source input")
            case_by_id[case_id] = (line_no, case)
            case_lines[case_id] = line_no
            case_records[case_id] = case
            if (str(case.get("au_product_id")) != str(plan.get("au_product_id"))
                    or case.get("rakuten_selected", {}).get("source_sku_key") != plan.get("source_sku_key")
                    or case.get("rakuten_selected", {}).get("sku_record_key") != plan.get("sku_record_key")):
                raise ValueError("full DEV case plan does not bind to frozen case row")
        if set(case_by_id) != set(devplans):
            raise ValueError("full DEV plans are not fully present in frozen input")

        product_by_key = {}
        for line_no, product in selected_jsonl_records(verified_inputs["products.jsonl"], dev_dossiers, "dossier_id", version + " products"):
            key = (str(product.get("dossier_id")), str((product.get("au_product") or {}).get("product_id")))
            if key[0] in dev_dossiers:
                if key in product_by_key:
                    raise ValueError("duplicate product identity in frozen input")
                product_by_key[key] = (line_no, product)
                product_records[key] = product
                product_lines[key] = line_no
        required_products = {(str(p["dossier_id"]), str(p["au_product_id"])) for p in devplans.values()}
        if not required_products.issubset(product_by_key):
            raise ValueError("a frozen DEV AU product row is missing")

        member_specs = entry["input_members"]
        input_archive = source_archives.get("token_input_archive")
        raw_archive = source_archives.get(f"{version}_raw_source_archive")
        if input_archive is None or raw_archive is None:
            raise ValueError("original input/raw archive pin missing")
        input_archive_name = Path(input_archive["path"]).name
        input_archive_sha = input_archive["sha256"]
        raw_archive_name = Path(raw_archive["path"]).name
        raw_archive_sha = raw_archive["sha256"]
        for case_id, (line_no, case) in case_by_id.items():
            plan = devplans[case_id]
            product_key = (str(case["dossier_id"]), str(case["au_product_id"]))
            product_line = product_lines[product_key]
            group_line = group_lines[str(case["dossier_id"])]
            mapping.append({
                "case_id": case_id, "dossier_id": str(case["dossier_id"]),
                "au_product_id": str(case["au_product_id"]), "source_sku_key": case["rakuten_selected"]["source_sku_key"],
                "source_version": version, "original_input_archive": input_archive_name,
                "original_input_archive_sha256": input_archive_sha,
                "original_raw_source_archive": raw_archive_name,
                "original_raw_source_archive_sha256": raw_archive_sha,
                "cases_jsonl_line": line_no, "cases_jsonl_sha256": member_specs["cases.jsonl"]["sha256"],
                "products_jsonl_line": product_line, "products_jsonl_sha256": member_specs["products.jsonl"]["sha256"],
                "group_map_jsonl_line": group_line, "group_map_jsonl_sha256": sha(group_data),
                "adapter_case_plan_jsonl_line": plan["_handoff_plan_line"],
                "rakuten_source_sha256": case["rakuten_selected"]["sha256"],
                "au_product_source_sha256": (product_records[product_key].get("au_product") or {}).get("sha256"),
                "adapter_case_plan_sha256": sha(canonical({k: v for k, v in plan.items() if k != "_handoff_plan_line"})),
            })
        # Preserve original source records byte-for-byte, including all AU rows/axes.
        for label, selected, source_bytes in (
            ("cases", case_by_id, verified_inputs["cases.jsonl"]),
        ):
            name = f"source_inputs/{version}/{label}.dev.jsonl"
            members[name] = b"".join(next(line for n, line in enumerate(source_bytes.splitlines(keepends=True), 1)
                                             if n == case_lines[cid])
                                      for cid in sorted(selected, key=lambda cid: case_lines[cid]))
        selected_product_line_numbers = {product_lines[k] for k in product_by_key}
        members[f"source_inputs/{version}/products.dev.jsonl"] = b"".join(
            line for n, line in enumerate(verified_inputs["products.jsonl"].splitlines(keepends=True), 1)
            if n in selected_product_line_numbers)
        members[f"source_inputs/{version}/groups.dev.jsonl"] = b"".join(
            line for n, line in enumerate(group_data.splitlines(keepends=True), 1)
            if n in set(group_lines.values()))
        # The original input manifest itself may enumerate non-DEV raw captures;
        # record only its immutable pin and required source-member pins instead.
        input_pin = {
            "source_version": version,
            "original_input_archive": input_archive_name,
            "original_input_archive_sha256": input_archive_sha,
            "original_raw_source_archive": raw_archive_name,
            "original_raw_source_archive_sha256": raw_archive_sha,
            "input_members": {k: {"sha256": v["sha256"], "bytes": v["bytes"]}
                              for k, v in member_specs.items()},
            "groups_jsonl": {"path": rel_group, "sha256": sha(group_data), "bytes": len(group_data)},
            "dev_case_rows": len(case_by_id), "dev_product_rows": len(product_by_key),
            "labels_read": False,
        }
        put_json(members, f"source_inputs/{version}/source-pin.json", input_pin)
        for record in [*case_by_id.values(), *product_by_key.values()]:
            obj = record[1]
            for raw_path, digest in recursive_raw_refs(obj):
                old = raw_pins.setdefault(raw_path, digest)
                if old != digest:
                    raise ValueError("conflicting SHA pins for one raw capture path")

    if len(case_records) != DEV_CASES or len(product_records) != DEV_PRODUCTS:
        raise ValueError("DEV source record totals do not match frozen inventory")
    mapping.sort(key=lambda r: (r["source_version"], r["cases_jsonl_line"]))
    members["source_inputs/dev-source-mapping.jsonl"] = b"".join(canonical(x) + b"\n" for x in mapping)
    members["source_inputs/source-index.dev.json"] = b""  # filled after raw-source selection

    index_path = PREP / "source-index.json"
    full_index = json.loads(index_path.read_text(encoding="utf-8"))
    index_by_path = {x.get("path"): x for x in full_index}
    raw_index = []
    for raw_path, expected in sorted(raw_pins.items()):
        path = RAW_ROOT / raw_path
        resolved = path.resolve(strict=True)
        try:
            resolved.relative_to(RAW_ROOT.resolve())
        except ValueError as exc:
            raise ValueError("raw capture resolves outside workspace") from exc
        data = resolved.read_bytes()
        if sha(data) != expected:
            raise ValueError(f"raw capture SHA mismatch: {raw_path}")
        pin = index_by_path.get(raw_path)
        if pin is None or pin.get("sha256") != expected or pin.get("bytes") != len(data):
            raise ValueError(f"DEV raw capture is not exactly pinned by source index: {raw_path}")
        member = safe_member("raw_sources/" + raw_path)
        members[member] = data  # real bytes are stored even if workspace input was a symlink
        raw_index.append({"path": raw_path, "sha256": expected, "bytes": len(data),
                          "archive_origins": pin.get("archive_origins", []),
                          "bundle_member": member, "input_symlink": path.is_symlink(),
                          "resolved_target_sha256": sha(data)})
    members["source_inputs/source-index.dev.json"] = json.dumps(raw_index, ensure_ascii=False,
        sort_keys=True, indent=2).encode("utf-8") + b"\n"
    return mapping, raw_index, case_records, product_records


def check_adapter_outputs(members, manifest):
    for rel in ADAPTER_FILES:
        path = ADAPTER / "dev" / rel
        data = path.read_bytes()
        expected = manifest.get("outputs_sha256", {}).get(rel)
        if expected and sha(data) != expected:
            raise ValueError(f"DEV adapter output SHA mismatch: {rel}")
        members[f"adapter/dev/{rel}"] = data


def scan_forbidden_keys(value, where):
    if isinstance(value, dict):
        for key, child in value.items():
            if key.lower() in FORBIDDEN_KEYS:
                raise ValueError(f"label/score field prohibited from handoff: {where}:{key}")
            scan_forbidden_keys(child, where)
    elif isinstance(value, list):
        for child in value:
            scan_forbidden_keys(child, where)


def build_payload():
    inventory, source_index, inventory_bytes, source_index_bytes = read_pins()
    dev_manifest, adapter_case_plans = selected_adapter_cases()
    members: dict[str, bytes] = {}
    mapping, raw_index, cases, products = gather_source_members(members, inventory, adapter_case_plans)

    # Copy the complete source-bound DEV handoff plans and provenance code only.
    check_adapter_outputs(members, dev_manifest)
    members["provenance/full-inventory-sha256.txt"] = (sha(inventory_bytes) + "  inventory.json\n").encode()
    members["provenance/full-source-index-sha256.txt"] = (sha(source_index_bytes) + "  source-index.json\n").encode()
    for rel in CODE_FILES:
        path = ROOT / rel
        data = path.read_bytes()
        members[safe_member("provenance/code/" + rel)] = data
    if sha(V7_ARCHIVE.read_bytes()) != V7_ARCHIVE_SHA256:
        raise ValueError("pinned v7 producer archive SHA mismatch")
    with ZipFile(V7_ARCHIVE) as archive:
        code = archive.read(V7_CODE_MEMBER)
    if sha(code) != V7_CODE_SHA256:
        raise ValueError("pinned v7 producer code SHA mismatch")
    members[safe_member("provenance/code/v7-7fd8e17/align_sku_conditions.py")] = code
    join_audit = HERE / "audit.json"
    if join_audit.exists():
        members["provenance/v7-full-dev-join-audit.json"] = join_audit.read_bytes()
    disjoint_audit = HERE / "dev-test-product-disjoint-audit.json"
    if disjoint_audit.exists():
        members["provenance/dev-test-product-disjoint-audit.json"] = disjoint_audit.read_bytes()

    for name, data in members.items():
        safe_member(name)
    # Guard the exact source-record and adapter files against result-like fields.
    for case_id, case in cases.items():
        scan_forbidden_keys(case, f"source case {case_id}")
    for key, product in products.items():
        scan_forbidden_keys(product, f"source product {key}")
    # The model/task adapter contracts declare selected values binding-only and
    # all tasks unevaluated; don't package outputs, scores, labels, or baselines.
    if dev_manifest.get("model_inference_run") is not False or dev_manifest.get("labels_read") is not False:
        raise ValueError("DEV adapter manifest indicates inference or label access")
    flags = {
        "source_version_case_counts": dict(Counter(x["source_version"] for x in mapping)),
        "dev_case_count": len(cases), "dev_product_count": len(products),
        "dev_raw_capture_count": len(raw_index),
        "dev_raw_capture_total_bytes": sum(x["bytes"] for x in raw_index),
        "purchase_option_source_field": "au_purchase_option_lines",
        "dev_products_with_purchase_option_lines": sum(bool(p.get("au_purchase_option_lines")) for p in products.values()),
        "dev_products_with_empty_or_missing_purchase_option_lines": sum(not p.get("au_purchase_option_lines") for p in products.values()),
        "purchase_api_missing_claim": "not inferred; empty/missing source field is reported above only",
        "failed_input_attempt_rows_packaged": 0,
        "failed_input_attempts_in_full_population": 259,
        "failed_attempt_details_excluded": True,
        "selected_rakuten_values_are_binding_only": True,
        "one_sidedness_inferred_from_absence": False,
        "alternative_winner_treated_as_alignment_proof": False,
        "test_cases_or_test_labels_included": False,
        "gold_labels_or_predictions_included": False,
        "model_inference_run": False,
        "semantic_normalization_or_category_rules_added": False,
    }
    put_json(members, "source_inputs/source-flags.json", flags)
    bundle_manifest = {
        "schema_version": "sku-claude-frozen-dev-alignment-inputs-v1",
        "purpose": "Source-backed DEV-only input handoff for an existing condition/axis aligner; packaging only.",
        "split": "dev", "case_count": DEV_CASES, "product_count": DEV_PRODUCTS,
        "row_plan_count": dev_manifest["row_plan_count"],
        "task_binding_count": dev_manifest["task_binding_count"],
        "request_count": dev_manifest["unique_request_count"],
        "labels_read": False, "inference_run": False, "scoring_run": False,
        "test_cases_or_labels_included": False,
        "source_mapping_member": "source_inputs/dev-source-mapping.jsonl",
        "source_flags_member": "source_inputs/source-flags.json",
        "raw_source_index_member": "source_inputs/source-index.dev.json",
        "one_sidedness_policy": "explicit source-bound alignment required; absence is unknown",
        "alignment_policy": "an alternative winner alone is not proof; retain bound axis/row/family provenance and structured conflicts/unknowns",
        "member_index": [{"path": k, "bytes": len(v), "sha256": sha(v)} for k, v in sorted(members.items())],
    }
    members["instructions/claude-frozen-dev-alignment-request-20261013.txt"] = (
        ROOT / "experiments/sku-matching/claude-frozen-dev-alignment-request-20261013.txt"
    ).read_bytes()
    bundle_manifest["member_index"] = [{"path": k, "bytes": len(v), "sha256": sha(v)}
                                        for k, v in sorted(members.items())]
    put_json(members, "BUNDLE_MANIFEST.json", bundle_manifest)
    return members, bundle_manifest


def write_zip(members, bundle_manifest):
    RESULT.mkdir(parents=True, exist_ok=True)
    for path in (ZIP_PATH, EXTERNAL_MANIFEST, SHA_SIDECAR):
        if path.exists():
            raise FileExistsError(f"refusing to overwrite {path}")
    with zipfile.ZipFile(ZIP_PATH, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name in sorted(members):
            info = zipfile.ZipInfo(safe_member(name))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, members[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=6)
    zip_data = ZIP_PATH.read_bytes()
    zip_sha = sha(zip_data)
    external = {
        "schema_version": "sku-claude-frozen-dev-alignment-inputs-archive-v1",
        "archive": ZIP_PATH.name, "sha256": zip_sha, "size_bytes": len(zip_data),
        "file_count": len(members), "uncompressed_bytes": sum(len(v) for v in members.values()),
        "bundle_manifest_sha256": sha(members["BUNDLE_MANIFEST.json"]),
        "split": "dev", "case_count": DEV_CASES, "test_cases_or_labels_included": False,
    }
    EXTERNAL_MANIFEST.write_text(json.dumps(external, ensure_ascii=False, indent=2) + "\n")
    SHA_SIDECAR.write_text(f"{zip_sha}  {ZIP_PATH.name}\n")
    return external


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true", help="create ZIP and sidecars after root GO")
    args = parser.parse_args()
    members, manifest = build_payload()
    result = {
        "mode": "write" if args.write else "dry_run",
        "zip_path": str(ZIP_PATH.relative_to(ROOT)),
        "external_manifest_path": str(EXTERNAL_MANIFEST.relative_to(ROOT)),
        "sha256_sidecar_path": str(SHA_SIDECAR.relative_to(ROOT)),
        "member_count": len(members), "uncompressed_bytes": sum(len(v) for v in members.values()),
        "members": [{"path": p, "bytes": len(data), "sha256": sha(data)} for p, data in sorted(members.items())],
        "cases": DEV_CASES, "products": DEV_PRODUCTS,
        "raw_capture_count": sum(1 for n in members if n.startswith("raw_sources/")),
        "raw_capture_bytes": sum(len(v) for n, v in members.items() if n.startswith("raw_sources/")),
        "labels_read": False, "test_cases_or_labels_included": False,
    }
    if args.write:
        result["archive"] = write_zip(members, manifest)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
