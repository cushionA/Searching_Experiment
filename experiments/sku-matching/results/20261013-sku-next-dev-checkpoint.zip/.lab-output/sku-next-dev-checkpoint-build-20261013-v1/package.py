#!/usr/bin/env python3
"""Build/estimate a label-safe checkpoint for the frozen DEV score.

By default this emits a metadata preflight and compressed-size estimate. ZIP
creation requires both --root-go and --build after the selected DEV score and
final report are frozen. Full answer archives/model weights stay external.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
import zipfile
import zlib
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / ".lab-output/sku-next-dev-checkpoint-build-20261013-v1"
OUT = ROOT / "experiments/sku-matching/results/20261013-sku-next-dev-checkpoint.zip"
SHA_PATH = OUT.with_suffix(OUT.suffix + ".sha256")
REPORT = ROOT / "experiments/sku-matching/fresh-dev-choice-nli-result-20261013.txt"
SCORE = BUILD / "dev-score.json"
REFERENCES = BUILD / "selected-dev-references.jsonl"
SCORING_RECEIPT = BUILD / "scoring-completion-receipt.json"
FREEZE_RECEIPT = ROOT / ".lab-output/sku-next-dev-v7-adapter-20261013-v1/final-gate-run-v2/dev-grading-freeze.json"
HANDOFF = ROOT / "experiments/sku-matching/results/20261013-sku-claude-frozen-dev-alignment-inputs.zip"

TREES = [
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1",
    ".lab-output/sku-next-dev-v7-runtime-20261013-v1",
    ".lab-output/sku-next-dev-choice-nli-20261013-v1",
    ".lab-output/sku-next-dev-choice-nli-20261013-v2",
    ".lab-output/sku-next-dev-choice-nli-execution-20261013-v1",
    ".lab-output/sku-next-dev-literal-family-proofs-20261013-v1",
    ".lab-output/sku-next-dev-baseline-source-projection-20261013-v1",
    ".lab-output/sku-next-dev-conflict-method-20261013-v1",
    ".lab-output/sku-next-dev-fresh-baseline-20261013-v1",
    ".lab-output/sku-next-dev-alignment-audit-20261013-v1",
    ".lab-output/sku-next-dev-required-checks-20261013-v2",
    ".lab-output/sku-next-dev-checkpoint-build-20261013-v1",
]
FILES = [
    "experiments/sku-matching/grade_fresh_dev_sku_gate_v1.py",
    "tests/test_lab_fresh_dev_sku_gate.py",
    "experiments/sku-matching/prepare_fresh_dev_v7_gate_v1.py",
    "experiments/sku-matching/run_fresh_dev_baseline_v1.py",
    "experiments/sku-matching/integrate_claude_description_v1.py",
    "experiments/sku-matching/sku_directional_choice_nli_v1.py",
    "experiments/sku-matching/normalize_source_nli_citations_v1.py",
    "experiments/sku-matching/evaluate_dev_source_bound_whole_sku_gate_v1.py",
    "experiments/sku-matching/prepare_dev_literal_family_proofs_v1.py",
    "experiments/sku-matching/validate_dev_literal_family_proofs_v1.py",
    "experiments/sku-matching/build_sku_literal_family_proofs_v1.py",
    "experiments/sku-matching/sku_literal_family_proof_v1.py",
    "experiments/sku-matching/route_mixed_sku_references_v1.py",
    "experiments/sku-matching/grade_final_test_subset_v1.py",
    "tests/test_lab_normalize_source_nli_citations_v1.py",
    "tests/test_lab_dev_source_bound_whole_sku_gate.py",
    "tests/test_lab_dev_literal_family_proofs.py",
    "tests/test_lab_sku_literal_family_proof.py",
    "tests/test_lab_mixed_sku_reference_router.py",
    "tests/test_lab_final_test_subset_grader.py",
    "tests/test_lab_sku_directional_choice_nli_v1.py",
    "experiments/sku-matching/fresh-dev-choice-nli-result-20261013.txt",
    "experiments/sku-matching/session-result-20261012.txt",
    "experiments/sku-matching/session-handoff-20261012.txt",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/selection-plan.json",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/membership.jsonl",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/adapter-contract.json",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/preparation-status.json",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/selection-plan.json",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/membership.jsonl",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/case-plans.jsonl",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/row-plans.jsonl",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/requests.jsonl",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/tasks.jsonl",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/documents.jsonl",
    ".lab-output/sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v8/manifest.json",
    ".lab-output/sku-next-dev-v7-runtime-20261013-v1/input-freeze.json",
    ".lab-output/sku-next-dev-v7-runtime-20261013-v1/experiment-freeze.json",
    ".lab-output/sku-next-dev-v7-runtime-20261013-v1/run-receipt.json",
    ".lab-output/sku-next-dev-choice-nli-20261013-v1/freeze.json",
    ".lab-output/sku-next-dev-choice-nli-20261013-v1/summary.json",
    ".lab-output/sku-next-dev-fresh-baseline-20261013-v1/input-preparation/preparation-receipt.json",
    ".lab-output/sku-next-dev-fresh-baseline-20261013-v1/model-run/runtime-source-freeze.json",
    ".lab-output/sku-next-dev-fresh-baseline-20261013-v1/model-run/model-run/freeze.json",
    ".lab-output/sku-next-dev-checkpoint-build-20261013-v1/dev-score.json",
    ".lab-output/sku-next-dev-checkpoint-build-20261013-v1/selected-dev-references.jsonl",
    ".lab-output/sku-next-dev-checkpoint-build-20261013-v1/scoring-completion-receipt.json",
    ".lab-output/sku-next-dev-checkpoint-build-20261013-v1/required-checks-tree-change.json",
    ".lab-output/sku-next-dev-checkpoint-build-20261013-v1/freeze-pin-allowlist-repair.json",
]

EXTERNAL = [
    {"name": "final-test-checkpoint", "path": "experiments/sku-matching/results/20261013-sku-final-test-checkpoint.zip", "sha256": "9a1991ceac77dcec7fee07934bf5343bc4c9a941cff90943eee25f21a5813549"},
    {"name": "frozen-dev-source-handoff", "path": "experiments/sku-matching/results/20261013-sku-claude-frozen-dev-alignment-inputs.zip", "sha256": "fd9f5bfda54e8bbb9497f1fde2a8237db89050949d738689f0a85032ef9d23af"},
    {"name": "v2-reference-archive", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261011-sku-independent-real-eval-v2.zip", "sha256": "6f65d988222c79c758614592340ba28565a51fa8891317724ba354c5fc38b457", "label_members_external": True},
    {"name": "v3-reference-archive", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261012-sku-independent-real-eval-v3.zip", "sha256": "52f6faa51127a9c12250a3cdb5eb3d1818a36461a8c09323e481748aeed1f37b", "label_members_external": True},
    {"name": "v2-v3-label-free-source-inputs", "path": ".lab-output/sku-claude-dev-input-share-20261012-v1/20261012-sku-independent-real-eval-v2-v3-token-inputs.zip", "sha256": "db2815a3d5c726e45f996ad07e73cdcf1cdff0610de53ad84af8a4a0a880488f"},
]

FORBIDDEN_PARTS = {".deps", "models", "model", "weights", "secrets", "credentials", ".venv", "venv", "labels-token", "private", "__pycache__"}
FORBIDDEN_SUFFIXES = {".safetensors", ".pt", ".pth", ".ckpt", ".bin", ".env", ".pyc", ".pyo"}


@dataclass(frozen=True)
class Source:
    archive_path: str
    member: str
    expected_sha256: str
    expected_bytes: int
    origin: str


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe(rel: str) -> bool:
    p = Path(rel)
    if ".." in p.parts or p.is_absolute():
        return False
    parts = {x.lower() for x in p.parts}
    name = p.name.lower()
    if parts & FORBIDDEN_PARTS or p.suffix.lower() in FORBIDDEN_SUFFIXES | {".zip"}:
        return False
    if name.startswith(("answer-", "label-", "gold-")) or name in {"answers.jsonl", "labels.jsonl", "gold.jsonl", "resolved.jsonl"}:
        return False
    return True


def _collect_raw_refs(files: dict[str, Path]) -> dict[str, dict]:
    raw: dict[str, dict] = {}
    for arc, path in files.items():
        if not arc.endswith((".jsonl", ".json")):
            continue
        # These are selected input/source traces only; never scan answer archives.
        try:
            if path.stat().st_size > 350_000_000:
                continue
            data = path.read_bytes()
        except OSError:
            continue
        lines = data.splitlines() if arc.endswith(".jsonl") else [data]
        for line_no, line in enumerate(lines, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            stack = [obj]
            while stack:
                value = stack.pop()
                if isinstance(value, dict):
                    raw_path = value.get("raw_file")
                    expected = value.get("sha256")
                    if isinstance(raw_path, str) and isinstance(expected, str) and len(expected) == 64:
                        raw_path = raw_path.replace("\\", "/")
                        entry = raw.setdefault(raw_path, {"sha256": expected, "origins": []})
                        if entry["sha256"] != expected:
                            entry.setdefault("conflicting_hashes", []).append({"sha256": expected, "origin": arc})
                        entry["origins"].append({"file": arc, "line": line_no})
                    stack.extend(value.values())
                elif isinstance(value, list):
                    stack.extend(value)
    return raw


def gather() -> tuple[list[tuple[Path, str]], list[Source], list[str]]:
    files: dict[str, Path] = {}
    missing: list[str] = []
    for rel in FILES:
        path = ROOT / rel
        if path.is_file() and safe(rel) and not path.is_symlink():
            files[rel] = path
        else:
            missing.append(rel)
    for rel in TREES:
        base = ROOT / rel
        if not base.exists():
            missing.append(rel + "/")
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.is_symlink():
                continue
            arc = path.relative_to(ROOT).as_posix()
            if safe(arc):
                files[arc] = path
    # Freeze receipts often pin source code in addition to local run trees.
    # Include only repository-local Python files whose exact bytes still match.
    for path in list(files.values()):
        if path.suffix != ".json":
            continue
        try:
            receipt = json.loads(path.read_text())
        except Exception:
            continue
        snapshot = receipt.get("source_snapshot", receipt.get("source_code_pins", {}))
        if not isinstance(snapshot, dict):
            continue
        for raw, pin in snapshot.items():
            source = Path(raw)
            if source.suffix != ".py":
                continue
            if not source.is_absolute():
                source = ROOT / source
            try:
                arc = source.resolve().relative_to(ROOT).as_posix()
            except ValueError:
                missing.append(f"frozen-source-outside-repository:{raw}")
                continue
            expected_sha = pin.get("sha256") if isinstance(pin, dict) else pin
            expected_bytes = pin.get("bytes") if isinstance(pin, dict) else None
            if not source.is_file() or source.is_symlink() or digest(source) != expected_sha or (expected_bytes is not None and source.stat().st_size != expected_bytes):
                missing.append(f"frozen-source-pin-mismatch:{arc}")
            elif safe(arc):
                files[arc] = source

    raw_refs = _collect_raw_refs(files)
    handoff_path = ROOT / HANDOFF.relative_to(ROOT)
    raw_sources: list[Source] = []
    if not handoff_path.is_file() or digest(handoff_path) != EXTERNAL[1]["sha256"]:
        missing.append("frozen-dev-source-handoff-archive-missing-or-sha-mismatch")
    else:
        with zipfile.ZipFile(handoff_path) as archive:
            if "BUNDLE_MANIFEST.json" not in archive.namelist():
                missing.append("source-handoff-bundle-manifest-missing")
            else:
                bundle = json.loads(archive.read("BUNDLE_MANIFEST.json"))
                expected_bundle_sha = "ee1d5992371284259544fb8fb6971b40ae7fb37436039390dc16488e913ccb61"
                if bundle.get("split") != "dev" or bundle.get("test_cases_or_labels_included") is not False or sha_bytes(archive.read("BUNDLE_MANIFEST.json")) != expected_bundle_sha:
                    missing.append("source-handoff-bundle-manifest-pin-or-split-mismatch")
                indexed = {row["path"]: row for row in bundle.get("member_index", [])}
                for raw_path, pin in sorted(raw_refs.items()):
                    if not safe(raw_path):
                        missing.append(f"raw-source-path-forbidden:{raw_path}")
                        continue
                    if pin.get("conflicting_hashes"):
                        missing.append(f"raw-source-conflicting-references:{raw_path}")
                        continue
                    member = "raw_sources/" + raw_path
                    row = indexed.get(member)
                    if not row or row.get("sha256") != pin["sha256"]:
                        missing.append(f"raw-source-not-pinned-by-handoff:{raw_path}")
                        continue
                    # Hash the selected raw member only; no source text is interpreted.
                    h = hashlib.sha256()
                    byte_count = 0
                    try:
                        with archive.open(member) as stream:
                            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                                h.update(chunk)
                                byte_count += len(chunk)
                    except KeyError:
                        missing.append(f"raw-source-member-missing:{member}")
                        continue
                    if byte_count != row["bytes"] or h.hexdigest() != pin["sha256"]:
                        missing.append(f"raw-source-content-hash-mismatch:{raw_path}")
                        continue
                    if raw_path in files:
                        if digest(files[raw_path]) != pin["sha256"] or files[raw_path].stat().st_size != byte_count:
                            missing.append(f"raw-source-payload-collision:{raw_path}")
                        continue
                    raw_sources.append(Source(str(handoff_path), member, pin["sha256"], byte_count,
                                              json.dumps(pin["origins"], sort_keys=True)))

    # The generated ledger makes every included capture's canonical path,
    # original handoff ZIP member and reference origin auditable.
    ledger_path = BUILD / "raw-source-pins.json"
    if raw_sources:
        ledger = {"schema_version": "sku-next-dev-checkpoint-raw-capture-pins-v1",
                  "source_handoff_archive": "experiments/sku-matching/results/20261013-sku-claude-frozen-dev-alignment-inputs.zip",
                  "source_handoff_sha256": EXTERNAL[1]["sha256"],
                  "raw_captures": [{"path": source.member.removeprefix("raw_sources/"),
                                    "bundle_member": source.member, "bytes": source.expected_bytes,
                                    "sha256": source.expected_sha256, "origin": json.loads(source.origin)}
                                   for source in raw_sources]}
        ledger_path.parent.mkdir(parents=True, exist_ok=True)
        ledger_path.write_text(json.dumps(ledger, indent=2, sort_keys=True) + "\n")
        files[ledger_path.relative_to(ROOT).as_posix()] = ledger_path
    elif raw_refs:
        missing.append("no-verified-selected-raw-captures")
    return [(path, arc) for arc, path in sorted(files.items())], raw_sources, missing


def verify_score_outputs() -> tuple[bool, list[str]]:
    problems = []
    for path in (SCORE, REFERENCES, SCORING_RECEIPT):
        if not path.is_file():
            problems.append(f"missing-score-artifact:{path.relative_to(ROOT)}")
    if problems:
        return False, problems
    score, completion = json.loads(SCORE.read_text()), json.loads(SCORING_RECEIPT.read_text())
    if score.get("schema_version") != "sku-next-dev-gate-score-v1" or score.get("phase") != "dev_score":
        problems.append("dev-score-schema-or-phase-mismatch")
    for obj, title in ((score, "score"), (completion, "completion")):
        if obj.get("source_split") != "dev" or obj.get("independent_test") is not False:
            problems.append(f"{title}-not-marked-dev-only")
        if obj.get("membership_sha256") != "ab90d19dc4065be564acb8fe7d57d966d9c82f8018b1482de515083ab39f3a58":
            problems.append(f"{title}-membership-sha-mismatch")
    if completion.get("schema_version") != "sku-next-dev-score-completion-v1" or completion.get("root_go") is not True or completion.get("scoring_completed") is not True:
        problems.append("score-completion-root-go-or-status-missing")
    frozen = completion.get("frozen_files", {})
    for rel, path in ((SCORE.relative_to(ROOT).as_posix(), SCORE), (REFERENCES.relative_to(ROOT).as_posix(), REFERENCES)):
        pin = frozen.get(rel)
        if not isinstance(pin, dict) or pin.get("bytes") != path.stat().st_size or pin.get("sha256") != digest(path):
            problems.append(f"score-completion-output-pin-mismatch:{rel}")
    if score.get("selected_case_count") != 40 or score.get("selected_product_count") != 20 or score.get("selected_reference_count") != 40:
        problems.append("dev-score-selected-count-mismatch")
    refs = [json.loads(line) for line in REFERENCES.read_text().splitlines() if line.strip()]
    ref_ids = [row.get("case_id") for row in refs]
    if len(refs) != 40 or any(not isinstance(x, str) for x in ref_ids) or len(set(ref_ids)) != 40:
        problems.append("dev-selected-references-not-exactly-40-unique-cases")
    if REPORT.is_file():
        report = REPORT.read_text()
        if "source_split: dev" not in report and "開発" not in report and "DEV" not in report:
            problems.append("root-report-does-not-identify-development-result")
        if "independent_test" not in report and "独立テストではない" not in report and "独立testではない" not in report:
            problems.append("root-report-does-not-disclaim-independent-test-status")
    else:
        problems.append(f"missing-final-report:{REPORT.relative_to(ROOT)}")
    return not problems, problems


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--root-go", action="store_true", help="explicit root authorization after the score and report review")
    args = parser.parse_args()
    files, raw_sources, missing = gather()
    dependencies = []
    for dependency in EXTERNAL:
        path = ROOT / dependency["path"]
        item = dict(dependency, present=path.is_file())
        if path.is_file():
            item.update(bytes=path.stat().st_size, actual_sha256=digest(path), sha256_matches=digest(path) == dependency["sha256"])
        dependencies.append(item)
    score_valid, score_problems = verify_score_outputs()
    source_valid = not any("frozen-source-pin-mismatch" in item or "raw-source-" in item or "source-handoff-" in item for item in missing)
    report = {
        "schema_version": "sku-next-dev-checkpoint-preflight-v1",
        "label_archives_or_contents_opened_by_builder": False,
        "selected_dev_score_ready": score_valid,
        "score_problems": score_problems,
        "source_capture_pins_verified": source_valid,
        "raw_capture_count": len(raw_sources),
        "selected_file_count": len(files) + len(raw_sources),
        "uncompressed_payload_bytes": sum(path.stat().st_size for path, _ in files) + sum(x.expected_bytes for x in raw_sources),
        "missing_expected_files_or_pins": missing,
        "external_dependencies": dependencies,
        "excluded": "full gold/reference archives (including labels-token), model weights, secrets, .env and .deps",
        "build_ready": not missing and score_valid and source_valid and all(row.get("sha256_matches") is True for row in dependencies),
    }
    BUILD.mkdir(parents=True, exist_ok=True)
    (BUILD / "preflight.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    # Estimate DEFLATE without writing a ZIP; this remains label-archive blind.
    compressed = 0
    for path, _ in files:
        co = zlib.compressobj(6, zlib.DEFLATED, -15)
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                compressed += len(co.compress(block))
        compressed += len(co.flush())
    if raw_sources:
        with zipfile.ZipFile(HANDOFF) as source:
            for capture in raw_sources:
                co = zlib.compressobj(6, zlib.DEFLATED, -15)
                with source.open(capture.member) as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b""):
                        compressed += len(co.compress(block))
                compressed += len(co.flush())
    report["deflate_payload_estimate_bytes"] = compressed
    report["estimated_zip_bytes"] = compressed + (len(files) + len(raw_sources)) * 220 + 8000
    report["github_100mb_headroom_bytes"] = 100_000_000 - report["estimated_zip_bytes"]
    (BUILD / "preflight.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))
    if not args.build:
        return 0
    if not args.root_go:
        raise SystemExit("refusing ZIP build without explicit --root-go")
    if not report["build_ready"]:
        raise SystemExit("refusing ZIP build: score/report/source pins/dependencies are incomplete")
    manifest_path = OUT.with_suffix(OUT.suffix + ".manifest.json")
    if OUT.exists() or SHA_PATH.exists() or manifest_path.exists():
        raise SystemExit(f"refusing overwrite of any existing final ZIP/sidecar: {OUT}")

    # The final score's selected-reference output is allowlisted; source label
    # archives themselves are never inserted into this checkpoint.
    members = []
    tmp_archive = OUT.with_name(OUT.name + f".partial-{os.getpid()}")
    tmp_manifest = manifest_path.with_name(manifest_path.name + f".partial-{os.getpid()}")
    tmp_sha = SHA_PATH.with_name(SHA_PATH.name + f".partial-{os.getpid()}")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(tmp_archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as target:
            for path, arc in files:
                if not safe(arc):
                    raise RuntimeError(f"unsafe checkpoint path: {arc}")
                target.write(path, arc)
                members.append({"path": arc, "bytes": path.stat().st_size, "sha256": digest(path)})
            with zipfile.ZipFile(HANDOFF) as source:
                for capture in raw_sources:
                    raw_path = capture.member.removeprefix("raw_sources/")
                    data = source.read(capture.member)
                    if len(data) != capture.expected_bytes or sha_bytes(data) != capture.expected_sha256:
                        raise RuntimeError(f"raw-source changed between preflight and build: {raw_path}")
                    target.writestr(raw_path, data)
                    members.append({"path": raw_path, "bytes": len(data), "sha256": capture.expected_sha256,
                                    "origin_bundle_member": capture.member, "origin_archive_sha256": EXTERNAL[1]["sha256"]})
            if len({item["path"] for item in members}) != len(members):
                raise RuntimeError("duplicate checkpoint member path")
            target.writestr("CHECKPOINT_MANIFEST.json", json.dumps({**report, "members": members,
                                                                     "external_dependencies": dependencies,
                                                                     "archive": OUT.name}, indent=2, sort_keys=True) + "\n")
        with zipfile.ZipFile(tmp_archive) as archive:
            if archive.testzip() is not None:
                raise RuntimeError("ZIP CRC verification failed")
            names = archive.namelist()
            expected = {item["path"] for item in members} | {"CHECKPOINT_MANIFEST.json"}
            if len(names) != len(set(names)) or set(names) != expected:
                raise RuntimeError("ZIP member set differs from the allowlisted payload")
            for item in members:
                data = archive.read(item["path"])
                if len(data) != item["bytes"] or sha_bytes(data) != item["sha256"]:
                    raise RuntimeError(f"member bytes/SHA mismatch: {item['path']}")
        archive_sha = digest(tmp_archive)
        archive_bytes = tmp_archive.stat().st_size
        sidecar = {"schema_version": "sku-next-dev-checkpoint-archive-manifest-v1",
                   "archive": OUT.name, "archive_bytes": archive_bytes, "archive_sha256": archive_sha,
                   "payload_member_count": len(members), "member_count": len(members) + 1,
                   "crc_verified": True, "all_member_bytes_and_sha256_verified": True,
                   "members": members, "external_dependencies": dependencies}
        tmp_manifest.write_text(json.dumps(sidecar, indent=2, sort_keys=True) + "\n")
        tmp_sha.write_text(f"{archive_sha}  {OUT.name}\n")
        promoted = []
        try:
            os.link(tmp_archive, OUT); promoted.append(OUT)
            os.link(tmp_manifest, manifest_path); promoted.append(manifest_path)
            os.link(tmp_sha, SHA_PATH); promoted.append(SHA_PATH)
        except Exception:
            for path in promoted:
                path.unlink(missing_ok=True)
            raise
    finally:
        tmp_archive.unlink(missing_ok=True)
        tmp_manifest.unlink(missing_ok=True)
        tmp_sha.unlink(missing_ok=True)
    print(json.dumps({"archive": str(OUT), "bytes": archive_bytes, "sha256": archive_sha,
                      "manifest": str(manifest_path), "sha256_file": str(SHA_PATH),
                      "payload_member_count": len(members), "crc_verified": True,
                      "all_member_bytes_and_sha256_verified": True}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
