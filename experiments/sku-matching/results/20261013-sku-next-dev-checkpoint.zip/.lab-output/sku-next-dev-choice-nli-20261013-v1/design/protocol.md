# DEV40 directional whole-option NLI protocol

This package prepares a source-bound diagnostic over the frozen DEV40 handoff. It creates no NLI results, scores, gate decisions, or adoption policy. The existing strict literal-family proof remains protected and takes precedence in any later comparison. An NLI `support` or `explicit_conflict` is an experimental model judgment, never deterministic source proof; production adoption remains false.

Each original directional task gets one paired context and a vector covering every whole member of that task's full raw source-side option family, in its original order. The vector is checked against the source selector itself. The selected raw axis facts from both the exact selected SKU and exact AU row, all selected axes, each complete raw family, and eligible source-body blocks are attached through source-bound context records. Candidate values stay whole, including quantity, units, dimensions, ranges, parentheticals, and composite wording. Duplicate or malformed family members make the task abstention-only; no values are rekeyed.

The model may judge that two differently named coordinates refer to the same condition, but that is explicitly a model scope assessment. A complete family on one store does not establish cross-store identity or exclusivity by itself. For a decisive judgment, the model must explain the coordinate relationship and exclusivity basis, name the exact selected target facts it assessed, and cite both the selected source fact and the exact whole candidate member. A direct `explicit_conflict` must state that the complete candidate option is incompatible with the actual selected SKU fact for the model-assessed same condition. A different winner, alternative plausibility, omitted mention, raw inequality, numeric difference, or implicit mismatch alone stays `unknown`.

The model output is a per-option vector, not a single winner. It has no requested/desired value field, no prior prediction, no producer status/hint, no score, no label, and no test data. It receives the exact selected SKU facts because those are the source evidence it must judge. Axis names and values are provided as separate source fields; no constructed `axis: value` string is presented as a literal quote.

## Response shape

```json
{
  "protocol": "sku-directional-choice-nli-v1",
  "pair_id": "choice-pair:<sha256>",
  "cache_key": "<sha256>",
  "task_binding": {"task_id": "...", "request_id": "...", "case_id": "...", "dossier_id": "...", "au_product_id": "...", "au_row_key": "...", "source_sku_key": "...", "direction": "rakuten_to_au"},
  "request_binding": {"request_id": "...", "request_sha256": "...", "target_document_id": "...", "target_document_sha256": "..."},
  "scope_status": "model_assessed_unproved",
  "sourceproof_certified": false,
  "production_adoption_allowed": false,
  "judgments": [
    {
      "option_index": 0,
      "whole_option": "exact original whole string",
      "option_evidence_id": "raw-span:<sha256>",
      "whole_value_assessed": true,
      "state": "support | explicit_conflict | unknown",
      "scope_assessment": "same_condition | different_condition | uncertain",
      "scope_explanation": "model assessment and evidence",
      "semantic_relation": "support | explicit_conflict | uncertain",
      "coordinate_relation_explanation": "model explanation",
      "exclusivity_assessment": "source_family | source_body | model_assessed | uncertain",
      "exclusivity_explanation": "model explanation",
      "option_relation_explanation": "assessment of this complete value against exact selected facts",
      "target_fact_ids": ["raw-span:<selected target field SHA>"],
      "citations": [
        {"evidence_id": "raw-span:<sha256>", "start": 10, "end": 14, "quote": "literal", "source_sha256": "<raw source SHA>"},
        {"evidence_id": "body-block:<block id>", "start": 0, "end": 14, "quote": "literal body excerpt", "source_sha256": "<raw source SHA>", "document_id": "...", "document_sha256": "..."}
      ]
    }
  ]
}
```

Every `option_index` and `whole_option` must match the original ordered family exactly. A decisive state needs a source citation for the raw whole-option member and a direct citation for at least one exact selected target fact. When the target side has one exact same-name axis, the validator binds the judgment to that raw fact; when names differ, the model's relation assessment remains semantic and unproved. `unknown` is always allowed.

## Citation and source rules

- Exact SKU facts come from each task's raw selected-axis field and its raw span. Label spans and value spans stay separate, and every raw source SHA, locator, offset, and quote is checked.
- Complete Rakuten and AU option families are re-derived from the corresponding raw selector fields. Whole family members carry their own raw spans and selected/unselected roles. Family completeness is provenance, not proof that another store uses the same coordinate.
- Body evidence comes only from the existing anchor-excluded `build_scoped_html_blocks_v1` extractor and its renderer. Each eligible block carries its raw JSON field, raw SHA, exact HTML block span, block ID, visible support text, and source run refs. Body citations use offsets inside that exact block support text; the validator re-extracts the block from the pinned raw field.
- Metadata alone, titles, unscoped sibling claims, category/case rules, normalized values, stripped cores, residuals, and candidate rankings cannot support a decisive result.
- The validator checks schema, task/context identity, exact source spans and SHAs, full family order/coverage, citation offsets, and required model assessment fields. It cannot establish that the model's semantic explanation is true.

## Exact paired cache key

The cache key binds direction, original task and row identities, target and source document SHAs, all selected source facts, full source and target families, and the complete ordered hypothesis family. Context identities remain in the key, so results cannot be shared across distinct cases or rows. It does not include prediction outputs because no inference is part of this preparation.

