# Source preparation handoff

The builder consumed only the frozen DEV40 source-only handoff at `../../sku-next-dev-v7-adapter-20261013-v1/full-gate-inputs-v2/`. It verified the handoff file SHAs, every selected axis raw span, the full raw option family for each task, and paired selected facts from the exact case and AU row. It used no task status, fresh-v7 hint, prediction, label, worker response, or test data.

The prepared package retains all 1,924 original tasks: 962 Rakuten-to-AU and 962 AU-to-Rakuten. Every task has a full ordered option vector and a source-bound context. Invalid or duplicate families would have been retained as abstention-only rows instead of being silently dropped or rekeyed; this frozen bundle produced zero preparation abstentions and zero selected-fact source errors.

`model-pairs.jsonl` is the compact per-task request/vector. Join `paired-contexts.jsonl` by `context_id` for all selected raw-axis facts, complete families, exact task/row/SKU bindings, and paired document IDs. Join `source-documents.jsonl` by document ID for existing eligible anchor-excluded body blocks. The 20 AU documents yielded 422 eligible blocks; the 20 Rakuten documents have no route through the existing eligible-block extractor, and are explicitly marked as having no eligible block route. No other document body text is supplied as evidence.

`validation-bindings.jsonl` is validator-only metadata and must not be sent to the model. It records exact-name target-axis bindings for checking an otherwise decisive response. `preparation-errors.jsonl` is empty for this input. The validator rechecks prepared-file SHAs and cited raw/body spans against the pinned source capture.

The cache key is per exact task context, direction, source and target document hashes, selected facts, complete raw families, and ordered option vector. It is not shared across a different case or row.
