#!/usr/bin/env python3
"""Assemble and freeze DEV40 whole-SKU outputs before selected-label access."""
from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import evaluate_dev_source_bound_whole_sku_gate_v1 as GATE
import grade_fresh_dev_sku_gate_v1 as GRADE

def rows(p):
    with p.open() as f:
        return [json.loads(x) for x in f if x.strip()]
def pin(p):
    return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def jwrite(p,obj):
    with p.open('x') as f:
        json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
def rwrite(p,items):
    with p.open('x') as f:
        for obj in items:
            f.write(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
def main():
    b=HERE/'full-gate-inputs-v8';n=ROOT/'.lab-output/sku-next-dev-choice-nli-20261013-v2'
    e=ROOT/'.lab-output/sku-next-dev-choice-nli-execution-20261013-v1'
    p=ROOT/'.lab-output/sku-next-dev-literal-family-proofs-20261013-v1'
    baseline=ROOT/'.lab-output/sku-next-dev-baseline-source-projection-20261013-v1'
    out=HERE/'final-gate-run';out.mkdir()
    tasks=rows(b/'tasks.jsonl'); requests=rows(b/'requests.jsonl');cases=rows(b/'case-plans.jsonl');aurows=rows(b/'row-plans.jsonl')
    assert (len(tasks),len(requests),len(cases),len(aurows))==(1924,1045,40,504)
    assert pin(b/'membership.jsonl')['sha256']==GRADE.MEMBERSHIP_SHA256
    validated=rows(e/'source-validation-v1/validated-pairs.jsonl')
    statuses=rows(e/'source-validation-v1/validation-statuses.jsonl')
    assert len(statuses)==238
    assert {v['pair_id'] for v in validated}=={v['pair_id'] for v in statuses if v['status']=='source_metadata_valid'}
    taskproofs=rows(p/'task-proof-states.jsonl');sourcereceipts=rows(p/'task-source-verification.jsonl')
    resolutions={
        'choice_nli_full':GATE.build_choice_nli_task_resolutions(tasks,rows(n/'validation-bindings.jsonl'),validated,taskproofs,sourcereceipts),
        'baseline_literal_overlay':GATE.baseline_task_resolutions(tasks,
            GATE.project_baseline_literal_overlay(requests,rows(p/'request-proof-statuses.jsonl'),
                GATE.index(rows(baseline/'request-states.jsonl'),'request_id','fresh baseline request')))}
    mapping={'choice_nli_full':'explicit-choice-nli-experimental','baseline_literal_overlay':'baseline-literal-overlay'}
    variants={};gatefiles=[];summary={}
    for internal,items in resolutions.items():
        name=mapping[internal];v=out/name;v.mkdir();result=GATE.finish_whole_sku_gate(internal,cases,aurows,tasks,items)
        for filename,data in [('task-resolutions.jsonl',items),('all-row-results.jsonl',result['rows']),('case-decisions.jsonl',result['decisions'])]:
            q=v/filename;rwrite(q,data);gatefiles.append(str(q.relative_to(ROOT)))
        summary[name]={k:result[k] for k in ('task_state_counts','row_state_counts','decision_counts')}
        summary[name]['task_sources']=dict(Counter(x['source'] for x in items))
        variants[name]={'predictions':str((v/'case-decisions.jsonl').relative_to(ROOT)),
                       'gate_files':[str((v/f).relative_to(ROOT)) for f in ('case-decisions.jsonl','all-row-results.jsonl','task-resolutions.jsonl')]}
    jwrite(out/'gate-summary.json',{'source_split':'dev','independent_test':False,'labels_read':False,'variants':summary})
    paths=set()
    for receiptpath in (e/'experiment-freeze.json',e/'root-policy-review-and-go.json',e/'root-citation-metadata-normalization-go.json'):
        receipt=json.loads(receiptpath.read_text())
        for rel,expected in receipt['frozen_files'].items():
            q=ROOT/rel
            if rel=='.lab-output/sku-next-dev-literal-family-proofs-20261013-v1/manifest.json':
                supplement=json.loads((e/'proof-manifest-metadata-reconciliation.json').read_text())
                assert expected==supplement['original_pin'];assert pin(q)==supplement['current_pin']
            else:
                assert pin(q)==expected,rel
            paths.add(rel)
        paths.add(str(receiptpath.relative_to(ROOT)))
    # Source-only runtime dependency freeze and inference outputs; no model weights or label archives.
    for d in [e/'completed-response-snapshot-v1',e/'citation-normalization-v1',e/'source-validation-v1',baseline,
              ROOT/'.lab-output/sku-next-dev-fresh-baseline-20261013-v1/model-run/model-run']:
        for q in d.iterdir():
            if q.is_file():paths.add(str(q.relative_to(ROOT)))
    for q in [e/'proof-manifest-metadata-reconciliation.json',e/'validate_completed_responses.py',e/'dispatch-trace.json',Path(__file__),
              out/'gate-summary.json',ROOT/'experiments/sku-matching/route_mixed_sku_references_v1.py',
              ROOT/'experiments/sku-matching/grade_final_test_subset_v1.py',
              ROOT/'experiments/sku-matching/integrate_claude_description_v1.py']:
        paths.add(str(q.relative_to(ROOT)))
    paths.update(gatefiles)
    inputfiles={key:str((b/file).relative_to(ROOT)) for key,file in [('membership','membership.jsonl'),('case_plans','case-plans.jsonl'),('row_plans','row-plans.jsonl'),('selection_plan','selection-plan.json')]}
    paths.update(inputfiles.values())
    code={'grader_code_sha256':'experiments/sku-matching/grade_fresh_dev_sku_gate_v1.py',
          'reference_parser_helper_sha256':'experiments/sku-matching/route_mixed_sku_references_v1.py',
          'score_helper_sha256':'experiments/sku-matching/grade_final_test_subset_v1.py',
          'grader_tests_sha256':'tests/test_lab_fresh_dev_sku_gate.py'}
    paths.update(code.values())
    receipt={'schema_version':'sku-next-dev-grading-freeze-v1','freeze_status':'all_dev_predictions_and_gates_frozen',
             'created_at_utc':datetime.datetime.now(datetime.UTC).isoformat(),'source_split':'dev','independent_test':False,
             'all_predictions_frozen':True,'all_gates_frozen':True,'labels_read':False,'test_split_read':False,
             'policy_or_threshold_changed':False,'classifier_outputs_changed_after_freeze':False,
             'membership_sha256':GRADE.MEMBERSHIP_SHA256,'variants':variants,'gate_files':gatefiles,'input_files':inputfiles,
             'required_artifact_paths':sorted(paths),'frozen_files':{rel:pin(ROOT/rel) for rel in sorted(paths)},
             **{key:pin(ROOT/rel)['sha256'] for key,rel in code.items()},
             'metadata_supplement_receipts':[str((e/f).relative_to(ROOT)) for f in ('proof-manifest-metadata-reconciliation.json','root-citation-metadata-normalization-go.json')],
             'worker_0_pre_snapshot_cleanup_disclosed_in':str((e/'completed-response-snapshot-v1/snapshot-receipt.json').relative_to(ROOT)),
             'production_adoption_allowed':False}
    jwrite(out/'dev-grading-freeze.json',receipt)
    GRADE.validate_dev_freeze_receipt(out/'dev-grading-freeze.json',membership_path=b/'membership.jsonl',case_plans_path=b/'case-plans.jsonl',row_plans_path=b/'row-plans.jsonl',selection_plan_path=b/'selection-plan.json',expected_variants=set(mapping.values()))
    GRADE.validate_dev_membership(b/'membership.jsonl',b/'case-plans.jsonl',b/'row-plans.jsonl',b/'selection-plan.json')
    print(json.dumps({'freeze_sha256':pin(out/'dev-grading-freeze.json')['sha256'],'frozen_file_count':len(paths),'variants':summary},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
