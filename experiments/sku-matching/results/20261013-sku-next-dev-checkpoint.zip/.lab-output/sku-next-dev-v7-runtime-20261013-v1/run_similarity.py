"""Pinned-local-model adapter that invokes the archived similarity function unchanged."""
from __future__ import annotations
import argparse
import pathlib
import sys

RUNTIME = pathlib.Path(__file__).resolve().parent
MODEL_DIR = pathlib.Path('.deps/sku-original-small-reranker/model').resolve()
CODE = RUNTIME / 'producer/v7/align_sku_conditions.py'
sys.path.insert(0, str(CODE.parent))

import huggingface_hub

def pinned_snapshot_download(repo_id, revision=None, **kwargs):
    expected = ('hotchpotch/japanese-reranker-small-v2', 'e8091d132c23b372e059505edbb9255f346100d3')
    if (repo_id, revision) != expected:
        raise RuntimeError(f'unexpected model request: {(repo_id, revision)!r}')
    if kwargs.get('local_files_only') is False:
        raise RuntimeError('network loading disabled in inference adapter')
    return str(MODEL_DIR)

huggingface_hub.snapshot_download = pinned_snapshot_download
import align_sku_conditions as archived

args = argparse.Namespace(run='run', out='out', threads=4)
archived.similarity(args)
