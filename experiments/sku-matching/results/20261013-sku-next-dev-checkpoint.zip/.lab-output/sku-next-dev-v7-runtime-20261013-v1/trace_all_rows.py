"""Separate, label-free all-row trace using archived v7 functions on frozen DEV scores."""
from __future__ import annotations
import argparse, hashlib, json, math, pathlib, sys
import numpy as np
RUNTIME=pathlib.Path(__file__).resolve().parent
CODE=RUNTIME/'producer/v7/align_sku_conditions.py'
sys.path.insert(0,str(CODE.parent))
import align_sku_conditions as v7


def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def clean(x):
 if isinstance(x,dict): return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)): return [clean(v) for v in x]
 if isinstance(x,np.generic): return clean(x.item())
 if isinstance(x,float) and (math.isnan(x) or math.isinf(x)): return None
 return x

run=RUNTIME/'run'; out=RUNTIME/'out'; dest=out/'trace'; dest.mkdir(parents=True,exist_ok=True)
contexts,cases,_,_=v7.load(run)
pairs,axes=v7.tables(out)
rows=[]; casecount=0; aurowtotal=0
for case in cases:
 d=case['dossier_id']; ctx=contexts[d]
 conds=v7.conditions(case,ctx,pairs[d],*axes[d])
 states=v7.row_states(conds)
 decision,top,reason=v7.decide(states)
 selected={a['axis_key']:{k:a[k] for k in ('axis_key','axis_label','value','family_values','value_span')} for a in case['rakuten_selected']['axes']}
 optionmap={n:list(dict.fromkeys(a['value'] for r in ctx['au_rows'] for a in r['axes'] if a['axis_name']==n))
            for n in dict.fromkeys(a['axis_name'] for r in ctx['au_rows'] for a in r['axes'])}
 rowkeys=[r['row_key'] for r in ctx['au_rows']]
 assert len(rowkeys)==len(set(rowkeys))
 assert set(states.index)==set(rowkeys),(case['case_id'],len(states),len(rowkeys))
 case_records=[]
 for aurow in ctx['au_rows']:
  key=aurow['row_key']; c=conds[conds['row_key']==key]
  condition_records=[]
  for rec in c.drop(columns='row_key').to_dict('records'):
   condition_records.append(clean(rec))
  auaxes=[{k:a[k] for k in ('axis_name','value','value_span')} for a in aurow['axes']]
  state=str(states.loc[key])
  case_records.append({'case_id':case['case_id'],'dossier_id':d,'au_product_id':case['au_product_id'],'au_row_key':key,
   'case_decision':decision,'case_top_row_key':top,'case_reason':reason,'state':state,
   'pending_description_check_candidate':state=='pending_description_check',
   'heuristic_status_is_untrusted_hint':True,
   'rakuten_axes':selected,'au_row_axes':auaxes,'au_axis_options':optionmap,'conditions':condition_records})
 rows.extend(case_records); casecount+=1; aurowtotal+=len(case_records)
path=dest/'all-row-trace.jsonl'
assert not path.exists()
path.write_text(''.join(json.dumps(clean(x),ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n' for x in rows),encoding='utf-8')
sourcefile={}
for version in ('v2','v3'):
 p=pathlib.Path(f'.lab-output/sku-independent-real-20261011/eval-{version}/run-token/inputs/cases.jsonl')
 for n,line in enumerate(p.open(encoding='utf-8'),1):
  c=json.loads(line)
  if c['case_id'] in {x['case_id'] for x in cases}: sourcefile[c['case_id']]={'source_input':str(p),'source_line':n,'source_sha256':sha(p)}
manifest={'schema_version':'sku_v7_all_row_trace_manifest_v1','split':'dev','independent_test':False,'labels_read':False,
 'prediction_inputs_read':False,'trace_kind':'separate recomputation from frozen similarity output using unchanged archived tables/conditions/row_states/decide functions; this is not the archived align() run',
 'all_condition_status_core_residual_fields_are_untrusted_heuristic_hints':True,'no_source_proof_or_gate_conflict_is_claimed':True,
 'case_count':casecount,'au_row_trace_count':aurowtotal,'trace_sha256':sha(path),
 'inputs':{'cases_sha256':sha(run/'inputs/cases.jsonl'),'products_sha256':sha(run/'inputs/products.jsonl'),
           'similarities_jsonl_sha256':sha(out/'similarities.jsonl'),'similarities_manifest_sha256':sha(out/'similarities.json')},
 'producer_code_sha256':sha(CODE),'archive_member_sha256':'173c9c90157278147740f3c885ba5fae9144152b0d20493a19056eb3efba5a7e',
 'runtime_freeze_sha256':sha(RUNTIME/'experiment-freeze.json'),'source_case_record_line_bindings':sourcefile,
 'pair_count':json.loads((out/'similarities.json').read_text())['pairs_scored'],
 'outputs_sha256':{'all-row-trace.jsonl':sha(path)}}
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('case_count','au_row_trace_count','trace_sha256','pair_count','outputs_sha256')},ensure_ascii=False))
