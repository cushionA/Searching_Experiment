#!/usr/bin/env python3
"""Diagnostic PhraseMatcher view for unresolved native SKU requests."""
from __future__ import annotations

from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
import time

from spacy.matcher import PhraseMatcher
import spacy
from run_installed_library_selection_v1 import catalogs, selected_state

def read_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def write_jsonl(path, rows):
    with path.open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n")


def run(spec_dir: Path, catalog_dir: Path, views_path: Path, output: Path):
    run_start = time.perf_counter()
    if output.exists():
        raise FileExistsError(output)
    input_paths = [spec_dir / "requests.jsonl", spec_dir / "documents.jsonl",
                   spec_dir / "spec-table-selections.jsonl", spec_dir / "SPEC_TABLE_POLICY.json",
                   catalog_dir / "requests.jsonl", catalog_dir / "documents.jsonl", views_path]
    pins = {str(p): digest(p) for p in input_paths}
    requests, documents, selections = (read_jsonl(p) for p in input_paths[:3])
    catalog_requests, catalog_documents = (read_jsonl(p) for p in input_paths[4:6])
    policy = json.loads(input_paths[3].read_text(encoding="utf-8"))
    view_data = json.loads(views_path.read_text(encoding="utf-8"))
    view = view_data["views"]["spacy_norm"]
    if len(documents) != 40 or len(selections) != 40:
        raise ValueError("frozen DEV40 document/selection coverage required")
    docs = {d["document_id"]: d for d in documents}
    selected = {d["document_id"]: d for d in selections}
    if len(docs) != 40 or set(docs) != set(selected):
        raise ValueError("frozen spec table selection/document IDs differ")
    if any(docs[k]["document_sha256"] != selected[k]["document_sha256"] for k in docs):
        raise ValueError("spec table selection/document SHA mismatch")
    if policy.get("semantic_or_sku_scope_proof") is not False:
        raise ValueError("spec policy proof contract changed")

    catalog_docs, families = catalogs(catalog_requests, catalog_documents)
    classified = []
    for request in requests:
        state, reason = selected_state(request, catalog_docs, families, view)
        if state == "unknown":
            classified.append((request, reason))

    matcher_start = time.perf_counter()
    nlp = spacy.blank("ja")
    matcher = PhraseMatcher(nlp.vocab, attr="NORM")
    option_id = {}
    for index, value in enumerate(dict.fromkeys(
            value for request in requests for value in request.get("option_values", [])
            if isinstance(value, str) and value)):
        pattern = nlp.make_doc(value)
        if not len(pattern):
            continue
        label = f"request_option_{index}"
        matcher.add(label, [pattern])
        option_id[label] = value
    matcher_build_seconds = time.perf_counter() - matcher_start

    def find(text, scope, source_refs):
        doc = nlp.make_doc(text)
        result = []
        for match_id, start, end in matcher(doc):
            begin, finish = doc[start].idx, doc[end - 1].idx + len(doc[end - 1].text)
            result.append({"option_value": option_id[nlp.vocab.strings[match_id]],
                           "scope": scope, "start": begin, "end": finish,
                           "source_span": [begin, finish], "quote": text[begin:finish],
                           "source_refs": source_refs})
        return result
    body_cache, title_cache = {}, {}
    start_time = time.perf_counter()
    observations = []
    for request, state_reason in classified:
        document_id = request["target_document_id"]
        document, selection = docs[document_id], selected[document_id]
        allowed = set(v for v in request.get("option_values", []) if isinstance(v, str))
        mode = selection.get("mode")
        if mode == "spec_table":
            sources = [(i, table.get("text", ""), [table.get("source_ref")])
                       for i, table in enumerate(selection.get("tables", []))]
        else:
            sources = [(0, selection.get("text", ""), selection.get("raw_sources", []))]
        key = (document_id, mode)
        if key not in body_cache:
            body_cache[key] = [find(text, f"{mode}:segment:{i}", refs)
                               for i, text, refs in sources]
        segment_hits = [hit for group in body_cache[key] for hit in group
                        if hit["option_value"] in allowed]
        route = "spec_table" if mode == "spec_table" else "full_body_fallback"
        focus = []
        hits = segment_hits
        if segment_hits:
            found_indices = {int(hit["scope"].rsplit(":", 1)[1]) for hit in segment_hits}
            focus_indices = {j for i in found_indices for j in range(max(0, i - 1), min(len(sources), i + 2))}
            focus = [{"segment_index": i, "scope": sources[i][0] if mode == "spec_table" else "full_body",
                      "text": sources[i][1], "source_refs": sources[i][2]} for i in sorted(focus_indices)]
        elif mode == "spec_table":
            body = document.get("description", {}).get("text", "")
            body_refs = [segment.get("input_ref") for segment in document.get("description", {}).get("segments", [])]
            if document_id not in body_cache:
                body_cache[document_id] = find(body, "description_full_fallback", body_refs)
            hits = [hit for hit in body_cache[document_id] if hit["option_value"] in allowed]
            route = "full_body_fallback_after_table_miss"
            focus = [{"segment_index": 0, "scope": route, "text": body, "source_refs": body_refs}]
        else:
            body = selection.get("text", "")
            focus = [{"segment_index": 0, "scope": "full_body_fallback", "text": body,
                      "source_refs": selection.get("raw_sources", [])}]

        if document_id not in title_cache:
            title = document.get("title", {})
            title_cache[document_id] = find(title.get("text", ""), "title", title.get("source_refs", []))
        title_hits = [hit for hit in title_cache[document_id] if hit["option_value"] in allowed]
        observations.append({
            "request": request, "native_state": "unknown", "native_state_reason": state_reason,
            "target_document_id": document_id, "target_document_sha256": document["document_sha256"],
            "spec_selection_mode": mode, "search_route": route,
            "matched_description_hits": hits, "matched_title_hits": title_hits,
            "reading_focus_segments": focus,
            "full_original_description": document.get("description"),
            "semantic_or_sku_scope_proof": False, "production_adoption_allowed": False,
            "matches_are_reading_focus_only": True,
        })

    output.mkdir(parents=True)
    write_jsonl(output / "request-observations.jsonl", observations)
    write_jsonl(output / "document-snapshots.jsonl",
                [{"document": d, "spec_table_selection": selected[d["document_id"]]} for d in documents])
    summary = {
        "schema": "probe-library-residual-text-v1", "request_count": len(requests),
        "unknown_request_count": len(observations),
        "unknown_by_state_reason": dict(Counter(o["native_state_reason"] for o in observations)),
        "description_hits": sum(bool(o["matched_description_hits"]) for o in observations),
        "title_hits": sum(bool(o["matched_title_hits"]) for o in observations),
        "no_match_full_fallback_count": sum(not o["matched_description_hits"] for o in observations),
        "selection_modes": dict(Counter(d["mode"] for d in selections)),
        "table_selection_policy": policy, "source_pins": pins,
        "code_sha256": digest(Path(__file__)), "selection_helper_sha256": digest(Path(__file__).with_name("run_installed_library_selection_v1.py")),
        "views_sha256": pins[str(views_path)], "spacy_version": view_data["versions"]["spaCy"],
        "trained_components": [], "handwritten_matcher_patterns": False,
        "models": [], "teacher_labels_used": False,
        "patterns_source": "request.option_values verbatim; PhraseMatcher attr=NORM",
        "accept_reject_or_absence_claims": False, "labels_read": False,
        "production_adoption_allowed": False, "matching_seconds": time.perf_counter() - start_time,
        "matcher_build_seconds": matcher_build_seconds, "total_seconds": time.perf_counter() - run_start,
    }
    write_json(output / "SUMMARY.json", summary)
    if any(digest(p) != pins[str(p)] for p in input_paths):
        raise ValueError("input changed during run")
    return summary


if __name__ == "__main__":
    base = Path(".lab-output")
    root = base / "sku-v7-small-nli-spec-first-20261014-v1/host"
    catalog = base / "sku-classical-parser-20261015-v1/population-inputs"
    views = base / "sku-installed-library-matching-20261015-v1/views.json"
    output = base / "sku-installed-library-matching-20261015-v1/residual-text-v1"
    print(json.dumps(run(root, catalog, views, output), ensure_ascii=False))
