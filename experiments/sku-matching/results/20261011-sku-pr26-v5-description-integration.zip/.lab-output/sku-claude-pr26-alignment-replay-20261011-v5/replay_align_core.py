"""Execute reviewed v5 alignment functions on frozen corresponding SKU input fields.
No score step, annotation reference, source labels or model weights are loaded.
Only algorithm-consumed fields are replayed; original producer context bytes and
its rule-baseline predictions are unavailable, so the fifth diff file is not run.
"""
from collections import Counter
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import time
import platform
import numpy,pandas
ROOT=Path('/workspace/Searching_Experiment-model-gates-20261010')
REVIEW=ROOT/'.lab-output/sku-claude-pr26-review-20261011-v5'
DEST=ROOT/'.lab-output/sku-claude-pr26-alignment-replay-20261011-v5'
DEST.mkdir(exist_ok=False)
SOURCE=REVIEW/'align_sku_conditions.py'
EXPECTED_CODE='70e75088c40e4fc600c7ed91abaf237842ed7ea6f4d99c58bb40723d751280c3'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(SOURCE.read_bytes())==EXPECTED_CODE
spec=importlib.util.spec_from_file_location('reviewed_pr26_v5_source',SOURCE)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
INPUT=ROOT/'.lab-output/sku-integrated-inputs-20261010-v1/inputs'
meta=json.loads((INPUT/'manifest.json').read_text())
for n in ('cases.jsonl','products.jsonl'):
 assert sha((INPUT/n).read_bytes())==meta['output_sha256']['inputs/'+n]
cases={r['case_id']:r for r in m.read_jsonl(INPUT/'cases.jsonl')}
products={r['dossier_id']:r for r in m.read_jsonl(INPUT/'products.jsonl')}
receipts={};started=time.perf_counter()
for cohort in ('legacy','family'):
 upstream=REVIEW/'payload/.lab-output/sku-align-20261011-v5'/cohort
 sims=m.read_jsonl(upstream/'similarities.jsonl')
 localcases=[cases[i] for i in meta['bundle_inputs'][cohort]['case_ids']]
 # Every complete selector family and fixed AU option is identical to the
 # frozen similarity query material. No semantic label is read.
 rak={};au={}
 for c in localcases:
  for a in c['rakuten_selected']['axes']:
   for v in a['family_values']:
    rak.setdefault(c['dossier_id'],{}).setdefault((a['axis_key'],v),a['axis_label'])
 rak={d:[[k,label,v] for (k,v),label in opts.items()] for d,opts in rak.items()}
 for d in meta['bundle_inputs'][cohort]['dossier_ids']:
  au[d]=[list(o) for o in dict.fromkeys((a['axis_name'],a['value']) for r in products[d]['au_rows'] for a in r['axes'])]
 assert set(rak)=={s['dossier_id'] for s in sims}
 for s in sims:
  assert rak[s['dossier_id']]==s['rakuten']
  assert au[s['dossier_id']]==s['au']
 pairs={s['dossier_id']:m.value_pairs(s) for s in sims}
 axes={s['dossier_id']:m.axis_pairs(pairs[s['dossier_id']],s['au']) for s in sims}
 decisions=[];handoff=[]
 for case in localcases:
  d,sel=case['dossier_id'],case['rakuten_selected'];context=products[d]
  conds=m.conditions(case,context,pairs[d],*axes[d]);states=m.row_states(conds)
  decision,top,reason=m.decide(states)
  decisions.append({'case_id':case['case_id'],'dossier_id':d,'decision':decision,'top_row_key':top,
                    'reason':reason,'row_states':states.value_counts().to_dict()})
  for rowkey in states.index[states=='pending_description_check']:
   mine=conds[conds['row_key']==rowkey]
   handoff.append({'case_id':case['case_id'],'dossier_id':d,'au_product_id':case['au_product_id'],
     'au_row_key':rowkey,'au_product_source':{k:context['au_product'][k] for k in ('raw_file','sha256')},
     'rakuten_sku':{k:sel[k] for k in ('source_sku_key','sku_record_key','variant_id','url','raw_file','sha256')},
     'conditions':mine.drop(columns='row_key').to_dict('records'),
     'rakuten_axes':{a['axis_key']:{'family_values':a['family_values'],'value_span':a['value_span']} for a in sel['axes']}})
 payload={'value_pairs.jsonl':[{'dossier_id':d,**r} for d,t in sorted(pairs.items()) for r in t.to_dict('records')],
          'axes.jsonl':[{'dossier_id':d,'symmetric':s,'au_only':a} for d,(s,a) in sorted(axes.items())],
          'decisions.jsonl':decisions,'handoff.jsonl':handoff}
 summary=json.loads((upstream/'align/summary.json').read_text())
 out=DEST/cohort;out.mkdir()
 checks={}
 for name,rows in payload.items():
  m.write_new(out/name,rows)
  got=sha((out/name).read_bytes());expected=summary['outputs_sha256'][name]
  checks[name]={'replayed_sha256':got,'upstream_sha256':expected,'identical':got==expected,'row_count':len(rows)}
 receipts[cohort]={'checks':checks,'similarity_sha256':sha((upstream/'similarities.jsonl').read_bytes()),
 'case_count':len(localcases),'dossier_count':len(sims),'decision_counts':dict(Counter(r['decision'] for r in decisions))}
print(json.dumps(receipts,ensure_ascii=False,indent=2))
receipt={'upstream_head':'7b8f5abf20ad5428a9a1dd48f5b67a1a208a1ba8','upstream_code_sha256':EXPECTED_CODE,
 'replay_script_sha256':sha(Path(__file__).read_bytes()),'frozen_input_manifest_sha256':sha((INPUT/'manifest.json').read_bytes()),
 'frozen_inputs_sha256':{n:sha((INPUT/n).read_bytes()) for n in ('cases.jsonl','products.jsonl')},
 'input_source':'frozen integrated v9 inputs; every model-consumed whole option compared to v5 matrices',
 'producer_input_bytes_reverified':False,'model_inference_rerun':False,'alignment_executed':True,'labels_read':False,
 'old_rule_mask_used_for_alignment':False,'cohorts':receipts,'seconds':time.perf_counter()-started,
 'python':platform.python_version(),'numpy':numpy.__version__,'pandas':pandas.__version__,
 'not_replayed_outputs':{'diff-vs-rule-v10.jsonl':'Original full rule-baseline predictions unavailable. This diagnostic does not affect decisions/handoff.'}}
(DEST/'replay-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
(DEST/'replay_align_core.py').write_bytes(Path(__file__).read_bytes())
if not all(v['identical'] for c in receipts.values() for v in c['checks'].values()):sys.exit(1)
