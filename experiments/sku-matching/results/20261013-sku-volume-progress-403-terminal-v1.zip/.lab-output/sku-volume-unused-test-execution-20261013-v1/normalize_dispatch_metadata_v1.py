"""Preserve available event bytes and normalize duplicate bookkeeping only.

This module never reads classifier decision fields, changes drafts, runs a model,
or decides which semantic response to retain. The frozen collector owns drafts.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

EX = Path(__file__).resolve().parent


def decode_events(data: bytes) -> list[dict]:
    text = data.decode("utf-8")
    decoder = json.JSONDecoder()
    position = 0
    events = []
    while position < len(text):
        while position < len(text) and text[position].isspace():
            position += 1
        if text[position:position + 2] == "\\n":
            position += 2
            continue
        if position == len(text):
            break
        event, position = decoder.raw_decode(text, position)
        if not isinstance(event, dict):
            raise ValueError("event must be a JSON object")
        events.append(event)
    return events


def normalize(events: list[dict], expected_packets: set[str]) -> tuple[list[dict], dict]:
    spawns, terminals = {}, {}
    duplicate_spawn_rows, duplicate_terminal_rows = [], []
    for index, original in enumerate(events):
        kind = original.get("event")
        if kind == "spawn_call":
            event = dict(original)
            model = event.get("model", event.get("requested_model"))
            if model != "gpt-6-luna" or event.get("fork_turns") != "none":
                raise ValueError("spawn metadata lacks the required model selector")
            if event.get("requested_model", model) != model:
                raise ValueError("model metadata aliases disagree")
            event["model"] = model
            task = event.get("returned_task_name")
            if not isinstance(task, str) or not task.startswith("/root/"):
                raise ValueError("spawn lacks its actual canonical tool-returned name")
            if task in spawns:
                old = spawns[task]
                for field in ("assigned_packet", "model", "fork_turns", "task_name"):
                    if old.get(field) != event.get(field):
                        raise ValueError("duplicate canonical spawn name has conflicting metadata")
                duplicate_spawn_rows.append(index + 1)
            else:
                spawns[task] = event
        elif kind in {"worker_final", "worker_failure"}:
            task = original.get("task_name")
            if task in terminals:
                old = terminals[task]
                if old.get("event") != kind or old.get("assigned_packet") != original.get("assigned_packet"):
                    raise ValueError("duplicate terminal name has conflicting outcome metadata")
                duplicate_terminal_rows.append(index + 1)
            else:
                terminals[task] = dict(original)
    assigned = [event.get("assigned_packet") for event in spawns.values()]
    if len(assigned) != len(set(assigned)):
        raise ValueError("multiple actual canonical attempts were assigned one packet")
    if set(assigned) != expected_packets or set(spawns) != set(terminals):
        raise ValueError("not every frozen packet has one actual terminal attempt")
    output = []
    for task, spawn in spawns.items():
        terminal = terminals[task]
        if terminal.get("assigned_packet") != spawn.get("assigned_packet"):
            raise ValueError("terminal packet differs from actual spawn assignment")
        output.extend((spawn, terminal))
    return output, {
        "actual_unique_canonical_spawn_count": len(spawns),
        "actual_unique_canonical_terminal_count": len(terminals),
        "unique_assigned_packet_count": len(set(assigned)),
        "duplicate_spawn_metadata_row_numbers": duplicate_spawn_rows,
        "duplicate_terminal_metadata_row_numbers": duplicate_terminal_rows,
        "original_event_objects_preserved_separately": True,
        "semantic_response_bytes_changed": False,
    }


def main() -> None:
    original = EX / "supervisor-dispatch-ledger.jsonl"
    data = original.read_bytes()
    index = json.loads((EX / "packet-index-v1/packet-index.json").read_text())
    events = decode_events(data)
    normalized, receipt = normalize(events, {p["file"] for p in index["packets"]})
    directory = EX / "collector-normalized-metadata-v1"
    directory.mkdir()
    (directory / "available-original-ledger.bin").write_bytes(data)
    output = b"".join(json.dumps(event, ensure_ascii=False, separators=(",", ":")).encode()
                      + bytes([10]) for event in normalized)
    (directory / "supervisor-dispatch-ledger.jsonl").write_bytes(output)
    receipt.update({
        "schema_version": "sku-volume-dispatch-metadata-normalization-v1",
        "available_original_ledger_sha256": hashlib.sha256(data).hexdigest(),
        "normalized_ledger_sha256": hashlib.sha256(output).hexdigest(),
        "available_original_event_count": len(events),
        "normalized_event_count": len(normalized),
        "labels_read": False,
        "model_calls_made": False,
        "pre_repair_original_ledger_bytes_fully_available": False,
        "pre_repair_limit": "supervisor rewrote one malformed delimiter line before retaining its full raw bytes; line SHA and decoded event objects are recorded in history",
    })
    (directory / "normalization-receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: v for k, v in receipt.items() if "row_numbers" not in k}))


if __name__ == "__main__":
    main()
