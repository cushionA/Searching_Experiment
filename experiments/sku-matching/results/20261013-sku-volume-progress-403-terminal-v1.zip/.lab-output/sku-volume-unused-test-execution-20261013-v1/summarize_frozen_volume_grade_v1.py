"""Summarize already frozen/graded predictions without opening label archives.

All per-case outcomes are reconstructed from the original scorer's explicit
exclusions/differences and unchanged predictions, then reconciled to its cells.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
VARIANTS = ("indexed-body-invariant-v3", "literal-only")


def read(path: Path):
    return json.loads(path.read_text())


def rows(path: Path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def pin(path: Path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def outcome_map(result: dict, predictions: dict) -> dict:
    unknown = set(result["unknown_reference_case_ids"])
    differences = {r["case_id"]: r for r in result["differences"]}
    if len(differences) != len(result["differences"]):
        raise ValueError("original scorer differences are duplicated")
    outcomes = {}
    for case_id, prediction in predictions.items():
        if case_id in unknown:
            continue
        accepted = prediction["decision"] == "accept"
        difference = differences.get(case_id)
        if difference:
            reason = difference["difference"]
            if reason == "wrong_accepted_row":
                cell, correct_row = "tp", False
            elif reason in {"fp", "fn"}:
                cell, correct_row = reason, False
            else:
                raise ValueError("unexpected original difference kind")
        else:
            cell, correct_row = ("tp", True) if accepted else ("tn", False)
        if accepted != (cell in {"tp", "fp"}):
            raise ValueError("original scored cell contradicts frozen prediction")
        outcomes[case_id] = {"cell": cell, "correct_row": correct_row,
                             "positive": cell in {"tp", "fn"}}
    cells = Counter(o["cell"] for o in outcomes.values())
    if any(cells[k] != result["metrics"][k] for k in ("tp", "fp", "fn", "tn")):
        raise ValueError("reconstructed per-case outcomes do not reconcile")
    row_metrics = result["row_metrics"]
    if row_metrics.get("accepted_matched_row_unscored", 0):
        raise ValueError("cannot infer exact-row correctness for unscored accepted rows")
    if sum(o["correct_row"] for o in outcomes.values()) != row_metrics.get("correct_accepted_row", 0):
        raise ValueError("reconstructed exact rows do not reconcile")
    return outcomes


def main() -> None:
    parser = argparse.ArgumentParser()
    for name in ("grade", "freeze", "assembly-dir", "membership", "snapshot", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    grade = read(args.grade)
    if (grade.get("phase") != "post-freeze-grade"
            or grade.get("labels_read_after_root_go") is not True
            or grade.get("freeze_receipt_sha256") != pin(args.freeze)["sha256"]
            or grade.get("gates_changed") is not False
            or grade.get("classifier_outputs_changed") is not False):
        raise ValueError("input is not an unchanged freeze-bound grade")
    freeze = read(args.freeze)
    membership = {r["case_id"]: r for r in rows(args.membership)}
    if (pin(args.membership)["sha256"] != freeze["selected_membership_sha256"]
            or len(membership) != grade["selected_case_count"]):
        raise ValueError("membership differs from the frozen grade")
    products = {r["au_product_id"] for r in membership.values()}
    if len(products) != grade["selected_product_count"]:
        raise ValueError("product population differs from the grade")
    predictions, outcomes, summaries = {}, {}, {}
    for variant in VARIANTS:
        predictions[variant] = {r["case_id"]: r for r in rows(args.assembly_dir / variant / "case-decisions.jsonl")}
        if set(predictions[variant]) != set(membership):
            raise ValueError("prediction population differs from membership")
        result = grade["variants"][variant]
        outcomes[variant] = outcome_map(result, predictions[variant])
        pos = result["metrics"]["tp"] + result["metrics"]["fn"]
        known_accepts = result["metrics"]["tp"] + result["metrics"]["fp"]
        exact = result["row_metrics"].get("correct_accepted_row", 0)
        unknown = set(result["unknown_reference_case_ids"])
        product_counts = defaultdict(Counter)
        for case_id, outcome in outcomes[variant].items():
            product = membership[case_id]["au_product_id"]
            product_counts[product]["positive"] += int(outcome["positive"])
            product_counts[product]["exact_tp"] += int(outcome["correct_row"])
        macro_denominators = [c for c in product_counts.values() if c["positive"]]
        summaries[variant] = {
            "binary_metrics": result["metrics"], "row_metrics": result["row_metrics"],
            "class_and_exact_row_accuracy_on_known_references": (exact + result["metrics"]["tn"]) / result["metrics"]["scored_case_count"] if result["metrics"]["scored_case_count"] else None,
            "known_positive_count": pos,
            "known_negative_count": result["metrics"]["fp"] + result["metrics"]["tn"],
            "exact_accepted_row_recall": exact / pos if pos else None,
            "exact_row_fraction_of_known_accepts": exact / known_accepts if known_accepts else None,
            "product_macro_exact_row_recall": sum(c["exact_tp"] / c["positive"] for c in macro_denominators) / len(macro_denominators) if macro_denominators else None,
            "products_with_known_positive_count": len(macro_denominators),
            "gross_accept_count": sum(r["decision"] == "accept" for r in predictions[variant].values()),
            "unknown_reference_count": len(unknown),
            "unknown_reference_accept_count": sum(predictions[variant][cid]["decision"] == "accept" for cid in unknown),
            "all_case_gate_reason_counts": dict(Counter(r["reason"] for r in predictions[variant].values())),
            "false_negative_gate_reason_counts": dict(Counter(predictions[variant][cid]["reason"] for cid, o in outcomes[variant].items() if o["cell"] == "fn")),
            "products_with_false_negative_count": len({membership[cid]["au_product_id"] for cid, o in outcomes[variant].items() if o["cell"] == "fn"}),
        }
    model, literal = VARIANTS
    if set(outcomes[model]) != set(outcomes[literal]):
        raise ValueError("variant known populations differ")
    paired = Counter()
    for case_id, current in outcomes[model].items():
        previous = outcomes[literal][case_id]
        if current["positive"] != previous["positive"]:
            raise ValueError("variant reference labels differ")
        correct = current["cell"] in {"tp", "tn"}
        old_correct = previous["cell"] in {"tp", "tn"}
        paired["binary_gain" if correct and not old_correct else "binary_loss" if old_correct and not correct else "binary_unchanged"] += 1
        if current["positive"]:
            row, old_row = current["correct_row"], previous["correct_row"]
            paired["exact_row_gain" if row and not old_row else "exact_row_loss" if old_row and not row else "exact_row_unchanged_positive"] += 1
    snapshot = read(args.snapshot)
    assembly = read(args.assembly_dir / "assembly-receipt.json")
    report = {
        "schema_version": "sku-volume-frozen-grade-summary-v1",
        "selected_product_count": len(products), "selected_case_count": len(membership),
        "reference_kind": "claude-haiku-5-5 machine annotation; not human gold",
        "variants": summaries, "same_cohort_paired_change": dict(paired),
        "source_and_execution": {
            "assigned_packet_count": snapshot["assigned_packet_count"],
            "assigned_pair_count": snapshot["assigned_pair_count"],
            "response_count": snapshot["response_count"],
            "missing_firstpass_pair_count": snapshot["failure_count"],
            "structurally_invalid_pair_count": sum(r.get("status") == "invalid_unknown_firstpass_preserved" for r in snapshot["packet_checks"]),
            "invalid_or_unvalidated_pair_count": assembly["invalid_or_unvalidated_pair_count"],
            "source_family_unknown_task_count": assembly["source_family_unknown_task_count"],
            "contextless_task_count": assembly["contextless_task_count"],
            "all_original_task_count": assembly["task_count"],
            "all_original_row_count": assembly["row_count"],
        },
        "pins": {"grade": pin(args.grade), "freeze": pin(args.freeze), "snapshot": pin(args.snapshot),
                 "membership": pin(args.membership), "summary_script": pin(Path(__file__))},
        "reference_archives_opened_by_summary": False, "predictions_changed": False,
        "whole_sku_semantic_truth_independently_established": False,
        "semantic_retries": 0, "category_rules_added": 0,
        "case_weighted_and_product_macro_metrics_reported_separately": True,
        "production_adoption_allowed": False,
    }
    with args.output.open("x") as output:
        json.dump(report, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
