#!/usr/bin/env python3
"""Freeze original dispatched drafts into a source-indexed first-pass snapshot.

This utility performs no model calls, repairs, semantic retries, grading, or label reads.
"""
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EXP = ROOT / 'experiments/sku-matching'
sys.path.insert(0, str(EXP))
import run_indexed_volume_test_v1 as RUNNER
import prepare_body_indexed_volume_packets_v1 as PACK
import sku_body_invariant_indexed_transport_v1 as INDEXED

EXEC = ROOT / '.lab-output/sku-volume-unused-test-execution-20261013-v1'
CONFIG = ROOT / '.lab-output/sku-volume-unused-test-20261013-v1/runner-config-volume-v2.json'
INDEX_DIR = EXEC / 'packet-index-v1'
OUT = EXEC / 'firstpass-snapshot-v1'

def sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def pin(path: Path) -> dict: return {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
def strict(data: bytes): return PACK.strict_loads(data)
def rows(path: Path):
    return [strict(line) for line in path.read_bytes().splitlines() if line.strip()]
def canon(v): return json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
def dump(path: Path, obj): path.write_bytes(canon(obj)+b'\n')

def validate_packet_population(index):
    """Validate independent pair and packet grains; packets may hold multiple pairs."""
    packets = index.get('packets')
    refs = index.get('dispatch_pair_refs')
    if not isinstance(packets, list) or not isinstance(refs, list):
        raise ValueError('packet index lacks packet records or dispatched refs')
    files = [p.get('file') for p in packets]
    packet_refs = [r for p in packets for r in p.get('pair_refs', [])]
    if (len(files) != len(set(files)) or index.get('packet_count') != len(packets)
            or index.get('dispatch_pair_count') != len(refs)
            or len(refs) != len(set(refs)) or sorted(packet_refs) != sorted(refs)
            or len(packet_refs) != len(set(packet_refs))):
        raise ValueError('packet and dispatched-pair populations do not reconcile')
    return len(packets), len(refs)

def parse_draft(data):
    """Parse original JSONL without normalization; return objects paired with original line bytes."""
    parsed, error = [], None
    try:
        if not data.endswith(b'\n'):
            raise ValueError('draft lacks final newline delimiter')
        for line in data.splitlines(keepends=True):
            if not line.strip(): raise ValueError('blank JSONL line')
            obj = strict(line)
            if not isinstance(obj, dict): raise ValueError('JSONL value is not an object')
            parsed.append((obj, line))
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        error = f'{type(exc).__name__}: {exc}'
    return parsed, error

def eligible_packet_rows(parsed, expected_refs, parse_error=None):
    refs = [obj.get('pair_ref') for obj, _ in parsed]
    valid_order = refs == list(expected_refs) and all(type(r) is int for r in refs)
    counts = {}
    for ref in refs:
        if type(ref) is int: counts[ref] = counts.get(ref, 0) + 1
    # A syntactically valid but wrong/duplicate ref sequence invalidates the
    # packet as a unit. Do not select an implicit winner among duplicated rows.
    eligible = ([(obj, line) for obj, line in parsed
                 if type(obj.get('pair_ref')) is int
                 and obj.get('pair_ref') in expected_refs
                 and counts.get(obj.get('pair_ref')) == 1]
                if valid_order or parse_error else [])
    return valid_order, eligible, refs

def main():
    if OUT.exists(): raise FileExistsError(OUT)
    cfg = json.loads(CONFIG.read_text())
    RUNNER.configure_identity(cfg)
    PACK.CONFIG_COHORT_NAME = cfg['cohort_name']
    pre = ROOT / cfg['preflight_output']
    index_data = (INDEX_DIR / 'packet-index.json').read_bytes()
    index = strict(index_data)
    # Full public source metadata and packet index are verified and loaded once.
    checked_index, source = PACK._verify_packet_index(INDEX_DIR)
    assert checked_index == index
    packet_count, pair_count = validate_packet_population(index)
    assert pair_count == index['dispatch_pair_count']
    packet_by_name = {p['file']: p for p in index['packets']}
    assert len(packet_by_name) == packet_count

    ledger_path = EXEC / 'supervisor-dispatch-ledger.jsonl'
    ledger_bytes = ledger_path.read_bytes()
    ledger = [strict(line) for line in ledger_bytes.splitlines() if line.strip()]
    spawned = [r for r in ledger if r.get('event') == 'spawn_call']
    terminals = [r for r in ledger if r.get('event') in {'worker_final','worker_failure'}]
    by_task = {}
    for r in terminals:
        task = r.get('task_name')
        if task in by_task: raise ValueError('duplicate terminal task in supervisor ledger')
        by_task[task] = r
    assigned = [r.get('assigned_packet') for r in spawned]
    if len(assigned) != len(set(assigned)) or set(assigned) != set(packet_by_name):
        raise ValueError('spawn ledger must assign every packet exactly once')
    task_names = {r.get('returned_task_name') for r in spawned}
    if task_names != set(by_task): raise ValueError('not all spawned classifier tasks are terminal')
    if any(r.get('model') != 'gpt-6-luna' or r.get('fork_turns') != 'none' for r in spawned):
        raise ValueError('actual spawn ledger does not record requested gpt-6-luna/fork_turns=none')

    draft_dir = EXEC / 'drafts'
    OUT.mkdir(parents=True)
    (OUT / 'unaccepted-original-drafts').mkdir()
    raw_parts, failures, draft_pins, packet_checks = [], [], {}, []
    accepted_ref_to_line = {}
    all_refs = {r['pair_ref']: r for r in source['refs'].values()}
    dispatch_ids = set(source['dispatch_ids'])
    for packet_name, rec in packet_by_name.items():
        ppath = draft_dir / (Path(packet_name).stem + '.jsonl')
        expected = list(rec['pair_refs'])
        if not ppath.is_file():
            parsed, parse_error = [], 'assigned first draft file is absent'
            data = b''
        else:
            data = ppath.read_bytes()
            draft_pins[ppath.relative_to(ROOT).as_posix()] = {'bytes':len(data),'sha256':sha(data)}
            # Preserve every draft verbatim, including malformed JSON and line endings.
            (OUT/'unaccepted-original-drafts'/ppath.name).write_bytes(data)
            parsed, parse_error = parse_draft(data)
        packet_valid, eligible, refs = eligible_packet_rows(parsed, expected, parse_error)
        accepted_in_packet = []
        for obj,line in eligible:
            ref=obj['pair_ref']; pid=all_refs[ref]['pair_id']
            if pid not in dispatch_ids or ref in accepted_ref_to_line: continue
            # Frozen canonical renderer only checks structural completeness; it never edits the draft.
            try:
                INDEXED.render_indexed_response(obj, source['pairs'][pid], source['payloads'][pid], ref)
                state='structurally_valid_firstpass'
            except (KeyError,TypeError,ValueError) as exc:
                state='invalid_unknown_firstpass_preserved'
                packet_checks.append({'packet_file':packet_name,'pair_ref':ref,'status':state,'error_type':type(exc).__name__,'error':str(exc)})
            accepted_ref_to_line[ref]=line
            accepted_in_packet.append(ref)
        for ref in expected:
            if ref not in accepted_ref_to_line:
                failures.append({'pair_id':all_refs[ref]['pair_id'],'pair_ref':ref,
                    'status':'missing_firstpass_response_unknown','semantic_retry_performed':False,
                    'reason':parse_error or 'missing, malformed, duplicate, or unassigned first-draft response',
                    'unaccepted_raw_draft_present':ppath.is_file(),'classifier_was_dispatched':True,
                    'unknown_means_no_registered_response_not_no_model_judgment':True})
        packet_checks.append({'packet_file':packet_name,'assigned_pair_refs':expected,
            'parsed_pair_refs':refs,'packet_ref_coverage_order_valid':packet_valid,
            'registered_dispatched_responses':accepted_in_packet,'parse_or_coverage_error':parse_error})

    raw = OUT/'raw-indexed-responses.jsonl'
    raw.write_bytes(b''.join(accepted_ref_to_line[r] for r in sorted(accepted_ref_to_line)))
    failure_path=OUT/'missing-firstpass-ledger.jsonl'
    failure_path.write_bytes(b''.join(canon(f)+b'\n' for f in sorted(failures,key=lambda x:x['pair_ref'])))
    # Actual unique task-name terminal count, independent of duplicated dispatch rows.
    dispatch_pairs=rows(pre/'dispatch-pair-ids.jsonl'); protected=rows(pre/'literal-protected-pair-ids.jsonl')
    assert len(dispatch_ids) == pair_count == len({r['pair_id'] for r in dispatch_pairs})
    assert len({r['pair_id'] for r in protected}) == index['literal_protected_pair_count']
    task_status={'spawn_calls':len(spawned),'unique_assigned_packets':len(set(assigned)),
        'unique_spawned_task_names':len(task_names),'unique_terminal_task_names':len(by_task),
        'all_classifier_attempts_terminal':task_names==set(by_task),
        'requested_model':'gpt-6-luna','fork_turns':'none'}
    receipt={'schema_version':'indexed-test-raw-snapshot-v1','status':'complete_firstpass_snapshot_frozen',
        'dataset':index['dataset'],'independent_test':True,'test_split_read':True,
        'identity_plan_manifest_sha256':index['identity_plan_manifest_sha256'],
        'selected_membership_sha256':index['selected_membership_sha256'],
        'raw_path':raw.relative_to(ROOT).as_posix(),'raw_bytes':raw.stat().st_size,'raw_sha256':sha(raw.read_bytes()),
        'partition_receipt_sha256':sha((pre/'source-partition-receipt.json').read_bytes()),
        'preflight_inventory_sha256':sha((pre/'preflight-inventory.json').read_bytes()),
        'dispatch_pair_count':len({r['pair_id'] for r in dispatch_pairs}),
        'dispatch_pair_ids_sha256':hashlib.sha256(canon(sorted(r['pair_id'] for r in dispatch_pairs))).hexdigest(),
        'literal_protected_pair_count':len({r['pair_id'] for r in protected}),
        'literal_protected_pair_ids_sha256':hashlib.sha256(canon(sorted(r['pair_id'] for r in protected))).hexdigest(),
        'response_count':len(accepted_ref_to_line),
        'response_pair_ids_sha256':hashlib.sha256(canon(sorted(all_refs[r]['pair_id'] for r in accepted_ref_to_line))).hexdigest(),
        'failure_count':len(failures),'failure_ledger_bytes':failure_path.stat().st_size,'failure_ledger_sha256':sha(failure_path.read_bytes()),
        'labels_read':False,'scores_created':False,'all_predictions_frozen':True,'semantic_retry_performed':False,
        'draft_pins':draft_pins,'packet_checks':packet_checks,'supervisor_ledger_pin':{'bytes':len(ledger_bytes),'sha256':sha(ledger_bytes)},
        'model_spawn_attempt_count':len(spawned),'unique_assigned_packet_count':len(set(assigned)),
        'assigned_packet_count':packet_count,'assigned_pair_count':pair_count,
        'terminal_task_count':len(by_task),'all_classifier_attempts_terminal':task_status['all_classifier_attempts_terminal'],
        'requested_model':'gpt-6-luna','fork_turns':'none','collector_sha256':sha(Path(__file__).read_bytes())}
    dump(OUT/'snapshot-receipt.json',receipt)
    dump(OUT/'collection-qa-receipt.json',{'status':'collector_preflight_complete','snapshot_receipt_sha256':sha((OUT/'snapshot-receipt.json').read_bytes()),
        'packet_index_sha256':sha(index_data),'source_metadata_loaded_once':True,'dispatch_pair_count':len(dispatch_ids),
        'protected_pair_count':len(source['refs'])-len(dispatch_ids),'response_count':len(accepted_ref_to_line),
        'failure_count':len(failures),'task_status':task_status,'structurally_invalid_responses_quarantined_by_frozen_renderer':sum(x.get('status')=='invalid_unknown_firstpass_preserved' for x in packet_checks),
        'labels_read':False,'classifier_calls_made':False,'semantic_retries':0})
    print(json.dumps({'response_count':len(accepted_ref_to_line),'failure_count':len(failures),'snapshot':str(OUT/'snapshot-receipt.json')}))

if __name__=='__main__': main()
