"""Retain declared early tool-record gaps as explicit supplemental metadata."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import normalize_dispatch_metadata_v1 as BASE

EX = Path(__file__).resolve().parent


def expand_reported_gaps(events: list[dict]) -> tuple[list[dict], list[dict]]:
    expanded = list(events)
    declared = []
    existing = {event.get("returned_task_name") for event in events if event.get("event") == "spawn_call"}
    terminal_names = {event.get("task_name") for event in events
                      if event.get("event") in {"worker_final", "worker_failure"}}
    for row_number, event in enumerate(events, 1):
        if event.get("event") != "spawn_metadata_gap":
            continue
        if (event.get("requested_model") != "gpt-6-luna" or event.get("fork_turns") != "none"
                or event.get("tool_calls_occurred") is not True):
            raise ValueError("gap declaration does not identify the frozen requested model")
        for item in event["missing_spawn_call_rows"]:
            name = item["returned_task_name"]
            if name in existing or name not in terminal_names:
                raise ValueError("reported missing spawn is duplicate or has no terminal event")
            supplemental = {
                **item, "event": "spawn_call", "model": event["requested_model"],
                "requested_model": event["requested_model"], "fork_turns": event["fork_turns"],
                "returned_status": "terminal_event_present_original_spawn_row_unavailable",
                "original_individual_spawn_record_available": False,
                "selector_evidence_kind": "supervisor_reported_actual_tool_selector_batch",
                "original_spawn_timestamp_available": False,
                "gap_declaration_event_row": row_number,
                "is_supplemental_metadata_not_a_new_or_replayed_tool_call": True,
            }
            expanded.append(supplemental)
            declared.append(supplemental)
            existing.add(name)
    return expanded, declared


def main() -> None:
    original = EX / "supervisor-dispatch-ledger.jsonl"
    data = original.read_bytes()
    events = BASE.decode_events(data)
    expanded, supplemental = expand_reported_gaps(events)
    index = json.loads((EX / "packet-index-v1/packet-index.json").read_text())
    normalized, receipt = BASE.normalize(expanded, {item["file"] for item in index["packets"]})
    directory = EX / "collector-normalized-metadata-v2"
    directory.mkdir()
    (directory / "available-original-ledger.bin").write_bytes(data)
    output = b"".join(json.dumps(event, ensure_ascii=False, separators=(",", ":")).encode()
                      + bytes([10]) for event in normalized)
    (directory / "supervisor-dispatch-ledger.jsonl").write_bytes(output)
    receipt.update({
        "schema_version": "sku-volume-dispatch-metadata-normalization-v2",
        "available_original_ledger_sha256": hashlib.sha256(data).hexdigest(),
        "normalized_ledger_sha256": hashlib.sha256(output).hexdigest(),
        "available_original_event_count": len(events),
        "normalized_event_count": len(normalized),
        "supplemental_selector_records": supplemental,
        "individual_spawn_record_gaps_remain_explicit": True,
        "gap_records_are_supervisor_reported_not_independent_weight_attestations": True,
        "original_spawns_not_replayed": True,
        "pre_repair_original_ledger_bytes_fully_available": False,
        "pre_repair_limit": "one malformed delimiter line was rewritten before retaining all original bytes; line SHA and decoded objects remain",
        "labels_read": False, "model_calls_made": False,
    })
    (directory / "normalization-receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"normalized_actual_attempts": receipt["actual_unique_canonical_spawn_count"],
                      "selector_records_with_explicit_gaps": len(supplemental)}))


if __name__ == "__main__":
    main()
