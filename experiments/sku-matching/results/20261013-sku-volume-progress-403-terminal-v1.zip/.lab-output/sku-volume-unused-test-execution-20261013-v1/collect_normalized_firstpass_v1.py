"""Map original draft bytes for the frozen collector after all tasks terminate.

This wrapper changes only the metadata input directory. It makes no classifier
calls, alters no response bytes, and opens no labels.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

EX = Path(__file__).resolve().parent
ROOT = EX.parents[1]
EXPECTED_COLLECTOR_SHA = "95a2da93c93c60c91f5ce706cc17b8aa4f77f504b67746f14cc7a2b7f3eadafb"


def pin(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main() -> None:
    collector_path = EX / "collect_volume_firstpass_v1.py"
    if pin(collector_path.read_bytes())["sha256"] != EXPECTED_COLLECTOR_SHA:
        raise ValueError("frozen collector changed")
    metadata = EX / "collector-normalized-metadata-v2"
    receipt = json.loads((metadata / "normalization-receipt.json").read_text())
    index = json.loads((EX / "packet-index-v1/packet-index.json").read_text())
    packet_count = index["packet_count"]
    if any(receipt.get(k) != packet_count for k in (
        "actual_unique_canonical_spawn_count", "actual_unique_canonical_terminal_count",
        "unique_assigned_packet_count",
    )):
        raise ValueError("normalized metadata does not cover all terminal packets")
    ledger = (metadata / "supervisor-dispatch-ledger.jsonl").read_bytes()
    if pin(ledger)["sha256"] != receipt["normalized_ledger_sha256"]:
        raise ValueError("normalized metadata changed")
    draft_dir = metadata / "drafts"
    draft_dir.mkdir()
    mappings, missing = [], []
    for packet in index["packets"]:
        name = Path(packet["file"]).stem + ".jsonl"
        original = EX / "drafts" / name
        if not original.is_file():
            missing.append(name)
            continue
        data = original.read_bytes()
        copied = draft_dir / name
        with copied.open("xb") as output:
            output.write(data)
        if copied.read_bytes() != data:
            raise ValueError("original draft copy is not byte identical")
        mappings.append({
            "original_path": original.relative_to(ROOT).as_posix(),
            "collector_path": copied.relative_to(ROOT).as_posix(), **pin(data),
        })
    provenance = {
        "schema_version": "sku-volume-original-draft-mapping-v1",
        "status": "all_available_original_drafts_copied_byte_identically",
        "draft_mappings": mappings, "missing_original_draft_filenames": missing,
        "normalization_receipt_sha256": pin((metadata / "normalization-receipt.json").read_bytes())["sha256"],
        "collector_sha256": EXPECTED_COLLECTOR_SHA,
        "wrapper_sha256": pin(Path(__file__).read_bytes())["sha256"],
        "classifier_calls_made": False, "labels_read": False,
        "response_bytes_changed": False, "semantic_retries": 0,
        "runtime_overrides": {
            "EXEC": metadata.relative_to(ROOT).as_posix(),
            "OUT": (EX / "firstpass-snapshot-v1").relative_to(ROOT).as_posix(),
            "INDEX_DIR": "unchanged original packet index", "CONFIG": "unchanged original fixed config",
        },
    }
    with (metadata / "original-draft-mapping-receipt.json").open("x") as output:
        json.dump(provenance, output, ensure_ascii=False, indent=2)
        output.write("\n")
    spec = importlib.util.spec_from_file_location("frozen_volume_collector", collector_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.EXEC = metadata
    module.OUT = EX / "firstpass-snapshot-v1"
    module.main()


if __name__ == "__main__":
    main()
