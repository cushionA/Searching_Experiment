from pathlib import Path
from collections import defaultdict
import hashlib,json,sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import evaluate_mixed_gpu_sku_v1 as E
import trial_keyword_filtered_product_v1 as VERIFY
import composition_language_model_v1 as LM

OUT=Path(__file__).resolve().parent
MAIN=ROOT/'.lab-output/sku-composition-evidence-20261013-v1'
REVALID=ROOT/'.lab-output/sku-composition-source-revalidation-20261013-v2'
def rows(p):return list(E.rows(p))
def read(p):return json.loads(p.read_text())
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

PROTOCOL='''あなたは商品SKUの購入構成を判定するモデルです。与えられた原文だけを使用し、他ファイル・既存予測・正解・評価結果は見ないでください。
各入力のaxis_nameについて、全option_valuesのうち購入対象の実際の仕様・内容・数量・付属品・選択状態に該当するものを1つ選びます。不明・複数の可能性・数量や残余の未確認があればnullです。
kind=sharedでは商品全体の記載だけを判断します。特定の選択SKUや行を推測してはいけません。kind=pairedではtarget_selected_axes_textが対象SKUの全選択軸で、本文の条件付き記載と併せて判断します。
候補の語句が商品紹介・別仕様の一覧・検索語に現れるだけでは支持しません。表の内容が現在の購入対象に適用されるかを確認してください。追加購入オプションが存在するだけでは、選択済み・付属済みと扱いません。
数量、単位、符号、上限、修飾語、付属品、条件付き記載を無視しないでください。部分一致だけで選ばず、候補全体が合う必要があります。価格・在庫・配送・UI指示は同一性の証拠にしません。
原文を変更せず、winning_valueはoption_valuesの文字列をそのまま複写するかnullにしてください。確率やモデル名は出力しません。
応答は各入力につき {unit_id,winning_value,evidence_block_ids,reason} のJSONです。nonnullには根拠のあるblocksのblock_idを1つ以上、nullには空配列を付けます。reasonは日本語500文字以内で、どの数量・付属品・選択状態を照合したか、または不明の理由を記載します。
これは自動モデル予測の実験です。既存ラベルの作成・変更や人による採否の指示ではありません。'''

if (OUT/'freeze.json').exists():raise FileExistsError('already prepared')
summary=read(MAIN/'summary.json')
for n,s in summary['output_sha256'].items():assert E.sha(MAIN/n)==s,n
validation=read(REVALID/'validation.json')
assert validation['v1_model_inputs_unchanged'] and validation['all_accepted_spans_verified']
units={u['group_id']:u for u in rows(MAIN/'classification-units.jsonl')}
blocks={b['block_id']:b for b in rows(MAIN/'source-blocks.jsonl')}
for b in rows(REVALID/'source-blocks.jsonl'):
 old=blocks[b['block_id']]
 assert old['model_passage']==b['model_passage'] and old['quote_refs']==b['quote_refs']
 blocks[b['block_id']]=b
requests=defaultdict(list)
for r in rows(MAIN/'model-requests.jsonl'):requests[r['group_id']].append(r)
packets=[]; empty=[]
for uid,u in sorted(units.items()):
 selected=sorted(requests[uid],key=lambda x:x['block_rank'])
 if not selected:
  empty.append({'unit_id':uid,'winning_value':None,'evidence_block_ids':[],'reason':'出典を検証できる本文ブロックがないため不明。'})
  continue
 packet={'unit_id':uid,'kind':u['kind'],'axis_name':u['axis_name'],'option_values':u['option_values'],
         'target_document_id':u['target_document_id'],
         'blocks':[{'block_id':r['block_id'],'model_passage':blocks[r['block_id']]['model_passage'],
                    'quote_refs':blocks[r['block_id']]['quote_refs']} for r in selected]}
 if u['kind']=='paired':packet['target_selected_axes_text']=u['target_selected_axes_text']
 assert len(packet['blocks'])<=3
 assert 'selected_value' not in packet and 'title' not in packet
 packet['packet_sha256']=digest(packet)
 packets.append(packet)
(OUT/'worker-responses').mkdir()
E.write_rows(OUT/'packets.jsonl',packets)
E.write_rows(OUT/'empty-unit-responses.jsonl',empty)
E.write_json(OUT/'protocol.json',{'protocol':PROTOCOL,'protocol_sha256':hashlib.sha256(PROTOCOL.encode()).hexdigest(),
  'policies':['fallback-all','replace-model-conditions'],'requested_model':'gpt-6-luna',
  'hosted_model_weights_revision_verified':False,'model_identity_basis':'explicit orchestrator model selection; never model self-report',
  'probabilities_available':False,'labels_or_prior_predictions_in_model_inputs':False,'independent_test':False})
for i in range(4):E.write_json(OUT/f'worker-{i}.json',{'protocol':PROTOCOL,'packets':packets[i::4]})
paths=[Path(__file__),Path(LM.__file__),MAIN/'classification-units.jsonl',MAIN/'model-requests.jsonl',MAIN/'source-blocks.jsonl',
       REVALID/'validation.json',REVALID/'source-blocks.jsonl',REVALID/'span-receipts.jsonl',
       *(OUT/f'worker-{i}.json' for i in range(4)),OUT/'packets.jsonl',OUT/'empty-unit-responses.jsonl',OUT/'protocol.json']
E.write_json(OUT/'freeze.json',{'schema_version':'composition-language-model-inputs-v1','labels_read':False,
 'independent_test':False,'production_adoption_allowed':False,'experiment_status':'exploratory_dev_informed',
 'unit_count':len(units),'classification_unit_count':len(packets),'no_evidence_unit_count':len(empty),
 'worker_count':4,'source_snapshot':VERIFY.snapshot_paths({str(p):p for p in paths}),
 'requested_model':'gpt-6-luna','hosted_model_weights_revision_verified':False,
 'policies':['fallback-all','replace-model-conditions']})
print(json.dumps({'units':len(units),'classification_units':len(packets),'empty_units':len(empty),'workers':4}))
