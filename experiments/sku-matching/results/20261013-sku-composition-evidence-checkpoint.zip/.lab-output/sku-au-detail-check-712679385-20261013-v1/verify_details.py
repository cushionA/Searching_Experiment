"""Check the user supplied item's visible specification table in captured API JSON."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
body = (ROOT / 'item-api.body').read_bytes()
capture = json.loads((ROOT / 'item-api-capture.json').read_text())
assert capture['status'] == 200
assert capture['sha256'] == hashlib.sha256(body).hexdigest()
item = json.loads(body)['itemInfo']
field = 'extraItemComment'
html = item[field]
quotes = [
    '2台セット シャープ プラズマクラスターイオン発生機 IG-MX15',
    'ブラック系、ホワイト系',
    '1年間',
    'カーアダプター（DC12V）',
    '上部：78×76mm',
    '下部：直径65mm×高さ165mm',
    '295g（付属品除く）',
    '1.5m',
    '約17,500時間',
    '約19,000時間',
]
receipts = []
for quote in quotes:
    start = html.index(quote)
    end = start + len(quote)
    assert html[start:end] == quote
    receipts.append({'json_path': '$.itemInfo.' + field, 'start': start,
                     'end': end, 'offset_unit': 'decoded_string_code_points',
                     'quote': quote, 'raw_response_sha256': capture['sha256']})
assert html == item['extraItemCommentWithVideo']
assert item['skuInfo']['rowNames'] == ['ブラック系', 'ホワイト系']
result = {
    'item_id': '712679385',
    'requested_page_url': 'https://wowma.jp/item/712679385?spe_id=top_total_rank_2',
    'api_url': capture['requested_url'],
    'capture': capture,
    'request_public_header': {'x-triton-api': '1'},
    'details_field': '$.itemInfo.extraItemComment',
    'identical_details_field': '$.itemInfo.extraItemCommentWithVideo',
    'screenshot_specifications_found_as_html_text': True,
    'quote_receipts': receipts,
    'sku_axis': item['skuInfo']['optionName'],
    'sku_row_names': item['skuInfo']['rowNames'],
    'existing_frozen_experiment_inputs_changed': False,
    'used_for_model_or_accuracy_evaluation': False,
    'initial_request_without_x_triton_api': {
        'observed_status': 404, 'raw_response_retained': False,
        'observation_source': 'parent tool result; initial urllib request raised HTTPError 404',
    },
}
(ROOT / 'details-verification.json').write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_quotes': len(receipts), 'field': result['details_field'],
                  'raw_sha256': capture['sha256']}, ensure_ascii=False))
