from __future__ import annotations

import hashlib
import json
import os
import subprocess
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "experiments/sku-matching/results"
STEM = "20261013-sku-composition-evidence-checkpoint"
ARCHIVE = RESULTS / f"{STEM}.zip"
MANIFEST_PATH = RESULTS / f"{STEM}.manifest.json"

RUN_ROOTS = (
    ".lab-output/sku-composition-evidence-20261013-v1",
    ".lab-output/sku-composition-resume-20261013-v1",
    ".lab-output/sku-composition-source-inventory-20261013-v1",
    ".lab-output/sku-composition-nli-20261013-v1",
    ".lab-output/sku-composition-source-revalidation-20261013-v2",
    ".lab-output/sku-composition-language-model-20261013-v1",
    ".lab-output/sku-au-detail-check-712679385-20261013-v1",
)
EXACT_FILES = (
    ".lab-output/sku-composition-source-inventory-20261013-v1/README.md",
    "experiments/sku-matching/composition_evidence_v1.py",
    "experiments/sku-matching/composition_source_blocks_v1.py",
    "experiments/sku-matching/composition_source_blocks_v2.py",
    "experiments/sku-matching/trial_composition_evidence_v1.py",
    "experiments/sku-matching/trial_composition_nli_v1.py",
    "experiments/sku-matching/composition_language_model_v1.py",
    "experiments/sku-matching/composition-evidence-result-20261013.txt",
    "experiments/sku-matching/session-result-20261012.txt",
    "tests/test_lab_sku_composition_evidence.py",
    "tests/test_lab_sku_composition_source_blocks.py",
    "tests/test_lab_sku_composition_source_blocks_v2.py",
    "tests/test_lab_sku_composition_trial.py",
    "tests/test_lab_sku_composition_nli.py",
    "tests/test_lab_sku_composition_language_model.py",
    ".lab-output/sku-composition-checkpoint-build-20261013-v1/package.py",
)
DEPENDENCIES = (
    (
        "experiments/sku-matching/results/20261012-sku-mixed-cpu-checkpoint.zip",
        "f55928415f5028f6b110e44e68f936b03adbad177da1be58da3d3ee58fc4a951",
    ),
    (
        "experiments/sku-matching/results/20261012-sku-mixed-gates-improvement-checkpoint.zip",
        "26ddd2289ea44072a37f7aa677bd078372644fbb7e59b063c84b18f9c182c11c",
    ),
    (
        "experiments/sku-matching/results/20261012-sku-followup-checkpoint.zip",
        "3d013ed382adc4467d97575ae3602d162e2a8a1ea84d3087a622bdcadf186cf5",
    ),
    (
        "experiments/sku-matching/results/20261012-sku-option-context-checkpoint.zip",
        "beeb336a455a32d324dec03c103ee412e06e236ff1aed92353d0a7ff389567a0",
    ),
    (
        "experiments/sku-matching/results/20261012-sku-value-equivalence-integration-checkpoint.zip",
        "a0579182143d6d496e1acb95af46e741b47f3f2e2a15f0986ad81ab2642fe747",
    ),
)
SKIP_PARTS = {
    "__pycache__", "models", ".deps", ".aws", ".codex", ".git",
    "secrets", "credentials", "cache", "caches", "weights", "model_weights",
    "venv", ".venv", "node_modules",
}
WEIGHT_SUFFIXES = (".safetensors", ".pt", ".pth", ".ckpt", ".bin")
POLICIES = ("replace-model-conditions", "fallback-all", "fallback-shared")
MAIN_ROOT = RUN_ROOTS[0]
NLI_ROOT = RUN_ROOTS[3]
LANGUAGE_ROOT = ".lab-output/sku-composition-language-model-20261013-v1"
ADDITIONAL_REQUIRED_FILES = (
    f"{LANGUAGE_ROOT}/freeze.json",
    f"{LANGUAGE_ROOT}/dispatch-trace.json",
    f"{LANGUAGE_ROOT}/coverage-repair-trace.json",
    f"{LANGUAGE_ROOT}/evaluation/summary.json",
    f"{LANGUAGE_ROOT}/coherent-evaluation/summary.json",
    f"{LANGUAGE_ROOT}/complete-sku-evaluation/summary.json",
    f"{LANGUAGE_ROOT}/complete-sku-evaluation/complete-sku-fallback/predictions.jsonl",
    f"{LANGUAGE_ROOT}/complete-sku-evaluation/complete-sku-fallback/gates/decisions.jsonl",
    ".lab-output/sku-composition-source-revalidation-20261013-v2/validation.json",
    ".lab-output/sku-composition-source-revalidation-20261013-v2/span-receipts.jsonl",
    ".lab-output/sku-au-detail-check-712679385-20261013-v1/item-api.body",
    ".lab-output/sku-au-detail-check-712679385-20261013-v1/details-verification.json",
    ".lab-output/sku-composition-resume-20261013-v1/read-only-review.json",
    ".lab-output/sku-composition-resume-20261013-v1/all-composition-tests-final.log",
    ".lab-output/sku-composition-resume-20261013-v1/required-tests-complete-final.log",
)
MAIN_REQUIRED_OUTPUTS = tuple(
    f"{MAIN_ROOT}/{policy}/{relative}"
    for policy in POLICIES
    for relative in (
        "predictions.jsonl",
        "gates/decisions.jsonl",
        "gates/row_results.jsonl",
        "gates/condition_results.jsonl",
        "gates/manifest.json",
    )
) + tuple(f"{MAIN_ROOT}/{name}" for name in (
    "jev-unique-scores.jsonl",
    "jev-classification-options.jsonl",
    "retrieval-unique-scores.jsonl",
))


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_value(*args: str) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=ROOT, text=True, stderr=subprocess.DEVNULL
    ).strip()


def safe_relative(name: str) -> Path:
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"invalid archive path: {name}")
    return relative


def collect_paths() -> list[str]:
    names: set[str] = set()
    for root_name in RUN_ROOTS:
        root = ROOT / safe_relative(root_name)
        if not root.is_dir() or root.is_symlink():
            raise FileNotFoundError(f"required run directory missing or unsafe: {root_name}")
        for current, directories, filenames in os.walk(root, followlinks=False):
            current_path = Path(current)
            retained = []
            for dirname in directories:
                child = current_path / dirname
                if dirname.lower() in SKIP_PARTS:
                    continue
                if child.is_symlink():
                    raise ValueError(f"symlink in allowlisted source tree: {child.relative_to(ROOT)}")
                retained.append(dirname)
            directories[:] = retained
            for filename in filenames:
                path = current_path / filename
                relative_name = path.relative_to(ROOT).as_posix()
                if path.is_symlink():
                    raise ValueError(f"symlink in allowlisted source tree: {relative_name}")
                names.add(relative_name)

    names.update(EXACT_FILES)
    names.update(MAIN_REQUIRED_OUTPUTS)
    names.update(ADDITIONAL_REQUIRED_FILES)
    names.add(f"{NLI_ROOT}/summary.json")
    for name in names:
        path = ROOT / safe_relative(name)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"required file missing or unsafe: {name}")
        if any(part.lower() in SKIP_PARTS for part in Path(name).parts):
            raise ValueError(f"required file is under an excluded path: {name}")
    if any(Path(name).suffix.lower() in WEIGHT_SUFFIXES for name in names):
        raise ValueError("model-weight file found in the allowlisted package")
    composition_names = {name for name in names if name.startswith(MAIN_ROOT + "/")}
    if f"{MAIN_ROOT}/execution-freeze.json" not in composition_names:
        raise FileNotFoundError("composition execution-freeze.json is missing")
    if f"{MAIN_ROOT}/all-gates-frozen.json" not in composition_names:
        raise FileNotFoundError("composition all-gates-frozen.json is missing")
    freeze = json.loads((ROOT / f"{MAIN_ROOT}/execution-freeze.json").read_text(encoding="utf-8"))
    if freeze.get("policies") != list(POLICIES):
        raise ValueError("execution freeze policy set differs from the required three policies")
    for name in MAIN_REQUIRED_OUTPUTS:
        if name not in names:
            raise FileNotFoundError(f"required composition output missing: {name}")
    if f"{NLI_ROOT}/summary.json" not in names:
        raise FileNotFoundError("NLI composition summary.json is missing")
    return sorted(names)


def find_upstream_head(names: list[str]) -> tuple[str, str]:
    candidate_keys = (
        "upstream_head", "upstream_commit", "baseline_head", "baseline_commit",
        "source_head", "starting_head",
    )
    for name in names:
        path = Path(name)
        if path.name not in {"execution-freeze.json", "source-freeze.json", "freeze.json"}:
            continue
        try:
            data = json.loads((ROOT / name).read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if isinstance(data, dict):
            for key in candidate_keys:
                value = data.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip(), name
    try:
        ref = git_value("rev-parse", "--symbolic-full-name", "@{upstream}")
        return git_value("rev-parse", "@{upstream}"), ref
    except subprocess.CalledProcessError as exc:
        return git_value("rev-parse", "HEAD"), "git HEAD fallback; no tracking ref or explicit upstream field"


def verify_summary_outputs(summary_path: Path, *, required: bool) -> None:
    if not summary_path.is_file() or summary_path.is_symlink():
        if required:
            raise FileNotFoundError(f"required output summary missing: {summary_path.relative_to(ROOT)}")
        return
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    output_hashes = summary.get("output_sha256")
    if output_hashes is None:
        if required:
            raise ValueError(f"summary has no output_sha256 map: {summary_path.relative_to(ROOT)}")
        return
    if not isinstance(output_hashes, dict) or not output_hashes:
        raise ValueError(f"invalid output_sha256 map: {summary_path.relative_to(ROOT)}")
    for relative_name, expected_sha in output_hashes.items():
        relative = safe_relative(relative_name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"invalid summary output path: {relative_name}")
        path = summary_path.parent / relative
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"summary output missing: {path.relative_to(ROOT)}")
        if digest(path.read_bytes()) != expected_sha:
            raise ValueError(f"summary output SHA256 mismatch: {path.relative_to(ROOT)}")


def main() -> None:
    if ARCHIVE.exists() or MANIFEST_PATH.exists():
        raise FileExistsError("refusing to overwrite an existing checkpoint or manifest")

    files = []
    payloads: dict[str, bytes] = {}
    for name in collect_paths():
        body = (ROOT / name).read_bytes()
        payloads[name] = body
        files.append({"path": name, "bytes": len(body), "sha256": digest(body)})

    names = [row["path"] for row in files]
    summaries = [ROOT / name for name in names if Path(name).name == "summary.json"]
    required_summaries = {
        ROOT / MAIN_ROOT / "summary.json",
        ROOT / NLI_ROOT / "summary.json",
        ROOT / NLI_ROOT / "evaluation/summary.json",
        ROOT / LANGUAGE_ROOT / "evaluation/summary.json",
        ROOT / LANGUAGE_ROOT / "coherent-evaluation/summary.json",
        ROOT / LANGUAGE_ROOT / "complete-sku-evaluation/summary.json",
    }
    for summary_path in required_summaries:
        if summary_path not in summaries:
            raise FileNotFoundError(f"required summary missing: {summary_path.relative_to(ROOT)}")
    for summary_path in summaries:
        verify_summary_outputs(summary_path, required=summary_path in required_summaries)

    dependencies = []
    for name, expected_sha in DEPENDENCIES:
        path = ROOT / safe_relative(name)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"required dependency checkpoint missing: {name}")
        actual_sha = digest(path.read_bytes())
        if actual_sha != expected_sha:
            raise ValueError(f"dependency SHA256 mismatch: {name}")
        dependencies.append({"path": name, "sha256": actual_sha})

    upstream_head, upstream_head_source = find_upstream_head([row["path"] for row in files])
    manifest = {
        "schema_version": "sku-composition-evidence-checkpoint-v1",
        "experiment_status": "exploratory_dev_informed",
        "branch": git_value("branch", "--show-current"),
        "head": git_value("rev-parse", "HEAD"),
        "upstream_head": upstream_head,
        "upstream_head_source": upstream_head_source,
        "independent_test_read": False,
        "model_weights_included": False,
        "production_adoption_allowed": False,
        "model_identity": {
            "alias": "gpt-6-luna",
            "revision": None,
            "revision_pinned": False,
        },
        "excluded_content": ["models", ".deps", "secrets", "credentials", "caches", "model weights"],
        "dependencies": dependencies,
        "file_count": len(files),
        "files": files,
        "restore_rule": "verify exact member names, CRC, byte counts and SHA256 before extraction; never overwrite a different existing source",
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()

    RESULTS.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for row in files:
            body = payloads[row["path"]]
            if len(body) != row["bytes"] or digest(body) != row["sha256"]:
                raise ValueError(f"source changed while packaging: {row['path']}")
            zipped.writestr(row["path"], body)
        zipped.writestr("CHECKPOINT_MANIFEST.json", manifest_bytes)

    with zipfile.ZipFile(ARCHIVE, "r") as zipped:
        expected_names = {row["path"] for row in files} | {"CHECKPOINT_MANIFEST.json"}
        names = zipped.namelist()
        if (zipped.testzip() is not None or set(names) != expected_names
                or len(names) != len(expected_names)):
            raise ValueError("archive CRC or exact member-name verification failed")
        for row in files:
            body = zipped.read(row["path"])
            if len(body) != row["bytes"] or digest(body) != row["sha256"]:
                raise ValueError(f"archive member verification failed: {row['path']}")
        if zipped.read("CHECKPOINT_MANIFEST.json") != manifest_bytes:
            raise ValueError("embedded manifest verification failed")

    for row in files:
        current = (ROOT / row["path"]).read_bytes()
        if len(current) != row["bytes"] or digest(current) != row["sha256"]:
            raise ValueError(f"source changed during packaging: {row['path']}")

    archive_sha = digest(ARCHIVE.read_bytes())
    adjacent = dict(manifest)
    adjacent["archive"] = {
        "path": ARCHIVE.relative_to(ROOT).as_posix(),
        "bytes": ARCHIVE.stat().st_size,
        "sha256": archive_sha,
    }
    MANIFEST_PATH.write_text(
        json.dumps(adjacent, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "archive": str(ARCHIVE),
        "manifest": str(MANIFEST_PATH),
        "archive_bytes": ARCHIVE.stat().st_size,
        "archive_sha256": archive_sha,
        "verified_members": len(files),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
