from pathlib import Path
from copy import deepcopy
import json,sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import composition_language_model_v1 as LM
import trial_composition_evidence_v1 as T
import evaluate_mixed_gpu_sku_v1 as E
import evaluate_keyword_filtered_product_v1 as REFERENCES
import product_condition_sharing_v1 as SHARING
import trial_keyword_filtered_product_v1 as VERIFY

RUN=Path(__file__).resolve().parent
OUT=RUN/'evaluation'
MAIN=ROOT/'.lab-output/sku-composition-evidence-20261013-v1'
def rows(p):return list(E.rows(p))
def read(p):return json.loads(p.read_text())
def indexed(p,k):return E.GATE.indexed(p,k)

if OUT.exists():raise FileExistsError(OUT)
freeze=read(RUN/'freeze.json')
VERIFY.verify_snapshot(freeze['source_snapshot'],phase='before language model assembly')
VERIFY.verify_source(T.CPU/'product-model')
manifest,requests,documents,tasks,cases,membership,hosts=E.load_mixed_prepared(T.PREP)
baseline=indexed(T.CURRENT_PRED,'request_id')
E.GATE.validate_predictions(requests,documents,tasks,baseline,baseline,'baseline')
units=indexed(MAIN/'classification-units.jsonl','group_id')
packets=indexed(RUN/'packets.jsonl','unit_id')
responses={}
for i in range(4):
 assigned={p['unit_id'] for p in read(RUN/f'worker-{i}.json')['packets']}
 result=read(RUN/f'worker-responses/worker-{i}.json')
 assert set(result)=={'responses'}
 received=result['responses']
 assert len(received)==len(assigned) and {r['unit_id'] for r in received}==assigned
 for r in received:
  assert r['unit_id'] not in responses
  responses[r['unit_id']]=r
assert set(responses)==set(packets) and len(responses)==72
results={}
invalid=[]
for uid,p in packets.items():
 try:
  results[uid]=LM.validate_response(p,responses[uid],requests[uid] if p['kind']=='paired' else None,documents)
 except ValueError as error:
  invalid.append({'unit_id':uid,'reason':str(error),'raw_response':responses[uid]})
  results[uid]={'unit_id':uid,'status':'unknown','winning_value':None,'quote_refs':[],
                'reason':'invalid_source_bound_model_response','source_model_response':responses[uid],
                'scope_status':'unproved','production_adoption_allowed':False}
for r in rows(RUN/'empty-unit-responses.jsonl'):
 results[r['unit_id']]={'unit_id':r['unit_id'],'status':'unknown','winning_value':None,'quote_refs':[],
                       'reason':r['reason'],'source_model_response':r,'scope_status':'unproved','production_adoption_allowed':False}
assert set(results)==set(units) and len(results)==82
trace=read(RUN/'dispatch-trace.json')
assert trace['dispatcher']=='collaboration.spawn_agent' and trace['model_override']=='gpt-6-luna'
assert trace['hosted_weights_revision_verified'] is False and len(trace['agents'])==4
protocol=read(RUN/'protocol.json')
identity={'model_id':'gpt-6-luna','revision':'hosted-alias-revision-unresolved/20261013',
          'hosted_weights_revision_verified':False,'identity_basis':'explicit orchestrator model override',
          'probabilities_available':False,'protocol_sha256':protocol['protocol_sha256'],
          'validator_sha256':E.sha(Path(LM.__file__)), 'input_scope':'original global one-sided; separately paired selected axes',
          'evidence':'source-bound top-three original passages; no title field; exact full options; one model response per unit'}
contract=read(MAIN/'sharing-contract.json')
plan=SHARING.build_groups(requests,documents,{rid:p['source_task_bindings'] for rid,p in baseline.items()},
                         model_identity=identity,content_version=LM.CONTENT_VERSION,invariance_contract=contract)
eligible=set(plan['request_to_group'])
old_plan=read(MAIN/'sharing-plan.json')
old_ids={tuple(sorted(g['request_ids'])):g['group_id'] for g in old_plan['groups']}
shared={}
for g in plan['groups']:
 uid=old_ids[tuple(sorted(g['request_ids']))]
 assert units[uid]['option_values']==g['option_values'] and units[uid]['target_document_id']==g['target_document_id']
 r=results[uid]
 shared[g['group_id']]={'group_sha256':g['group_sha256'],'status':'ok' if r['winning_value'] else 'unknown',
                      'winning_value':r['winning_value'],'quote_refs':r['quote_refs'],'reason':'source_bound_language_model_choice',
                      'source_unit_id':uid,'source_model_response':r['source_model_response'],'variant':LM.CONTENT_VERSION}
derived={p['request_id']:p for p in SHARING.fan_out(plan,shared,baseline)}
E.SHARED.validate_shared_predictions(requests,documents,tasks,derived,baseline,eligible,'product-top3-jev')
for uid,u in units.items():
 if u['kind']=='paired':
  r=results[uid]
  derived[uid]=T.paired_prediction(requests[uid],baseline[uid],r)
  derived[uid]['variant']=LM.CONTENT_VERSION
proof_ids={rid for rid,p in baseline.items() if p.get('verified_value_equivalence')}
assert len(proof_ids)==1 and len(eligible)==80
OUT.mkdir()
E.write_rows(OUT/'validated-unit-results.jsonl',results.values())
E.write_rows(OUT/'invalid-model-responses.jsonl',invalid)
E.write_json(OUT/'sharing-plan.json',plan)
source_paths=[Path(__file__),Path(LM.__file__),T.CURRENT_PRED,RUN/'freeze.json',RUN/'protocol.json',RUN/'packets.jsonl',
              RUN/'empty-unit-responses.jsonl',RUN/'dispatch-trace.json',MAIN/'sharing-plan.json',MAIN/'sharing-contract.json',
              MAIN/'classification-units.jsonl',*(RUN/f'worker-{i}.json' for i in range(4)),
              *(RUN/f'worker-responses/worker-{i}.json' for i in range(4))]
snapshot=VERIFY.snapshot_paths({str(p):p for p in source_paths})
E.write_json(OUT/'execution-freeze.json',{'experiment_status':'exploratory_dev_informed','labels_read':False,
 'independent_test':False,'production_adoption_allowed':False,'policies':freeze['policies'],'model_identity':identity,
 'source_snapshot':snapshot,'all_unit_responses_frozen':True,'raw_values_unmodified':True,
 'shared_selected_axes_in_model_inputs':False,'title_field_in_model_inputs':False,
 'model_identity_not_inferred_from_self_report':True,'hosted_weights_revision_verified':False,
 'unsupported_or_invalid_responses_abstain':True,'invalid_response_count':len(invalid)})
for policy in freeze['policies']:
 dst=OUT/policy;dst.mkdir()
 predicted=T.policy_predictions(policy,baseline,derived,eligible,proof_ids)
 E.GATE.validate_predictions(requests,documents,tasks,predicted,baseline,'baseline')
 assert all(not any(r.get('field')=='selected_axes' for r in predicted[rid].get('quote_refs',[])) for rid in eligible)
 E.write_rows(dst/'predictions.jsonl',predicted.values())
 E.GATE.finish(T.PREP,dst/'predictions.jsonl',dst/'gates')
gate_snapshot=VERIFY.snapshot_paths({str(p):p for p in OUT.rglob('*') if p.is_file()})
E.write_json(OUT/'all-gates-frozen.json',{'labels_read':False,'all_predictions_and_gates_frozen':True,
 'policies':freeze['policies'],'source_snapshot':gate_snapshot})
_,_,_,refs,_=REFERENCES.verify_original_sources(T.PREP,T.OLD_EVAL,T.ROUTES)
ids={r['case_id'] for r in E.eligibility_rows(membership,hosts)[0] if r['primary_score_eligible']}
scored={k:v for k,v in refs.items() if k in ids and not v.get('reference_uncertain',False)}
assert len(scored)==73
oldgates=indexed(T.CURRENT/'gates/decisions.jsonl','case_id')
before={r['case_id']:r for r in E.metrics_for(oldgates,scored)['case_results']}
metrics={}
for policy in freeze['policies']:
 dst=OUT/policy
 gates=indexed(dst/'gates/decisions.jsonl','case_id');assert set(gates)==set(cases)
 metrics[policy]={};detail=[]
 for stratum in E.STRATA:
  value=E.metrics_for(gates,{k:v for k,v in scored.items() if membership[k]['membership_strata']==[stratum]})
  metrics[policy][stratum]={k:v for k,v in value.items() if k!='case_results'}
  detail.extend({'stratum':stratum,**r} for r in value['case_results'])
 value=E.metrics_for(gates,scored)
 metrics[policy]['scored_primary_reference_union']={k:v for k,v in value.items() if k!='case_results'}
 E.write_rows(dst/'case-results.jsonl',detail)
 E.write_rows(dst/'case-changes-vs-current.jsonl',[{'case_id':r['case_id'],'before':before[r['case_id']],'after':r}
             for r in value['case_results'] if r!=before[r['case_id']]])
for s in [freeze['source_snapshot'],snapshot,gate_snapshot]:VERIFY.verify_snapshot(s,phase='after language model scoring')
VERIFY.verify_source(T.CPU/'product-model')
E.write_json(OUT/'summary.json',{'schema_version':'composition-language-model-evaluation-v1','model_identity':identity,
 'experiment_status':'exploratory_dev_informed','independent_test':False,'production_adoption_allowed':False,
 'model_input_unit_count':72,'no_evidence_unit_count':10,'scored_case_count':73,'all_case_count':83,
 'invalid_model_response_count':len(invalid),'reference_kind':'existing machine labels',
 'labels_read_after_all_predictions_and_gates_frozen':True,'sources_and_outputs_verified_after_scoring':True,
 'policies':metrics,'output_sha256':{str(p.relative_to(OUT)):E.sha(p) for p in OUT.rglob('*') if p.is_file()}})
print(json.dumps({k:v['scored_primary_reference_union'] for k,v in metrics.items()},ensure_ascii=False))
