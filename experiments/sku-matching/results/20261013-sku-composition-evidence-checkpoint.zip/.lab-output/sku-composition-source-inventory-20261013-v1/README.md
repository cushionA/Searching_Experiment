# SKU 購入構成ソース棚卸し（read-only）

対象は `.lab-output/sku-mixed-gpu-prep-20261012-v5/` の frozen-source-products / frozen-source-cases / raw-source-registry / documents / blocks / model-tasks / baseline-predictions のみ。原本や評価物を変更せず、新規取得も行っていない。ケース ID は分析用に記したが、manual SKU matched labels は作成していない。

## 要点

説明文には購入内容・数量・付属品を示す文章や表が入ることがある。ただし、現行の model input は説明文を文章ブロックとして提示し、選択軸は一つずつの `raw_condition` と選択肢群で渡す。商品説明の表構造と選択 SKU の全軸組合せは、現在の baseline state に統合されていない。baseline は `unevaluated_input_placeholder`、`model_inference_run=false`、`scope_status=unproved`、空の `quote_refs`。

SKU 選択実値の根拠は説明文の一致ではなく、SKU に結び付く原本 option/selector の値である。楽天では `sku[variantId=...].selectorValues[i]` と `variantSelectors[i].label`、au では `$.itemInfo.skuInfo.rowNames[]` / `columnNames[]` と `optionName.row` / `optionName.column` が強い。楽天の値は variantId で一組の選択状態を示す。au は row/column の交差（または SKU array / row key）で状態を示す。商品説明の数字や検索語、商品タイトル、選択肢一覧だけから SKU 実値を確定できない。

## 既存入力にある購入構成の証拠

|対象例|購入構成に関する原文証拠|意味と限界|
|---|---|---|
|カーテン: レースなし / 数量2枚|楽天 HTML SHA `1537d447e5c229028fc5e0d2e1cf47a3ae38f380429661b16d024b09d8dcabc8`。`sku[variantId=CT01220SGH].selectorValues[2]` quote「なし」、値 offset 331543–331545（byte offsets）。同 variant の selectorValues[0]「100×220cm」。au JSON SHA `16b9d833f5fc694f43b0ec61c93cdc8ab4cf4daaaf7bac778a119ee5f2a39dbd`、`$.itemInfo.skuInfo.columnNames[12]` quote「幅100×丈220cm(2枚)」。|楽天の SKU は「レースカーテンなし」を直接選択値で示す。au の SKU option は2枚を数量付きで示す。モデルの単一軸 state には全体構成がない。|
|毛布系: ハーフとクッションカバー|楽天 HTML SHA `94ed896ea4519662b796d6c37d73fcb17f67d1c52a9529e91819a0287e7c9337`、`sku[variantId=FEK002XSGG].selectorValues[1]` quote「ハーフ(100×160cm)」、および同 variant の `selectorValues[0]` quote「もことろん毛布」。別 option の同じページに「クッションカバー(45×45cm)」。|説明・選択肢に毛布とカバーの両方が登場する。SKU variantIdに紐づく値を読む必要があり、ページ内に存在する option を全部購入内容と解釈できない。|
|バー付き|楽天 HTML SHA `5cbddc238b00b452f25da2c6912db4999d4cd47fce9aed696fa2e854e9aa9e36`、`sku[variantId=hg020gy].selectorValues[0]` quote「バー付き」、label は `variantSelectors[0].label` quote「タイプ」。|軸名とSKUごとの値が明示される。親品名や説明だけでは選択状態を代替しない。|
|テント単品|楽天 HTML SHA `4bb74497a4b625555fee6d86401a9aca92ce6e6be7e7f146ca4d0bb94cc990e2`、`sku[variantId=54907].selectorValues[0]` quote「テント単品」、同軸選択肢には「グランドシート付（+780円）」もある。|付属品を含むSKU選択の直接証拠。選択肢集合だけでは付属品の有無を決められない。|
|250g×2P|楽天 HTML SHA `73a434c57287cd256f5cae03e64793cffd4500acf19924663454907457c29035`、`sku[variantId=200132aa].selectorValues[0]` quote「ゆで250g×2P」。au JSON SHA `1a3cdc446ddb8fa47398f8a155f96263580484dba6bfef0162c9202f951e30aa`、`$.itemInfo.skuInfo.columnNames[0]` quote「ゆで250g×2p」。|数量と加工種別が option 値に含まれる。片側にある選択肢の列挙は他側SKUの数量証明にならない。|

原本相対パスは frozen-source-cases / model-tasks の `raw_condition.value_span.raw_file` を参照。全ファイルを横断検索せず、上記の task/case に登録された既存入力を辿った。offset は frozen locator が記す値をそのまま転記（楽天 HTML は EUC-JP の byte offset）。

## 説明文・表とモデル state

`frozen-source-products.jsonl` の `au_description_lines` / `rakuten_description_lines` は原商品説明の行と原本 field locator を保持し、`au_purchase_option_lines` は購入オプション記述を別管理する。`documents.jsonl` は入力商品説明のセグメント、`blocks.jsonl` は提示用テキストと `quote_refs` / `source_ref` / `html_start` / `html_end` を持つ。したがって「説明中に表らしい価格・セット・内容物の記載があるか」はこれらの説明ブロックにある文字列・DOM構造で確認できるが、それは選択済みSKUの根拠とは別。

一方、現行 `model-tasks.jsonl` の task は軸単位で、`raw_condition` は現在値、`option_values` は候補集合、`whole_values_and_full_choices_preserved` は全候補保持を表す。state は同じ variant/row に属する選択値を一つの購入構成として束ねず、数量、付属品、セット構成を専用属性として正規化していない。baseline placeholder が引用根拠を持たないため、説明ブロックに内容・数量表が収録されていても、現在の state 上では証拠を選択値に結合できない。

## 購入 options が実 SKU 値を示す条件

楽天 `selectorValues[i]` は、対応する `variantId` と selector label が保持されていれば実値。ケースの `rakuten_selected.axes[].value` はその variant に対して固定された選択値を転記している。au の SKU option は `rowNames[]` と `columnNames[]`（軸名は `optionName.row` / `.column`）の交差が selected row key と結び付いているとき実値。options 配列だけ、説明文、選択肢群、product-wide な variant token vocabulary は実値の証拠にならない。

PREP 内の frozen source case は 32 件、商品レコードは31件、model tasks は137件、documents は38件。今回の 83 case / 134 request mixed replay に含まれる全ソースをこの短い例だけで評価しきったわけではない。指定された旧FN例（race, blanket set, king vs semi-double, half vs cushion-cover, bar vs normal, tent-only, 250g×2P）のうち、直接照合できた購入構成例を記載した。キング/セミダブルおよび毛布セットの全原文表を網羅するには、該当する frozen locator に限って次段で読む必要がある。

## 現在 blocked の範囲

1. 同じ商品ページの全軸選択を一 SKU 購入構成として表す state がない。
2. 内容物・数量・付属品（例: 2枚、グランドシート付）の構成属性と provenance が軸値から分離されていない。
3. 商品説明にあるセット内容表を SKU 選択値へ結ぶ証拠リンクがなく、説明文上の記載だけで SKU を推定すると誤結合する。
4. すべての実値の比較には、楽天 variantId または au row key で selected options を完全に束ね、各 field/table quote の locator・hash を保持する入力設計が必要。
