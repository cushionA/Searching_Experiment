#!/usr/bin/env python3
"""Freeze two NLI composition variants, gate all cases, then score 73 dev refs."""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
import json
import math
from pathlib import Path
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
SKU = ROOT / "experiments/sku-matching"
if str(SKU) not in sys.path:
    sys.path.insert(0, str(SKU))

import composition_evidence_v1 as CONTENT
import evaluate_keyword_filtered_product_v1 as REFERENCES
import evaluate_mixed_gpu_sku_v1 as E
import product_condition_sharing_v1 as SHARING
import trial_composition_evidence_v1 as MAIN
import trial_composition_nli_v1 as NLI_SCORE
import trial_generic_model_nli_v1 as NLI
import trial_keyword_filtered_product_v1 as VERIFY

PREP = ROOT / ".lab-output/sku-mixed-gpu-prep-20261012-v5"
CPU = ROOT / ".lab-output/sku-mixed-cpu-run-20261012-v1"
MAIN_DIR = ROOT / ".lab-output/sku-composition-evidence-20261013-v1"
NLI_DIR = ROOT / ".lab-output/sku-composition-nli-20261013-v1"
REVALIDATION_DIR = ROOT / ".lab-output/sku-composition-source-revalidation-20261013-v2"
BASE_PRED = ROOT / ".lab-output/sku-raw-nli-unique-support-20261012-v1"
BASE_EVAL = ROOT / ".lab-output/sku-raw-nli-unique-support-evaluation-20261012-v1"
OLD_EVAL = ROOT / ".lab-output/sku-mixed-cpu-evaluation-20261012-v4"
ROUTES = ROOT / ".lab-output/sku-mixed-cpu-reference-routes-20261012-v2"
OUTPUT = NLI_DIR / "evaluation"
METHODS = ("nli-two-block-fallback-all", "same-block-jev-nli-fallback-all")
METHOD_KIND = {METHODS[0]: "nli", METHODS[1]: "same-block-jev-nli"}
EXPECTED = {"cases": 83, "requests": 134, "shared_requests": 80,
            "shared_units": 29, "paired_units": 53, "typed_proofs": 1, "scored": 73}


def sha(path: Path) -> str:
    import hashlib
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_rows(path):
    with Path(path).open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def write_rows(path, values):
    E.write_rows(Path(path), values)


def indexed(values, key, where):
    result = {}
    for value in values:
        identity = value.get(key)
        if not isinstance(identity, str) or not identity or identity in result:
            raise ValueError(f"missing or duplicate {key}: {where}")
        result[identity] = value
    return result


def verify_hashes(directory: Path, hashes: dict, *, skip=()):
    if not isinstance(hashes, dict) or not hashes:
        raise ValueError("missing output SHA inventory: " + str(directory))
    for relative, expected in hashes.items():
        if relative in skip:
            continue
        path = directory / relative
        if not path.is_file() or sha(path) != expected:
            raise ValueError("frozen output hash differs: " + str(path))


def verify_revalidated_source(main_blocks):
    validation_path = REVALIDATION_DIR / "validation.json"
    validation = read_json(validation_path)
    if (validation.get("schema_version") != "sku-composition-source-revalidation-v2"
            or validation.get("all_accepted_spans_verified") is not True
            or validation.get("all_document_literal_refs_rechecked") is not True
            or validation.get("all_scopes_unproved") is not True
            or validation.get("v1_model_inputs_unchanged") is not True
            or validation.get("block_count") != 513
            or validation.get("verified_span_count") != 15394):
        raise ValueError("v2 source span revalidation is incomplete")
    validated = indexed(read_rows(REVALIDATION_DIR / "source-blocks.jsonl"), "block_id", "v2 source blocks")
    if len(validated) != 513:
        raise ValueError("v2 revalidated source block count differs")
    receipts = read_rows(REVALIDATION_DIR / "span-receipts.jsonl")
    if len(receipts) != 15394 or any(row.get("verified") is not True for row in receipts):
        raise ValueError("v2 span receipts do not all pass")
    raw_pins = read_rows(REVALIDATION_DIR / "raw-pins.jsonl")
    if len(raw_pins) != validation.get("raw_file_count"):
        raise ValueError("v2 raw capture pin count differs")
    for pin in raw_pins:
        path = Path(pin["absolute_path"])
        if not path.is_file() or path.stat().st_size != pin.get("bytes") or sha(path) != pin.get("sha256"):
            raise ValueError("v2 raw HTML capture pin differs: " + str(path))
    for relative, expected in validation.get("source_code_sha256", {}).items():
        path = REVALIDATION_DIR / "code" / relative
        if not path.is_file() or sha(path) != expected:
            raise ValueError("v2 source revalidation code pin differs: " + relative)
    for absolute, expected in validation.get("source_sha256", {}).items():
        path = Path(absolute)
        if not path.is_file() or sha(path) != expected:
            raise ValueError("v2 source input pin differs: " + absolute)
    for block_id, new in validated.items():
        old = main_blocks.get(block_id)
        if old is None:
            raise ValueError("v2 source block is absent from MAIN model input: " + block_id)
        if old.get("model_passage") != new.get("model_passage") or old.get("quote_refs") != new.get("quote_refs"):
            raise ValueError("v2 revalidation changed model passage or literal quote refs: " + block_id)
        old_ref, new_ref = old.get("source_ref", {}), new.get("source_ref", {})
        for key in ("raw_file", "sha256", "start", "end", "quote"):
            if old_ref.get(key) != new_ref.get(key):
                raise ValueError("v2 revalidation changed original raw source span " + key + ": " + block_id)
    return validated, validation


def verify_synthetic_aggregation():
    def record(value, index, scores):
        return {"option_value": value, "option_index": index, "probabilities": scores,
                "token_count_untruncated": 1, "error_type": None}
    win = block_winner([record("a", 0, {"support": .1, "conflict": .4, "unknown": .5}),
                        record("b", 1, {"support": .8, "conflict": .1, "unknown": .1})], ["a", "b"])
    tie = block_winner([record("a", 0, {"support": .6, "conflict": .2, "unknown": .2}),
                        record("b", 1, {"support": .6, "conflict": .2, "unknown": .2})], ["a", "b"])
    empty = aggregate_units({"empty": {"group_sha256": "h", "kind": "paired", "option_values": ["a", "b"],
                                         "target_document_id": "doc"}}, [], {}, {}, {},
                            {"empty": {"group_id": "empty", "group_sha256": "h", "block_winners": {}}},
                            {}, "nli")
    if win != "b" or tie is not None or empty["empty"]["status"] != "unknown":
        raise ValueError("synthetic aggregate winner/tie/empty-unit verification failed")
    return {"winner_after_non_support": win, "two_supported_options": tie,
            "empty_route_status": empty["empty"]["status"], "passed": True}


def verify_nli_model_files():
    for name, expected in NLI.NLI_FILE_SHA256.items():
        path = ROOT / ".deps/sku-fixed-models/nli" / name
        if not path.is_file() or sha(path) != expected:
            raise ValueError("pinned NLI model file differs: " + name)


def verify_pair_records(main_dir, nli_dir, units, model_requests, blocks):
    expected_pairs = NLI_SCORE.pairs_for(units, model_requests, blocks)
    pair_by_id = indexed(expected_pairs, "id", "reconstructed model pairs")
    saved_pairs = indexed(read_rows(nli_dir / "model-pairs.jsonl"), "id", "saved model pairs")
    if saved_pairs != pair_by_id:
        raise ValueError("saved NLI model-pair identities/contents differ from frozen source requests")
    raw_values = read_rows(nli_dir / "classification-options.jsonl")
    raw = indexed(raw_values, "id", "raw NLI outputs")
    if set(raw) != set(pair_by_id) or len(raw_values) != len(pair_by_id):
        raise ValueError("raw NLI output pair identity set differs from every whole-option input")
    for identity, pair in pair_by_id.items():
        record = raw[identity]
        if any(record.get(key) != value for key, value in pair.items()):
            raise ValueError("raw NLI output no longer binds its exact source pair: " + identity)
    return pair_by_id, raw


def _probabilities(record):
    probabilities = record.get("probabilities")
    if not isinstance(probabilities, dict) or set(probabilities) != {"support", "conflict", "unknown"}:
        return None
    values = {}
    for key, value in probabilities.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
            return None
        values[key] = float(value)
    if not math.isclose(sum(values.values()), 1, rel_tol=0, abs_tol=1e-5):
        return None
    token_count = record.get("token_count_untruncated")
    if (record.get("error_type") is not None or type(token_count) is not int
            or token_count < 1 or NLI.exceeds_token_limit(token_count)):
        return None
    return values


def block_winner(option_records, options):
    """A block votes only when exactly one full raw option beats both controls."""
    if len(option_records) != len(options):
        return None
    votes = []
    for expected_index, (option, record) in enumerate(zip(options, option_records, strict=True)):
        if record.get("option_value") != option or record.get("option_index") != expected_index:
            return None
        probabilities = _probabilities(record)
        if probabilities is None:
            return None
        if probabilities["support"] > probabilities["conflict"] and probabilities["support"] > probabilities["unknown"]:
            votes.append(option)
    return votes[0] if len(votes) == 1 else None


def aggregate_units(units, requests, pair_by_id, raw_by_id, source_blocks,
                    main_unit_results, documents, method):
    """Aggregate raw pair scores by unit/block; preserve raw rows as receipts."""
    req_by_unit = defaultdict(list)
    request_values = requests.values() if isinstance(requests, dict) else requests
    for request in request_values:
        req_by_unit[request["group_id"]].append(request)
    pairs_by_unit_block = defaultdict(list)
    for pair_id, pair in pair_by_id.items():
        pairs_by_unit_block[pair["group_id"], pair["block_id"]].append((pair, raw_by_id[pair_id]))
    output = {}
    for unit_id, unit in units.items():
        selected_requests = sorted(req_by_unit.get(unit_id, []), key=lambda row: row["block_rank"])
        if len({row["block_id"] for row in selected_requests}) != len(selected_requests) or len(selected_requests) > 3:
            raise ValueError("source top-three block identities are duplicated or excessive")
        source_jev = main_unit_results.get(unit_id)
        if (not isinstance(source_jev, dict) or source_jev.get("group_id") != unit_id
                or source_jev.get("group_sha256") != unit["group_sha256"]):
            raise ValueError("MAIN JEV raw winner receipt is absent or differently bound: " + unit_id)
        jev_winners = source_jev.get("block_winners")
        expected_blocks = {row["block_id"] for row in selected_requests}
        if not isinstance(jev_winners, dict) or set(jev_winners) != expected_blocks:
            raise ValueError("MAIN JEV block-winner map differs from its frozen top-three requests")
        block_votes, block_receipts = {}, {}
        for request in selected_requests:
            bid = request["block_id"]
            values = sorted(pairs_by_unit_block.get((unit_id, bid), []),
                            key=lambda value: value[0]["option_index"])
            if values:
                pairs = [pair for pair, _ in values]
                if ([pair["option_value"] for pair in pairs] != unit["option_values"]
                        or [pair["option_index"] for pair in pairs] != list(range(len(unit["option_values"])) )):
                    raise ValueError("NLI block does not contain exactly the complete ordered raw option set")
            nli_winner = block_winner([raw for _, raw in values], unit["option_values"])
            jev_winner = jev_winners[bid]
            joint_winner = nli_winner if nli_winner is not None and nli_winner == jev_winner else None
            selected_winner = nli_winner if method == "nli" else joint_winner
            block_votes[bid] = selected_winner
            block_receipts[bid] = {
                "block_id": bid, "block_rank": request["block_rank"],
                "nli_winner": nli_winner, "jev_raw_unique_winner": jev_winner,
                "method_winner": selected_winner,
                "raw_option_records": [deepcopy(raw) for _, raw in values],
            }
        counts = Counter(value for value in block_votes.values() if value is not None)
        leaders = [option for option in unit["option_values"] if counts[option] >= 2]
        winner = leaders[0] if len(leaders) == 1 else None
        supporting = [bid for bid, value in block_votes.items() if winner is not None and value == winner]
        refs = []
        if winner is not None:
            for bid in supporting:
                source_block = source_blocks[bid]
                current_refs = MAIN.literal_block_refs(source_block, unit["target_document_id"], documents)
                if current_refs is None:
                    raise ValueError("winning NLI block lacks its exact fixed-document description refs")
                refs.extend(current_refs)
            if unit["kind"] == "paired":
                text = unit.get("target_selected_axes_text")
                request = unit.get("source_request")
                if not isinstance(text, str) or not text or not isinstance(request, dict):
                    raise ValueError("paired unit lacks fixed selected-axis context")
                selected_ref = {"document_id": unit["target_document_id"], "field": "selected_axes",
                                "start": 0, "end": len(text), "quote": text}
                if not E.GATE.verify_quote(selected_ref, request, documents):
                    raise ValueError("paired selected-axis context quote does not verify")
                refs.append(selected_ref)
            elif unit["kind"] != "shared":
                raise ValueError("unsupported source unit kind")
        output[unit_id] = {
            "source_unit_id": unit_id, "source_unit_sha256": unit["group_sha256"],
            "unit_kind": unit["kind"], "method": method,
            "status": "ok" if winner is not None else "unknown", "winning_value": winner,
            "block_votes": block_votes, "block_receipts": block_receipts,
            "supporting_block_ids": supporting, "quote_refs": CONTENT_REF_DEDUP(refs),
            "scope_status": "unproved", "production_adoption_allowed": False,
            "jev_receipt": deepcopy(source_jev),
        }
    if not set(req_by_unit).issubset(units):
        raise ValueError("model requests contain a unit absent from the frozen source units")
    return output


def CONTENT_REF_DEDUP(refs):
    return MAIN.PRODUCT.deduplicate_refs(refs)


def build_method_predictions(method, main_plan, main_units, unit_results, requests,
                             documents, tasks, baseline, eligible, proof_ids,
                             main_model_identity, contract, jev_pin):
    identity = deepcopy(main_model_identity)
    identity["composition_nli_method"] = method
    identity["composition_nli_pin"] = deepcopy(NLI_SCORE.model_pin())
    identity["composition_jev_pin"] = deepcopy(jev_pin)
    content_version = CONTENT.CONTENT_VERSION + "/" + method
    request_values = requests.values() if isinstance(requests, dict) else requests
    request_by_id = {request["request_id"]: request for request in request_values}
    if len(request_by_id) != len(requests):
        raise ValueError("source requests have duplicate request identities")
    plan = SHARING.build_groups(requests, documents,
        {rid: prediction["source_task_bindings"] for rid, prediction in baseline.items()},
        model_identity=identity, content_version=content_version, invariance_contract=contract)
    source_group_map = {}
    for group in main_plan["groups"]:
        source_group_map[frozenset(group["request_ids"])] = group["group_id"]
    if len(source_group_map) != len(main_plan["groups"]):
        raise ValueError("MAIN sharing groups do not have unique original request sets")
    shared_results = {}
    for group in plan["groups"]:
        source_id = source_group_map.get(frozenset(group["request_ids"]))
        if source_id is None or source_id not in unit_results:
            raise ValueError("new method group request set has no exact MAIN source unit")
        source_unit = main_units[source_id]
        if (source_unit["kind"] != "shared"
                or source_unit["option_values"] != group["option_values"]
                or source_unit["target_document_id"] != group["target_document_id"]):
            raise ValueError("shared source unit semantics differ from method-specific plan")
        result = unit_results[source_id]
        shared_results[group["group_id"]] = {
            "group_sha256": group["group_sha256"], "status": result["status"],
            "winning_value": result["winning_value"], "quote_refs": deepcopy(result["quote_refs"]),
            "reason": "two_distinct_blocks_agree" if result["winning_value"] else "no_unique_two_block_winner",
            "method": method, "source_unit_result": deepcopy(result),
        }
    derived = {row["request_id"]: row for row in SHARING.fan_out(plan, shared_results, list(baseline.values()))}
    for identity_value, unit_value in main_units.items():
        if unit_value["kind"] != "paired":
            continue
        request = request_by_id.get(identity_value)
        if request is None:
            raise ValueError("paired source unit does not map to an original request")
        result = unit_results[identity_value]
        paired_result = {"winning_value": result["winning_value"], "quote_refs": result["quote_refs"],
                         "reason": "two_distinct_blocks_agree" if result["winning_value"] else "no_unique_two_block_winner",
                         "method": method, "source_unit_result": deepcopy(result)}
        derived[identity_value] = MAIN.paired_prediction(request, baseline[identity_value], paired_result)
    if set(derived) != set(request_by_id):
        raise ValueError("method fanout does not cover exactly every original request")
    # Fallback is intentionally baseline-unknown -> candidate-support only.
    predicted = deepcopy(baseline)
    for request_id, candidate in derived.items():
        if request_id in proof_ids:
            continue
        if baseline[request_id]["state"] != "support" and candidate["state"] == "support":
            predicted[request_id] = deepcopy(candidate)
    E.GATE.validate_predictions(requests, documents, tasks, predicted, baseline, "baseline")
    for request_id in eligible:
        if any(ref.get("field") == "selected_axes" for ref in predicted[request_id].get("quote_refs", [])):
            raise ValueError("product-global result cites a selected row")
    if any(predicted[request_id] != baseline[request_id] for request_id in proof_ids):
        raise ValueError("typed raw proof must remain byte-semantically unchanged")
    return plan, derived, predicted


def run():
    if OUTPUT.exists():
        raise FileExistsError(OUTPUT)
    started = time.perf_counter()
    nli_summary = read_json(NLI_DIR / "summary.json")
    base_summary = read_json(BASE_PRED / "summary.json")
    verify_hashes(NLI_DIR, nli_summary["output_sha256"], skip=("summary.json",))
    for path in (BASE_EVAL / "gates/manifest.json", BASE_EVAL / "gates/decisions.jsonl",
                 BASE_EVAL / "gates/row_results.jsonl", BASE_EVAL / "gates/condition_results.jsonl",
                 BASE_EVAL / "gates/diff_vs_upstream.jsonl"):
        if not path.is_file():
            raise FileNotFoundError(path)
    if sha(BASE_PRED / "predictions.jsonl") != base_summary.get("predictions_sha256"):
        raise ValueError("frozen BASE predictions SHA differs")
    base_source_freeze = BASE_PRED / "source-freeze.json"
    if sha(base_source_freeze) != base_summary.get("source_freeze_sha256"):
        raise ValueError("frozen BASE source freeze SHA differs")
    if sha(BASE_PRED / "request-changes.jsonl") != base_summary.get("request_changes_sha256"):
        raise ValueError("frozen BASE request changes SHA differs")
    if (base_summary.get("request_count") != EXPECTED["requests"]
            or base_summary.get("typed_predictions_and_all_nondeclared_requests_unchanged") is not True):
        raise ValueError("BASE prediction artifact is outside the declared 134-request run")
    if (nli_summary.get("schema_version") != "composition-nli-score-only-v1"
            or nli_summary.get("references_read") is not False or nli_summary.get("gates_read") is not False
            or nli_summary.get("independent_test") is not False
            or nli_summary.get("predeclared_comparison_policies") != NLI_SCORE.POLICY_DECLARATIONS):
        raise ValueError("NLI artifact is not the predeclared score-only run")
    if nli_summary.get("model_pin") != NLI_SCORE.model_pin() or nli_summary.get("verified_model_pin", {}).get("revision") != NLI.MODEL_REVISION:
        raise ValueError("NLI model pin differs from the current frozen CPU model")
    verify_nli_model_files()

    manifest, requests, documents, tasks, cases, membership, hosts = E.load_mixed_prepared(PREP)
    cpu_summary, _ = E.verify_cpu_run(PREP, CPU, manifest, requests)
    VERIFY.verify_source(CPU / "product-model")
    main_freeze = read_json(MAIN_DIR / "execution-freeze.json")
    if (main_freeze.get("schema_version") != "composition-evidence-execution-v1"
            or main_freeze.get("labels_read") is not False
            or main_freeze.get("independent_test") is not False):
        raise ValueError("MAIN execution freeze violates label/test scope")
    for name, expected in nli_summary["input_sha256"].items():
        path = MAIN_DIR / name
        if not path.is_file() or sha(path) != expected:
            raise ValueError("NLI scoring input no longer matches MAIN: " + name)

    # The next MAIN outputs are model/gate inputs only; the label-bearing MAIN
    # summary is hashed here but intentionally not parsed until all new gates.
    main_units = indexed(read_rows(MAIN_DIR / "classification-units.jsonl"), "group_id", "MAIN units")
    model_requests = read_rows(MAIN_DIR / "model-requests.jsonl")
    source_blocks = indexed(read_rows(MAIN_DIR / "source-blocks.jsonl"), "block_id", "MAIN source blocks")
    revalidated_blocks, revalidation_manifest = verify_revalidated_source(source_blocks)
    source_blocks.update(revalidated_blocks)
    request_block_ids = {request["block_id"] for request in model_requests
                        if documents[source_blocks[request["block_id"]]["target_document_id"]]["side"] == "rakuten"}
    if not request_block_ids.issubset(revalidated_blocks):
        raise ValueError("a model-scored block lacks v2 raw HTML span validation")
    main_plan = read_json(MAIN_DIR / "sharing-plan.json")
    contract = read_json(MAIN_DIR / "sharing-contract.json")
    main_unit_results = indexed(read_rows(MAIN_DIR / "unit-results.jsonl"), "group_id", "MAIN unit results")
    if (len(requests) != EXPECTED["requests"] or len(cases) != EXPECTED["cases"]
            or len(contract.get("eligible_forward_request_ids", [])) != EXPECTED["shared_requests"]
            or sum(unit["kind"] == "shared" for unit in main_units.values()) != EXPECTED["shared_units"]
            or sum(unit["kind"] == "paired" for unit in main_units.values()) != EXPECTED["paired_units"]):
        raise ValueError("frozen MAIN source counts differ")
    eligible = set(contract["eligible_forward_request_ids"])
    if set(main_plan.get("request_to_group", {})) != eligible:
        raise ValueError("MAIN product-global request set differs from the explicit contract")

    baseline = E.GATE.indexed(BASE_PRED / "predictions.jsonl", "request_id")
    E.GATE.validate_predictions(requests, documents, tasks, baseline, baseline, "baseline")
    proof_ids = {identity for identity, value in baseline.items() if value.get("verified_value_equivalence")}
    if len(proof_ids) != EXPECTED["typed_proofs"]:
        raise ValueError("typed proof count differs from frozen baseline")
    pair_by_id, raw_by_id = verify_pair_records(MAIN_DIR, NLI_DIR, list(main_units.values()),
        model_requests, list(source_blocks.values()))
    if nli_summary.get("record_count") != len(raw_by_id):
        raise ValueError("NLI output count differs from its summary")
    if ((NLI_DIR / "source-model-requests.jsonl").read_bytes() != (MAIN_DIR / "model-requests.jsonl").read_bytes()
            or (NLI_DIR / "source-classification-units.jsonl").read_bytes() != (MAIN_DIR / "classification-units.jsonl").read_bytes()
            or (NLI_DIR / "source-source-blocks.jsonl").read_bytes() != (MAIN_DIR / "source-blocks.jsonl").read_bytes()):
        raise ValueError("NLI score-only source copies differ from frozen MAIN files")
    jev_pin = cpu_summary.get("verified_jev_pin")
    if not isinstance(jev_pin, dict) or jev_pin.get("device") != "cpu" or jev_pin.get("precision") != "fp32":
        raise ValueError("verified CPU JEV pin is missing")

    OUTPUT.mkdir(parents=True, exist_ok=False)
    code_dir = OUTPUT / "code"
    code_dir.mkdir()
    code_paths = {Path(__file__).name: Path(__file__),
        **{name: SKU / name for name in NLI_SCORE.CODE_NAMES},
        "trial_composition_evidence_v1.py": SKU / "trial_composition_evidence_v1.py",
        "composition_evidence_v1.py": SKU / "composition_evidence_v1.py",
        "evaluate_keyword_filtered_product_v1.py": SKU / "evaluate_keyword_filtered_product_v1.py",
    }
    code_hashes = {}
    for name, path in code_paths.items():
        if not path.is_file():
            raise FileNotFoundError(path)
        shutil.copyfile(path, code_dir / name)
        code_hashes[name] = sha(code_dir / name)

    input_paths = [PREP / "manifest.json", *(PREP / name for name in E.PREP_FILES),
                   CPU / "summary.json", CPU / "cpu-source-freeze.json", CPU / "execution-freeze.json",
                   *(path for path in MAIN_DIR.rglob("*") if path.is_file()),
                   NLI_DIR / "summary.json", *(NLI_DIR / name for name in nli_summary["output_sha256"]),
                   BASE_PRED / "summary.json", BASE_PRED / "source-freeze.json", BASE_PRED / "predictions.jsonl",
                   BASE_PRED / "request-changes.jsonl",
                   BASE_EVAL / "gates/manifest.json", BASE_EVAL / "gates/decisions.jsonl",
                   BASE_EVAL / "gates/row_results.jsonl", BASE_EVAL / "gates/condition_results.jsonl",
                   BASE_EVAL / "gates/diff_vs_upstream.jsonl", OLD_EVAL / "summary.json", ROUTES / "manifest.json",
                   REVALIDATION_DIR / "validation.json", REVALIDATION_DIR / "source-blocks.jsonl",
                   REVALIDATION_DIR / "span-receipts.jsonl", REVALIDATION_DIR / "raw-pins.jsonl",
                   *(REVALIDATION_DIR / "code" / name for name in revalidation_manifest["source_code_sha256"])]
    input_paths = list(dict.fromkeys(input_paths))
    input_hashes = {str(path.resolve()): sha(path) for path in input_paths}
    source_snapshot = VERIFY.snapshot_paths({str(path): path for path in input_paths})
    write_rows(OUTPUT / "source-nli-records.jsonl", raw_by_id.values())
    write_rows(OUTPUT / "source-model-pairs.jsonl", pair_by_id.values())
    write_rows(OUTPUT / "source-model-requests.jsonl", model_requests)
    write_rows(OUTPUT / "source-classification-units.jsonl", main_units.values())
    write_rows(OUTPUT / "source-blocks-v2-revalidated.jsonl", revalidated_blocks.values())
    synthetic_check = verify_synthetic_aggregation()
    write_json(Path(__file__).resolve().parent / "synthetic-checks.json", synthetic_check)

    method_outputs, method_gate_manifests = {}, {}
    aggregate_path = OUTPUT / "source-unit-aggregates.jsonl"
    per_method_aggregates = {}
    main_model_identity = main_freeze.get("model_identity")
    if not isinstance(main_model_identity, dict):
        raise ValueError("MAIN freeze lacks its pinned JEV model identity")
    for method in METHODS:
        kind = METHOD_KIND[method]
        results = aggregate_units(main_units, model_requests, pair_by_id, raw_by_id,
                                  source_blocks, main_unit_results, documents, kind)
        per_method_aggregates[method] = results
        plan, derived, predicted = build_method_predictions(method, main_plan, main_units, results,
            requests, documents, tasks, baseline, eligible, proof_ids,
            main_model_identity, contract, jev_pin)
        variant_dir = OUTPUT / method
        variant_dir.mkdir()
        write_json(variant_dir / "sharing-plan.json", plan)
        write_rows(variant_dir / "derived-predictions.jsonl", derived.values())
        write_rows(variant_dir / "predictions.jsonl", predicted.values())
        E.GATE.validate_predictions(requests, documents, tasks, predicted, baseline, "baseline")
        method_gate_manifests[method] = E.GATE.finish(PREP, variant_dir / "predictions.jsonl", variant_dir / "gates")
        gates = E.GATE.indexed(variant_dir / "gates/decisions.jsonl", "case_id")
        if set(gates) != set(cases):
            raise ValueError("same-AU-row gate coverage differs: " + method)
        method_outputs[method] = {"derived_count": len(derived), "prediction_count": len(predicted),
                                  "gate_count": len(gates), "decision_counts": method_gate_manifests[method]["decision_counts"],
                                  "plan_sha256": sha(variant_dir / "sharing-plan.json"),
                                  "predictions_sha256": sha(variant_dir / "predictions.jsonl"),
                                  "gate_manifest_sha256": sha(variant_dir / "gates/manifest.json")}
        write_rows(variant_dir / "unit-aggregates.jsonl", results.values())

    write_rows(aggregate_path, (row for method, values in per_method_aggregates.items()
                                for row in (dict(value, comparison_method=method) for value in values.values())))
    pre_reference_paths = {str(path): path for path in OUTPUT.rglob("*") if path.is_file()}
    pre_reference_snapshot = VERIFY.snapshot_paths(pre_reference_paths)
    gate_hashes = {method: sha(OUTPUT / method / "gates/manifest.json") for method in METHODS}
    evaluator_freeze = {
        "schema_version": "composition-nli-evaluation-freeze-v1", "labels_read": False,
        "independent_test": False, "production_adoption_allowed": False,
        "predeclared_methods": list(METHODS), "all_predictions_and_same_au_gates_frozen": True,
        "case_count": len(cases), "request_count": len(requests), "shared_request_count": len(eligible),
        "shared_unit_count": EXPECTED["shared_units"], "paired_unit_count": EXPECTED["paired_units"],
        "typed_proof_count": len(proof_ids), "nli_raw_pair_count": len(raw_by_id),
        "nli_model_pin": nli_summary["verified_model_pin"], "jev_model_pin": jev_pin,
        "input_sha256": input_hashes, "source_snapshot": source_snapshot,
        "source_revalidation_v2": {"validation_sha256": sha(REVALIDATION_DIR / "validation.json"),
            "source_blocks_sha256": sha(REVALIDATION_DIR / "source-blocks.jsonl"),
            "span_receipts_sha256": sha(REVALIDATION_DIR / "span-receipts.jsonl"),
            "raw_pins_sha256": sha(REVALIDATION_DIR / "raw-pins.jsonl"),
            "accepted_block_count": len(revalidated_blocks), "verified_span_count": len(read_rows(REVALIDATION_DIR / "span-receipts.jsonl")),
            "source_code_sha256": revalidation_manifest["source_code_sha256"]},
        "code_sha256": code_hashes, "gate_manifest_sha256": gate_hashes,
        "pre_reference_output_snapshot": pre_reference_snapshot,
        "literal_quote_existence_is_not_applicability_proof": True,
        "nli_raw_probabilities_preserved": True, "nli_relation_or_confidence_not_used": True,
        "same_block_joint_uses_saved_main_raw_jev_winner": True,
        "baseline_support_and_typed_proofs_preserved_by_fallback": True,
    }
    write_json(OUTPUT / "freeze.json", evaluator_freeze)
    write_json(OUTPUT / "all-gates-frozen.json", {"labels_read": False,
        "all_predictions_and_gates_frozen": True, "gate_manifest_sha256": gate_hashes,
        "methods": list(METHODS)})
    frozen_files = {str(path): path for path in OUTPUT.rglob("*") if path.is_file()}
    frozen_output_snapshot = VERIFY.snapshot_paths(frozen_files)
    VERIFY.verify_snapshot(pre_reference_snapshot, phase="before existing dev references")
    VERIFY.verify_snapshot(source_snapshot, phase="before existing dev references")
    VERIFY.verify_snapshot(frozen_output_snapshot, phase="before existing dev references")

    # This is the first access to the existing machine reference set.
    _, _, route_manifest, references, _ = REFERENCES.verify_original_sources(PREP, OLD_EVAL, ROUTES)
    main_summary = read_json(MAIN_DIR / "summary.json")
    base_eval_summary = read_json(BASE_EVAL / "summary.json")
    verify_hashes(MAIN_DIR, main_summary["output_sha256"], skip=("summary.json",))
    verify_hashes(BASE_EVAL, base_eval_summary["output_sha256"], skip=("summary.json",))
    if (main_summary.get("schema_version") != "composition-evidence-result-v1"
            or main_summary.get("verified_jev_pin") != jev_pin):
        raise ValueError("MAIN scored summary differs from the frozen JEV identity")
    scored_ids = {row["case_id"] for row in E.eligibility_rows(membership, hosts)[0]
                  if row["primary_score_eligible"]}
    scored = {identity: value for identity, value in references.items()
              if identity in scored_ids and not value.get("reference_uncertain", False)}
    if len(scored) != EXPECTED["scored"]:
        raise ValueError("existing scored machine-reference count differs from the declared 73")
    base_gates = E.GATE.indexed(BASE_EVAL / "gates/decisions.jsonl", "case_id")
    if set(base_gates) != set(cases):
        raise ValueError("frozen TP30/FP1 baseline gate coverage differs")
    base_metrics = E.metrics_for(base_gates, scored)
    if base_metrics["tp"] != 30 or base_metrics["fp"] != 1:
        raise ValueError("the frozen BASE artifact is not the declared TP30/FP1 reference")
    summaries = {}
    for method in METHODS:
        variant_dir = OUTPUT / method
        gates = E.GATE.indexed(variant_dir / "gates/decisions.jsonl", "case_id")
        details, by_stratum = [], {}
        for stratum in E.STRATA:
            subset = {identity: reference for identity, reference in scored.items()
                      if membership[identity]["membership_strata"] == [stratum]}
            value = E.metrics_for(gates, subset)
            by_stratum[stratum] = {key: item for key, item in value.items() if key != "case_results"}
            details.extend({"stratum": stratum, **result} for result in value["case_results"])
        union = E.metrics_for(gates, scored)
        changes = []
        base_details = {row["case_id"]: row for row in base_metrics["case_results"]}
        for result in union["case_results"]:
            old = base_details[result["case_id"]]
            if result != old:
                changes.append({"case_id": result["case_id"], "before": old, "after": result})
        write_rows(variant_dir / "case-results.jsonl", details)
        write_rows(variant_dir / "case-changes-vs-baseline.jsonl", changes)
        summaries[method] = {"strata": by_stratum,
                             "scored_primary_reference_union": {key: item for key, item in union.items()
                                                                 if key != "case_results"},
                             "changes_vs_baseline": len(changes),
                             "gate_decision_counts": method_gate_manifests[method]["decision_counts"],
                             "reference_kind": "existing_machine_dev_labels_not_human_gold"}

    VERIFY.verify_snapshot(pre_reference_snapshot, phase="after existing dev scoring")
    VERIFY.verify_snapshot(source_snapshot, phase="after existing dev scoring")
    VERIFY.verify_snapshot(frozen_output_snapshot, phase="after existing dev scoring")
    VERIFY.verify_source(CPU / "product-model")
    verify_nli_model_files()
    verify_hashes(MAIN_DIR, main_summary["output_sha256"], skip=("summary.json",))
    verify_hashes(NLI_DIR, nli_summary["output_sha256"], skip=("summary.json",))
    if (sha(BASE_PRED / "predictions.jsonl") != base_summary.get("predictions_sha256")
            or sha(BASE_PRED / "source-freeze.json") != base_summary.get("source_freeze_sha256")
            or sha(BASE_PRED / "request-changes.jsonl") != base_summary.get("request_changes_sha256")):
        raise ValueError("frozen BASE prediction inputs changed during evaluation")
    result = {
        "schema_version": "composition-nli-evaluation-result-v1",
        "experiment_status": "exploratory_dev_informed", "independent_test": False,
        "production_adoption_allowed": False, "case_count": len(cases),
        "request_count": len(requests), "scored_case_count": len(scored),
        "labels_read_after_all_predictions_and_gates_frozen": True,
        "reference_kind": "existing_machine_dev_labels_not_human_gold",
        "reference_route_manifest_sha256": sha(ROUTES / "manifest.json"),
        "nli_model_pin": nli_summary["verified_model_pin"], "jev_model_pin": jev_pin,
        "methods": summaries, "baseline_scored_primary_reference_union": {
            key: value for key, value in base_metrics.items() if key != "case_results"},
        "total_seconds": time.perf_counter() - started,
        "original_inputs_and_code_verified_after_scoring": True,
    }
    result["output_sha256"] = {str(path.relative_to(OUTPUT)): sha(path)
                               for path in OUTPUT.rglob("*") if path.is_file() and path.name != "summary.json"}
    write_json(OUTPUT / "summary.json", result)
    print(json.dumps({method: value["scored_primary_reference_union"]
                      for method, value in summaries.items()}, ensure_ascii=False), flush=True)
    return result


if __name__ == "__main__":
    run()
