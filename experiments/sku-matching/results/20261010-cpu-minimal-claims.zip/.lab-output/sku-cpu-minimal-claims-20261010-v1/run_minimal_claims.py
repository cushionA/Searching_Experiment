#!/usr/bin/env python3
"""Frozen, label-blind two-template CPU task diagnostic on v9 real residuals."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
TASK_DIR = ROOT / ".lab-output/sku-cpu-residual-task-20261010-v9"
TASKS = TASK_DIR / "tasks.jsonl"
PRODUCTS = TASK_DIR / "products.jsonl"
TASK_MANIFEST = TASK_DIR / "manifest.json"
ARRAYS = ROOT / ".lab-output/sku-observed-product-pairs-20261010-final-v4/au_product_sku_arrays.jsonl"
MODEL_DIR = ROOT / ".deps/sku-gliner-model"
TRIAL_CODE = ROOT / "experiments/sku-matching/trial_cpu_residual_axis.py"
TRY_GLINER = ROOT / "experiments/sku-matching/try_gliner.py"
REV = "e173bca1f0c4217d7a55b3b0c705d5ece8a0218d"
REPO = "fastino/GLiNER2.5-multi-Decide"
GENERIC_LABELS = ["条件を満たす", "条件に矛盾する", "固定条件から不明"]
DESCRIPTIVE_LABELS = [
    "商品名がこの選択条件を明示的に支持する",
    "商品名がこの選択条件を明示的に否定する、または排他的な別条件を示す",
    "商品名だけでは判断できない",
]

if str(ROOT / "experiments/sku-matching") not in sys.path:
    sys.path.insert(0, str(ROOT / "experiments/sku-matching"))
import trial_cpu_residual_axis as residual


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_jsonl(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_json(path: Path, value: object, *, exclusive: bool = True) -> None:
    with path.open("x" if exclusive else "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def title_flags(title: str) -> dict:
    """Mechanical metadata only; never used to alter prompts or model outputs."""
    patterns = {
        "quantity_mentions": r"\d+\s*(?:枚|個|組|セット|本|台|段|パネル|点)",
        "dimension_mentions": r"\d+(?:\.\d+)?\s*(?:cm|mm|ｍｍ)",
        "selection_or_condition_cues": r"選べる|選択|の場合|選択時|タイプ|カラー|色|サイズ|レース|セット|付き|なし|あり",
        "sales_or_scope_cues": r"販売案内|ランキング|\d+\s*%OFF|シリーズ|ラインナップ|全\d+",
    }
    return {name: re.findall(pattern, title, flags=re.I) for name, pattern in patterns.items()}


def build_inputs() -> list[dict]:
    tasks = read_jsonl(TASKS)
    products_rows = read_jsonl(PRODUCTS)
    products = {p["dossier_id"]: p for p in products_rows}
    task_lines = {t["case_id"]: i for i, t in enumerate(tasks, 1)}
    product_lines = {p["dossier_id"]: i for i, p in enumerate(products_rows, 1)}
    array_path = ARRAYS
    array_by_id = {str(a["au_product_id"]): (i, a) for i, a in enumerate(read_jsonl(array_path), 1)}

    unique: dict[tuple, dict] = {}
    for task in tasks:
        product = products[task["fixed_au_product_ref"]["dossier_id"]]
        expanded = {**task, "au_sku_rows": product.get("au_sku_rows", [])}
        plan = residual.common_axis_plan(expanded)
        for axis in plan["residual_axes"]:
            # Inputs contain no common-axis context; deduplicate only fields in prompt.
            key = (str(task["product_id"]), product.get("title_raw", ""),
                   axis.get("semantic_key"), axis.get("axis_name_raw", ""), axis.get("value_raw", ""))
            row = unique.get(key)
            if row is None:
                title_ref = product.get("title_source_ref", {})
                title_leaf = title_ref.get("raw_title_source", {})
                array_line, array_row = array_by_id.get(str(task["product_id"]), (None, {}))
                axis_ref = axis.get("source_ref", {})
                row = {
                    "residual_id": "claim-" + hashlib.sha256("\0".join(map(str, key)).encode()).hexdigest()[:20],
                    "product_id": str(task["product_id"]), "semantic_key": axis.get("semantic_key"),
                    "axis_name_raw": axis.get("axis_name_raw", ""), "value_raw": axis.get("value_raw", ""),
                    "normalized_value": axis.get("normalized_value"), "title_raw": product.get("title_raw", ""),
                    "title_source_provenance": {
                        "prepared_product_file": str(PRODUCTS.relative_to(ROOT)),
                        "prepared_product_line": product_lines[product["dossier_id"]],
                        "prepared_json_path": f"$.title_raw; source path: {title_ref.get('json_path')}",
                        "title_source_ref": title_ref, "raw_title_leaf": title_leaf,
                        "raw_title_array_file": str(array_path.relative_to(ROOT)),
                        "raw_title_array_sha256": sha256(array_path),
                        "raw_title_array_line": array_line,
                        "raw_title_array_json_path": "$.au_product_title_raw",
                        "raw_array_title_equals_prepared_title": array_row.get("au_product_title_raw") == product.get("title_raw", ""),
                        "title_is_dossier_semantic_line": "semantic_line" in str(title_ref.get("json_path", "")),
                    },
                    "rakuten_axis_source": {
                        "prepared_task_file": str(TASKS.relative_to(ROOT)),
                        "example_case_id": task["case_id"], "prepared_task_line": task_lines[task["case_id"]],
                        "prepared_json_path": f"$.rakuten.axes[source_order={axis.get('source_order')}]",
                        "raw_axis_source_ref": axis_ref, "source_order": axis.get("source_order"),
                    },
                    "example_case_ids": [],
                    "title_ambiguity_flags": title_flags(product.get("title_raw", "")),
                }
                row["prompt_a"] = f"商品名: {row['title_raw']}\n確認する選択条件: {row['axis_name_raw']}={row['value_raw']}"
                row["prompt_b"] = row["prompt_a"]
                unique[key] = row
            row["example_case_ids"].append(task["case_id"])
    return sorted(unique.values(), key=lambda x: (x["product_id"], x["semantic_key"], x["axis_name_raw"], x["value_raw"]))


def verify_model() -> dict:
    import try_gliner
    if try_gliner.REPO != REPO or try_gliner.REVISION != REV:
        raise RuntimeError("try_gliner model pin mismatch")
    files = {}
    for name, expected in try_gliner.FILES.items():
        path = MODEL_DIR / name
        actual = {"size_bytes": path.stat().st_size, "sha256": sha256(path)}
        if actual["size_bytes"] != expected["size_bytes"] or actual["sha256"] != expected["sha256"]:
            raise RuntimeError(f"Pinned model checksum mismatch: {name}")
        files[name] = actual
    source = json.loads((MODEL_DIR / "source-manifest.json").read_text(encoding="utf-8"))
    if source.get("repo") != REPO or source.get("revision") != REV:
        raise RuntimeError("Local model source-manifest pin mismatch")
    return {"repo": REPO, "revision": REV, "files": files,
            "source_manifest_sha256": sha256(MODEL_DIR / "source-manifest.json")}


def main() -> None:
    if (OUT / "freeze.json").exists():
        raise FileExistsError(f"Already frozen: {OUT}")
    OUT.mkdir(parents=True, exist_ok=True)
    source_paths = (TASKS, PRODUCTS, TASK_MANIFEST, ARRAYS, TRIAL_CODE, TRY_GLINER)
    source_hashes = {str(p.relative_to(ROOT)): sha256(p) for p in source_paths}
    task_manifest = json.loads(TASK_MANIFEST.read_text(encoding="utf-8"))
    if sha256(TASKS) != task_manifest["tasks_sha256"] or sha256(PRODUCTS) != task_manifest["products_sha256"]:
        raise RuntimeError("v9 tasks/products do not match their frozen manifest")

    inputs = build_inputs()
    if not inputs:
        raise RuntimeError("No residual claim prompts")
    inputs_path = OUT / "inputs.jsonl"
    with inputs_path.open("x", encoding="utf-8") as f:
        for row in inputs:
            f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    model_pin = verify_model()
    runtime_versions = {name: importlib.metadata.version(name) for name in
                        ("gliner2", "torch", "transformers", "tokenizers", "safetensors")}
    freeze = {
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_hashes": source_hashes,
        "input_count": len(inputs), "unique_products": len({x["product_id"] for x in inputs}),
        "inputs_sha256": sha256(inputs_path), "inputs_path": str(inputs_path.relative_to(ROOT)),
        "model": model_pin, "runtime_versions": runtime_versions,
        "trial_script_sha256": sha256(Path(__file__)),
        "method": "Two fixed template variants; title-only premise vs one Rakuten residual selected axis/value; no common-axis context, descriptions, decision gate, or gold.",
        "templates": {
            "A": {"prompt_format": "商品名: {title}\\n確認する選択条件: {axis_name}={value}", "labels": GENERIC_LABELS},
            "B": {"same_prompt_text_as_A": True, "labels": DESCRIPTIVE_LABELS},
        },
        "execution": {"cpu_only": True, "threads_intra": 2, "threads_inter": 1,
                      "batch_size": 8, "confidence_cutoff": "none applied for this diagnostic",
                      "no_threshold_tuning": True, "no_output_adjudication": True},
        "provenance_rule": "Each row retains title and axis source refs, prepared JSONL lines/paths, upstream raw title array leaf/line, exact prepared-vs-source title equality, and dossier-derived status.",
        "labels_predictions_gold_read": False,
    }
    write_json(OUT / "freeze.json", freeze)
    if source_hashes != {str(p.relative_to(ROOT)): sha256(p) for p in source_paths}:
        raise RuntimeError("Frozen source changed before inference")

    os.environ.update(CUDA_VISIBLE_DEVICES="", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                      TOKENIZERS_PARALLELISM="false")
    import torch
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    if torch.cuda.is_available():
        raise RuntimeError("CUDA available; refusing non-CPU execution")
    from gliner2 import AutoExtractor
    load_start = time.perf_counter()
    model = AutoExtractor.from_pretrained(str(MODEL_DIR), local_files_only=True)
    model.eval()
    load_seconds = time.perf_counter() - load_start

    raw = []
    elapsed = {}
    for variant, labels, prompt_key in (("A", GENERIC_LABELS, "prompt_a"), ("B", DESCRIPTIVE_LABELS, "prompt_b")):
        texts = [row[prompt_key] for row in inputs]
        start_time = time.perf_counter()
        outputs = []
        for start in range(0, len(texts), 8):
            outputs.extend(model.batch_classify_text(texts[start:start + 8], {"relation": labels},
                                                     batch_size=8, include_confidence=True))
        elapsed[variant] = time.perf_counter() - start_time
        if len(outputs) != len(inputs):
            raise RuntimeError(f"Output/input count mismatch in {variant}")
        for row, output in zip(inputs, outputs, strict=True):
            value = output.get("relation") if isinstance(output, dict) else output
            label = value.get("label") if isinstance(value, dict) else value
            confidence = value.get("confidence") if isinstance(value, dict) else None
            raw.append({"variant": variant, "residual_id": row["residual_id"], "product_id": row["product_id"],
                        "semantic_key": row["semantic_key"], "axis_name_raw": row["axis_name_raw"],
                        "value_raw": row["value_raw"], "example_case_ids": row["example_case_ids"],
                        "prompt": row[prompt_key], "labels": labels, "raw_output": output,
                        "predicted_label": label, "confidence": confidence,
                        "confidence_ge_0_70": confidence is not None and float(confidence) >= 0.70,
                        "title_source_provenance": row["title_source_provenance"],
                        "rakuten_axis_source": row["rakuten_axis_source"],
                        "title_ambiguity_flags": row["title_ambiguity_flags"]})
    raw_path = OUT / "raw_outputs.jsonl"
    with raw_path.open("x", encoding="utf-8") as f:
        for row in raw:
            f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")

    counts, per_axis = {}, {}
    for variant in ("A", "B"):
        subset = [r for r in raw if r["variant"] == variant]
        scores = sorted(float(r["confidence"]) for r in subset)
        p95 = scores[int(0.95 * len(scores) + 0.999999) - 1]
        counts[variant] = {"n": len(subset),
                           "label_counts": dict(Counter(str(x["predicted_label"]) for x in subset)),
                           "confidence_ge_0_70_count": sum(x["confidence_ge_0_70"] for x in subset),
                           "confidence_min_median_p95_max": [scores[0], scores[len(scores)//2], p95, scores[-1]]}
        grouped = defaultdict(list)
        for row in subset:
            grouped[row["semantic_key"]].append(row)
        per_axis[variant] = {key: {"n": len(values),
                                   "label_counts": dict(Counter(str(x["predicted_label"]) for x in values)),
                                   "confidence_ge_0_70_count": sum(x["confidence_ge_0_70"] for x in values)}
                             for key, values in sorted(grouped.items())}
    paired = defaultdict(dict)
    for row in raw:
        paired[row["residual_id"]][row["variant"]] = row
    transitions = Counter((value["A"]["predicted_label"], value["B"]["predicted_label"])
                          for value in paired.values())
    summary = {
        "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        "n_unique_product_axis_value_inputs": len(inputs), "products": len({x["product_id"] for x in inputs}),
        "variant_results": counts, "per_semantic_key": per_axis,
        "A_to_B_label_transitions": {f"{a} => {b}": n for (a, b), n in sorted(transitions.items())},
        "model_load_seconds": load_seconds, "inference_seconds": elapsed,
        "runtime_versions": freeze["runtime_versions"],
        "cpu_threads": {"intra_op": torch.get_num_threads(), "inter_op": torch.get_num_interop_threads()},
        "cuda_available": torch.cuda.is_available(), "raw_outputs_sha256": sha256(raw_path),
        "sample_outputs": [
            {"residual_id": x["residual_id"], "product_id": x["product_id"],
             "semantic_key": x["semantic_key"], "axis_name_raw": x["axis_name_raw"], "value_raw": x["value_raw"],
             "A": paired[x["residual_id"]]["A"]["raw_output"],
             "B": paired[x["residual_id"]]["B"]["raw_output"]}
            for x in inputs[:12]
        ],
        "interpretation_limit": "Prompt-sensitivity diagnostic only: one title and one raw selected condition. The classifier's softmax argmax/score is not NLI ground truth or a calibrated probability; no labels, gold, prior predictions, full-page scope, row applicability, or final match decisions were evaluated. Do not accept/reject a SKU from these outputs alone.",
        "labels_predictions_gold_read": False,
    }
    write_json(OUT / "summary.json", summary)
    print(json.dumps({"input_count": len(inputs), "counts": counts,
                      "transitions": summary["A_to_B_label_transitions"],
                      "model_load_seconds": load_seconds, "inference_seconds": elapsed,
                      "output": str(OUT)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
