from pathlib import Path
from collections import Counter
import json
import hashlib
import sys
import shutil

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / 'experiments/sku-matching'
sys.path.insert(0, str(HERE))
import evaluate_mixed_gpu_sku_v1 as E
import evaluate_keyword_filtered_product_v1 as REFERENCES
import product_condition_sharing_v1 as SHARING

OUT = Path(__file__).resolve().parent
PREP = ROOT / '.lab-output/sku-mixed-gpu-prep-20261012-v5'
CPU = ROOT / '.lab-output/sku-mixed-cpu-run-20261012-v1'
OLD_EVAL = ROOT / '.lab-output/sku-mixed-cpu-evaluation-20261012-v4'
ROUTES = ROOT / '.lab-output/sku-mixed-cpu-reference-routes-20261012-v2'
PRODUCT = CPU / 'product-model'
VARIANTS = ('jev', 'nli', 'forward-jev-reverse-nli', 'forward-nli-reverse-jev', 'residual-nli')
SOURCE_VARIANTS = ('jev', 'nli')

def sha(path):
    return E.sha(Path(path))

def read_json(path):
    return json.loads(Path(path).read_text())

def read_index(path, key):
    return E.GATE.indexed(Path(path), key)

manifest, requests, documents, tasks, cases, membership, hosts = E.load_mixed_prepared(PREP)
cpu_summary, cpu_freeze = E.verify_cpu_run(PREP, CPU, manifest, requests)
fusion_baseline, original_predictions, eligible = E.check_prediction_coverage(PREP, CPU, requests, documents, tasks, cpu_summary)
plan = read_json(PRODUCT / 'sharing-plan.json')
group_results = read_index(PRODUCT / 'product-top3-jev-group-results.jsonl', 'group_id')
baseline_model = CPU / 'baseline-refresh/baseline-model'
baseline_summary = read_json(baseline_model / 'summary.json')
for name, want in baseline_summary['output_sha256'].items():
    assert sha(baseline_model / name) == want, name
source_paths = [PREP / 'manifest.json', *(PREP / name for name in E.PREP_FILES),
                CPU / 'summary.json', CPU / 'cpu-source-freeze.json', CPU / 'execution-freeze.json',
                PRODUCT / 'sharing-plan.json', PRODUCT / 'product-top3-jev-group-results.jsonl',
                baseline_model / 'summary.json', *(baseline_model / (v + '-predictions.jsonl') for v in SOURCE_VARIANTS),
                Path(__file__), Path(E.__file__), Path(REFERENCES.__file__), Path(SHARING.__file__)]
frozen = {str(p):sha(p) for p in source_paths}
saved = {v:read_index(baseline_model / (v+'-predictions.jsonl'), 'request_id')
         for v in SOURCE_VARIANTS}
residual_ids = set()
for task in tasks.values():
    direction = task['direction']
    source_side = 'rakuten' if direction=='rakuten_to_au' else 'au'
    target_side = 'au' if direction=='rakuten_to_au' else 'rakuten'
    for hint in task.get('focused_verification_hints', []):
        if hint.get('side') == source_side:
            assert hint.get('verify_with') == target_side
            assert hint.get('source_value') == task['raw_condition']['value']
            residual_ids.add(task['request_id'])
gates, predictions, files = {}, {}, {}
for variant in VARIANTS:
    if variant in SOURCE_VARIANTS:
        baseline = dict(saved[variant])
    elif variant == 'forward-jev-reverse-nli':
        baseline = {rid:saved['jev' if request['direction']=='rakuten_to_au' else 'nli'][rid]
                    for rid,request in requests.items()}
    elif variant == 'forward-nli-reverse-jev':
        baseline = {rid:saved['nli' if request['direction']=='rakuten_to_au' else 'jev'][rid]
                    for rid,request in requests.items()}
    else:
        baseline = {rid:saved['nli' if rid in residual_ids else 'jev'][rid]
                    for rid in requests}
    assert set(baseline) == set(requests)
    for identity, pred in baseline.items():
        assert pred['source_request'] == requests[identity]
        assert pred['source_task_bindings'] == fusion_baseline[identity]['source_task_bindings']
    E.GATE.validate_predictions(requests, documents, tasks, baseline, baseline, 'baseline')
    predictions[variant] = SHARING.fan_out(plan, group_results, baseline)
    predicted = {p['request_id']:p for p in predictions[variant]}
    assert len(predicted) == len(predictions[variant]) == len(requests)
    E.SHARED.validate_shared_predictions(requests, documents, tasks, predicted, baseline, eligible, 'product-top3-jev')
    assert all(predicted[k] == baseline[k] for k in set(requests)-eligible)
    directory = OUT / variant
    directory.mkdir(exist_ok=False)
    files[variant] = directory / 'predictions.jsonl'
    E.write_rows(files[variant], predictions[variant])
    E.GATE.finish(PREP, files[variant], directory / 'gates')
    gates[variant] = read_index(directory / 'gates/decisions.jsonl', 'case_id')
    assert set(gates[variant]) == set(cases)
gated_files = {str(p):sha(p) for v in VARIANTS for p in (OUT / v).rglob('*') if p.is_file()}
E.write_json(OUT / 'freeze.json', {
    'schema_version':'sku-saved-baseline-ablation-v1', 'experiment_status':'exploratory_dev_informed',
    'labels_read':False, 'independent_test':False, 'new_model_inference_run':False,
    'source_actual_cpu_inference_verified':True, 'group_results':'unchanged original product-top3-jev',
    'source_sha256':frozen, 'prediction_and_gate_sha256':gated_files,
    'case_count':len(cases),'request_count':len(requests),'nonshared_request_count':len(requests)-len(eligible),
    'variants':list(VARIANTS), 'residual_nli_request_ids':sorted(residual_ids),
    'residual_policy':'NLI only for a request with a source-side residual requiring the opposite side; JEV otherwise; unchanged JEV for genuine shared one_sided',
    'production_adoption_allowed':False})
_, _, _, references, old_results = REFERENCES.verify_original_sources(PREP, OLD_EVAL, ROUTES)
eligible_rows, _ = E.eligibility_rows(membership, hosts)
score_ids = {r['case_id'] for r in eligible_rows if r['primary_score_eligible']}
scored = {k:v for k,v in references.items() if k in score_ids and not v.get('reference_uncertain',False)}
assert len(scored) == 73
reference_hashes = {str(p):sha(p) for p in [OLD_EVAL / 'references-for-scoring.jsonl', ROUTES / 'manifest.json']}
scores = {}
details = []
for variant in VARIANTS:
    scores[variant] = {}
    for stratum in E.STRATA:
        subset = {k:v for k,v in scored.items() if membership[k]['membership_strata'] == [stratum]}
        metrics = E.metrics_for(gates[variant], subset)
        scores[variant][stratum] = {k:v for k,v in metrics.items() if k!='case_results'}
        details.extend({'variant':variant,'stratum':stratum,**r} for r in metrics['case_results'])
    metrics, changes = REFERENCES.score_changes(gates[variant], old_results, scored)
    scores[variant]['scored_primary_reference_union'] = {k:v for k,v in metrics.items() if k!='case_results'}
    scores[variant]['changes_vs_original_top3'] = changes
E.write_rows(OUT / 'case-results.jsonl', details)
for path,want in {**frozen,**gated_files,**reference_hashes}.items():
    assert sha(path) == want, path
E.verify_cpu_run(PREP, CPU, manifest, requests)
E.write_json(OUT / 'summary.json', {
    'schema_version':'sku-saved-baseline-ablation-result-v1',
    'experiment_status':'exploratory_dev_informed','independent_test':False,
    'new_model_inference_run':False,'source_actual_cpu_inference_verified':True,
    'reference_kind':'existing machine labels','scored_case_count':73,'all_case_count':83,
    'labels_read_after_all_gates_frozen':True,'input_and_prediction_hashes_verified_after_scoring':True,
    'source_sha256':frozen,'reference_sha256':reference_hashes,'production_adoption_allowed':False,
    'variants':scores,'output_sha256':{str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()}})
print(json.dumps({v:scores[v]['scored_primary_reference_union'] for v in VARIANTS}))
