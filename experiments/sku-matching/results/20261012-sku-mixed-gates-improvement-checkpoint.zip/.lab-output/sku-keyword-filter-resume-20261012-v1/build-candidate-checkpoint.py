from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
STEM = '20261012-sku-mixed-gates-improvement-checkpoint'
RESULTS = ROOT / 'experiments/sku-matching/results'
BASES = [
    '.lab-output/sku-keyword-filter-cpu-20261012-v2',
    '.lab-output/sku-keyword-filter-evaluation-20261012-v3',
    '.lab-output/sku-keyword-filter-resume-20261012-v1',
    '.lab-output/sku-baseline-ablation-20261012-v1',
    '.lab-output/sku-baseline-ablation-20261012-v2',
]
NAMES = [
    'experiments/sku-matching/trial_keyword_filtered_product_v1.py',
    'experiments/sku-matching/evaluate_keyword_filtered_product_v1.py',
    'experiments/sku-matching/session-result-20261012.txt',
    'experiments/sku-matching/claude-followup-20261012.txt',
    '.lab-output/sku-real-luna-labels-20261010-v3/labels.jsonl',
    '.lab-output/sku-novel-luna-labels-20261010-v1/labels.jsonl',
    'tests/test_lab_sku_keyword_filtered_product.py',
    'tests/test_lab_keyword_filtered_product_evaluation.py',
]

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while body := stream.read(1024 * 1024):
            h.update(body)
    return h.hexdigest()

for base in BASES[:2]:
    if not (ROOT / base / 'summary.json').is_file():
        raise ValueError('candidate run and evaluation must be complete')
names = set(NAMES)
for base in BASES:
    names.update(str(p.relative_to(ROOT)) for p in (ROOT / base).rglob('*') if p.is_file())
files = []
for name in sorted(names):
    relative = Path(name)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('invalid checkpoint path')
    if any(p in relative.parts for p in ('.deps', '.aws', '.git', '.codex', 'node_modules')):
        raise ValueError('excluded runtime or credential path')
    path = ROOT / relative
    if not path.is_file() or path.is_symlink():
        raise ValueError('checkpoint source is not a regular file: ' + name)
    files.append({'path':name,'bytes':path.stat().st_size,'sha256':digest(path)})
dependency = ROOT / 'experiments/sku-matching/results/20261012-sku-mixed-cpu-checkpoint.zip'
manifest = {
    'schema_version':'sku-mixed-gates-improvement-checkpoint-v1',
    'experiment_status':'exploratory_dev_informed',
    'branch':'codex-sku-generic-model-gates-20261010',
    'baseline_commit':'281c14f',
    'model_weights_included':False, 'independent_test_read':False,
    'canonical_run':BASES[0], 'canonical_evaluation':BASES[1],
    'saved_model_policy_comparison':'.lab-output/sku-baseline-ablation-20261012-v2',
    'development_candidate':'shared top3-JEV; nonshared forward NLI/reverse JEV',
    'dependencies':[{'path':str(dependency.relative_to(ROOT)),'sha256':digest(dependency)}],
    'restore_rule':'verify CRC and all byte/SHA values; never overwrite a different existing source',
    'file_count':len(files),'files':files,
}
archive = RESULTS / (STEM + '.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
    for row in files:
        body = (ROOT / row['path']).read_bytes()
        if len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']:
            raise ValueError('source changed during checkpoint construction')
        zipped.writestr(row['path'],body)
    zipped.writestr('CHECKPOINT_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as zipped:
    if zipped.testzip() is not None:
        raise ValueError('checkpoint CRC failure')
    if set(zipped.namelist()) != {r['path'] for r in files} | {'CHECKPOINT_MANIFEST.json'}:
        raise ValueError('checkpoint inventory mismatch')
    for row in files:
        body = zipped.read(row['path'])
        if len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']:
            raise ValueError('checkpoint SHA mismatch')
archive_sha = digest(archive)
(RESULTS / (STEM + '.manifest.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(RESULTS / (STEM + '.zip.sha256')).write_text(archive_sha+'  '+archive.name+'\n')
(RESULTS / (STEM + '.audit.json')).write_text(json.dumps({'archive_sha256':archive_sha,'archive_bytes':archive.stat().st_size,'crc_verified':True,'all_member_bytes_and_sha256_verified':True,'verified_file_count':len(files)},indent=2)+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':archive_sha,'verified_files':len(files)}))
