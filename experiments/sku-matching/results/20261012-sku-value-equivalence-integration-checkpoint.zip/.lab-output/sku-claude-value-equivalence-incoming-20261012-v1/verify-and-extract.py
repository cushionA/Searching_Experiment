from pathlib import Path
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent
ARCHIVE = OUT / '20261012-sku-value-equivalence-v1.zip'
MANIFEST = OUT / '20261012-sku-value-equivalence-v1.manifest.json'
EXPECTED_SHA = '0b97e1a900bd1172ec91464029278cb7f3994da8c32a1596557f96cee4a17e69'
DEST = OUT / 'extracted'
def sha(b): return hashlib.sha256(b).hexdigest()
m = json.loads(MANIFEST.read_text())
assert m['sha256'] == sha(ARCHIVE.read_bytes()) == EXPECTED_SHA
assert m['size_bytes'] == ARCHIVE.stat().st_size
assert m['labels_read'] is False and m['test_split_read'] is False
assert not DEST.exists()
files = {x['path']: x for x in m['code']}
for run in m['runs']:
    if run['name'].startswith('eval-'):
        assert run['splits'] == ['dev']
    for x in run['files']:
        assert x['path'] not in files
        files[x['path']] = x
inner_name = '20261012-sku-value-equivalence-v1.inner-manifest.json'
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == m['file_count']
    assert set(z.namelist()) == set(files) | {inner_name}
    inner = json.loads(z.read(inner_name))
    assert all(inner[k] == m[k] for k in ('code', 'runs', 'labels_read', 'test_split_read'))
    for name in z.namelist():
        p = Path(name)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
        body = z.read(name)
        if name in files:
            assert sha(body) == files[name]['sha256'], name
            if 'bytes' in files[name]: assert len(body) == files[name]['bytes'], name
        target = DEST / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(body)
    for run in m['runs']:
        summary_path = next(DEST / x['path'] for x in run['files'] if x['path'].endswith('/summary.json'))
        sidecar_path = next(DEST / x['path'] for x in run['files'] if x['path'].endswith('/sidecars.jsonl'))
        summary = json.loads(summary_path.read_text())
        assert summary['labels_read'] is False
        assert summary['sidecars_sha256'] == sha(sidecar_path.read_bytes())
        assert summary['code_sha256'] == run['code_sha256']
        assert summary['align_code_sha256'] == summary['align_module_sha256'] == run['align_code_sha256']
        assert summary['inputs_sha256'] == {k: v['sha256'] for k, v in run['inputs'].items()}
receipt = {'schema_version': 'verified-claude-value-equivalence-archive-v1',
           'upstream_commit': 'e614a3f30bde3db7112d477b070707e2bf4a78cb',
           'archive_sha256': EXPECTED_SHA, 'file_count': m['file_count'],
           'all_crc_byte_sha_checks_passed': True, 'independent_test_read': False,
           'members': {name: sha((DEST / name).read_bytes()) for name in files}}
(OUT / 'validation.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'verified_members': m['file_count'], 'archive_sha256': EXPECTED_SHA}))
