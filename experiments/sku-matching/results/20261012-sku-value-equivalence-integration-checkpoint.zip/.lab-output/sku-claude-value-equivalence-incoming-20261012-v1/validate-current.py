from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
import verify_typed_value_equivalence_v1 as VERIFY

PREP = ROOT / '.lab-output/sku-mixed-gpu-prep-20261012-v5'
INCOMING = Path(__file__).resolve().parent
def rows(p): return [json.loads(l) for l in Path(p).read_text().splitlines() if l.strip()]

class BundleStore(VERIFY.sources.RawStore):
    def __init__(self, prepared):
        super().__init__(prepared)
        self.entries = {}
        for entry in rows(prepared / 'raw-source-registry.jsonl'):
            for alias in entry['original_aliases'] + [entry['raw_file']]:
                key = alias.replace('\\', '/')
                previous = self.entries.setdefault(key, entry)
                if previous != entry: raise ValueError('conflicting raw alias')

    def raw(self, rel, expected_sha256=None):
        key = rel.replace('\\', '/')
        entry = self.entries[key]
        path = Path(entry['bundle_file'])
        if path.is_absolute() or '..' in path.parts: raise ValueError('unsafe raw capture path')
        body = (self.root / path).read_bytes()
        digest = hashlib.sha256(body).hexdigest()
        if digest != entry['sha256'] or len(body) != entry['bytes']:
            raise ValueError('frozen raw capture differs')
        if expected_sha256 is not None and digest != expected_sha256:
            raise ValueError('raw source SHA differs from proof')
        self._bytes[key], self._sha[key] = body, digest
        return body

    def sha(self, rel):
        self.raw(rel)
        return self._sha[rel.replace('\\', '/')]

if __name__ == '__main__':
    source_case = next(c for c in rows(PREP / 'frozen-source-cases.jsonl') if c['case_id'] == 'case-163fa1792c386ae5e726')
    source_product = next(p for p in rows(PREP / 'frozen-source-products.jsonl') if p['dossier_id'] == source_case['dossier_id'])
    tasks = [t for t in rows(PREP / 'tasks.jsonl') if t['case_id'] == source_case['case_id']]
    requests = {r['request_id']: r for r in rows(PREP / 'requests.jsonl')}
    sidecar_file = INCOMING / 'extracted/.lab-output/sku-value-equivalence-20261012-v1/eval-v2-token-dev/sidecars.jsonl'
    sidecar = next(s for s in rows(sidecar_file) if s['case_id'] == source_case['case_id'])
    store = BundleStore(PREP)
    receipts = [VERIFY.validate_sidecar(sidecar, t, requests[t['request_id']], source_case, source_product, store) for t in tasks]
    (INCOMING / 'verified-L-receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'verified_receipts': len(receipts), 'directions': [r['direction'] for r in receipts]}, ensure_ascii=False))
