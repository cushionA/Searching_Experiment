from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
import evaluate_mixed_gpu_sku_v1 as E
import evaluate_keyword_filtered_product_v1 as REFERENCES
import trial_keyword_filtered_product_v1 as VERIFY

PREP = ROOT / '.lab-output/sku-mixed-gpu-prep-20261012-v5'
CPU = ROOT / '.lab-output/sku-mixed-cpu-run-20261012-v1'
TYPED = ROOT / '.lab-output/sku-typed-value-equivalence-20261012-v1'
SOURCE = ROOT / '.lab-output/sku-raw-nli-unique-support-20261012-v1'
MODEL = CPU / 'baseline-refresh/baseline-model'
OLD_EVAL = ROOT / '.lab-output/sku-mixed-cpu-evaluation-20261012-v4'
ROUTES = ROOT / '.lab-output/sku-mixed-cpu-reference-routes-20261012-v2'
OUT = Path(__file__).resolve().parent
def read_json(p): return json.loads(Path(p).read_text())
def index(p, k): return E.GATE.indexed(Path(p), k)

manifest, requests, documents, tasks, cases, membership, hosts = E.load_mixed_prepared(PREP)
E.verify_cpu_run(PREP, CPU, manifest, requests)
VERIFY.verify_source(CPU / 'product-model')
typed_summary = read_json(TYPED / 'summary.json')
for name, want in typed_summary['output_sha256'].items(): assert E.sha(TYPED / name) == want
VERIFY.verify_snapshot(read_json(TYPED / 'execution-freeze.json')['source_snapshot'], phase='before raw-class comparison')
builder_summary = read_json(SOURCE / 'summary.json')
assert builder_summary['new_model_inference'] is False
assert E.sha(SOURCE / 'source-freeze.json') == builder_summary['source_freeze_sha256']
assert E.sha(SOURCE / 'predictions.jsonl') == builder_summary['predictions_sha256']
assert E.sha(SOURCE / 'request-changes.jsonl') == builder_summary['request_changes_sha256']
freeze = read_json(SOURCE / 'source-freeze.json')
source_paths = {
    **{'prepared_' + key: PREP / name for key, name in (
        ('manifest', 'manifest.json'), ('requests', 'requests.jsonl'), ('documents', 'documents.jsonl'),
        ('tasks', 'tasks.jsonl'), ('row_plans', 'row_plans.jsonl'), ('case_plans', 'case_plans.jsonl'),
        ('membership', 'membership.jsonl'), ('gpu_cases', 'gpu-cases.jsonl'), ('failures', 'failures.jsonl'))},
    'typed_predictions': TYPED / 'predictions.jsonl', 'cpu_product_model_freeze': CPU / 'product-model/freeze.json',
    'baseline_model_summary': MODEL / 'summary.json', 'baseline_model_freeze': MODEL / 'freeze.json',
    'baseline_nli_predictions': MODEL / 'nli-predictions.jsonl', 'baseline_model_nli_pairs': MODEL / 'model-nli-pairs.jsonl',
    'baseline_source_requests': MODEL / 'source-requests.jsonl', 'baseline_source_documents': MODEL / 'source-documents.jsonl'}
assert {name: E.sha(p) for name, p in source_paths.items()} == freeze['source_sha256']
for name, want in freeze['code_sha256'].items(): assert E.sha(ROOT / name) == want
predicted = index(SOURCE / 'predictions.jsonl', 'request_id')
baseline = index(TYPED / 'predictions.jsonl', 'request_id')
E.GATE.validate_predictions(requests, documents, tasks, predicted, baseline, 'raw-nli-unique-support-v1')
changed = {rid for rid in predicted if predicted[rid] != baseline[rid]}
assert changed == set(builder_summary['changed_request_ids']) and len(changed) == 2
E.GATE.finish(PREP, SOURCE / 'predictions.jsonl', OUT / 'gates')
gates = index(OUT / 'gates/decisions.jsonl', 'case_id')
assert set(gates) == set(cases)
paths = [Path(__file__), *(SOURCE / n for n in ('assemble-predictions.py', 'source-freeze.json', 'predictions.jsonl',
          'request-changes.jsonl', 'summary.json')), TYPED / 'summary.json', TYPED / 'predictions.jsonl',
         *source_paths.values(), *(ROOT / name for name in freeze['code_sha256']),
         *(p for p in (OUT / 'gates').rglob('*') if p.is_file())]
snapshot = VERIFY.snapshot_paths({str(p): p for p in paths})
E.write_json(OUT / 'all-gates-frozen.json', {'labels_read': False, 'all_gates_frozen': True,
             'experiment_status': 'exploratory_dev_informed', 'independent_test': False,
             'case_count': 83, 'request_count': 134, 'source_and_gate_snapshot': snapshot})
_, _, _, references, _ = REFERENCES.verify_original_sources(PREP, OLD_EVAL, ROUTES)
score_ids = {r['case_id'] for r in E.eligibility_rows(membership, hosts)[0] if r['primary_score_eligible']}
scored = {k: v for k, v in references.items() if k in score_ids and not v.get('reference_uncertain', False)}
assert len(scored) == 73
before_gates = index(TYPED / 'gates/decisions.jsonl', 'case_id')
metrics, details = {}, []
for stratum in E.STRATA:
    value = E.metrics_for(gates, {k: v for k, v in scored.items() if membership[k]['membership_strata'] == [stratum]})
    metrics[stratum] = {k: v for k, v in value.items() if k != 'case_results'}
    details.extend({'stratum': stratum, **r} for r in value['case_results'])
value = E.metrics_for(gates, scored)
metrics['scored_primary_reference_union'] = {k: v for k, v in value.items() if k != 'case_results'}
before = {r['case_id']: r for r in E.metrics_for(before_gates, scored)['case_results']}
changes = [{'case_id': r['case_id'], 'before': before[r['case_id']], 'after': r}
           for r in value['case_results'] if r != before[r['case_id']]]
E.write_rows(OUT / 'case-results.jsonl', details)
E.write_rows(OUT / 'changes-vs-typed-candidate.jsonl', changes)
VERIFY.verify_snapshot(snapshot, phase='after raw-class scoring')
E.write_json(OUT / 'summary.json', {'schema_version': 'raw-nli-unique-support-evaluation-v1',
             'experiment_status': 'exploratory_dev_informed', 'new_model_inference': False,
             'independent_test': False, 'production_adoption_allowed': False, 'scored_case_count': 73,
             'reference_kind': 'existing machine labels', 'labels_read_after_all_gates_frozen': True,
             'source_and_output_hashes_verified_after_scoring': True, 'metrics': metrics,
             'changed_scored_case_count': len(changes),
             'output_sha256': {str(p.relative_to(OUT)): E.sha(p) for p in OUT.rglob('*') if p.is_file()}})
print(json.dumps({'metrics': metrics['scored_primary_reference_union'],
                  'changes': [(r['case_id'], r['before']['binary_cell'], r['after']['binary_cell']) for r in changes]}, ensure_ascii=False))
