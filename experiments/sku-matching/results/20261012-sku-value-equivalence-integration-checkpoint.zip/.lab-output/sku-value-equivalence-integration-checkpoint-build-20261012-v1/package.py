from __future__ import annotations

import hashlib
import json
import subprocess
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "experiments/sku-matching/results"
STEM = "20261012-sku-value-equivalence-integration-checkpoint"
ARCHIVE = RESULTS / f"{STEM}.zip"
MANIFEST_PATH = RESULTS / f"{STEM}.manifest.json"

# Explicitly allowlisted run trees. Do not broaden this list to historical
# material or independent-test data. __pycache__ is intentionally omitted.
RUN_ROOTS = (
    ".lab-output/sku-claude-value-equivalence-incoming-20261012-v1",
    ".lab-output/sku-typed-value-equivalence-20261012-v1",
    ".lab-output/sku-typed-value-equivalence-resume-20261012-v1",
    ".lab-output/sku-raw-nli-unique-support-20261012-v1",
    ".lab-output/sku-raw-nli-unique-support-evaluation-20261012-v1",
)
INCOMING_REQUIRED = (
    ".lab-output/sku-claude-value-equivalence-incoming-20261012-v1/20261012-sku-value-equivalence-v1.zip",
    ".lab-output/sku-claude-value-equivalence-incoming-20261012-v1/20261012-sku-value-equivalence-v1.manifest.json",
    ".lab-output/sku-claude-value-equivalence-incoming-20261012-v1/validation.json",
    ".lab-output/sku-claude-value-equivalence-incoming-20261012-v1/verify-and-extract.py",
    ".lab-output/sku-claude-value-equivalence-incoming-20261012-v1/validate-current.py",
    ".lab-output/sku-claude-value-equivalence-incoming-20261012-v1/verified-L-receipts.json",
)
EXACT_FILES = (
    "experiments/sku-matching/verify_typed_value_equivalence_v1.py",
    "experiments/sku-matching/trial_typed_value_equivalence_v1.py",
    "tests/test_lab_sku_typed_value_equivalence.py",
    "experiments/sku-matching/typed-value-equivalence-result-20261012.txt",
    "experiments/sku-matching/session-result-20261012.txt",
    "experiments/sku-matching/claude-followup-20261012.txt",
    ".lab-output/sku-value-equivalence-integration-checkpoint-build-20261012-v1/package.py",
)
DEPENDENCIES = (
    "experiments/sku-matching/results/20261012-sku-option-context-checkpoint.zip",
    "experiments/sku-matching/results/20261012-sku-mixed-cpu-checkpoint.zip",
    "experiments/sku-matching/results/20261012-sku-mixed-gates-improvement-checkpoint.zip",
    "experiments/sku-matching/results/20261012-sku-followup-checkpoint.zip",
)
DEPENDENCY_SHA256 = {
    "20261012-sku-option-context-checkpoint.zip": "beeb336a455a32d324dec03c103ee412e06e236ff1aed92353d0a7ff389567a0",
    "20261012-sku-mixed-cpu-checkpoint.zip": "f55928415f5028f6b110e44e68f936b03adbad177da1be58da3d3ee58fc4a951",
    "20261012-sku-mixed-gates-improvement-checkpoint.zip": "26ddd2289ea44072a37f7aa677bd078372644fbb7e59b063c84b18f9c182c11c",
    "20261012-sku-followup-checkpoint.zip": "3d013ed382adc4467d97575ae3602d162e2a8a1ea84d3087a622bdcadf186cf5",
}
SKIP_PARTS = {"__pycache__"}
DENIED_PARTS = {
    ".aws", ".codex", ".git", ".deps", "node_modules", "venv", ".venv",
    "cache", "caches", "weights", "model_weights", "credentials",
}
WEIGHT_SUFFIXES = (".safetensors", ".pt", ".pth", ".ckpt", ".bin")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_value(*args: str) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=ROOT, text=True, stderr=subprocess.DEVNULL
    ).strip()


def safe_relative(name: str) -> Path:
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"invalid archive path: {name}")
    if any(part.lower() in DENIED_PARTS for part in relative.parts):
        raise ValueError(f"prohibited archive path: {name}")
    return relative


def collect_paths() -> list[str]:
    names: set[str] = set()
    for root_name in RUN_ROOTS:
        root = ROOT / safe_relative(root_name)
        if not root.is_dir() or root.is_symlink():
            raise FileNotFoundError(f"required run directory missing or unsafe: {root_name}")
        for path in root.rglob("*"):
            relative_name = path.relative_to(ROOT).as_posix()
            relative = Path(relative_name)
            if any(part in SKIP_PARTS for part in relative.parts):
                continue
            safe_relative(relative_name)
            if path.is_symlink():
                raise ValueError(f"symlink in required run directory: {relative_name}")
            if path.is_file():
                names.add(relative_name)

    names.update(EXACT_FILES)
    names.update(INCOMING_REQUIRED)
    for name in names:
        path = ROOT / safe_relative(name)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"required file missing or unsafe: {name}")

    extracted = ROOT / RUN_ROOTS[0] / "extracted"
    if not extracted.is_dir() or extracted.is_symlink():
        raise FileNotFoundError("required extracted incoming payload directory is missing")
    extracted_count = sum(
        1 for path in extracted.rglob("*")
        if path.is_file() and not path.is_symlink()
        and not any(part in SKIP_PARTS for part in path.relative_to(ROOT).parts)
    )
    if extracted_count != 22:
        raise ValueError(f"expected 22 extracted incoming members; found {extracted_count}")

    if any(Path(name).suffix.lower() in WEIGHT_SUFFIXES for name in names):
        raise ValueError("model-weight files are prohibited in this checkpoint")
    return sorted(names)


def main() -> None:
    if ARCHIVE.exists() or MANIFEST_PATH.exists():
        raise FileExistsError("refusing to overwrite an existing checkpoint or manifest")

    dependencies = []
    for name in DEPENDENCIES:
        path = ROOT / safe_relative(name)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"required dependency checkpoint missing: {name}")
        actual_sha = digest(path.read_bytes())
        if actual_sha != DEPENDENCY_SHA256[path.name]:
            raise ValueError(f"dependency differs from verified checkpoint: {name}")
        dependencies.append({"path": name, "sha256": actual_sha})

    summary = json.loads((ROOT / RUN_ROOTS[-1] / "summary.json").read_text())
    actual_counts = summary["metrics"]["scored_primary_reference_union"]
    if {key: actual_counts[key.lower()] for key in ("TP", "FP", "FN", "TN")} != {"TP": 30, "FP": 1, "FN": 25, "TN": 17}:
        raise ValueError("final evaluation does not match the stated checkpoint result")
    if summary["independent_test"] or summary["production_adoption_allowed"]:
        raise ValueError("checkpoint must remain a development comparison")

    payloads: dict[str, bytes] = {}
    files = []
    for name in collect_paths():
        body = (ROOT / name).read_bytes()
        payloads[name] = body
        files.append({"path": name, "bytes": len(body), "sha256": digest(body)})

    manifest = {
        "schema_version": "sku-value-equivalence-integration-checkpoint-v1",
        "experiment_status": "exploratory_dev_informed",
        "result_counts": {"TP": 30, "FP": 1, "FN": 25, "TN": 17},
        "labels": ["machine labels", "no independent test"],
        "branch": git_value("branch", "--show-current"),
        "head": git_value("rev-parse", "HEAD"),
        "independent_test_read": False,
        "production_adoption_allowed": False,
        "model_weights_included": False,
        "excluded_content": ["independent-test data", "model weights", "caches", "credential directories"],
        "dependencies": dependencies,
        "file_count": len(files),
        "files": files,
        "restore_rule": "verify archive member names, CRC, byte counts and SHA256 before extraction; never overwrite a different existing source",
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()

    RESULTS.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for row in files:
            body = payloads[row["path"]]
            if len(body) != row["bytes"] or digest(body) != row["sha256"]:
                raise ValueError(f"source changed while packaging: {row['path']}")
            zipped.writestr(row["path"], body)
        zipped.writestr("CHECKPOINT_MANIFEST.json", manifest_bytes)

    with zipfile.ZipFile(ARCHIVE, "r") as zipped:
        expected_names = {row["path"] for row in files} | {"CHECKPOINT_MANIFEST.json"}
        names = zipped.namelist()
        if (zipped.testzip() is not None or set(names) != expected_names
                or len(names) != len(expected_names)):
            raise ValueError("archive CRC or exact member-name verification failed")
        for row in files:
            body = zipped.read(row["path"])
            if len(body) != row["bytes"] or digest(body) != row["sha256"]:
                raise ValueError(f"archive member verification failed: {row['path']}")
        if zipped.read("CHECKPOINT_MANIFEST.json") != manifest_bytes:
            raise ValueError("embedded manifest verification failed")

    for row in files:
        current = (ROOT / row["path"]).read_bytes()
        if len(current) != row["bytes"] or digest(current) != row["sha256"]:
            raise ValueError(f"source changed during packaging: {row['path']}")

    archive_sha = digest(ARCHIVE.read_bytes())
    adjacent = dict(manifest)
    adjacent["archive"] = {
        "path": ARCHIVE.relative_to(ROOT).as_posix(),
        "bytes": ARCHIVE.stat().st_size,
        "sha256": archive_sha,
    }
    MANIFEST_PATH.write_text(
        json.dumps(adjacent, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "archive": str(ARCHIVE),
        "manifest": str(MANIFEST_PATH),
        "archive_bytes": ARCHIVE.stat().st_size,
        "archive_sha256": archive_sha,
        "verified_members": len(files),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
