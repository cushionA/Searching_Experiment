#!/usr/bin/env python3
"""Assemble a no-inference raw-NLI unique-support policy comparison.

This script reads only frozen model/preparation artifacts and the typed run's
prediction file. It never opens evaluation labels, case results, or gates for
reference scoring. It writes derived predictions and source-only provenance;
the parent workflow owns gate freezing and evaluation.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "experiments/sku-matching"))
import evaluate_mixed_gpu_sku_v1 as E


PREP = ROOT / ".lab-output/sku-mixed-gpu-prep-20261012-v5"
CPU = ROOT / ".lab-output/sku-mixed-cpu-run-20261012-v1"
TYPED = ROOT / ".lab-output/sku-typed-value-equivalence-20261012-v1"
OUT = ROOT / ".lab-output/sku-raw-nli-unique-support-20261012-v1"
BASE_MODEL = CPU / "baseline-refresh/baseline-model"
VARIANT = "raw-nli-unique-support-v1"
HYPOTHESIS_TEMPLATE = "この商品の〈{axis_name}〉は〈{selected_value}〉である。"
EXPECTED_CHANGED_IDS = {
    "generic-description:63d9da4d659e18aa392244859dd7e500fe2916d75433970c64f25ba4dc2b2f89",
    "generic-description:97da57494f619237978c24a56ceabc42ebe4a9ecc971804a54fda363b714f587",
}
OUTPUT_NAMES = (
    "source-freeze.json",
    "predictions.jsonl",
    "request-changes.jsonl",
    "summary.json",
)
CODE_PATHS = (
    Path(__file__),
    ROOT / "experiments/sku-matching/evaluate_mixed_gpu_sku_v1.py",
    ROOT / "experiments/sku-matching/evaluate_scoped_html_trial_v1.py",
    ROOT / "experiments/sku-matching/integrate_claude_description_v1.py",
    ROOT / "experiments/sku-matching/trial_scoped_condition_nli_choice_v1.py",
    ROOT / "experiments/sku-matching/trial_scoped_condition_nli_v1.py",
    BASE_MODEL / "code/trial_generic_model_nli_v1.py",
)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def indexed(path: Path, key: str) -> dict[str, dict]:
    rows = read_rows(path)
    result = {}
    for row in rows:
        identity = row.get(key)
        if not isinstance(identity, str) or not identity or identity in result:
            raise ValueError(f"missing or duplicate {key} in {path}")
        result[identity] = row
    return result


def write_json(path: Path, value: dict) -> None:
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def write_rows(path: Path, values) -> None:
    with path.open("x", encoding="utf-8") as handle:
        for value in values:
            handle.write(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":"), allow_nan=False) + "\n")


def literal_context_refs(request: dict, document: dict) -> list[dict]:
    """Rebuild only the title and selected-axis refs used by the scored pair."""
    refs = []
    for field, text in (("title", document["title"]["text"]),
                        ("selected_axes", request["target_selected_axes_text"])):
        if text:
            refs.append({"document_id": document["document_id"], "field": field,
                         "start": 0, "end": len(text), "quote": text})
    return refs


def expected_pair(request: dict, document: dict, option_index: int, option_value: str) -> dict:
    title = document["title"]["text"]
    selected_axes = request["target_selected_axes_text"]
    premise = "現在の商品名：" + title + "\n現在の選択行：\n" + selected_axes
    hypothesis = HYPOTHESIS_TEMPLATE.format(axis_name=request["axis_name"], selected_value=option_value)
    return {"id": request["request_id"] + ":nli-option:" + str(option_index),
            "request_id": request["request_id"], "request_sha256": request["request_sha256"],
            "option_index": option_index, "option_value": option_value,
            "premise": premise, "hypothesis": hypothesis,
            "quote_refs": literal_context_refs(request, document)}


def valid_raw_scores(source_prediction: dict, request: dict, documents: dict,
                     pair_inputs: dict) -> tuple[bool, list[dict], str | None]:
    """Validate every saved option pair before deriving its strict raw class."""
    options = request.get("option_values")
    candidates = source_prediction.get("candidate_records")
    if (not isinstance(options, list) or not options or
            not isinstance(candidates, list) or len(candidates) != len(options)):
        return False, [], "incomplete_candidate_scores"
    if source_prediction.get("request_id") != request["request_id"]:
        return False, [], "request_identity_mismatch"
    if source_prediction.get("request_sha256") != request["request_sha256"]:
        return False, [], "request_sha256_mismatch"
    if source_prediction.get("source_request") != request:
        return False, [], "source_request_mismatch"
    if source_prediction.get("direction") != request["direction"]:
        return False, [], "direction_mismatch"

    document = documents[request["target_document_id"]]
    if document.get("document_sha256") != request["target_document_sha256"]:
        return False, [], "target_document_sha256_mismatch"
    validated = []
    for index, (option, candidate) in enumerate(zip(options, candidates, strict=True)):
        expected = expected_pair(request, document, index, option)
        pair = pair_inputs.get(expected["id"])
        if pair is None:
            return False, [], "scored_pair_input_missing"
        for field, value in expected.items():
            if pair.get(field) != value:
                return False, [], "frozen_pair_rendering_mismatch"
        for field in ("id", "request_id", "request_sha256", "option_index", "option_value",
                      "premise", "hypothesis", "quote_refs"):
            if candidate.get(field) != pair.get(field):
                return False, [], "score_pair_metadata_mismatch"
        refs = expected["quote_refs"]
        if not refs or not all(E.GATE.verify_quote(ref, request, documents) for ref in refs):
            return False, [], "model_context_quote_not_literal"

        probabilities = candidate.get("probabilities")
        if (candidate.get("error_type") is not None or
                not isinstance(probabilities, dict) or
                set(probabilities) != {"support", "conflict", "unknown"}):
            return False, [], "score_missing_or_error"
        values = [probabilities[label] for label in ("support", "conflict", "unknown")]
        if (any(type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 1
                for value in values) or not math.isclose(sum(values), 1.0, abs_tol=1e-5)):
            return False, [], "score_nonfinite_or_invalid"
        token_count = candidate.get("token_count_untruncated")
        if type(token_count) is not int or token_count < 1 or token_count > 512:
            return False, [], "score_token_count_unusable"
        validated.append({"candidate": candidate, "pair": pair, "expected_pair": expected})
    return True, validated, None


def raw_support_options(validated: list[dict]) -> list[dict]:
    winners = []
    for item in validated:
        candidate = item["candidate"]
        probabilities = candidate["probabilities"]
        if probabilities["support"] > max(probabilities["conflict"], probabilities["unknown"]):
            winners.append(item)
    return winners


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    present = {path.name for path in OUT.iterdir()}
    if present - {Path(__file__).name}:
        raise FileExistsError("output folder already contains derived artifacts")
    if any((OUT / name).exists() for name in OUTPUT_NAMES):
        raise FileExistsError("refusing to overwrite derived output")

    prep_manifest, requests, documents, tasks, cases, membership, gpu_cases = E.load_mixed_prepared(PREP)
    base = indexed(TYPED / "predictions.jsonl", "request_id")
    if set(base) != set(requests) or len(base) != 134:
        raise ValueError("typed prediction file must cover all 134 fixed requests")
    E.GATE.validate_predictions(requests, documents, tasks, base, base, "baseline")

    cpu_freeze = json.loads((CPU / "product-model/freeze.json").read_text(encoding="utf-8"))
    refresh = cpu_freeze["invariance_contract"]["baseline_refresh"]
    if refresh.get("baseline_model_summary_sha256") != sha(BASE_MODEL / "summary.json"):
        raise ValueError("CPU product-model freeze does not bind the baseline-model summary")
    eligible_ids = set(cpu_freeze["invariance_contract"]["eligible_forward_request_ids"])
    nonshared_forward_ids = set(cpu_freeze["invariance_contract"]["pass_through"]["noneligible_forward_request_ids"])
    if len(eligible_ids) != 80 or len(nonshared_forward_ids) != 25 or eligible_ids & nonshared_forward_ids:
        raise ValueError("frozen shared80/nonshared-forward25 contract differs")
    if any(requests[rid]["direction"] != "rakuten_to_au" for rid in nonshared_forward_ids):
        raise ValueError("nonshared forward set contains a reverse request")
    if not eligible_ids <= set(requests) or not nonshared_forward_ids <= set(requests):
        raise ValueError("frozen request sets escape the fixed request universe")

    model_summary = json.loads((BASE_MODEL / "summary.json").read_text(encoding="utf-8"))
    model_freeze = json.loads((BASE_MODEL / "freeze.json").read_text(encoding="utf-8"))
    expected_hashes = model_summary.get("output_sha256", {})
    frozen_model_files = ("nli-predictions.jsonl", "model-nli-pairs.jsonl", "source-requests.jsonl",
                          "source-documents.jsonl", "freeze.json")
    for name in frozen_model_files:
        if expected_hashes.get(name) != sha(BASE_MODEL / name):
            raise ValueError("baseline model output SHA differs: " + name)
    if model_freeze.get("labels_read") is not False or model_freeze.get("independent_test") is not False:
        raise ValueError("baseline model artifact is not a frozen label-free source")

    source_requests = indexed(BASE_MODEL / "source-requests.jsonl", "request_id")
    source_documents = indexed(BASE_MODEL / "source-documents.jsonl", "document_id")
    if source_requests != requests:
        raise ValueError("original baseline model requests differ from frozen prepared requests")
    for doc_id, document in documents.items():
        source_doc = source_documents.get(doc_id)
        if source_doc is None or source_doc.get("document_sha256") != document.get("document_sha256"):
            raise ValueError("original baseline model document binding differs: " + doc_id)

    source_nli = indexed(BASE_MODEL / "nli-predictions.jsonl", "request_id")
    pair_inputs = indexed(BASE_MODEL / "model-nli-pairs.jsonl", "id")
    if not nonshared_forward_ids <= set(source_nli):
        raise ValueError("saved whole-option NLI predictions do not cover nonshared forward25")

    sources = {
        "prepared_manifest": PREP / "manifest.json",
        "prepared_requests": PREP / "requests.jsonl",
        "prepared_documents": PREP / "documents.jsonl",
        "prepared_tasks": PREP / "tasks.jsonl",
        "prepared_row_plans": PREP / "row_plans.jsonl",
        "prepared_case_plans": PREP / "case_plans.jsonl",
        "prepared_membership": PREP / "membership.jsonl",
        "prepared_gpu_cases": PREP / "gpu-cases.jsonl",
        "prepared_failures": PREP / "failures.jsonl",
        "typed_predictions": TYPED / "predictions.jsonl",
        "cpu_product_model_freeze": CPU / "product-model/freeze.json",
        "baseline_model_summary": BASE_MODEL / "summary.json",
        "baseline_model_freeze": BASE_MODEL / "freeze.json",
        "baseline_nli_predictions": BASE_MODEL / "nli-predictions.jsonl",
        "baseline_model_nli_pairs": BASE_MODEL / "model-nli-pairs.jsonl",
        "baseline_source_requests": BASE_MODEL / "source-requests.jsonl",
        "baseline_source_documents": BASE_MODEL / "source-documents.jsonl",
    }
    source_sha = {name: sha(path) for name, path in sources.items()}
    code_sha = {str(path.relative_to(ROOT)): sha(path) for path in CODE_PATHS}
    source_freeze = {
        "schema_version": "sku-raw-nli-unique-support-source-freeze-v1",
        "variant": VARIANT,
        "labels_read": False,
        "independent_test_read": False,
        "new_model_inference": False,
        "reference_or_gate_evaluation_performed": False,
        "request_count": len(requests),
        "shared_forward_request_count": len(eligible_ids),
        "nonshared_forward_request_count": len(nonshared_forward_ids),
        "source_sha256": source_sha,
        "code_sha256": code_sha,
        "policy": "For a complete, finite, error-free saved NLI score set, count options with support strictly greater than conflict and unknown. Change only a non-support typed prediction when exactly one option qualifies and it equals the request's binding selected_value. Preserve every saved probability/class score unchanged.",
        "quote_policy": "Accept reconstructed literal refs only when every saved pair premise/hypothesis/ref exactly matches frozen title plus target_selected_axes_text rendering; do not use descriptions.",
    }
    write_json(OUT / "source-freeze.json", source_freeze)

    predicted = deepcopy(base)
    changes = []
    disposition_counts = Counter()
    unusable_reasons = Counter()
    for rid in sorted(nonshared_forward_ids):
        request = requests[rid]
        original_nli = source_nli[rid]
        valid, validated, invalid_reason = valid_raw_scores(original_nli, request, documents, pair_inputs)
        if not valid:
            disposition_counts["incomplete_or_unusable_scores"] += 1
            unusable_reasons[invalid_reason] += 1
            continue
        raw_support = raw_support_options(validated)
        if len(raw_support) == 0:
            disposition_counts["no_unique_raw_support_option"] += 1
            continue
        if len(raw_support) > 1:
            disposition_counts["multiple_raw_support_options"] += 1
            continue
        winner = raw_support[0]
        option_value = winner["candidate"]["option_value"]
        base_prediction = base[rid]
        if option_value != request["selected_value"]:
            disposition_counts["unique_alternative_kept"] += 1
            continue
        if rid in EXPECTED_CHANGED_IDS and (
                original_nli.get("state") != "unknown" or
                original_nli.get("reason") != "relative_mass_below_threshold" or
                base_prediction.get("state") != "unknown"):
            raise ValueError("declared policy-difference request no longer has the frozen unknown source state")
        if base_prediction["state"] == "support":
            disposition_counts["selected_support_already_present"] += 1
            continue
        if base_prediction.get("verified_value_equivalence"):
            raise ValueError("refusing to replace a typed-proof support carrier")
        expected_refs = winner["expected_pair"]["quote_refs"]
        if winner["pair"].get("quote_refs") != expected_refs:
            raise ValueError("selected raw support pair refs differ from literal frozen context")
        if not all(E.GATE.verify_quote(ref, request, documents) for ref in expected_refs):
            raise ValueError("selected raw support pair quote failed literal validation")

        derived = deepcopy(base_prediction)
        derived.update({
            "state": "support",
            "winning_value": option_value,
            "quote_refs": deepcopy(expected_refs),
            "reason": "unique_raw_nli_support_option_matches_selected_value",
            "variant": VARIANT,
            "source_nli_prediction": deepcopy(original_nli),
        })
        predicted[rid] = derived
        disposition_counts["selected_unique_raw_support_changed"] += 1
        changes.append({
            "request_id": rid,
            "before_state": base_prediction["state"],
            "after_state": derived["state"],
            "before_winning_value": base_prediction.get("winning_value"),
            "after_winning_value": option_value,
            "source_nli_state": original_nli.get("state"),
            "source_nli_reason": original_nli.get("reason"),
            "raw_option_count": len(request["option_values"]),
            "unique_raw_support_probabilities": deepcopy(winner["candidate"]["probabilities"]),
            "unique_raw_support_predicted_class": winner["candidate"].get("predicted_class"),
            "source_pair_id": winner["pair"]["id"],
            "literal_model_context_quote_refs": deepcopy(expected_refs),
            "actual_source_nli_prediction_preserved_in_prediction": True,
            "probabilities_or_class_scores_rewritten": False,
            "new_model_inference": False,
        })

    changed_ids = {item["request_id"] for item in changes}
    if changed_ids != EXPECTED_CHANGED_IDS:
        raise ValueError("score-derived changed request IDs differ from the declared two-ID comparison")
    for rid in set(requests) - EXPECTED_CHANGED_IDS:
        if predicted[rid] != base[rid]:
            raise ValueError("request outside the two declared forward IDs changed: " + rid)
    for rid in eligible_ids:
        if predicted[rid] != base[rid]:
            raise ValueError("shared forward request changed: " + rid)
    for rid, request in requests.items():
        if request["direction"] == "au_to_rakuten" and predicted[rid] != base[rid]:
            raise ValueError("reverse request changed: " + rid)
        if base[rid].get("verified_value_equivalence") and rid not in EXPECTED_CHANGED_IDS:
            if predicted[rid] != base[rid]:
                raise ValueError("typed proof support changed: " + rid)
    E.GATE.validate_predictions(requests, documents, tasks, predicted, base, VARIANT)

    # Inputs and code must still match the pre-assembly freeze.
    if {name: sha(path) for name, path in sources.items()} != source_sha:
        raise ValueError("a frozen source changed while assembling predictions")
    if {str(path.relative_to(ROOT)): sha(path) for path in CODE_PATHS} != code_sha:
        raise ValueError("a frozen code source changed while assembling predictions")

    write_rows(OUT / "predictions.jsonl", predicted.values())
    write_rows(OUT / "request-changes.jsonl", changes)
    summary = {
        "schema_version": "sku-raw-nli-unique-support-summary-v1",
        "variant": VARIANT,
        "labels_read": False,
        "independent_test_read": False,
        "gate_or_reference_scoring_performed": False,
        "new_model_inference": False,
        "request_count": len(predicted),
        "shared_forward_request_count": len(eligible_ids),
        "nonshared_forward_request_count": len(nonshared_forward_ids),
        "changed_request_count": len(changes),
        "changed_request_ids": sorted(changed_ids),
        "raw_score_dispositions": dict(sorted(disposition_counts.items())),
        "unusable_score_reasons": dict(sorted(unusable_reasons.items())),
        "prediction_states_before": dict(sorted(Counter(row["state"] for row in base.values()).items())),
        "prediction_states_after": dict(sorted(Counter(row["state"] for row in predicted.values()).items())),
        "source_freeze_sha256": sha(OUT / "source-freeze.json"),
        "predictions_sha256": sha(OUT / "predictions.jsonl"),
        "request_changes_sha256": sha(OUT / "request-changes.jsonl"),
        "typed_predictions_and_all_nondeclared_requests_unchanged": True,
        "saved_nli_probabilities_and_class_scores_preserved": True,
        "quote_fields_used": ["title", "selected_axes"],
    }
    write_json(OUT / "summary.json", summary)


if __name__ == "__main__":
    main()
