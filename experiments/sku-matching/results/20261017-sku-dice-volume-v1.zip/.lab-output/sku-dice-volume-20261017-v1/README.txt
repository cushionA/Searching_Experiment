SKU volume diagnostic, 2026-10-17 JST
Base repository: 90a15121581d465a313b6df952ff049140179d8f
Branch: codex-sku-generic-model-gates-20261010

Read experiments/sku-matching/results/20261017-sku-dice-volume-v1.txt first.
This ZIP includes complete projected inputs, five unchanged source snapshots,
private Kaggle metadata/drivers/jobs/monitor logs, downloaded predictions,
host re-execution audit, grades and all needed selected historical references.
MANIFEST.json lists SHA256 and bytes of every other member. Entry paths are
repository-relative; original input/capture/model/index files were not changed.
No authentication values/files are included. Large dictionary binaries are omitted.

Accuracy corpus: 2662 unique cases /213 products /62502 native candidate rows
and267334 original condition bindings. 55082 unique request IDs. TRAIN1330 cases
built the frozen dictionary; EVAL1332 cases did not. Keep both cohorts separate.
All references are prior machine annotations, not fresh independent human gold.
Never use the50004 repeated load cases as a larger accuracy denominator.

CPU benchmark recomputes fixed dictionary lookup, optional normalized lookup,
all candidate Dice scores, row conflicts and the original final gate. Product-local
phrase/graph condition states and text-normalization tables are frozen inputs.
Pip/download/raw graph construction/reference scoring are outside the timers.
No similarity score cache. Single worker. This is a Python warm benchmark, not
a TypeScript cold-start or whole-production SLA. Read the source-scope caveat.

Kaggle private CPU kernel:
https://www.kaggle.com/code/superbigzabuton/sku-dice-volume-20261017-v1
Successful version2; dataset superbigzabuton/sku-dice-volume-input-20261017-v1 v1.
Version1 error is preserved: Kaggle auto-expanded payload.json.gz to payload.json.
Version2 checked original uncompressed SHA before using it. It does not claim
to have reverified compressed gzip bytes when the compressed file was unavailable.
Only packaging/preflight changed. SKU policies, parameters and data stayed fixed.
Scoring EVAL references were never uploaded. Frozen dictionary TRAIN evidence
metadata was included as part of that already-trained artifact.

Full source/policy SHA table: ORIGINAL_POLICY_PINS.json. Submission audit and
packaging-v1-v2.diff show the exact repair. All downloaded files are pinned in
job-v2/continuation.json and worker FREEZE.json; host re-execution matched every
row/case and all18 prior EVAL projections before scoring references were opened.
HOST_PREDICTION_AUDIT field all_original_conditions_retained counts unique
requests55082; original condition bindings are267334 as specified in PLAN.

Install SudachiPy0.7.0 and Core/Full20260723.1 only; binary SHA256 in the Dataset
MANIFEST is the check. Full can remain in .deps/sku-sudachi-full-20261017-v1;
add this directory to PYTHONPATH for a local worker replay. Worker input can be
the original compressed dataset-upload directory or Kaggle's expanded copy.
For an expanded copy supply --payload-raw-sha from payload-raw-sha256.json.

Local replay in a restored base repo (use a NEW output directory):
.deps/sku-classical-venv/bin/python -B experiments/sku-matching/benchmark_sudachi_dice_volume_v1.py --input .lab-output/sku-dice-volume-20261017-v1/dataset-upload --output NEW_OUTPUT

Host scorer (refuses to overwrite GRADE.json; run in a separate restored copy):
.deps/sku-classical-venv/bin/python -B experiments/sku-matching/grade_sudachi_dice_volume_v1.py
This host scorer retains original /workspace/Searching_Experiment asset paths
from the previous pinned experiment. For relocation create new verified receipts,
do not edit the historical files. Previous selected references and old EVAL
predictions used by this audit are included under their original relative paths.

New tests: tests/test_lab_sku_dice_volume.py (3 passed). Required full lab suite
1580 tests still has the prior4 failures/66 errors/60 skips; all70 names match.
No new LLM inference, model-weight download, GPU/TPU job or production-gate edit.
