#!/usr/bin/env python3
"""Post-freeze original-rowset diagnostics for completed GPU product strata.

Run only after ROOT has recovered/imported the terminal bounded cache, assembled
all whole products, and frozen all four collector routes. No inference, threshold
selection, output repair, or independent-TEST assertion is performed.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / 'experiments' / 'sku-matching'
sys.path.insert(0, str(HERE))

import grade_nextdata_description_original_rowsets_v1 as ORIGINAL_GRADE
import nextdata_exact_cache_resume_v1 as CACHE
import run_indexed_volume_test_v1 as VOLUME
import run_nextdata_table_experiment_v1 as EXP

ROUTES = ('jev-full', 'jev-table', 'nli-full', 'nli-table')
VARIANT_BY_ROUTE = {'jev-full': 'full', 'jev-table': 'table',
                    'nli-full': 'full', 'nli-table': 'table'}
KIND_BY_ROUTE = {'jev-full': 'jev', 'jev-table': 'jev',
                 'nli-full': 'nli', 'nli-table': 'nli'}


def _canonical_rows(rows):
    return sorted((EXP.canon(row) for row in rows))


def _read_json(path: Path):
    return VOLUME.read_json(path)


def verify_frozen_collections(experiment: Path, parent: Path):
    """Verify all four freezes, route pins, cohort partition, and source closure."""
    parent_receipt_path = parent / 'complete-product-cohort.json'
    parent_receipt = _read_json(parent_receipt_path)
    if parent_receipt.get('all_original_rows_tasks_retained') is not True:
        raise ValueError('cohort receipt does not attest complete original rows/tasks')
    if (parent_receipt.get('independent_test') is not False
            or parent_receipt.get('consumed_test_diagnostic') is not True
            or parent_receipt.get('production_adoption_allowed') is not False):
        raise ValueError('cohort receipt diagnostic/adoption flags differ')
    ml_cases = parent_receipt.get('ml_product_case_ids')
    literal_cases = parent_receipt.get('literal_only_product_case_ids')
    if not isinstance(ml_cases, list) or not isinstance(literal_cases, list):
        raise ValueError('cohort receipt lacks product-stratum case lists')
    ml_ids, literal_ids = set(ml_cases), set(literal_cases)
    if len(ml_ids) != len(ml_cases) or len(literal_ids) != len(literal_cases):
        raise ValueError('cohort receipt repeats stratum case IDs')
    if ml_ids & literal_ids:
        raise ValueError('ML and literal-only case strata overlap')
    expected_case_ids = ml_ids | literal_ids
    listed = parent_receipt.get('collections')
    if not isinstance(listed, dict) or set(ROUTES) - set(listed):
        raise ValueError('cohort receipt does not list all four required routes')

    frozen, bundle, _, _, _ = EXP.load_experiment(experiment)
    source = bundle.source['cohort_rows']
    source_membership = source['membership.jsonl']
    source_cases = VOLUME.unique_index(source['case-plans.jsonl'], 'case_id', 'source cases')
    source_rows = source['row-plans.jsonl']
    source_tasks = source['tasks.jsonl']
    if not expected_case_ids <= set(source_cases):
        raise ValueError('stratum union includes a case outside original source')
    expected_members = [r for r in source_membership if r['case_id'] in expected_case_ids]
    if {r['case_id'] for r in expected_members} != expected_case_ids:
        raise ValueError('stratum union does not match original membership')
    expected_rows = [r for r in source_rows if r['case_id'] in expected_case_ids]
    expected_tasks = [r for r in source_tasks if r['case_id'] in expected_case_ids]
    expected_row_keys = {(r['case_id'], r['au_row_key']) for r in expected_rows}
    expected_task_ids = {r['task_id'] for r in expected_tasks}
    if len(expected_row_keys) != len(expected_rows) or len(expected_task_ids) != len(expected_tasks):
        raise ValueError('original source row/task identities are not unique')

    reference_sets = {}
    cohort_fingerprint = None
    input_pin = EXP.pin(experiment / 'input-freeze.json')
    for route in ROUTES:
        directory = parent / route
        if not directory.is_dir() or directory.is_symlink():
            raise ValueError('missing or unsafe collector route: ' + route)
        freeze_path = directory / 'output-freeze.json'
        freeze = _read_json(freeze_path)
        if freeze.get('all_predictions_and_gates_frozen') is not True:
            raise ValueError('collector output is not frozen: ' + route)
        if freeze.get('input_freeze') != input_pin:
            raise ValueError('collector input freeze differs: ' + route)
        if (freeze.get('independent_test') is not False
                or freeze.get('consumed_test_diagnostic') is not True
                or freeze.get('production_adoption_allowed') is not False):
            raise ValueError('collector diagnostic/adoption flags differ: ' + route)
        EXP.verify_pins(freeze['files'])
        for name in ('membership.jsonl', 'task-resolutions.jsonl',
                     'all-row-results.jsonl', 'case-decisions.jsonl',
                     'collection-receipt.json'):
            if freeze['files'].get(str((directory / name).resolve())) != EXP.pin(directory / name):
                raise ValueError('required collector file is not pinned: ' + route + '/' + name)

        receipt = _read_json(directory / 'collection-receipt.json')
        top_entry = listed[route]
        embedded_receipt = {k: v for k, v in top_entry.items() if k != 'output_freeze_sha256'}
        if receipt != embedded_receipt:
            raise ValueError('cohort receipt differs from frozen route receipt: ' + route)
        if top_entry.get('output_freeze_sha256') != VOLUME.sha_file(freeze_path):
            raise ValueError('cohort receipt freeze digest differs: ' + route)
        if (receipt.get('all_original_rows_tasks_retained') is not True
                or receipt.get('ml_product_case_ids') != ml_cases
                or receipt.get('literal_only_product_case_ids') != literal_cases
                or receipt.get('case_count') != len(expected_case_ids)):
            raise ValueError('route cohort/stratum receipt differs: ' + route)
        expected_kind = KIND_BY_ROUTE[route]
        expected_variant = VARIANT_BY_ROUTE[route]
        if (receipt.get('variant') != expected_variant
                or receipt.get('model_id') != CACHE.model_identity(expected_kind)['model_id']):
            raise ValueError('route model/variant identity differs: ' + route)
        if (receipt.get('scope_validation_relaxed') is not True
                or receipt.get('source_citations_manufactured') is not False):
            raise ValueError('small-model scope/citation policy differs: ' + route)

        membership = VOLUME.read_rows(directory / 'membership.jsonl')
        members = VOLUME.unique_index(membership, 'case_id', route + ' membership')
        if set(members) != expected_case_ids or _canonical_rows(membership) != _canonical_rows(expected_members):
            raise ValueError('route membership differs from exact original cohort: ' + route)
        row_results = VOLUME.read_rows(directory / 'all-row-results.jsonl')
        task_results = VOLUME.read_rows(directory / 'task-resolutions.jsonl')
        row_keys = {(r['case_id'], r['au_row_key']) for r in row_results}
        task_ids = {r['task_id'] for r in task_results}
        if (len(row_keys) != len(row_results) or row_keys != expected_row_keys
                or len(task_ids) != len(task_results) or task_ids != expected_task_ids):
            raise ValueError('route row/task closure differs from original source: ' + route)
        if (receipt.get('row_count') != len(expected_rows)
                or receipt.get('task_count') != len(expected_tasks)):
            raise ValueError('route row/task counts differ from source: ' + route)
        fingerprint = (tuple(_canonical_rows(membership)), tuple(sorted(row_keys)), tuple(sorted(task_ids)))
        if cohort_fingerprint is None:
            cohort_fingerprint = fingerprint
        elif fingerprint != cohort_fingerprint:
            raise ValueError('four collector routes do not share identical cohort/row/task closure')
        reference_sets[route] = (directory, receipt, membership,
                                 VOLUME.read_rows(directory / 'case-decisions.jsonl'))

    return frozen, bundle, source_cases, expected_rows, expected_tasks, ml_ids, literal_ids, reference_sets


def grade(experiment: Path, collection_parent: Path, output: Path) -> dict:
    if output.exists():
        raise FileExistsError(output)
    frozen, bundle, source_cases, expected_rows, expected_tasks, ml_ids, literal_ids, records = \
        verify_frozen_collections(experiment, collection_parent)

    all_case_ids = ml_ids | literal_ids
    source_membership = bundle.source['cohort_rows']['membership.jsonl']
    union_membership = [{**m,
        'source_version': source_cases[m['case_id']]['source_version'],
        'split': source_cases[m['case_id']]['source_version']}
        for m in source_membership if m['case_id'] in all_case_ids]
    if {m['case_id'] for m in union_membership} != all_case_ids:
        raise ValueError('original annotation membership does not cover frozen strata')
    archives = [EXP.ROOT / VOLUME.SCORE_ORIGINAL.V2_LABEL_ARCHIVE,
                EXP.ROOT / VOLUME.SCORE_ORIGINAL.V3_LABEL_ARCHIVE]
    # The original multi-rowset reader is invoked only after every collector freeze
    # and pinned output has passed the checks above.
    references = VOLUME.cloned_selected_label_reader()(
        *archives, union_membership, bundle.prepared / 'row-plans.jsonl')
    if set(references) != all_case_ids:
        raise ValueError('original annotation rowsets do not cover all frozen cases')
    unknown_ids = {cid for cid, reference in references.items()
                   if VOLUME.SCORE_ORIGINAL.canonical_reference(reference)[0] not in {'matched', 'unmatched'}}

    def score(membership, predictions):
        result = VOLUME.SCORE_ORIGINAL.score_variant(membership, predictions, references)
        metric, rows = result['metrics'], result['row_metrics']
        positives = metric['tp'] + metric['fn']
        correct = rows.get('correct_accepted_row', 0)
        return {
            'case_count': len(membership),
            'known_reference_case_count': result.get('known_reference_case_count'),
            'unknown_reference_count': result.get('unknown_reference_count'),
            'exact_row_recall': correct / positives if positives else None,
            'known_wrong_accepted_count': metric['fp'] + rows.get('wrong_accepted_row', 0),
            'unknown_accepted_count': sum(p.get('decision') == 'accept'
                                          and p.get('case_id') in unknown_ids
                                          for p in predictions),
            'metrics': metric,
            'row_metrics': rows,
        }

    result_routes = {}
    normalized = {}
    for route in ROUTES:
        directory, receipt, membership, predictions = records[route]
        ids = {row['case_id'] for row in membership}
        route_result = {'model_id': receipt['model_id'], 'variant': receipt['variant'],
                        'collection_freeze_sha256': VOLUME.sha_file(directory / 'output-freeze.json'),
                        'strata': {}}
        for stratum, chosen in (('overall', ids), ('ml_only', ids & ml_ids),
                                ('literal_only', ids & literal_ids)):
            subset_membership = [m for m in membership if m['case_id'] in chosen]
            subset_predictions = [p for p in predictions if p['case_id'] in chosen]
            if ({m['case_id'] for m in subset_membership} != chosen
                    or {p['case_id'] for p in subset_predictions} != chosen):
                raise ValueError('stratum predictions/membership differ: ' + route + '/' + stratum)
            route_result['strata'][stratum] = score(subset_membership, subset_predictions)
        result_routes[route] = route_result
        normalized[route] = (membership, predictions)

    paired = []
    for kind in ('jev', 'nli'):
        before_route = kind + '-full'
        after_route = kind + '-table'
        before_members, before_predictions = normalized[before_route]
        after_members, after_predictions = normalized[after_route]
        chosen = ml_ids
        before = [p for p in before_predictions if p['case_id'] in chosen]
        after = [p for p in after_predictions if p['case_id'] in chosen]
        if ({p['case_id'] for p in before} != chosen or {p['case_id'] for p in after} != chosen):
            raise ValueError('fresh full/table ML-only pair membership differs: ' + kind)
        paired.append({'model_id': CACHE.model_identity(kind)['model_id'],
                       'full_collection': before_route, 'description_collection': after_route,
                       'case_count': len(chosen),
                       'change': EXP.paired_change(before, after, references)})

    report = {
        'schema_version': 'nextdata-completed-gpu-product-strata-original-rowsets-v1',
        **EXP.FLAGS,
        'scope_status': 'unproved', 'citation_semantics_supported': False,
        'annotations_read_after_all_four_collector_freezes_verified': True,
        'reference_rowsets': 'original complete multi-rowset annotation reader; no historical singleton-derived cache',
        'reference_kind': 'Claude Haiku 5.5 machine reference, not human gold',
        'thresholds_selected': False, 'gates_changed': False, 'outputs_changed': False,
        'description_payload_alias': 'table',
        'small_models_are_scope_relaxed_diagnostics': True,
        'execution_failures_are_retained_as_unknown': True,
        'input_freeze': EXP.pin(experiment / 'input-freeze.json'),
        'cohort_receipt': EXP.pin(collection_parent / 'complete-product-cohort.json'),
        'reference_case_count': len(references),
        'ml_case_count': len(ml_ids), 'literal_only_case_count': len(literal_ids),
        'row_count': len(expected_rows), 'task_count': len(expected_tasks),
        'routes': result_routes, 'fresh_full_vs_description_ml_only': paired,
        'grader_source': EXP.pin(Path(__file__)),
        'original_score_source': EXP.pin(Path(VOLUME.SCORE_ORIGINAL.__file__)),
        'label_archives': [EXP.pin(path) for path in archives],
    }
    EXP.write_json(output, report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--experiment', type=Path, required=True)
    parser.add_argument('--collection-parent', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = grade(args.experiment, args.collection_parent, args.output)
    print(json.dumps({'reference_case_count': report['reference_case_count'],
                      'ml_case_count': report['ml_case_count'],
                      'literal_only_case_count': report['literal_only_case_count'],
                      'routes': {name: {stratum: values['exact_row_recall']
                                        for stratum, values in row['strata'].items()}
                                 for name, row in report['routes'].items()},
                      'fresh_full_vs_description_ml_only': report['fresh_full_vs_description_ml_only']},
                     ensure_ascii=False, sort_keys=True))
