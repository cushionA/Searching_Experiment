"""Root fixed-version terminal retrieval only; no submit, inference, or grading."""
from pathlib import Path
import importlib.util,json,hashlib,sys,datetime,zipfile,shutil
ROOT=Path.cwd()
R=ROOT/'.lab-output/sku-nextdata-description-bounded-resume-20261013-v1'
from dotenv import load_dotenv
load_dotenv(ROOT/'.env',override=False,interpolate=False)
s=importlib.util.spec_from_file_location('ops',ROOT/'.agents/skills/kaggle-ops/scripts/kaggle_ops.py');o=importlib.util.module_from_spec(s);s.loader.exec_module(o)
c=o.api();job=json.loads((R/'kaggle-job-s000-v1/job.json').read_text())
assert job['ref']=='superbigzabuton/sku-nextdata-table-fp32-20261013-resume-s000' and job['version']==1
o.verify_saved_version(c,job,version=1)
status=o.status(c,job['ref'],job['version'])
if status['status'] not in {'complete','error','cancel_acknowledged'}:
 raise RuntimeError('Frozen output recovery requires terminal status: '+str(status))
out=R/'fixed-s000-v1-recovered'
if out.exists():raise FileExistsError('Never overwrite recovered bytes: '+str(out))
out.mkdir()
continuation_path=R/'kaggle-job-s000-v1/continuation.json'
continuation=json.loads(continuation_path.read_text()) if continuation_path.exists() else {}
reuse=(continuation.get('ready_for_verification') is True and continuation.get('ref')==job['ref'] and continuation.get('version')==job['version'])
if reuse:
 manifest=continuation['files']
 for row in manifest:
  relative=Path(row['path'])
  assert not relative.is_absolute() and '..' not in relative.parts
  source=R/'kaggle-job-s000-v1/artifacts'/relative
  assert source.stat().st_size==row['bytes'] and hashlib.sha256(source.read_bytes()).hexdigest()==row['sha256']
  dest=out/'artifacts'/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
else:manifest=o.outputs(c,job,out,download=True)
def pin(p):return {'path':str(p.relative_to(ROOT)),'size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for row in manifest:
 p=out/'artifacts'/row['path']
 assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
rec={'schema':'root-fixed-bounded-gpu-terminal-recovery-v1','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'remote_ref':job['ref'],'version':job['version'],'source_signature':job['source_signature'],'actual_saved_source_verified':True,'status_observation':status,'terminal_status':'cancelled' if status['status']=='cancel_acknowledged' else status['status'],'files':manifest,'downloaded_file_bytes_verified':True,'reused_fixed_version_wait_recovery':reuse,'original_bytes_changed':False,'credentials_or_signed_urls_in_receipt':False}
(out/'ROOT_FIXED_VERSION_RECOVERY.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2))
cache=list((out/'artifacts').rglob('new-first-scores.jsonl'))
freeze=list((out/'artifacts').rglob('EXECUTION_FREEZE.json'))
if len(cache)!=1 or len(freeze)!=1:raise ValueError('Need exactly one raw cache/freeze')
cache,freeze=cache[0],freeze[0]
raw=cache.read_bytes()
if raw and not raw.endswith(b'\n'):raise ValueError('Partial JSONL tail preserved; review before import')
rows=[json.loads(x) for x in raw.splitlines()]
keys=[(x['kind'],x['exact_key']) for x in rows]
assert len(keys)==len(set(keys))
expected=json.loads((R/'prepared-after-v2-v1/worker-state/worker-plan.json').read_text())['shards'][0]
allowed={tuple(x) for x in expected['request_keys']}
assert set(keys)<=allowed
f=json.loads(freeze.read_text())
completions=list((out/'artifacts').rglob('COMPLETION.json'))
if rec['terminal_status']=='complete':assert len(completions)==1
if completions:
 assert len(completions)==1
 completed=json.loads(completions[0].read_text())
 assert all(completed.get(k)==v for k,v in f.items())
 assert completed['new_first_scores_sha256']==pin(cache)['sha256'] and completed['new_first_scores_size_bytes']==cache.stat().st_size
 assert all(completed['totals'].get(k+'_new_unique_records',0)==sum(x['kind']==k for x in rows) for k in ('jev','nli'))
 if completed['totals']['complete']:assert set(keys)==allowed
 else:assert completed['totals']['bounded_time_reached'] is True
assert (f['remote_ref'],f['version'],f['shard_id'])==(job['ref'],1,0)
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import nextdata_exact_cache_resume_v1 as C
C.validate_runtime(f['gpu_runtime'])
for kind in C.KINDS:C.validate_pins(kind,f['model_pins'][kind])
for z in (out/'artifacts').rglob('sku-exact-resume-results.zip'):
 with zipfile.ZipFile(z) as a:
  assert a.testzip() is None
  for name,p in [('new-first-scores.jsonl',cache),('EXECUTION_FREEZE.json',freeze)]:
   members=[x for x in a.namelist() if Path(x).name==name]
   assert len(members)==1 and a.read(members[0])==p.read_bytes()
result={**rec,'cache_file':str(cache.relative_to(ROOT)),'execution_freeze':str(freeze.relative_to(ROOT)),'cache_file_sha256':pin(cache)['sha256'],'cache_file_size_bytes':cache.stat().st_size,'execution_freeze_sha256':pin(freeze)['sha256'],'record_count':len(rows),'new_records_per_model':{k:sum(x['kind']==k for x in rows) for k in C.KINDS},'jsonl_complete_tail':True,'all_keys_unique_and_within_frozen_shard':True,'complete_shard':set(keys)==allowed,'gpu_runtime':f['gpu_runtime'],'model_pins_verified':True,'no_original_scores_modified':True}
(R/'root-s000-terminal-cache-recovery-v1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:result[k] for k in ['terminal_status','record_count','new_records_per_model','complete_shard','gpu_runtime']},ensure_ascii=False))
