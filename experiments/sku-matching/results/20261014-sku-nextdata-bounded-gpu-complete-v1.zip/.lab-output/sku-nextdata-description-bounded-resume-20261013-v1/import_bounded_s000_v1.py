"""Import terminal first scores using reviewed importer, without per-record rehashing.

Only the immutable terminal cache digest is reused; it is checked before/after.
All model inputs, records, source/index/policy checks remain in the old importer.
"""
from pathlib import Path
import sys,json,runpy,time
ROOT=Path.cwd();D=ROOT/'.lab-output/sku-nextdata-description-bounded-resume-20261013-v1'
sys.path.insert(0,str(ROOT/'experiments/sku-matching'))
import nextdata_exact_cache_resume_v1 as R
receipt=D/'root-s000-terminal-cache-recovery-v1.json';rec=json.loads(receipt.read_text())
cache=(ROOT/rec['cache_file']).resolve();digest=R.sha(cache)
assert digest==rec['cache_file_sha256'] and cache.stat().st_size==rec['cache_file_size_bytes']
original_sha=R.sha;old_index=D/'prepared-after-v2-v1/index.sqlite';old_index_sha=original_sha(old_index)
def immutable_cache_digest(path):
 return digest if Path(path).resolve()==cache else original_sha(path)
sys.argv=['prepare_nextdata_exact_resume_v1.py','import-new-cache','--input-index',str(old_index),'--output-index',str(D/'merged-after-s000-v1.sqlite'),'--cache-file',str(cache),'--execution-freeze',str(ROOT/rec['execution_freeze']),'--recovery-receipt',str(receipt),'--worker-state-dir',str(D/'prepared-after-v2-v1/worker-state')]
started=time.monotonic();R.sha=immutable_cache_digest
try:runpy.run_path(str(ROOT/'experiments/sku-matching/prepare_nextdata_exact_resume_v1.py'),run_name='__main__')
finally:R.sha=original_sha
assert original_sha(cache)==digest and original_sha(old_index)==old_index_sha
(D/'root-s000-import-execution-v1.json').write_text(json.dumps({'cache_digest_reused_without_rehashing_each_record':True,'terminal_cache_sha_before_and_after':digest,'original_index_sha_before_and_after':old_index_sha,'original_reviewed_importer_unmodified':True,'model_or_policy_changes':False,'elapsed_seconds':time.monotonic()-started},indent=2))
print('Imported fixed first scores; original cache/index bytes unchanged.',flush=True)
