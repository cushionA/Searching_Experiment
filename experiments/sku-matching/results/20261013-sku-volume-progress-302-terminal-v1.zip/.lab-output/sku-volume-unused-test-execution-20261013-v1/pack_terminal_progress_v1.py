"""Save a label-free partial checkpoint of completed, original first-pass files."""
from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

EX = Path(__file__).resolve().parent
ROOT = EX.parents[1]
RESULTS = ROOT / "experiments/sku-matching/results"


def pin(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main() -> None:
    state_bytes = (EX / "supervisor-v2-state.json").read_bytes()
    state = json.loads(state_bytes)
    terminal = set(range(1, 109)) | set(state["terminal"])
    if any(type(n) is not int or n < 1 or n > 965 for n in terminal):
        raise ValueError("unexpected completed packet identity")
    index = json.loads((EX / "packet-index-v1/packet-index.json").read_text())
    packets = index["packets"]
    selected = [packets[n - 1] for n in sorted(terminal)]
    if len(packets) != 965 or any(int(Path(p["file"]).stem.split("-")[-1]) != n
                                 for n, p in zip(sorted(terminal), selected)):
        raise ValueError("packet ordinal differs from the fixed index")
    stem = f"20261013-sku-volume-progress-{len(terminal):03d}-terminal-v1"
    target = RESULTS / (stem + ".zip")
    receipt_path = RESULTS / (stem + ".receipt.json")
    if target.exists() or receipt_path.exists():
        raise FileExistsError("progress checkpoint already exists")
    files: dict[str, bytes] = {}
    missing = []

    def retain(path: Path) -> None:
        if path.is_symlink():
            raise ValueError("symlink is not a checkpoint source")
        if path.is_file():
            files[path.relative_to(ROOT).as_posix()] = path.read_bytes()

    for packet in selected:
        name = Path(packet["file"]).stem
        draft = EX / "drafts" / (name + ".jsonl")
        if draft.is_file():
            retain(draft)
        else:
            missing.append(name)
        for suffix in (".txt", ".spawn-input.json"):
            retain(EX / "root-supervisor-prompts" / (name + suffix))
    for path in sorted((EX / "supervisor-v2-events").glob("*.json")):
        retain(path)
    for path in sorted(EX.glob("root-*")):
        if path.is_file():
            retain(path)
    for name in (
        "supervisor-dispatch-ledger.jsonl", "supervisor-v2-state.json",
        "packet-70-original-draft-relocation-v1.json",
        "collect_volume_firstpass_v1.py", "collect_normalized_firstpass_v1.py",
        "normalize_dispatch_metadata_v1.py", "normalize_dispatch_metadata_v2.py",
        "pack_terminal_progress_v1.py", "summarize_frozen_volume_grade_v1.py",
        "post-inference-helper-preparation-qa-v1.json",
    ):
        retain(EX / name)
    # Preserve the exact state bytes from which completed membership was chosen.
    files[(EX / "supervisor-v2-state.json").relative_to(ROOT).as_posix()] = state_bytes
    inventory = {name: pin(data) for name, data in sorted(files.items())}
    manifest = {
        "schema_version": "sku-volume-partial-terminal-checkpoint-v1",
        "status": "partial_firstpass_progress_not_a_scored_or_complete_volume_test",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "completed_packet_ordinals": sorted(terminal),
        "completed_packet_count": len(terminal), "total_packet_count": 965,
        "available_original_draft_count": len(terminal) - len(missing),
        "missing_terminal_original_drafts": missing,
        "state_observed_pin": pin(state_bytes), "files": inventory,
        "source_checkpoint_dependency": "20261013-sku-volume-unused-test-source-checkpoint.chunks.json and restore supplement",
        "root_confirmed_terminal_seed": "packets 1..108; previous first108 terminal receipt",
        "live_metadata_can_include_unfinished_tasks": True,
        "original_early_provenance_gaps_remain": True,
        "labels_read": False, "scores_created": False,
        "model_calls_made_by_checkpoint": False, "semantic_retries": 0,
        "original_response_bytes_modified": False,
    }
    manifest_bytes = json.dumps(manifest, ensure_ascii=False, sort_keys=True,
                                separators=(",", ":")).encode() + bytes([10])
    with target.open("xb") as raw:
        with zipfile.ZipFile(raw, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, data in sorted(files.items()):
                archive.writestr(name, data)
            archive.writestr("checkpoint-manifest.json", manifest_bytes)
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise ValueError("checkpoint CRC failed")
        for name, expected in inventory.items():
            if pin(archive.read(name)) != expected:
                raise ValueError("checkpoint member bytes differ from originals")
    receipt = {"schema_version": "sku-volume-partial-terminal-checkpoint-receipt-v1",
               "archive": target.relative_to(ROOT).as_posix(), **pin(target.read_bytes()),
               "manifest_sha256": pin(manifest_bytes)["sha256"],
               "completed_packet_count": len(terminal),
               "available_original_draft_count": len(terminal) - len(missing),
               "missing_terminal_original_drafts": missing, "crc_and_all_member_sha_verified": True,
               "labels_read": False, "scores_created": False, "partial_checkpoint": True}
    with receipt_path.open("x") as output:
        json.dump(receipt, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
