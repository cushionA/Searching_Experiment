#!/usr/bin/env python3
"""Run the approved table-first comparison through one Kaggle helper monitor."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/Searching_Experiment')
EXP = ROOT / '.lab-output/sku-v7-small-nli-spec-first-20261014-v1'
PREFIX = [str(ROOT / '.deps/kaggle-venv/bin/python'), '-B',
          str(ROOT / '.agents/skills/kaggle-ops/scripts/kaggle_ops.py')]


def call(args):
    print(json.dumps({'stage': args[0], 'arguments': args}, ensure_ascii=False), flush=True)
    result = subprocess.run(PREFIX + args, cwd=ROOT, capture_output=True, text=True)
    with (EXP / ('network-' + args[0] + '.log')).open('x') as f:
        f.write(result.stdout); f.write(result.stderr)
    if result.stdout:
        print(result.stdout, end='', flush=True)
    if result.stderr:
        print(result.stderr, end='', file=sys.stderr, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    return json.loads(result.stdout.strip().splitlines()[-1])


if (EXP / 'job/job.json').exists():
    raise SystemExit('job already exists; resume fixed version instead of submitting')
freeze = json.loads((EXP / 'HOST_INPUT_FREEZE.json').read_text())
payload = EXP / 'dataset-upload/v7-small-nli-single-inputs.zip'
if hashlib.sha256(payload.read_bytes()).hexdigest() != freeze['archive_sha256']:
    raise SystemExit('reviewed private input payload changed')
doctor = call(['doctor'])
if not doctor['token_present']:
    raise SystemExit('configured Kaggle token unavailable')
budget = call(['quota'])
if budget['gpu']['remaining_seconds'] < 7200:
    raise SystemExit('insufficient fixed GPU time budget')
call(['dataset-update', '--folder', str(EXP / 'dataset-upload'), '--message',
      'DEV40 specification tables when available; same NLI model and decision rules'])
job = call(['submit', '--folder', str(EXP / 'notebook-upload'), '--output', str(EXP / 'job')])
print(json.dumps({'stage': 'fixed-job-monitor', 'ref': job['ref'], 'version': job['version'],
                  'source_signature': job['source_signature']}, ensure_ascii=False), flush=True)
call(['wait', '--job', str(EXP / 'job/job.json'), '--output', str(EXP / 'job'),
      '--wait-seconds', '7200'])
