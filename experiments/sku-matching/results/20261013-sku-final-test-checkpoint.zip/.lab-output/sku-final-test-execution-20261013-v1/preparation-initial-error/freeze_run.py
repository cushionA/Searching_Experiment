"""Root-controlled freeze and bounded, complete-context worker assignments."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '.lab-output/sku-final-composition-subset-20261013-v1'
SEL = BASE / 'inference-selection-v2'
SRC = BASE / 'composition-source-only'
OUT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def rows(path):
    return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]

def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')

def main():
    if (OUT / 'experiment-freeze.json').exists():
        raise FileExistsError('original root freeze already exists')
    critical = [
        'assemble_final_full_sku_gate_v1.py', 'freeze_final_sku_inference_selection_v1.py',
        'evaluate_final_full_sku_gate_v1.py', 'run_fresh_baseline_final_subset_v1.py',
        'prepare_final_composition_packets_v1.py', 'sku_literal_family_proof_v1.py',
        'build_sku_literal_family_proofs_v1.py', 'composition_context_policy_v1.py',
        'composition_language_model_v1.py', 'composition_context_v1.py',
        'composition_evidence_v1.py', 'composition_source_blocks_v1.py',
        'composition_source_blocks_v2.py', 'composition_source_blocks_v3.py',
        'integrate_claude_description_v1.py', 'trial_composition_evidence_v1.py',
        'evaluate_scoped_html_trial_v1.py', 'prepare_full_condition_inputs_v2.py',
        'prepare_full_test_subset_v1.py', 'trial_full_scoped_condition_choices_v1.py',
        'trial_generic_model_jev_v1.py', 'trial_raw_title_nli_v1.py',
    ]
    code = [ROOT / 'experiments/sku-matching' / n for n in critical]
    # Additional fixed-model implementation files are enumerated by the
    # original runner, rather than inferred from the filesystem.
    sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
    import trial_full_scoped_condition_choices_v1 as fixed
    code += [ROOT / 'experiments/sku-matching' / n for n in fixed.CODE_NAMES]
    code += [ROOT / 'experiments/sku-matching/claude_v9_gate/sku_gate_sources.py', Path(__file__)]
    files = set(code)
    for directory in (BASE / 'inputs', BASE / 'binding-only', BASE / 'gate-prepared-v2', SEL):
        files.update(p for p in directory.iterdir() if p.is_file())
    for directory in (SRC, ROOT / '.lab-output/sku-final-literal-family-proofs-40-20261013-v1'):
        manifest = read(directory / 'manifest.json')
        files.add(directory / 'manifest.json')
        for name, expected in manifest.get('output_sha256', {}).items():
            path = directory / name
            if sha(path) != expected:
                raise ValueError('source output changed: ' + str(path))
            files.add(path)
    files.update([SRC / 'packets.jsonl', SRC / 'model-payloads.jsonl',
                  SRC / 'request-fanout.jsonl', SRC / 'protocol.json', SRC / 'span-receipts.jsonl',
                  ROOT / '.lab-output/sku-final-literal-family-proofs-40-20261013-v1/proofs.jsonl',
                  BASE / 'plan/subset-plan.json', BASE / 'plan/subset-membership.jsonl'])
    membership = sha(BASE / 'plan/subset-membership.jsonl')
    if membership != '212123b8851168a8895e8a035f8a1a032c173c496b76024b707030efca93778d':
        raise ValueError('predeclared 40-case membership changed')
    payloads = rows(SEL / 'dispatch-model-payloads.jsonl')
    if len(payloads) != 216 or len({p['unit_id'] for p in payloads}) != 216:
        raise ValueError('predeclared non-proof inference coverage changed')
    payloads.sort(key=lambda p:p['unit_id'])
    protocol = read(SRC / 'protocol.json')
    agents = []
    for i in range(4):
        assigned = payloads[i::4]
        batches, pending, byte_count = [], [], 0
        for payload in assigned:
            size = len(json.dumps(payload, ensure_ascii=False).encode())
            if pending and (len(pending) == 8 or byte_count + size > 100000):
                batches.append(pending)
                pending, byte_count = [], 0
            pending.append(payload)
            byte_count += size
        if pending:
            batches.append(pending)
        batch_files = []
        for n, batch in enumerate(batches):
            path = SEL / f'worker-inputs/worker-{i}-batch-{n:02d}.json'
            write(path, {'protocol':protocol['protocol'], 'packets':batch})
            files.add(path)
            batch_files.append({'path':str(path), 'sha256':sha(path), 'unit_ids':[p['unit_id'] for p in batch]})
        assignment = SEL / f'worker-inputs/worker-{i}-assignment.json'
        unit_ids = [p['unit_id'] for p in assigned]
        write(assignment, {'worker_index':i, 'unit_ids':unit_ids, 'batch_files':batch_files,
                           'response_file':str(SEL / f'worker-responses/worker-{i}.jsonl'),
                           'protocol_sha256':protocol['protocol_sha256'],
                           'all_packet_blocks_present':True, 'batching_is_transport_only':True})
        files.add(assignment)
        agents.append({'task_name':f'/root/final_sku_luna_worker_{i}', 'model_override':'gpt-6-luna',
                       'fork_turns':'none', 'assignment_file':str(assignment),
                       'assignment_sha256':sha(assignment), 'response_file':f'worker-responses/worker-{i}.jsonl',
                       'expected_unit_ids':unit_ids})
    trace = SEL / 'dispatch-trace.json'
    write(trace, {'dispatcher':'collaboration.spawn_agent', 'model_override':'gpt-6-luna',
                  'fork_turns':'none', 'hosted_weights_revision_verified':False,
                  'protocol_sha256':protocol['protocol_sha256'], 'selection_manifest_sha256':sha(SEL / 'manifest.json'),
                  'agents':agents, 'batching_is_transport_only_no_context_truncation':True})
    files.add(trace)
    frozen = {str(p):{'bytes':p.stat().st_size, 'sha256':sha(p)} for p in sorted(files)}
    write(OUT / 'experiment-freeze.json', {
        'schema_version':'final-sku-blind-experiment-root-freeze-v1', 'membership_sha256':membership,
        'case_count':40, 'product_count':20, 'all_original_au_row_count':448,
        'request_count':1145, 'task_count':1798, 'exact_context_count':547,
        'literal_proof_context_skip_count':331, 'hosted_inference_context_count':216,
        'primary_policy':'complete-scoped-fallback', 'comparison_policy':'baseline-literal-overlay',
        'gate_contract':'same AU row, every original condition supported, exactly one row, every competing row explicitly conflict',
        'unknown_is_not_conflict':True, 'model_alternative_winner_is_not_conflict':True,
        'literal_route':'exact unique axis name and entire ordered raw option families, all source spans verified; no normalization or partial match',
        'literal_route_separate_from_old_46tp_dev_pipeline':True,
        'baseline':'fresh actual JEV/NLI equal fusion, original title plus exact target axes, pinned revisions, CPU FP32, 4 threads, batch16',
        'hosted_model':'gpt-6-luna', 'hosted_weights_revision_verified':False,
        'hosted_model_scope':'full eligible description body, exact paired context cache only, no titles or desired value',
        'original_200case_plan_preserved_not_inferred':True,
        'source_review_dispatched_field_means_prepared_packets_only':True,
        'test_labels_or_prior_test_predictions_read':False, 'any_test_model_inference_started':False,
        'policy_or_threshold_selection_after_test_forbidden':True, 'production_adoption_allowed':False,
        'source_snapshot':frozen})
    print(json.dumps({'frozen_files':len(files),'workers':4,'units':216,'membership_sha256':membership}))

if __name__ == '__main__':
    main()
