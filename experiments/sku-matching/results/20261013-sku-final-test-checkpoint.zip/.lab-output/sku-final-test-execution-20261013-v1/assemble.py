"""Replay unchanged frozen gate bytecode with one verified metadata alias."""
from pathlib import Path
from types import FunctionType
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
import evaluate_final_full_sku_gate_v1 as E

EXEC = Path(__file__).resolve().parent
FREEZE = EXEC / 'experiment-freeze.json'
PLAN = E.SELECTION / 'inference-selection-plan.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_root():
    freeze = json.loads(FREEZE.read_text())
    for name, pin in freeze['source_snapshot'].items():
        path = Path(name)
        if path.stat().st_size != pin['bytes'] or sha(path) != pin['sha256']:
            raise ValueError('original root freeze changed: ' + name)
    return freeze

def alias_read(path):
    obj = E.read_json(path)
    if Path(path).resolve() == PLAN.resolve():
        frozen = json.loads(FREEZE.read_text())
        expected = frozen['source_snapshot'][str(PLAN.resolve())]['sha256']
        if sha(PLAN) != expected:
            raise ValueError('original inference selection plan changed')
        value = obj.get('evaluation_membership_sha256')
        if value != frozen['membership_sha256']:
            raise ValueError('actual selected membership does not match root freeze')
        if obj.get('membership_sha256', value) != value:
            raise ValueError('contradictory membership aliases')
        obj = {**obj, 'membership_sha256': value}
    return obj

def main():
    freeze = verify_root()
    receipt = {
        'schema_version':'final-sku-assembly-metadata-alias-reconciliation-v1',
        'root_inference_freeze_sha256':sha(FREEZE),
        'original_frozen_files_preserved':True,
        'original_gate_runner_sha256':sha(Path(E.__file__)),
        'assembly_adapter_sha256':sha(Path(__file__)),
        'metadata_alias':{'file':str(PLAN),'from':'evaluation_membership_sha256','to':'membership_sha256',
                          'verified_value':freeze['membership_sha256'],'original_file_sha256':sha(PLAN)},
        'all_model_inputs_protocols_raw_responses_and_source_pins_unchanged':True,
        'policy_or_threshold_changed':False, 'classifier_answers_changed':False,
        'new_model_inference':False, 'test_labels_read':False,
        'responses_inspected_for_policy_selection':False,
        'gate_results_created_before_reconciliation':False,
        'source_snapshot':{str(Path(__file__).resolve()):{'bytes':Path(__file__).stat().st_size,'sha256':sha(Path(__file__))}}
    }
    with (EXEC / 'assembly-only-reconciliation.json').open('x') as f:
        json.dump(receipt,f,ensure_ascii=False,indent=2);f.write('\n')
    run = FunctionType(E.run.__code__,{**E.run.__globals__,'read_json':alias_read},
                       E.run.__name__,E.run.__defaults__,E.run.__closure__)
    run.__kwdefaults__ = E.run.__kwdefaults__
    result = run(E.PREP,E.SELECTION,E.SOURCE,E.PROOFS,E.BASELINE,E.OUT)
    verify_root()
    print(json.dumps({k:result[k] for k in ('case_count','request_count','task_count','composition_response_count',
                                          'invalid_response_count','all_predictions_frozen','all_gates_frozen')},ensure_ascii=False))

if __name__=='__main__':
    main()
