"""Supply a source-derived legacy summary field; keep frozen inference intact."""
from pathlib import Path
from types import FunctionType
import json
import shutil
import assemble as A

E, EXEC = A.E, A.EXEC
PREP = E.BASE / 'gate-prepared-assembly-v3'
OUT = E.BASE / 'evaluation-v2'

def main():
    A.verify_root()
    old = E.read_json(E.PREP / 'manifest.json')
    cases = E.read_rows(E.PREP / 'case_plans.jsonl')
    baseline_count = sum(p['upstream_decision']['decision']=='matched' for p in cases)
    if baseline_count != 0 or any(p['upstream_decision']['decision']!='unmatched' for p in cases):
        raise ValueError('source upstream placeholders no longer match the frozen contract')
    PREP.mkdir(exist_ok=False)
    for name, expected in old['output_sha256'].items():
        source, target = E.PREP / name, PREP / name
        if A.sha(source) != expected:
            raise ValueError('original gate data changed')
        shutil.copyfile(source,target)
        if A.sha(target) != expected:
            raise ValueError('assembly metadata adaptation changed gate data')
    updated = {**old, 'baseline_matched_count':baseline_count,
               'assembly_metadata_only':True,
               'original_manifest_sha256':A.sha(E.PREP/'manifest.json')}
    E.write_json(PREP/'manifest.json',updated)
    receipt = {
        'schema_version':'final-sku-assembly-legacy-summary-reconciliation-v2',
        'original_root_freeze_sha256':A.sha(A.FREEZE),
        'original_gate_runner_preserved':True,
        'original_gate_runner_sha256':A.sha(Path(E.__file__)),
        'assembly_adapter_sha256':A.sha(Path(__file__)),
        'selection_membership_alias_adapter_sha256':A.sha(Path(A.__file__)),
        'original_prepared_manifest_sha256':A.sha(E.PREP/'manifest.json'),
        'new_prepared_manifest_sha256':A.sha(PREP/'manifest.json'),
        'added_legacy_summary_field':{'name':'baseline_matched_count','value':baseline_count,
                                     'derived_from':'all unchanged case_plans upstream_decision placeholders'},
        'all_original_gate_data_files_byte_identical':True,
        'all_model_inputs_protocols_raw_responses_and_source_pins_unchanged':True,
        'classifier_answers_changed':False,'new_model_inference':False,
        'policy_or_threshold_changed':False,'test_labels_read':False,
        'responses_inspected_for_policy_selection':False,
        'partial_baseline_gate_files_exist_from_failed_v1_assembly':True,
        'partial_output_directory_preserved':str(E.OUT),
        'new_output_directory':str(OUT),
        'source_snapshot':{str(Path(__file__).resolve()):{'bytes':Path(__file__).stat().st_size,'sha256':A.sha(Path(__file__))}}}
    E.write_json(EXEC/'assembly-only-reconciliation-v2.json',receipt)
    run = FunctionType(E.run.__code__,{**E.run.__globals__,'read_json':A.alias_read},
                       E.run.__name__,E.run.__defaults__,E.run.__closure__)
    run.__kwdefaults__ = E.run.__kwdefaults__
    result = run(PREP,E.SELECTION,E.SOURCE,E.PROOFS,E.BASELINE,OUT)
    A.verify_root()
    print(json.dumps({k:result[k] for k in ('case_count','request_count','task_count','composition_response_count',
                                          'invalid_response_count','all_predictions_frozen','all_gates_frozen')},ensure_ascii=False))

if __name__=='__main__':
    main()
