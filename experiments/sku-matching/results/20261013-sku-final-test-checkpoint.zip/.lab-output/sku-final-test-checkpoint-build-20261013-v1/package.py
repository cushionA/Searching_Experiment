#!/usr/bin/env python3
"""Preflight/build the final SKU test checkpoint.

The full independent answer archives stay external. After scoring, only the
predeclared selected-reference rows and score may be included. Run without
flags for a metadata-only payload estimate.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "experiments/sku-matching/results/20261013-sku-final-test-checkpoint.zip"
SHA_PATH = OUT.with_suffix(OUT.suffix + ".sha256")
BUILD = ROOT / ".lab-output/sku-final-test-checkpoint-build-20261013-v1"
TREES = [
    ".lab-output/sku-final-test-subset-20261013-v1",
    ".lab-output/sku-final-composition-subset-20261013-v1",
    ".lab-output/sku-final-literal-family-proofs-40-20261013-v1",
    ".lab-output/sku-final-literal-family-proofs-20261013-v1",
    ".lab-output/sku-final-test-subset-source-capture-completion-20261013-v1",
    ".lab-output/sku-final-test-baseline-gpu-package-20261013-v1",
    ".lab-output/sku-final-test-baseline-gpu-blocked-20261013-v1",
    ".lab-output/sku-final-test-independent-review-20261013-v1",
    ".lab-output/sku-final-cpu-baseline-20261013-v1",
    ".lab-output/sku-final-test-execution-20261013-v1",
    ".lab-output/sku-final-test-checkpoint-build-20261013-v1",
]
FILES = [
    ".lab-output/sku-full-evaluation-inventory-20261013-v1/inventory.json",
    ".lab-output/sku-full-evaluation-prepare-20261013-v1/PREPARATION_PLAN.md",
    ".lab-output/sku-full-evaluation-prepare-20261013-v1/inventory.json",
    ".lab-output/sku-full-evaluation-prepare-20261013-v1/source-index.json",
    ".lab-output/sku-full-evaluation-prepare-20261013-v1/prepare_full_sku_evaluation_v1.py",
    "experiments/sku-matching/grade_final_test_subset_v1.py",
    "experiments/sku-matching/audit_final_test_subset_overlap_v1.py",
    "experiments/sku-matching/test_prepare_final_composition_packets_v1.py",
    "experiments/sku-matching/assemble_final_full_sku_gate_v1.py",
    "experiments/sku-matching/build_sku_literal_family_proofs_v1.py",
    "experiments/sku-matching/evaluate_final_full_sku_gate_v1.py",
    "experiments/sku-matching/freeze_final_sku_inference_selection_v1.py",
    "experiments/sku-matching/prepare_final_composition_packets_v1.py",
    "experiments/sku-matching/prepare_full_condition_inputs_v2.py",
    "experiments/sku-matching/prepare_full_test_subset_v1.py",
    "experiments/sku-matching/run_fresh_baseline_final_subset_v1.py",
    "experiments/sku-matching/sku_literal_family_proof_v1.py",
    "experiments/sku-matching/session-result-20261012.txt",
    "experiments/sku-matching/session-handoff-20261012.txt",
    "tests/test_lab_final_test_subset_grader.py",
    "tests/test_lab_final_full_sku_gate.py",
    "tests/test_lab_fresh_final_baseline.py",
    "tests/test_lab_sku_literal_family_proof.py",
    ".lab-output/sku-final-test-execution-20261013-v1/experiment-freeze.json",
    ".lab-output/sku-final-test-execution-20261013-v1/assembly-only-reconciliation.json",
    ".lab-output/sku-final-test-execution-20261013-v1/assembly-only-reconciliation-v2.json",
    ".lab-output/sku-final-test-execution-20261013-v1/assemble.py",
    ".lab-output/sku-final-test-execution-20261013-v1/resume_assembly.py",
    ".lab-output/sku-final-composition-subset-20261013-v1/evaluation-v2/all-gates-frozen.json",
    ".lab-output/sku-final-composition-subset-20261013-v1/evaluation-v2/execution-freeze.json",
    ".lab-output/sku-final-composition-subset-20261013-v1/evaluation-v2/grade-freeze-receipt.json",
    ".lab-output/sku-final-composition-subset-20261013-v1/evaluation-v2/grade-freeze-receipt-parser-v2.json",
    ".lab-output/sku-final-composition-subset-20261013-v1/evaluation-v2/scoring-go-and-completion-receipt.json",
    ".lab-output/sku-final-test-checkpoint-build-20261013-v1/references.jsonl",
    ".lab-output/sku-final-test-checkpoint-build-20261013-v1/reference-score.json",
    "experiments/sku-matching/final-blind-sku-test-result-20261013.txt",
    ".lab-output/sku-next-dev-alignment-audit-20261013-v1/audit.json",
    ".lab-output/sku-next-dev-alignment-audit-20261013-v1/plan.txt",
    ".lab-output/sku-next-dev-alignment-audit-20261013-v1/dev-test-product-disjoint-audit.json",
]
EXTERNAL = [
    {"split": "v2", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261011-sku-independent-real-eval-v2.zip", "sha256": "6f65d988222c79c758614592340ba28565a51fa8891317724ba354c5fc38b457", "label_member_prefix": ".lab-output/sku-independent-real-20261011/eval-v2/labels-token/"},
    {"split": "v3", "path": ".lab-output/sku-claude-additional-review-20261012-v1/20261012-sku-independent-real-eval-v3.zip", "sha256": "52f6faa51127a9c12250a3cdb5eb3d1818a36461a8c09323e481748aeed1f37b", "label_member_prefix": ".lab-output/sku-independent-real-20261011/eval-v3/labels-token/"},
    {"split": "v2-v3-label-free-inputs", "path": ".lab-output/sku-claude-dev-input-share-20261012-v1/20261012-sku-independent-real-eval-v2-v3-token-inputs.zip", "sha256": "db2815a3d5c726e45f996ad07e73cdcf1cdff0610de53ad84af8a4a0a880488f"},
]
FORBIDDEN_PARTS = {".deps", "models", "model", "weights", "secrets", "credentials", ".venv", "venv", "labels-token"}
FORBIDDEN_SUFFIXES = {".safetensors", ".pt", ".pth", ".ckpt", ".bin", ".env"}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe(rel: str) -> bool:
    p = Path(rel)
    lowparts = {x.lower() for x in p.parts}
    lowname = p.name.lower()
    if lowparts & (FORBIDDEN_PARTS | {"__pycache__"}) or p.suffix.lower() in FORBIDDEN_SUFFIXES | {".pyc", ".pyo"}:
        return False
    if lowname.startswith(("answer-", "label-", "gold-")) or lowname in {"answers.jsonl", "labels.jsonl", "gold.jsonl"}:
        return False
    return True


def gather() -> tuple[list[tuple[Path, str]], list[str]]:
    files: dict[str, Path] = {}
    missing: list[str] = []
    for rel in FILES:
        path = ROOT / rel
        if path.is_file() and safe(rel):
            files[rel] = path
        else:
            missing.append(rel)
    for rel in TREES:
        root = ROOT / rel
        if not root.exists():
            missing.append(rel + "/")
            continue
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            arc = path.relative_to(ROOT).as_posix()
            # Raw stores contain symlinks into the source tree. They are
            # materialized below only after SHA/byte/origin pins are checked.
            if path.is_symlink():
                continue
            if safe(arc):
                files[arc] = path
    # Every code file named in the immutable root experiment freeze is included
    # only if its current bytes still match that freeze.
    root_freeze_path = ROOT / ".lab-output/sku-final-test-execution-20261013-v1/experiment-freeze.json"
    if root_freeze_path.is_file():
        root_freeze = json.loads(root_freeze_path.read_text())
        for absolute, pin in root_freeze.get("source_snapshot", {}).items():
            path = Path(absolute)
            if path.suffix != ".py":
                continue
            try:
                arc = path.resolve().relative_to(ROOT).as_posix()
            except ValueError:
                missing.append(f"frozen-source-outside-repository:{absolute}")
                continue
            if not path.is_file() or path.stat().st_size != pin.get("bytes") or digest(path) != pin.get("sha256"):
                missing.append(f"frozen-source-pin-mismatch:{arc}")
                continue
            if safe(arc):
                files[arc] = path
    # Restore only raw captures named by the frozen 40-case source/proof
    # receipts and the preserved 200-case proof manifest. Never follow a raw
    # symlink until its target has matched its expected SHA and byte count.
    raw_expected: dict[str, dict] = {}
    source_index_path = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source-index.json"
    source_index = {}
    if source_index_path.is_file():
        source_index = {row["path"]: row for row in json.loads(source_index_path.read_text())}
    raw_pin_file = ROOT / ".lab-output/sku-final-composition-subset-20261013-v1/composition-source-only/raw-pins.jsonl"
    if raw_pin_file.is_file():
        for line in raw_pin_file.read_text().splitlines():
            row = json.loads(line)
            raw_expected[row["raw_file"]] = {"sha256": row["sha256"], "bytes": row["bytes"], "origin": row.get("source_origin"), "bundle_file": row.get("bundle_file")}
    for rel in (".lab-output/sku-final-literal-family-proofs-40-20261013-v1/manifest.json", ".lab-output/sku-final-literal-family-proofs-20261013-v1/manifest.json"):
        path = ROOT / rel
        if path.is_file():
            data = json.loads(path.read_text())
            for raw_path, receipt in data.get("used_raw_source_receipts", {}).items():
                old = raw_expected.get(raw_path, {})
                raw_expected[raw_path] = {**old, "sha256": receipt.get("sha256"), "origin": "proof_manifest:" + rel}
    for raw_rel, pin in sorted(raw_expected.items()):
        indexed = source_index.get(raw_rel, {})
        expected_sha = pin.get("sha256") or indexed.get("sha256")
        expected_bytes = pin.get("bytes", indexed.get("bytes"))
        source_path = ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source" / raw_rel
        if not source_path.is_file() or not expected_sha:
            missing.append(f"raw-source-unavailable:{raw_rel}")
            continue
        resolved = source_path.resolve()
        actual_bytes = resolved.stat().st_size
        actual_sha = digest(resolved)
        if (expected_bytes is not None and actual_bytes != expected_bytes) or actual_sha != expected_sha:
            missing.append(f"raw-source-pin-mismatch:{raw_rel}")
            continue
        files[raw_rel] = resolved
    (BUILD / "raw-source-pins.json").write_text(json.dumps({
        "schema_version": "final-test-checkpoint-raw-capture-pins-v1",
        "entries": [{"path": rel, "bytes": (ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source" / rel).resolve().stat().st_size,
                     "sha256": pin.get("sha256") or source_index.get(rel, {}).get("sha256"),
                     "origin": source_index.get(rel, {}).get("archive_origins", []),
                     "receipt_origin": pin.get("origin"),
                     "bundle_file": pin.get("bundle_file")} for rel, pin in sorted(raw_expected.items())
                    if (ROOT / ".lab-output/sku-full-evaluation-prepare-20261013-v1/source" / rel).is_file() and rel in files],
    }, indent=2, sort_keys=True) + "\n")
    return [(p, arc) for arc, p in sorted(files.items())], missing


def verify_assembly_receipts() -> tuple[bool, list[str]]:
    problems = []
    freeze_path = ROOT / ".lab-output/sku-final-test-execution-20261013-v1/experiment-freeze.json"
    paths = [
        ROOT / ".lab-output/sku-final-test-execution-20261013-v1/assembly-only-reconciliation.json",
        ROOT / ".lab-output/sku-final-test-execution-20261013-v1/assembly-only-reconciliation-v2.json",
    ]
    if not freeze_path.is_file() or any(not p.is_file() for p in paths):
        return False, [f"missing-assembly-reconciliation:{p}" for p in [freeze_path, *paths] if not p.is_file()]
    freeze = json.loads(freeze_path.read_text())
    freeze_sha = digest(freeze_path)
    original_runner = ROOT / "experiments/sku-matching/evaluate_final_full_sku_gate_v1.py"
    frozen_runner_sha = freeze.get("source_snapshot", {}).get(str(original_runner.resolve()), {}).get("sha256")
    if not frozen_runner_sha or digest(original_runner) != frozen_runner_sha:
        problems.append("root-frozen-gate-runner-pin-mismatch")
    first, second = (json.loads(p.read_text()) for p in paths)
    if first.get("root_inference_freeze_sha256") != freeze_sha or first.get("original_frozen_files_preserved") is not True:
        problems.append("first-reconciliation-root-freeze-mismatch")
    if first.get("original_gate_runner_sha256") != frozen_runner_sha or first.get("assembly_adapter_sha256") != digest(paths[0].parent / "assemble.py"):
        problems.append("first-reconciliation-code-pin-mismatch")
    if first.get("policy_or_threshold_changed") is not False or first.get("classifier_answers_changed") is not False or first.get("new_model_inference") is not False or first.get("test_labels_read") is not False:
        problems.append("first-reconciliation-scope-flags-mismatch")
    second_adapter = digest(paths[0].parent / "resume_assembly.py")
    if second.get("original_root_freeze_sha256") != freeze_sha or second.get("original_gate_runner_sha256") != frozen_runner_sha or second.get("original_gate_runner_preserved") is not True:
        problems.append("second-reconciliation-root-freeze-mismatch")
    if second.get("assembly_adapter_sha256") != second_adapter or second.get("selection_membership_alias_adapter_sha256") != digest(paths[0].parent / "assemble.py"):
        problems.append("second-reconciliation-code-pin-mismatch")
    if second.get("policy_or_threshold_changed") is not False or second.get("classifier_answers_changed") is not False or second.get("new_model_inference") is not False or second.get("test_labels_read") is not False:
        problems.append("second-reconciliation-scope-flags-mismatch")
    prepared = ROOT / ".lab-output/sku-final-composition-subset-20261013-v1/gate-prepared-assembly-v3"
    manifest_path = prepared / "manifest.json"
    if not manifest_path.is_file():
        problems.append("missing-assembly-prepared-manifest")
    else:
        manifest = json.loads(manifest_path.read_text())
        original_manifest_path = ROOT / ".lab-output/sku-final-composition-subset-20261013-v1/gate-prepared-v2/manifest.json"
        original_manifest = json.loads(original_manifest_path.read_text()) if original_manifest_path.is_file() else {}
        if not original_manifest or second.get("original_prepared_manifest_sha256") != digest(original_manifest_path):
            problems.append("original-prepared-manifest-pin-mismatch")
        if second.get("new_prepared_manifest_sha256") != digest(manifest_path):
            problems.append("assembly-prepared-manifest-pin-mismatch")
        if manifest.get("baseline_matched_count") != 0 or manifest.get("assembly_metadata_only") is not True:
            problems.append("assembly-added-summary-field-mismatch")
        for rel, expected in manifest.get("output_sha256", {}).items():
            path = prepared / rel
            if not path.is_file() or digest(path) != expected:
                problems.append(f"assembly-prepared-output-pin-mismatch:{rel}")
            if original_manifest and original_manifest.get("output_sha256", {}).get(rel) != expected:
                problems.append(f"assembly-data-not-identical-to-original:{rel}")
    return not problems, problems


def verify_gate_receipts(gate_path: Path) -> tuple[bool, list[str]]:
    problems = []
    execution_path = gate_path.parent / "execution-freeze.json"
    original_grade_path = gate_path.parent / "grade-freeze-receipt.json"
    grade_path = gate_path.parent / "grade-freeze-receipt-parser-v2.json"
    if not gate_path.is_file() or not execution_path.is_file() or not original_grade_path.is_file() or not grade_path.is_file():
        return False, [f"missing-final-freeze-receipt:{p}" for p in (gate_path, execution_path, original_grade_path, grade_path) if not p.is_file()]
    gate, execution, grade = (json.loads(p.read_text()) for p in (gate_path, execution_path, grade_path))
    membership = "212123b8851168a8895e8a035f8a1a032c173c496b76024b707030efca93778d"
    expected_variants = {"baseline-literal-overlay", "complete-scoped-fallback"}
    for name, obj in (("all-gates", gate), ("execution-freeze", execution)):
        if obj.get("schema_version") != "final-full-sku-gates-frozen-v1" or obj.get("membership_sha256") != membership:
            problems.append(f"{name}-schema-or-membership-mismatch")
        if obj.get("all_predictions_frozen") is not True or obj.get("all_gates_frozen") is not True:
            problems.append(f"{name}-not-fully-frozen")
        if obj.get("labels_read") is not False or obj.get("test_gold_opened") is not False:
            problems.append(f"{name}-label-state-not-blind")
        if set(obj.get("variants", [])) != expected_variants:
            problems.append(f"{name}-variant-set-mismatch")
        for rel, expected in obj.get("output_sha256", {}).items():
            path = gate_path.parent / rel
            if not path.is_file() or digest(path) != expected:
                problems.append(f"{name}-output-pin-mismatch:{rel}")
        for raw_path, pin in obj.get("source_snapshot", {}).items():
            path = Path(raw_path)
            if not path.is_file() or path.stat().st_size != pin.get("bytes") or digest(path) != pin.get("sha256"):
                problems.append(f"{name}-source-pin-mismatch:{raw_path}")
    if execution.get("all_gates_frozen_manifest_sha256") != digest(gate_path):
        problems.append("execution-freeze-does-not-bind-all-gates-receipt")
    if grade.get("independent_test") is not True or grade.get("membership_sha256") != membership:
        problems.append("supplemental-grade-receipt-independent-test-binding-mismatch")
    if grade.get("all_predictions_frozen") is not True or grade.get("all_gates_frozen") is not True:
        problems.append("supplemental-grade-receipt-not-fully-frozen")
    if grade.get("labels_read") is not False or grade.get("test_gold_opened") is not False:
        problems.append("supplemental-grade-receipt-label-state-not-blind")
    if grade.get("all_gates_frozen_manifest_sha256", digest(gate_path)) != digest(gate_path):
        problems.append("supplemental-grade-receipt-gate-hash-mismatch")
    repair = grade.get("parser_repair_record", {})
    original_grade = json.loads(original_grade_path.read_text())
    prior_script = ROOT / ".lab-output/sku-final-test-checkpoint-build-20261013-v1/grader-history/grade_final_test_subset_v1.failed-envelope-parser.py"
    prior_log = ROOT / ".lab-output/sku-final-test-checkpoint-build-20261013-v1/grader-history/grading-failed-envelope-parser.log"
    grader_script = ROOT / "experiments/sku-matching/grade_final_test_subset_v1.py"
    parser_helper = ROOT / "experiments/sku-matching/route_mixed_sku_references_v1.py"
    grader_tests = ROOT / "tests/test_lab_final_test_subset_grader.py"
    if (grade.get("grader_code_sha256") != digest(grader_script)
            or grade.get("reference_parser_helper_sha256") != digest(parser_helper)
            or grade.get("parser_repair_test_sha256") != digest(grader_tests)):
        problems.append("grader-or-reference-parser-code-pin-mismatch")
    if repair.get("previous_grader_sha256") != original_grade.get("grader_code_sha256"):
        problems.append("grader-repair-does-not-preserve-original-grader-pin")
    if (not prior_script.is_file() or digest(prior_script) != repair.get("preserved_failed_grader_sha256")
            or not prior_log.is_file() or digest(prior_log) != repair.get("preserved_failed_log_sha256")):
        problems.append("failed-grader-history-copy-or-log-pin-mismatch")
    if repair.get("answer_envelope_schema") != {"fields": ["au_rows", "data_quality_flag", "expected", "rationale", "s"], "case_id_field_present": False}:
        problems.append("grader-repair-envelope-schema-mismatch")
    if (repair.get("classifier_artifacts_or_gate_results_changed") is not False
            or not isinstance(repair.get("scoring_rerun_authorized"), bool)):
        problems.append("grader-repair-scope-or-run-status-mismatch")
    return not problems, problems


def verify_scoring_completion_receipt(receipt_path: Path) -> tuple[bool, list[str]]:
    """Bind the authorized post-freeze score, selected rows, code and log."""
    problems: list[str] = []
    score_path = BUILD / "reference-score.json"
    refs_path = BUILD / "references.jsonl"
    parser_receipt = receipt_path.parent / "grade-freeze-receipt-parser-v2.json"
    grader = ROOT / "experiments/sku-matching/grade_final_test_subset_v1.py"
    helper = ROOT / "experiments/sku-matching/route_mixed_sku_references_v1.py"
    success_log = ROOT / ".lab-output/sku-final-test-execution-20261013-v1/grading-parser-v2.log"
    if not receipt_path.is_file():
        return False, [f"missing-scoring-completion-receipt:{receipt_path}"]
    receipt = json.loads(receipt_path.read_text())
    expected_schema = "sku-final-score-go-completion-v1"
    if receipt.get("schema_version") != expected_schema:
        problems.append("scoring-completion-schema-mismatch")
    for key in ("root_go", "scoring_completed", "all_predictions_and_gates_frozen_before_labels"):
        if receipt.get(key) is not True:
            problems.append(f"scoring-completion-{key}-not-true")
    if receipt.get("scorer_exit_code") != 0 or receipt.get("selected_reference_rows") != 40:
        problems.append("scoring-completion-exit-or-row-count-mismatch")
    if receipt.get("membership_sha256") != "212123b8851168a8895e8a035f8a1a032c173c496b76024b707030efca93778d":
        problems.append("scoring-completion-membership-mismatch")
    if receipt.get("reference_kind") != "claude-haiku-5-5 machine annotation; not human gold":
        problems.append("scoring-completion-reference-kind-mismatch")
    if receipt.get("parser_v2_receipt_authorization_false_is_historical") is not True:
        problems.append("scoring-completion-historical-parser-receipt-context-missing")
    if receipt.get("prediction_policy_or_responses_changed") is not False or receipt.get("gold_or_resolved_row_keys_rewritten") is not False:
        problems.append("scoring-completion-change-scope-assertion-mismatch")

    pins = receipt.get("frozen_files")
    expected_files = {
        ".lab-output/sku-final-composition-subset-20261013-v1/evaluation-v2/grade-freeze-receipt-parser-v2.json": parser_receipt,
        ".lab-output/sku-final-test-checkpoint-build-20261013-v1/reference-score.json": score_path,
        ".lab-output/sku-final-test-checkpoint-build-20261013-v1/references.jsonl": refs_path,
        "experiments/sku-matching/grade_final_test_subset_v1.py": grader,
        "experiments/sku-matching/route_mixed_sku_references_v1.py": helper,
        ".lab-output/sku-final-test-execution-20261013-v1/grading-parser-v2.log": success_log,
    }
    if not isinstance(pins, dict) or set(pins) != set(expected_files):
        problems.append("scoring-completion-frozen-file-set-mismatch")
    else:
        for rel, path in expected_files.items():
            pin = pins[rel]
            if not path.is_file() or path.is_symlink():
                problems.append(f"scoring-completion-file-missing-or-unsafe:{rel}")
                continue
            if pin.get("bytes") != path.stat().st_size or pin.get("sha256") != digest(path):
                problems.append(f"scoring-completion-file-pin-mismatch:{rel}")

    if score_path.is_file():
        score = json.loads(score_path.read_text())
        names = {"baseline-literal-overlay", "complete-scoped-fallback"}
        if score.get("schema_version") != "final-sku-subset-integrate-score-v1" or score.get("phase") != "score":
            problems.append("score-schema-or-phase-mismatch")
        if score.get("test_total_case_count") != 40 or score.get("independent_test") is not True:
            problems.append("score-test-scope-mismatch")
        if score.get("reference_kind") != receipt.get("reference_kind") or score.get("membership_sha256") != receipt.get("membership_sha256"):
            problems.append("score-receipt-source-or-membership-mismatch")
        variants = score.get("variants", {})
        receipt_variants = receipt.get("variants", {})
        if set(variants) != names or set(receipt_variants) != names:
            problems.append("score-variant-set-mismatch")
        else:
            expected_metrics = {"tp": 16, "fp": 0, "fn": 19, "tn": 3, "scored_case_count": 38}
            variant_names = sorted(names)
            for name in variant_names:
                scored, frozen = variants[name], receipt_variants[name]
                for source, label in ((scored, "score"), (frozen, "receipt")):
                    if source.get("total_case_count") != 40 or source.get("known_reference_case_count") != 38 or source.get("unknown_reference_count") != 2:
                        problems.append(f"{label}-case-count-invariant-mismatch:{name}")
                    metrics = source.get("metrics", {})
                    if any(metrics.get(k) != v for k, v in expected_metrics.items()):
                        problems.append(f"{label}-binary-metrics-invariant-mismatch:{name}")
                    if source.get("row_metrics", {}).get("correct_accepted_row") != 16 or source.get("exact_accepted_row_key_validation") is not True:
                        problems.append(f"{label}-accepted-row-invariant-mismatch:{name}")
                    coverage = source.get("exact_membership_coverage", {})
                    if coverage != {"expected": 40, "predictions": 40, "scored_or_explicitly_unknown": 40, "case_omission_count": 0}:
                        problems.append(f"{label}-membership-coverage-invariant-mismatch:{name}")
                if scored.get("metrics") != frozen.get("metrics") or scored.get("row_metrics") != frozen.get("row_metrics") or scored.get("exact_membership_coverage") != frozen.get("exact_membership_coverage"):
                    problems.append(f"score-and-receipt-metrics-differ:{name}")
            first, second = (variants[name] for name in variant_names)
            if (first.get("metrics") != second.get("metrics")
                    or first.get("row_metrics") != second.get("row_metrics")
                    or first.get("exact_membership_coverage") != second.get("exact_membership_coverage")):
                problems.append("variant-score-results-differ")
    else:
        problems.append("selected-reference-score-missing")
    if refs_path.is_file():
        rows = [json.loads(line) for line in refs_path.read_text().splitlines() if line.strip()]
        ids = [row.get("case_id") for row in rows]
        if len(rows) != 40 or any(not isinstance(cid, str) or not cid for cid in ids) or len(set(ids)) != 40:
            problems.append("selected-reference-row-count-or-case-uniqueness-mismatch")
    else:
        problems.append("selected-reference-rows-missing")
    return not problems, problems


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", action="store_true", help="build only after frozen gates and final report exist")
    ap.add_argument("--root-go", action="store_true", help="explicit root authorization after review; required to build")
    args = ap.parse_args()
    files, missing = gather()
    payload_bytes = sum(p.stat().st_size for p, _ in files)
    deps = []
    for dep in EXTERNAL:
        path = ROOT / dep["path"]
        record = dict(dep, present=path.is_file())
        if path.is_file():
            record.update(bytes=path.stat().st_size, actual_sha256=digest(path), sha256_matches=digest(path) == dep["sha256"])
        deps.append(record)
    receipt = ROOT / ".lab-output/sku-final-composition-subset-20261013-v1/evaluation-v2/all-gates-frozen.json"
    reconciled, reconciliation_problems = verify_assembly_receipts()
    gates_valid, gate_problems = verify_gate_receipts(receipt)
    score_receipt = receipt.parent / "scoring-go-and-completion-receipt.json"
    scoring_valid, scoring_problems = verify_scoring_completion_receipt(score_receipt)
    report = ROOT / "experiments/sku-matching/final-blind-sku-test-result-20261013.txt"
    preflight = {
        "schema_version": "sku-final-test-checkpoint-preflight-v1",
        "full_answer_archive_contents_opened_by_builder": False,
        "selected_reference_rows_present": (ROOT / ".lab-output/sku-final-test-checkpoint-build-20261013-v1/references.jsonl").is_file(),
        "selected_file_count": len(files),
        "selected_payload_bytes_uncompressed": payload_bytes,
        "selected_payload_megabytes_decimal": round(payload_bytes / 1_000_000, 3),
        "missing_expected_files": missing,
        "all_gates_frozen_present": receipt.is_file(),
        "grade_freeze_receipt_present": (receipt.parent / "grade-freeze-receipt-parser-v2.json").is_file(),
        "assembly_reconciliations_verified": reconciled,
        "assembly_reconciliation_problems": reconciliation_problems,
        "final_gate_receipts_verified": gates_valid,
        "final_gate_receipt_problems": gate_problems,
        "scoring_completion_receipt_verified": scoring_valid,
        "scoring_completion_receipt_problems": scoring_problems,
        "final_report_present": report.is_file(),
        "external_dependencies": deps,
        "excluded": "answer/gold/label files, answer archives themselves, model weights, secrets, .env and .deps",
        "build_ready": not missing and reconciled and gates_valid and scoring_valid and receipt.is_file() and (receipt.parent / "grade-freeze-receipt-parser-v2.json").is_file() and report.is_file() and all(d.get("sha256_matches", False) for d in deps),
    }
    BUILD.mkdir(parents=True, exist_ok=True)
    (BUILD / "preflight.json").write_text(json.dumps(preflight, indent=2, sort_keys=True) + "\n")
    print(json.dumps(preflight, indent=2, sort_keys=True))
    if not args.build:
        return 0
    if not args.root_go:
        raise SystemExit("refusing build: pass --root-go only after root review/authorization")
    if not preflight["build_ready"]:
        raise SystemExit("refusing build: missing gates/report/artifacts or dependency SHA mismatch")
    manifest_path = OUT.with_suffix(OUT.suffix + ".manifest.json")
    if OUT.exists() or manifest_path.exists() or SHA_PATH.exists():
        raise SystemExit(f"refusing overwrite: archive or sidecar already exists: {OUT} / {manifest_path} / {SHA_PATH}")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    members = []
    tmp_archive = OUT.with_name(OUT.name + f".partial-{os.getpid()}")
    tmp_manifest = manifest_path.with_name(manifest_path.name + f".partial-{os.getpid()}")
    tmp_sha = SHA_PATH.with_name(SHA_PATH.name + f".partial-{os.getpid()}")
    try:
        with zipfile.ZipFile(tmp_archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for path, arc in files:
                if not safe(arc):
                    raise RuntimeError(f"unsafe payload path: {arc}")
                zf.write(path, arc)
                members.append({"path": arc, "bytes": path.stat().st_size, "sha256": digest(path)})
            if len({m["path"] for m in members}) != len(members):
                raise RuntimeError("duplicate payload member path")
            embedded = {**preflight, "members": members, "external_dependencies": deps, "archive_path": OUT.name}
            zf.writestr("CHECKPOINT_MANIFEST.json", json.dumps(embedded, indent=2, sort_keys=True) + "\n")
        with zipfile.ZipFile(tmp_archive) as zf:
            if zf.testzip() is not None:
                raise RuntimeError("ZIP CRC failure")
            names = set(zf.namelist())
            expected = {m["path"] for m in members} | {"CHECKPOINT_MANIFEST.json"}
            if names != expected:
                raise RuntimeError(f"ZIP member set mismatch: missing={expected - names}, extra={names - expected}")
            for m in members:
                info = zf.getinfo(m["path"])
                data = zf.read(m["path"])
                if info.file_size != m["bytes"] or hashlib.sha256(data).hexdigest() != m["sha256"]:
                    raise RuntimeError(f"payload bytes/SHA mismatch: {m['path']}")
        archive_sha, archive_bytes = digest(tmp_archive), tmp_archive.stat().st_size
        sidecar = {"schema_version": "sku-final-test-checkpoint-archive-manifest-v1", "archive": OUT.name,
                   "archive_bytes": archive_bytes, "archive_sha256": archive_sha,
                   "member_count": len(members) + 1, "payload_member_count": len(members),
                   "crc_verified": True, "all_member_bytes_and_sha256_verified": True,
                   "members": members, "external_dependencies": deps}
        with tmp_manifest.open("x") as f:
            f.write(json.dumps(sidecar, indent=2, sort_keys=True) + "\n")
        with tmp_sha.open("x") as f:
            f.write(f"{archive_sha}  {OUT.name}\n")
        # Promotion uses create-if-absent hard links; on any partial failure,
        # remove only outputs created by this process and leave existing files intact.
        promoted = []
        try:
            os.link(tmp_archive, OUT)
            promoted.append(OUT)
            os.link(tmp_manifest, manifest_path)
            promoted.append(manifest_path)
            os.link(tmp_sha, SHA_PATH)
            promoted.append(SHA_PATH)
        except Exception:
            for item in promoted:
                item.unlink(missing_ok=True)
            raise
    finally:
        tmp_archive.unlink(missing_ok=True)
        tmp_manifest.unlink(missing_ok=True)
        tmp_sha.unlink(missing_ok=True)
    print(json.dumps({"archive": str(OUT), "bytes": archive_bytes, "sha256": archive_sha,
                      "sidecar": str(manifest_path), "sha256_file": str(SHA_PATH), "payload_count": len(members),
                      "crc_verified": True, "member_set_verified": True,
                      "all_member_bytes_and_sha256_verified": True}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
