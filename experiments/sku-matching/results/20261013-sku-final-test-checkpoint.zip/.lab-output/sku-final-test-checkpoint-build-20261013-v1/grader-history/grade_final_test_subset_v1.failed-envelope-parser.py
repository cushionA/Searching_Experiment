#!/usr/bin/env python3
"""Score the frozen 40-case final subset after an explicit root GO.

This helper reads machine-reference answer shards only after it verifies that
the selected membership, every prediction variant, and every gate artifact are
bound by an all-predictions/all-gates-frozen receipt. It never changes a model,
threshold, or gate decision.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
EXPECTED_MEMBERSHIP_SHA256 = "212123b8851168a8895e8a035f8a1a032c173c496b76024b707030efca93778d"
EXPECTED_CASE_COUNT = 40
V2_LABEL_ARCHIVE = ".lab-output/sku-claude-additional-review-20261012-v1/20261011-sku-independent-real-eval-v2.zip"
V3_LABEL_ARCHIVE = ".lab-output/sku-claude-additional-review-20261012-v1/20261012-sku-independent-real-eval-v3.zip"
V2_LABEL_PREFIX = ".lab-output/sku-independent-real-20261011/eval-v2/labels-token/"
V3_LABEL_PREFIX = ".lab-output/sku-independent-real-20261011/eval-v3/labels-token/"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def read_jsonl_bytes(data: bytes, where: str) -> list[dict[str, Any]]:
    values = []
    for number, line in enumerate(data.decode("utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{where}:{number}: expected JSON object")
        values.append(value)
    return values


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return read_jsonl_bytes(path.read_bytes(), str(path))


def unique_index(rows: list[dict[str, Any]], key: str, where: str) -> dict[str, dict[str, Any]]:
    result = {}
    for row in rows:
        value = row.get(key)
        if not isinstance(value, str) or not value:
            raise ValueError(f"missing string {key} in {where}")
        if value in result:
            raise ValueError(f"duplicate {key} in {where}: {value}")
        result[value] = row
    return result


def validate_freeze_receipt(
    receipt_path: Path,
    membership_path: Path,
    prediction_paths: dict[str, Path],
    gate_paths: list[Path],
) -> dict[str, Any]:
    """Validate the freeze contract before any label archive is opened.

    Receipt contract: `freeze_status` is `all_predictions_and_gates_frozen`,
    `independent_test` is true, `membership_sha256` binds the 40-case subset,
    and `frozen_files` maps repo-relative artifact paths to SHA-256.
    """
    receipt = read_json(receipt_path)
    expected_status = receipt.get("freeze_status") == "all_predictions_and_gates_frozen"
    frozen_schema = receipt.get("schema_version") == "final-full-sku-gates-frozen-v1"
    if not expected_status and not frozen_schema:
        raise ValueError("freeze receipt must confirm all predictions and gates are frozen")
    if receipt.get("all_predictions_frozen") is not True or receipt.get("all_gates_frozen") is not True:
        raise ValueError("freeze receipt lacks both frozen-state assertions")
    if receipt.get("independent_test") is not True:
        raise ValueError("freeze receipt must identify the run as independent_test")
    if receipt.get("membership_sha256") != EXPECTED_MEMBERSHIP_SHA256:
        raise ValueError("freeze receipt membership SHA does not match the predeclared 40-case subset")
    if sha(membership_path.read_bytes()) != EXPECTED_MEMBERSHIP_SHA256:
        raise ValueError("40-case membership source SHA mismatch")
    pins = receipt.get("frozen_files", receipt.get("output_sha256"))
    if not isinstance(pins, dict) or not pins:
        raise ValueError("freeze receipt frozen_files/output_sha256 map is missing")
    # The final gate runner emits output_sha256 relative to the run directory and
    # a source_snapshot of frozen inputs/code; validate the whole receipt map.
    if "output_sha256" in receipt:
        for rel, expected in receipt["output_sha256"].items():
            path = receipt_path.parent / Path(rel)
            if not path.is_file() or path.is_symlink() or sha(path.read_bytes()) != expected:
                raise ValueError(f"frozen gate output SHA mismatch: {rel}")
    source_snapshot = receipt.get("source_snapshot", {})
    if not isinstance(source_snapshot, dict):
        raise ValueError("freeze receipt source_snapshot must be a mapping")
    source_code_pins = {}
    for recorded, row in source_snapshot.items():
        if not str(recorded).endswith(".py"):
            continue
        path = Path(recorded)
        if not path.is_absolute():
            path = ROOT / path
        expected = row.get("sha256") if isinstance(row, dict) else None
        if not path.is_file() or path.is_symlink() or not expected or sha(path.read_bytes()) != expected:
            raise ValueError(f"frozen source code pin mismatch: {recorded}")
        source_code_pins[str(path.resolve())] = expected
    # The production final-gate runner writes execution-freeze.json as a second
    # receipt binding all-gates-frozen.json by its complete byte hash.
    execution_receipt = receipt_path.parent / "execution-freeze.json"
    all_gates_receipt = receipt_path.parent / "all-gates-frozen.json"
    if execution_receipt.is_file() and all_gates_receipt.is_file():
        execution = read_json(execution_receipt)
        if execution.get("all_gates_frozen_manifest_sha256") != sha(all_gates_receipt.read_bytes()):
            raise ValueError("execution freeze does not bind all-gates-frozen.json")
    elif receipt_path.name == "execution-freeze.json":
        raise FileNotFoundError("execution freeze requires sibling all-gates-frozen.json")
    required = list(prediction_paths.values()) + gate_paths
    resolved = {}
    for path in required:
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"frozen prediction/gate artifact missing or unsafe: {path}")
        try:
            rel = path.resolve().relative_to(ROOT).as_posix()
        except ValueError as exc:
            raise ValueError(f"frozen artifact is outside repository: {path}") from exc
        receipt_rel = path.resolve().relative_to(receipt_path.parent.resolve()).as_posix() if path.resolve().is_relative_to(receipt_path.parent.resolve()) else None
        expected = pins.get(receipt_rel) if receipt_rel else None
        if expected is None:
            expected = pins.get(rel)
        actual = sha(path.read_bytes())
        if expected != actual:
            raise ValueError(f"artifact absent from freeze receipt or SHA mismatch: {rel}")
        resolved[rel] = actual
    declared_variants = receipt.get("variants")
    if declared_variants is not None and set(declared_variants) != set(prediction_paths):
        raise ValueError("variant names differ from the frozen gate receipt")
    return {"receipt_sha256": sha(receipt_path.read_bytes()), "frozen_artifacts": resolved,
            "source_code_pins": source_code_pins,
            "membership_sha256": EXPECTED_MEMBERSHIP_SHA256}


def load_token_reference_shards(
    archive_v2: Path,
    archive_v3: Path,
    prefixes: dict[str, str] | None = None,
) -> dict[str, dict[str, Any]]:
    """Load token answer JSONL shards; caller must already pass freeze guard."""
    prefixes = prefixes or {"v2": V2_LABEL_PREFIX, "v3": V3_LABEL_PREFIX}
    result: dict[str, dict[str, Any]] = {}
    for split, archive in (("v2", archive_v2), ("v3", archive_v3)):
        prefix = prefixes[split]
        with zipfile.ZipFile(archive) as source:
            members = sorted(info.filename for info in source.infolist()
                             if info.filename.startswith(prefix)
                             and Path(info.filename).name.startswith("answers-")
                             and info.filename.endswith(".jsonl"))
            if not members:
                raise FileNotFoundError(f"no frozen answer shards under {prefix}")
            for member in members:
                for row in read_jsonl_bytes(source.read(member), f"{archive}:{member}"):
                    case_id = row.get("case_id")
                    if not isinstance(case_id, str) or not case_id:
                        raise ValueError(f"answer shard row lacks case_id: {member}")
                    if case_id in result:
                        raise ValueError(f"duplicate reference case_id across answer shards: {case_id}")
                    result[case_id] = {**row, "_reference_split": split, "_reference_member": member}
    return result


def canonical_decision(row: dict[str, Any]) -> tuple[str, str | None]:
    raw = row.get("decision", row.get("gate_decision", row.get("strict_gate_decision")))
    mapped = {
        "accept": "matched", "matched": "matched",
        "drop": "unmatched", "unmatched": "unmatched",
        "review": "review", "unknown": "unknown", "error": "unknown",
    }.get(raw)
    if mapped is None:
        raise ValueError(f"unsupported prediction decision: {raw!r}")
    row_key = None
    for key in ("top_row_key", "au_row_key", "matched_au_row_key", "selected_row_key"):
        value = row.get(key)
        if value is not None:
            if not isinstance(value, str):
                raise ValueError(f"prediction {key} must be string or null")
            row_key = value
            break
    if mapped != "matched" and row_key is not None:
        raise ValueError("non-matched prediction must not carry a selected AU row key")
    return mapped, row_key


def canonical_reference(row: dict[str, Any]) -> tuple[str | None, list[str] | None]:
    if "label" in row and "decision" in row and row["label"] != row["decision"]:
        raise ValueError("reference label/decision aliases conflict")
    label = row.get("label", row.get("decision", row.get("semantic_label")))
    if label not in {"matched", "unmatched", "review", "needs_review", "unknown", None}:
        raise ValueError(f"unsupported reference label: {label!r}")
    row_values = [row.get(key) for key in ("matched_au_row_keys", "matching_au_row_keys", "gold_row_keys") if key in row]
    if row_values and any(value != row_values[0] for value in row_values[1:]):
        raise ValueError("reference row-key aliases conflict")
    keys = row_values[0] if row_values else None
    if keys is not None and (not isinstance(keys, list) or any(not isinstance(value, str) or not value for value in keys)):
        raise ValueError("reference AU row keys must be an array of nonempty strings")
    if label == "matched" and keys is not None and not keys:
        raise ValueError("matched reference with a supplied row-key list must have at least one row key")
    return label, keys


def score_variant(
    membership: list[dict[str, Any]],
    predictions: list[dict[str, Any]],
    references: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    members = unique_index(membership, "case_id", "membership")
    predicted = unique_index(predictions, "case_id", "predictions")
    if set(predicted) != set(members):
        missing = sorted(set(members) - set(predicted))
        extra = sorted(set(predicted) - set(members))
        raise ValueError(f"prediction coverage must exactly match frozen membership; missing={missing[:3]} extra={extra[:3]}")

    counts: Counter[str] = Counter()
    split_counts: dict[str, Counter[str]] = defaultdict(Counter)
    row_counts: Counter[str] = Counter()
    unknown_cases, differences, scored = [], [], []
    for case_id, member in members.items():
        prediction = predicted[case_id]
        decision, row_key = canonical_decision(prediction)
        reference = references.get(case_id)
        split = member.get("split", member.get("cohort", member.get("source_version", "unknown_split")))
        if reference is None:
            unknown_cases.append({"case_id": case_id, "split": split, "reason": "missing_reference"})
            continue
        label, expected_rows = canonical_reference(reference)
        expected_split = {"independent_real_eval_v2": "v2", "independent_real_eval_v3": "v3"}.get(split, split)
        if reference.get("_reference_split") not in {None, split, expected_split}:
            raise ValueError(f"reference split differs from frozen membership: {case_id}")
        if label not in {"matched", "unmatched"}:
            unknown_cases.append({"case_id": case_id, "split": split, "reason": "unresolved_reference"})
            continue
        accepted, matched = decision == "matched", label == "matched"
        cell = "tp" if accepted and matched else "fp" if accepted else "fn" if matched else "tn"
        counts[cell] += 1
        split_counts[str(split)][cell] += 1
        wrong_row = False
        if accepted and matched:
            if expected_rows is None:
                row_counts["accepted_matched_row_unscored"] += 1
            elif row_key in expected_rows:
                row_counts["correct_accepted_row"] += 1
            else:
                row_counts["wrong_accepted_row"] += 1
                wrong_row = True
        if cell in {"fp", "fn"} or wrong_row:
            differences.append({"case_id": case_id, "split": split, "label": label,
                                "prediction": decision, "predicted_row_key": row_key,
                                "reference_row_keys": expected_rows,
                                "difference": "wrong_accepted_row" if wrong_row else cell})
        scored.append(case_id)

    def metric(counter: Counter[str]) -> dict[str, Any]:
        cells = {key: counter[key] for key in ("tp", "fp", "fn", "tn")}
        known = sum(cells.values())
        return {**cells, "scored_case_count": known,
                "binary_accuracy": (cells["tp"] + cells["tn"]) / known if known else None,
                "precision": cells["tp"] / (cells["tp"] + cells["fp"]) if cells["tp"] + cells["fp"] else None,
                "recall": cells["tp"] / (cells["tp"] + cells["fn"]) if cells["tp"] + cells["fn"] else None}

    total = len(members)
    # Keep the existing INTEGRATE.score metrics layout while making the full
    # 40-case and unknown-reference denominators explicit.
    return {
        "schema_version": "claude-description-integration-v1",
        "phase": "score",
        "reference_kind": "claude-haiku-5-5 machine annotation; not human gold",
        "decisions_changed": False,
        "thresholds_selected": False,
        "production_adoption_allowed": False,
        "total_case_count": total,
        "known_reference_case_count": len(scored),
        "unknown_reference_count": len(unknown_cases),
        "unknown_reference_case_ids": [row["case_id"] for row in unknown_cases],
        "metrics": metric(counts),
        "cohort_metrics": {name: metric(value) for name, value in sorted(split_counts.items())},
        "row_metrics": dict(row_counts),
        "exact_membership_coverage": {"expected": total, "predictions": len(predicted),
                                      "scored_or_explicitly_unknown": len(scored) + len(unknown_cases),
                                      "case_omission_count": total - len(predicted)},
        "exact_accepted_row_key_validation": True,
        "excluded": unknown_cases,
        "differences": differences,
        "references_outside_received_decisions": len(set(references) - set(members)),
        "whole_sku_correctness_established": False,
    }


def score_all_variants(
    membership: list[dict[str, Any]],
    variant_predictions: dict[str, list[dict[str, Any]]],
    references: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    if not variant_predictions:
        raise ValueError("at least one prediction variant is required")
    results = {name: score_variant(membership, rows, references)
               for name, rows in sorted(variant_predictions.items())}
    return {"schema_version": "final-sku-subset-integrate-score-v1",
            "phase": "score", "independent_test": True,
            "reference_kind": "claude-haiku-5-5 machine annotation; not human gold",
            "test_total_case_count": len(membership),
            "labels_read_after_predictions_and_gates_frozen": True,
            "predictions_changed": False, "gates_changed": False,
            "thresholds_selected": False, "production_adoption_allowed": False,
            "same_membership_for_all_variants": True,
            "variants": results}


def read_label_archives(archive_v2: Path, archive_v3: Path,
                        expected_case_ids: set[str]) -> dict[str, dict[str, Any]]:
    references = load_token_reference_shards(archive_v2, archive_v3)
    # Keep the parsed in-memory set limited to the predeclared 40 selected ids.
    return {key: references[key] for key in expected_case_ids if key in references}


def grade_from_files(
    *,
    root_go: bool,
    membership_path: Path,
    receipt_path: Path,
    variant_paths: dict[str, Path],
    gate_paths: list[Path],
    archive_v2: Path,
    archive_v3: Path,
) -> dict[str, Any]:
    # These checks intentionally run before opening either reference ZIP.
    if root_go is not True:
        raise PermissionError("grading requires the explicit --root-go authorization")
    receipt_info = validate_freeze_receipt(receipt_path, membership_path, variant_paths, gate_paths)
    membership = read_jsonl(membership_path)
    if len(membership) != EXPECTED_CASE_COUNT:
        raise ValueError(f"frozen membership must contain exactly {EXPECTED_CASE_COUNT} cases")
    members = unique_index(membership, "case_id", "membership")
    expected = set(members)
    variant_rows = {name: read_jsonl(path) for name, path in variant_paths.items()}
    # Only now, after freeze receipt validation and explicit root GO, open labels.
    references = read_label_archives(archive_v2, archive_v3, expected)
    output = score_all_variants(membership, variant_rows, references)
    output["freeze_receipt"] = receipt_info
    output["membership_sha256"] = EXPECTED_MEMBERSHIP_SHA256
    output["variant_input_sha256"] = {name: sha(path.read_bytes()) for name, path in variant_paths.items()}
    output["gate_input_sha256"] = {path.resolve().relative_to(ROOT).as_posix(): sha(path.read_bytes()) for path in gate_paths}
    output["label_archive_sha256"] = {"v2": sha(archive_v2.read_bytes()), "v3": sha(archive_v3.read_bytes())}
    return output


def parse_variant(value: str) -> tuple[str, Path]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("variant must be NAME=PATH")
    name, raw_path = value.split("=", 1)
    if not name or not raw_path:
        raise argparse.ArgumentTypeError("variant must be NAME=PATH")
    return name, Path(raw_path)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-go", action="store_true", help="required explicit root authorization after freeze")
    parser.add_argument("--membership", type=Path, default=ROOT / ".lab-output/sku-final-composition-subset-20261013-v1/plan/subset-membership.jsonl")
    parser.add_argument("--freeze-receipt", type=Path, required=True)
    parser.add_argument("--variant", action="append", type=parse_variant, required=True)
    parser.add_argument("--gate-file", action="append", type=Path, required=True)
    parser.add_argument("--v2-label-archive", type=Path, default=ROOT / V2_LABEL_ARCHIVE)
    parser.add_argument("--v3-label-archive", type=Path, default=ROOT / V3_LABEL_ARCHIVE)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    variant_paths = dict(args.variant)
    if len(variant_paths) != len(args.variant):
        raise ValueError("variant names must be unique")
    result = grade_from_files(root_go=args.root_go, membership_path=args.membership,
                              receipt_path=args.freeze_receipt, variant_paths=variant_paths,
                              gate_paths=args.gate_file, archive_v2=args.v2_label_archive,
                              archive_v3=args.v3_label_archive)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("xb") as stream:
        stream.write((json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode())
    print(json.dumps({"output": str(args.output), "test_total_case_count": result["test_total_case_count"],
                      "variant_count": len(result["variants"]), "label_archives_read": True}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
