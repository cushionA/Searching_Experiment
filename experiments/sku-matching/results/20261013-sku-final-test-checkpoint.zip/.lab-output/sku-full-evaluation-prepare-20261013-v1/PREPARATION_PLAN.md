# Full SKU evaluation preparation plan

## Readiness state

The frozen v2/v3 source inputs are verified and materialized for preparation. This is a provenance and population audit only. No independent-test labels, case text, or model predictions were read; no inference, classification, or scoring was performed.

The executable source-only adapter is `prepare_full_sku_evaluation_v1.py`. It checks the input ZIP, external manifest and SHA sidecar before reading any archive member; checks the v2/v3 source archive pins; joins the frozen group map to determine dev/test membership; verifies referenced source-file hashes and literal source spans; and copies only the frozen cases, products, failures, manifests, group map, AU SKU option arrays, and referenced source files into `source/`. It refuses to overwrite an existing source bundle. Its stdout contains only schema/status, aggregate counts, and blocker names. The recorded run is in `inventory.json` and `source-index.json`.

## Full row-task adapter status

A split-aware paired-input adapter is now materialized in `.lab-output/sku-full-condition-adapter-20261013-v2/`, with source code at `experiments/sku-matching/prepare_full_condition_inputs_v2.py`. It creates independent dev/test scopes, verifies all 55,609 frozen source spans, retains all AU rows regardless of stock state, and pairs every original Rakuten axis with every complete AU row plus every AU row axis with the full selected Rakuten axes. It does not use v7 development decisions or old 83-case predictions.

For test, this yields 135,198 task bindings, 24,913 request bindings, and 4,735 exact classifier model-input keys after cache dedup by direction, axis, ordered options, target document SHA, and exact full target axes; desired selected value is excluded from the model-input key. Every original task/request remains separately mapped for fan-out. The analogous dev counts are 132,136 tasks, 30,169 request bindings, and 4,768 model-input keys. Output hashes and task/request/model-input/row coverage joins were checked. The failure table records 202 v2 and 57 v3 attempts separately.

Genuinely one-sided product-global units remain withheld. No verified full-population alignment result establishes which conditions lack an AU counterpart; a missing string-name match is not sufficient evidence. The paired raw-condition inputs are prepared, but the one-sided shared-input branch still needs full-population alignment semantics. Strict core/residual, raw-equality, and typed-proof shortcuts remain disabled.

## Frozen population and coverage

| Input version | Case rows | Dev | Test | Product rows | AU rows | Input failures |
|---|---:|---:|---:|---:|---:|---:|
| v2 | 2,494 | 1,295 | 1,199 | 176 | 2,142 | 202 |
| v3 | 168 | 75 | 93 | 37 | 122 | 57 |
| Total | 2,662 | 1,370 | 1,292 | 213 | 2,264 | 259 |

Case identities use source payload SHA plus SKU/source identifiers; product identities use the source product identity. No duplicate case or product identities were found across these inputs. The cases' own `split` field says `exploration`; the frozen `groups-token/groups.jsonl` mapping is the authoritative split declaration and yields the counts above. Keep the 1,370 dev cases available for development and protocol work. The independent test population is 1,292 successfully prepared input cases; the 259 input failures remain separate coverage-attempt accounting and must not be silently treated as successful cases.

All 213 product records join to their captured AU rows and their AU SKU option source arrays. There are 55,609 verified literal source locators across the case, product, and option-array references. The adapter found no missing referenced capture. The source manifests declare 519 raw capture files; 102 are not referenced by the successful case/product rows (68 v2, 34 v3). These are not counted as coverage and do not block the cases that have complete provenance. The frozen inputs include the full selected Rakuten axes and complete AU row/axis matrices; later task construction must preserve all of them and retain per-row and per-axis source bindings.

## Required row-task adapter

The existing mixed development preparation/evaluation is not a full-data pipeline: it is tied to 83 development cases, fixed 44/31/7/1 strata, development membership and upstream decisions. The full-condition evaluator explicitly records `independent_test=false`. Existing v9 alignment and generic-condition task artifacts may inform the schema, but development decisions or cached predictions cannot establish unseen-test baseline results.

Before any test inference, build a split-aware, baseline-aware row-task adapter over the verified `source/` bundle. It must:

1. Bind each successful case to its complete product row matrix and every selected Rakuten condition axis, with case/product/row/axis IDs and source capture path, SHA, and literal locator provenance.
2. Preserve all AU rows and axes, including unmatched/unresolved rows; do not narrow candidates using labels, old decisions, or the 83-case output. Keep the 259 failed input attempts in a distinct coverage table with failure provenance.
3. Emit complete request/task bindings for both directions and all condition choices needed by the frozen gate. Validate that each source condition and target AU/Rakuten row is represented exactly as specified by the frozen protocol. Keep request identity independent of labels and include source hashes in the binding.
4. Provide separate fresh baseline inference tasks for the fixed JEV/NLI/typed-proof baseline and hosted-composition tasks/requests. The selected development result was the fallback baseline plus hosted composition, so an unseen-test comparison requires actual baseline inference on these same held-out cases. Never replay old 83-case baseline predictions as test results. Exact global requests may be shared only when document SHA and family/choice sets match; case-row bindings must still fan out and remain auditable.
5. Write versioned input manifests and content hashes, assert split membership from the frozen group map, and make test labels inaccessible to preparation and inference. A test run must be marked independent only after the complete test row-task set and fresh baseline outputs cover the frozen test IDs.

The source bundle supports this adapter: every referenced source exists and the literal locators verify. The adapter still needs to implement and validate the frozen baseline/composition request semantics; source readiness alone is not a claim that model inputs or predictions are ready.

## Final evaluation sequence

Use all 1,292 independent-test cases if the frozen fixed-model pipeline can complete. Parent is checking the existing Kaggle job/capacity; do not submit a new job as part of this preparation. If full inference is materially too large after the fixed model/runtime is identified, define a deterministic product-balanced subset of about 200 test cases using only frozen test IDs, publish and hash its membership before labels are accessible, and still retain the all-input coverage audit. Do not choose the subset based on labels, errors, predictions, or convenience after seeing outcomes.

Before any independent-test label access, freeze and hash the model/runtime, baseline definition and fresh-inference requirement, composition policy, task construction code, thresholds, exclusions, and scoring protocol. Generate and hash the complete prediction set and exclusion/coverage records first. Only then may the separately pinned machine-label file be opened for scoring; identify those labels as machine-generated references rather than human gold. Preserve the original frozen inputs and all source manifests unchanged.

## Current blockers and limitations

There are no missing referenced source files or provenance failures in the preparation run. The paired baseline-aware row-task adapter is built and hash-verified. Remaining blockers are full-population one-sided alignment for any shared product-spec units, final model/runtime and policy freeze, and fresh baseline/composition inference. Full evaluation cannot be scored until the frozen pipeline is complete. This artifact does not infer SKU classifications, create labels, score cases, or establish product adoption readiness.
