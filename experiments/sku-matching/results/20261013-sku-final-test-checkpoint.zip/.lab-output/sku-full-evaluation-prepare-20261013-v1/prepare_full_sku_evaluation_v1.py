#!/usr/bin/env python3
"""Verify and materialize frozen v2/v3 SKU inputs without labels or inference.

This adapter reads only frozen case/product/failure input records, input
manifests, AU SKU/options source records, and source captures referenced by those
records. It validates source hashes and literal locators, counts rows/axes, and
copies verified source files into a new preparation directory. It never reads
label or prediction members and never classifies, scores, or calls a model.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from copy import deepcopy
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SHARE_ZIP = ROOT / ".lab-output/sku-claude-dev-input-share-20261012-v1/20261012-sku-independent-real-eval-v2-v3-token-inputs.zip"
SHARE_MANIFEST = SHARE_ZIP.with_suffix(".manifest.json")
SHARE_SIDECAR = Path(str(SHARE_ZIP) + ".sha256")
V2_RAW_ZIP = ROOT / ".lab-output/sku-claude-additional-review-20261012-v1/20261011-sku-independent-real-eval-v2.zip"
V3_RAW_ZIP = ROOT / ".lab-output/sku-claude-additional-review-20261012-v1/20261012-sku-independent-real-eval-v3.zip"
PINNED = {
    "share": "db2815a3d5c726e45f996ad07e73cdcf1cdff0610de53ad84af8a4a0a880488f",
    "v2_review": "6f65d988222c79c758614592340ba28565a51fa8891317724ba354c5fc38b457",
    "v3_review": "52f6faa51127a9c12250a3cdb5eb3d1818a36461a8c09323e481748aeed1f37b",
}
EXPECTED = {
    "v2": {"cases": 2494, "products": 176, "failures": 202, "au_rows": 2142,
           "dev": 1295, "test": 1199, "raw_declared": 416},
    "v3": {"cases": 168, "products": 37, "failures": 57, "au_rows": 122,
           "dev": 75, "test": 93, "raw_declared": 103},
}

sys.path.insert(0, str(ROOT / "experiments/sku-matching/claude_v9_gate"))
import sku_gate_sources as SOURCES  # noqa: E402


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_bytes(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def canonical_sha(value) -> str:
    return sha256(canonical_bytes(value))


def read_json(data: bytes, origin: str):
    try:
        return json.loads(data)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid JSON metadata/input in {origin}") from exc


def read_jsonl(data: bytes, origin: str) -> list[dict]:
    rows = []
    for line_no, line in enumerate(data.splitlines(), 1):
        if not line.strip():
            continue
        value = read_json(line, f"{origin}:{line_no}")
        if not isinstance(value, dict):
            raise ValueError(f"non-object JSONL row in {origin}:{line_no}")
        rows.append(value)
    return rows


def safe_member(name: str) -> str:
    normalized = name.replace("\\", "/")
    path = PurePosixPath(normalized)
    if not normalized or path.is_absolute() or ".." in path.parts or str(path) != normalized:
        raise ValueError("unsafe ZIP member path")
    return normalized


def assert_allowed_source(name: str) -> str:
    normalized = safe_member(name)
    parts = {part.lower() for part in PurePosixPath(normalized).parts}
    if parts & {"labels", "labels-token", "labels-family", "predictions"}:
        raise ValueError("adapter is not allowed to read labels or predictions")
    return normalized


def zip_index(zipped: ZipFile) -> dict[str, object]:
    index = {}
    for info in zipped.infolist():
        name = info.filename.replace("\\", "/")
        path = PurePosixPath(name)
        if (not name or name in index or path.is_absolute() or ".." in path.parts
                or str(path) != name or info.flag_bits & 1 or stat.S_ISLNK(info.external_attr >> 16)):
            raise ValueError("unsafe, duplicate, encrypted, or symlink ZIP member")
        # Keep directory names out of the source-member map.
        if not info.is_dir():
            safe_member(name)
            index[name] = info
    return index


def normalized_source_path(value: str) -> str:
    value = str(value).replace("\\", "/")
    if value.startswith("/"):
        try:
            value = Path(value).resolve().relative_to(ROOT.resolve()).as_posix()
        except ValueError as exc:
            raise ValueError("absolute source path is outside the repository") from exc
    value = re.sub(r"^[A-Za-z]:/", "", value)
    path = PurePosixPath(value)
    if not value or path.is_absolute() or ".." in path.parts or str(path) != value:
        raise ValueError("invalid source locator path")
    return value


def verify_external_share(archive: Path) -> tuple[dict, dict, dict[str, object], str]:
    manifest_path = archive.with_suffix(".manifest.json")
    sidecar_path = Path(str(archive) + ".sha256")
    manifest = read_json(manifest_path.read_bytes(), str(manifest_path))
    actual = sha256(archive.read_bytes())
    sidecar_tokens = sidecar_path.read_text(encoding="utf-8").strip().split()
    if (actual != PINNED["share"] or manifest.get("sha256") != actual
            or manifest.get("archive") != archive.name or manifest.get("size_bytes") != archive.stat().st_size
            or len(sidecar_tokens) != 2 or sidecar_tokens[0] != actual
            or sidecar_tokens[1].lstrip("*") != archive.name):
        raise ValueError("frozen input archive, sidecar, or external manifest binding differs")
    with ZipFile(archive) as zipped:
        members = zip_index(zipped)
        if len(members) != manifest.get("file_count"):
            raise ValueError("frozen input archive member count differs from manifest")
        if sum(info.file_size for info in members.values()) != manifest.get("uncompressed_bytes"):
            raise ValueError("frozen input archive uncompressed size differs from manifest")
        inner_names = [n for n in members if n.endswith(".inner-manifest.json")]
        if len(inner_names) != 1:
            raise ValueError("frozen input archive must have one embedded manifest")
        inner_name = inner_names[0]
        inner = read_json(zipped.read(inner_name), inner_name)
        if inner.get("archive") != archive.name or inner.get("sha256") not in (None, actual):
            raise ValueError("embedded input archive manifest binding differs")
        specs = inner.get("files")
        if not isinstance(specs, list):
            raise ValueError("embedded input archive file manifest is missing")
        spec_map = {}
        for spec in specs:
            name = safe_member(spec["path"])
            if name in spec_map or name not in members or spec.get("bytes") != members[name].file_size:
                raise ValueError("embedded file manifest membership/size differs")
            spec_map[name] = spec
        if set(spec_map) != set(members) - {inner_name}:
            raise ValueError("embedded file manifest does not cover archive members")
        if manifest.get("file_count") != len(spec_map) + 1:
            raise ValueError("external and embedded member counts differ")
        # No label artifacts may be in this source-only bundle.
        if any("label" in name.lower() for name in members):
            raise ValueError("input bundle unexpectedly contains label-named members")
        return manifest, inner, spec_map, actual


def verify_review_archive(path: Path, expected: str) -> tuple[ZipFile, dict[str, object], str]:
    actual = sha256(path.read_bytes())
    if actual != expected:
        raise ValueError("pinned raw-source review archive SHA256 differs")
    zipped = ZipFile(path)
    members = zip_index(zipped)
    return zipped, members, actual


class ArchiveSourceStore(SOURCES.RawStore):
    """Read a source path only from verified input/review ZIPs or exact local file."""

    def __init__(self, root: Path, archives: list[tuple[str, ZipFile, dict[str, object]]]):
        super().__init__(root)
        self.archives = archives
        self.origins: dict[str, list[str]] = defaultdict(list)
        self.bytes_by_key: dict[str, bytes] = {}

    def raw(self, rel: str, expected_sha256: str | None = None) -> bytes:
        key = assert_allowed_source(normalized_source_path(rel))
        if key not in self._bytes:
            choices = [(label, zipped, members[key]) for label, zipped, members in self.archives if key in members]
            if choices:
                bodies = [(label, zipped.read(info.filename)) for label, zipped, info in choices]
                body_hashes = {sha256(body) for _, body in bodies}
                if len(body_hashes) != 1:
                    raise ValueError("same source path differs across frozen archives")
                body = bodies[0][1]
                self.origins[key] = [label for label, _ in bodies]
            else:
                local_path = self.root / key
                if not local_path.is_file():
                    raise FileNotFoundError(key)
                body = local_path.read_bytes()
                self.origins[key] = ["local:" + key]
            self._bytes[key] = body
            self._sha[key] = sha256(body)
        if expected_sha256 is not None and self._sha[key].lower() != str(expected_sha256).lower():
            raise ValueError("source SHA256 differs: " + key)
        return self._bytes[key]

    def sha(self, rel: str) -> str:
        key = normalized_source_path(rel)
        self.raw(key)
        return self._sha[key]


def span_count_and_verify(store: ArchiveSourceStore, value) -> tuple[int, int]:
    spans = verified = 0
    if isinstance(value, dict):
        if all(k in value for k in ("raw_file", "sha256", "locator", "start", "end", "quote")):
            spans += 1
            if SOURCES.verify_span(store, value):
                verified += 1
            else:
                locator = value.get("locator") if isinstance(value.get("locator"), dict) else {}
                raise ValueError("literal source locator/hash verification failed for "
                                 + normalized_source_path(value.get("raw_file", ""))
                                 + " kind=" + str(locator.get("kind", "unknown")))
        for child in value.values():
            count, good = span_count_and_verify(store, child)
            spans += count
            verified += good
    elif isinstance(value, list):
        for child in value:
            count, good = span_count_and_verify(store, child)
            spans += count
            verified += good
    return spans, verified


def collect_source_pairs(value, result: set[tuple[str, str]]) -> None:
    if isinstance(value, dict):
        raw_file, digest = value.get("raw_file"), value.get("sha256")
        if isinstance(raw_file, str) and isinstance(digest, str):
            result.add((normalized_source_path(raw_file), digest))
        for child in value.values():
            collect_source_pairs(child, result)
    elif isinstance(value, list):
        for child in value:
            collect_source_pairs(child, result)


def unique_case_key(case: dict) -> str:
    payload = {k: v for k, v in case.items() if k not in {"case_id", "group_id", "split"}}
    selected = case.get("rakuten_selected") or {}
    sku_identity = {key: selected.get(key) for key in (
        "source_sku_key", "sku_record_key", "variant_id", "url", "source_row_key", "source_row_index")}
    source_record = case.get("source_record") or {}
    source_ids = {
        "dossier_id": case.get("dossier_id"),
        "au_product_id": case.get("au_product_id"),
        "source_pair_id": source_record.get("pair_id"),
        "source_sku_record_key": source_record.get("sku_record_key"),
        "selected_sku": sku_identity,
    }
    return canonical_sha({"case_payload_sha256": canonical_sha(payload), "source_ids": source_ids})


def unique_product_key(product: dict) -> str:
    p = product.get("au_product") or {}
    return canonical_sha({
        "product_payload_sha256": canonical_sha(product),
        "source_ids": {"dossier_id": product.get("dossier_id"), "pair_ref": product.get("pair_ref"),
                       "au_product_id": p.get("product_id")},
    })


def find_options_array_member(members: dict[str, object], split: str) -> str:
    marker = f"/eval-{split}/"
    candidates = [name for name in members if marker in name and name.endswith("/au_product_sku_arrays.jsonl")]
    if len(candidates) != 1:
        raise ValueError("expected one frozen AU SKU/options source file for " + split)
    return candidates[0]


def summarize_option_responses(rows: list[dict]) -> dict:
    free_rows = paid_rows = arrays = 0
    au_ids = set()
    sku_cell_rows = 0
    for row in rows:
        if row.get("au_product_id") is not None:
            au_ids.add(str(row["au_product_id"]))
        options = row.get("au_product_options_raw")
        if isinstance(options, dict):
            free_rows += int("free_options" in options)
            paid_rows += int("paid_options" in options)
            for key in ("free_options", "paid_options"):
                value = options.get(key)
                arrays += len(value) if isinstance(value, (list, dict)) else int(value is not None)
        cells = row.get("au_sku_cells_raw")
        if isinstance(cells, list):
            sku_cell_rows += len(cells)
        else:
            sku_cell_rows += int(row.get("au_sku_cells_count", 0) or 0)
    return {"response_record_count": len(rows), "unique_au_product_count": len(au_ids),
            "records_with_free_options_field": free_rows, "records_with_paid_options_field": paid_rows,
            "top_level_option_entries": arrays, "sku_array_cell_count": sku_cell_rows}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=HERE)
    args = parser.parse_args(argv)
    out_dir = args.output_dir.resolve()
    if out_dir != HERE.resolve():
        raise ValueError("this scaffold writes only to its own preparation directory")
    source_dir = out_dir / "source"
    if source_dir.exists():
        raise FileExistsError("refusing to overwrite existing frozen source bundle")

    blockers = []
    split_summaries = {}
    source_files_to_materialize: set[str] = set()
    source_file_hashes: dict[str, str] = {}
    source_pair_counts = {}
    total_spans = total_verified_spans = 0
    case_all: list[dict] = []
    product_all: list[dict] = []
    failures_total = 0

    try:
        external, inner, input_specs, input_digest = verify_external_share(SHARE_ZIP)
        v2zip, v2members, v2digest = verify_review_archive(V2_RAW_ZIP, PINNED["v2_review"])
        v3zip, v3members, v3digest = verify_review_archive(V3_RAW_ZIP, PINNED["v3_review"])
        with ZipFile(SHARE_ZIP) as share:
            share_members = zip_index(share)
            archives = [("frozen_token_input_zip", share, share_members),
                        ("v2_frozen_review_zip", v2zip, v2members),
                        ("v3_frozen_review_zip", v3zip, v3members)]
            store = ArchiveSourceStore(ROOT, archives)
            source_manifest_raw_count = {}
            expected_splits = external.get("sets", {})
            for split in ("v2", "v3"):
                marker = f"/eval-{split}/run-token/inputs/"
                direct = {}
                for file in ("cases.jsonl", "products.jsonl", "failures.jsonl", "manifest.json"):
                    names = [n for n in share_members if n.endswith(marker + file)]
                    if len(names) != 1:
                        raise ValueError("expected one frozen " + split + " input member for " + file)
                    name = names[0]
                    spec = input_specs.get(name)
                    if not spec:
                        raise ValueError("input member absent from embedded hash manifest")
                    body = share.read(name)
                    if len(body) != spec.get("bytes") or sha256(body) != spec.get("sha256"):
                        raise ValueError("frozen input member bytes/SHA differ: " + file)
                    direct[file] = (name, body)
                    source_files_to_materialize.add(name)
                    source_file_hashes[name] = spec["sha256"]

                input_manifest = read_json(direct["manifest.json"][1], direct["manifest.json"][0])
                expected = EXPECTED[split]
                cases = read_jsonl(direct["cases.jsonl"][1], direct["cases.jsonl"][0])
                products = read_jsonl(direct["products.jsonl"][1], direct["products.jsonl"][0])
                failure_rows = sum(1 for line in direct["failures.jsonl"][1].splitlines() if line.strip())
                if (len(cases) != expected["cases"] or input_manifest.get("case_count") != len(cases)
                        or len(products) != expected["products"] or input_manifest.get("product_pairs") != len(products)
                        or failure_rows != expected["failures"]
                        or input_manifest.get("failures", {}).get("case_input") != failure_rows):
                    raise ValueError("frozen case/product/failure row counts differ for " + split)
                splits = Counter(str(row.get("split", "unknown")) for row in cases)
                declared_splits = expected_splits.get(split, {}).get("cases_by_split", {})
                group_member_candidates = [n for n in share_members if f"/eval-{split}/groups-token/groups.jsonl" in n]
                if len(group_member_candidates) != 1:
                    raise ValueError("expected one frozen case-split group map for " + split)
                group_name = group_member_candidates[0]
                group_spec = input_specs.get(group_name)
                if not group_spec:
                    raise ValueError("case-split group map absent from embedded hash manifest")
                group_body = share.read(group_name)
                if sha256(group_body) != group_spec.get("sha256"):
                    raise ValueError("case-split group map SHA differs")
                groups = read_jsonl(group_body, group_name)
                group_map = {}
                for group in groups:
                    # Frozen group sidecars key the dev/test split by dossier;
                    # the `group_id` carried by case rows is a different grain.
                    gid = str(group.get("dossier_id"))
                    prior = group_map.get(gid)
                    if prior is not None and (prior.get("split"), prior.get("excluded")) != (group.get("split"), group.get("excluded")):
                        raise ValueError("conflicting split assignment in frozen group map")
                    group_map.setdefault(gid, group)
                grouped_splits = Counter()
                case_input_split_fields = Counter()
                for case in cases:
                    case_input_split_fields[str(case.get("split", "unknown"))] += 1
                    group = group_map.get(str(case.get("dossier_id")))
                    if group is None or group.get("excluded") or group.get("split") not in {"dev", "test"}:
                        raise ValueError("case lacks an eligible frozen dev/test group assignment")
                    grouped_splits[str(group["split"])] += 1
                if (dict(sorted(grouped_splits.items())) != declared_splits
                        or grouped_splits.get("test", 0) != expected["test"]
                        or grouped_splits.get("dev", 0) != expected["dev"]):
                    raise ValueError("case development/test split counts differ from frozen group map for " + split)
                source_files_to_materialize.add(group_name)
                source_file_hashes[group_name] = group_spec["sha256"]
                if input_manifest.get("labels_read") is not False:
                    raise ValueError("frozen input build does not attest labels_read=false")
                source_hashes = {normalized_source_path(k): v for k, v in input_manifest.get("source_sha256", {}).items()}
                raw_declared = sum(1 for k in source_hashes if "/raw/" in k and Path(k).suffix.lower() in {".html", ".json"})
                source_manifest_raw_count[split] = raw_declared
                if raw_declared != expected["raw_declared"]:
                    raise ValueError("declared raw source count differs for " + split)

                array_name = find_options_array_member(share_members, split)
                array_spec = input_specs.get(array_name)
                if not array_spec:
                    raise ValueError("AU SKU/options source file absent from embedded manifest")
                array_body = share.read(array_name)
                if sha256(array_body) != array_spec.get("sha256"):
                    raise ValueError("AU SKU/options source file SHA differs")
                arrays = read_jsonl(array_body, array_name)
                source_files_to_materialize.add(array_name)
                source_file_hashes[array_name] = array_spec["sha256"]

                # Counts from the complete captured product matrix and selected SKU axes.
                computed_au_rows = sum(len(p.get("au_rows") or []) for p in products)
                au_axis_entries = sum(len(row.get("axes") or []) for p in products for row in (p.get("au_rows") or []))
                au_axis_value_pairs = set()
                au_rows_with_source_array = sum(1 for p in products for row in (p.get("au_rows") or [])
                                                if isinstance(row.get("array_source"), dict))
                rakuten_axis_entries = sum(len((c.get("rakuten_selected") or {}).get("axes") or []) for c in cases)
                rakuten_variant_attribute_entries = sum(len((c.get("rakuten_selected") or {}).get("variant_attributes") or []) for c in cases)
                for p in products:
                    pid = str((p.get("au_product") or {}).get("product_id", ""))
                    for row in p.get("au_rows") or []:
                        for axis in row.get("axes") or []:
                            if isinstance(axis.get("axis_name"), str) and isinstance(axis.get("value"), str):
                                au_axis_value_pairs.add((pid, axis["axis_name"], axis["value"]))
                if computed_au_rows != input_manifest.get("au_rows") or computed_au_rows != expected["au_rows"]:
                    raise ValueError("complete AU row count differs from frozen input manifest")
                product_au_ids = {str((p.get("au_product") or {}).get("product_id")) for p in products}
                array_au_ids = {str(a.get("au_product_id")) for a in arrays if a.get("au_product_id") is not None}
                if not product_au_ids <= array_au_ids:
                    raise ValueError("some product rows lack an AU SKU/options source record")
                option_summary = summarize_option_responses(arrays)

                # Join every case to its full source product and preserve split in identity.
                product_by_pair = {(str(p.get("dossier_id")), str((p.get("au_product") or {}).get("product_id"))): p
                                   for p in products}
                joined_cases = sum(1 for c in cases if (str(c.get("dossier_id")), str(c.get("au_product_id"))) in product_by_pair)
                if joined_cases != len(cases):
                    raise ValueError("not every case resolves to one complete product source record")

                # Check every referenced file SHA and every original literal span without exposing quotes.
                refs: set[tuple[str, str]] = set()
                collect_source_pairs(cases, refs)
                collect_source_pairs(products, refs)
                collect_source_pairs(arrays, refs)
                referenced_raw_paths = {path for path, _ in refs if "/raw/" in path}
                declared_raw_paths = {path for path in source_hashes if "/raw/" in path and Path(path).suffix.lower() in {".html", ".json"}}
                declared_unreferenced = declared_raw_paths - referenced_raw_paths
                expected_by_path: dict[str, set[str]] = defaultdict(set)
                for path, digest in refs:
                    expected_by_path[path].add(digest)
                if any(len(values) != 1 for values in expected_by_path.values()):
                    raise ValueError("one source path has conflicting SHA declarations")
                missing_sources = []
                for path, values in expected_by_path.items():
                    expected_sha = next(iter(values))
                    manifest_sha = source_hashes.get(path)
                    if manifest_sha is not None and str(manifest_sha).lower() != expected_sha.lower():
                        raise ValueError("referenced source SHA differs from input manifest")
                    try:
                        store.raw(path, expected_sha)
                    except FileNotFoundError:
                        missing_sources.append(path)
                if missing_sources:
                    blockers.extend({"kind": "missing_referenced_source", "path": p} for p in missing_sources)
                    raise ValueError("one or more case/product source references are unavailable")
                spans, verified = span_count_and_verify(store, [cases, products, arrays])
                total_spans += spans
                total_verified_spans += verified
                if spans != verified:
                    raise ValueError("not every original source locator was verified")

                # Copy only directly consumed inputs and referenced provenance sources.
                for path in expected_by_path:
                    source_files_to_materialize.add(path)
                    source_file_hashes[path] = next(iter(expected_by_path[path]))
                case_hashes = Counter(unique_case_key(c) for c in cases)
                product_hashes = Counter(unique_product_key(p) for p in products)
                split_summaries[split] = {
                    "input_members": {file: {"path": name, "sha256": input_specs[name]["sha256"],
                                               "bytes": input_specs[name]["bytes"]}
                                      for file, (name, _) in direct.items()},
                    "case_rows": len(cases), "case_unique_source_identity_count": len(case_hashes),
                    "case_duplicate_identity_rows": len(cases) - len(case_hashes),
                    "case_input_split_field_counts": dict(sorted(case_input_split_fields.items())),
                    "case_split_counts_from_frozen_group_map": dict(sorted(grouped_splits.items())),
                    "test_case_rows": grouped_splits["test"], "dev_case_rows": grouped_splits["dev"],
                    "product_rows": len(products), "product_unique_source_identity_count": len(product_hashes),
                    "product_duplicate_identity_rows": len(products) - len(product_hashes),
                    "case_input_failure_rows": failure_rows,
                    "attempted_source_sku_records": input_manifest.get("source_sku_records"),
                    "case_input_failure_count_declared": input_manifest.get("failures", {}).get("case_input"),
                    "case_product_joined_rows": joined_cases,
                    "au_row_count": computed_au_rows,
                    "au_rows_with_source_array": au_rows_with_source_array,
                    "au_axis_entry_count": au_axis_entries,
                    "unique_au_axis_value_count_by_product": len(au_axis_value_pairs),
                    "selected_rakuten_axis_entries": rakuten_axis_entries,
                    "selected_rakuten_variant_attribute_entries": rakuten_variant_attribute_entries,
                    "au_sku_options_source": {"path": array_name, **option_summary,
                                              "product_au_ids_covered": len(product_au_ids),
                                              "product_au_ids_missing": len(product_au_ids - array_au_ids)},
                    "referenced_source_file_count": len(expected_by_path),
                    "referenced_raw_capture_file_count": len(referenced_raw_paths),
                    "manifest_declared_raw_capture_file_count": raw_declared,
                    "declared_raw_capture_files_unreferenced_by_cases_products": len(declared_unreferenced),
                    "case_product_source_spans_verified": spans,
                    "labels_read": False,
                }
                case_all.extend(cases)
                product_all.extend(products)
                failures_total += failure_rows
                source_pair_counts[split] = len(refs)

            # Materialize only after all archive, member, source SHA, split, join, and locator checks pass.
            if source_dir.exists():
                raise FileExistsError("refusing to overwrite existing source bundle")
            for path in sorted(source_files_to_materialize):
                assert_allowed_source(path)
                body = store.raw(path, source_file_hashes[path])
                target = source_dir / PurePosixPath(path)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(body)
            source_index = []
            for path in sorted(source_files_to_materialize):
                body = store.raw(path, source_file_hashes[path])
                source_index.append({"path": path, "sha256": source_file_hashes[path],
                                     "bytes": len(body), "archive_origins": store.origins.get(path, [])})
            (out_dir / "source-index.json").write_text(json.dumps(source_index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        v2zip.close()
        v3zip.close()

    except Exception as exc:
        blockers.append({"kind": "preparation_validation_failed", "error_type": type(exc).__name__,
                         "message": str(exc)})

    case_unique_all = len({unique_case_key(c) for c in case_all}) if case_all else 0
    product_unique_all = len({unique_product_key(p) for p in product_all}) if product_all else 0
    summary = {
        "schema_version": "sku-full-evaluation-preparation-v1",
        "status": "source_bundle_ready" if not blockers and source_dir.exists() else "blocked",
        "purpose": "frozen full v2/v3 source-input and provenance preparation; no model inference or scoring",
        "archive_verification": {
            "token_input_archive": {"path": str(SHARE_ZIP.relative_to(ROOT)), "sha256": PINNED["share"],
                                    "verified_external_manifest_and_sidecar": True},
            "v2_raw_source_archive": {"path": str(V2_RAW_ZIP.relative_to(ROOT)), "sha256": PINNED["v2_review"], "verified": True},
            "v3_raw_source_archive": {"path": str(V3_RAW_ZIP.relative_to(ROOT)), "sha256": PINNED["v3_review"], "verified": True},
        },
        "splits": split_summaries,
        "aggregate_before_deduplication": {
            "case_rows": sum(x["case_rows"] for x in split_summaries.values()),
            "test_case_rows": sum(x["test_case_rows"] for x in split_summaries.values()),
            "dev_case_rows": sum(x["dev_case_rows"] for x in split_summaries.values()),
            "product_rows": sum(x["product_rows"] for x in split_summaries.values()),
            "case_input_failure_rows": failures_total,
            "au_row_count": sum(x["au_row_count"] for x in split_summaries.values()),
        },
        "deduplicated_identity_counts": {"case_source_identity_count": case_unique_all,
                                          "case_duplicate_rows": sum(x["case_rows"] for x in split_summaries.values()) - case_unique_all,
                                          "product_source_identity_count": product_unique_all,
                                          "product_duplicate_rows": sum(x["product_rows"] for x in split_summaries.values()) - product_unique_all},
        "source_provenance": {"source_file_count_materialized": len(source_files_to_materialize) if source_dir.exists() else 0,
                              "source_locator_count_verified": total_verified_spans,
                              "labels_read": False, "model_outputs_read": False,
                              "missing_referenced_sources": [b["path"] for b in blockers if b.get("kind") == "missing_referenced_source"]},
        "harness_compatibility": {
            "current_mixed_preparer_and_evaluator_usable_as_is": False,
            "reason": "Existing mixed replay is membership/83-case development-only, fixes source strata at 44/31/7/1, and rejects independent_test=true. The full-input source schema is present, but a split-aware full-condition preparation adapter is required.",
            "current_full_condition_evaluator_independent_test": False,
            "full_condition_adapter_needed": True,
        },
        "test_phase_gate": "Do not load test labels until development model, policy, code, threshold, baseline, and scoring protocol are frozen and all test predictions are hashed.",
        "blockers": blockers,
    }
    (out_dir / "inventory.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"schema_version": summary["schema_version"], "status": summary["status"],
                      "case_rows": summary["aggregate_before_deduplication"]["case_rows"],
                      "test_case_rows": summary["aggregate_before_deduplication"]["test_case_rows"],
                      "dev_case_rows": summary["aggregate_before_deduplication"]["dev_case_rows"],
                      "product_rows": summary["aggregate_before_deduplication"]["product_rows"],
                      "au_rows": summary["aggregate_before_deduplication"]["au_row_count"],
                      "source_locators_verified": total_verified_spans,
                      "failure_rows": failures_total,
                      "blocker_kinds": sorted(Counter(b["kind"] for b in blockers).keys())}, ensure_ascii=False))
    return 0 if summary["status"] == "source_bundle_ready" else 2


if __name__ == "__main__":
    raise SystemExit(main())
