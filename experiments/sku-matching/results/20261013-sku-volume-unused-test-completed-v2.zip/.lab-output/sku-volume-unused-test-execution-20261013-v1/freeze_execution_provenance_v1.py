"""Record all available execution bytes after terminal collection, before labels."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

EX = Path(__file__).resolve().parent
ROOT = EX.parents[1]


def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main() -> None:
    initial = json.loads((EX / "root-pre-inference-freeze-v1.json").read_text())
    for relative, expected in initial["pins"].items():
        path = ROOT / relative
        if not path.is_file() or pin(path) != expected:
            raise ValueError("pre-inference frozen input changed: " + relative)
    state = json.loads((EX / "supervisor-v2-state.json").read_text())
    if (set(state["assigned"]) != set(range(109, 966))
            or set(state["terminal"]) != set(range(109, 966))
            or state["active"]):
        raise ValueError("coordinator has not recorded every remaining task terminal")
    snapshot = json.loads((EX / "firstpass-snapshot-v1/snapshot-receipt.json").read_text())
    if snapshot["assigned_packet_count"] != 965 or snapshot["assigned_pair_count"] != 971:
        raise ValueError("snapshot does not cover the frozen packet/pair population")
    target = EX / "root-full-pregrade-execution-provenance-v1.json"
    if target.exists() or (EX / "postfreeze-private-grade-v1.json").exists():
        raise FileExistsError("pregrade provenance must be created once before grading")
    inventory = {}
    for path in sorted(EX.rglob("*")):
        if path.is_symlink():
            raise ValueError("symlink in execution provenance")
        if path.is_file():
            inventory[path.relative_to(ROOT).as_posix()] = pin(path)
    receipt = {
        "schema_version": "sku-volume-root-full-pregrade-execution-provenance-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "all_available_execution_bytes_pinned_before_labels",
        "files": inventory,
        "actual_terminal_packet_count": 965,
        "dispatch_pair_count": 971,
        "pre_inference_frozen_input_pins_reverified": True,
        "root_terminal_seed": "1..108 closed in original first108 checkpoint",
        "coordinator_terminal_range": "109..965",
        "original_classifier_bytes_preserved": True,
        "semantic_retries": 0,
        "semantic_retry_count_scope": "no additional classifier redispatch or repair by ROOT/coordinator; each worker's complete hidden tool history is not independently available",
        "early_individual_spawn_record_gaps": [40, 49, 50, 51, 52, 54, 55, 56],
        "selector_gaps_are_coordinator_reported_not_independent_weight_attestation": True,
        "complete_pre_repair_original_ledger_available": False,
        "original_ledger_limit": "one malformed delimiter line rewritten before whole original bytes were retained; decoded objects and line hash preserved",
        "technical_defects_and_selfreports": "root-observed-protocol-issues-v*.json and original terminal events; no output repairs",
        "overwrite_capable_write_mode_packet331": "reported deviation; replacement of an earlier semantic draft was not independently established",
        "additional_nonexclusive_mode_selfreports": [851, 936],
        "preexisting_output_packet958": "original available bytes preserved; file creator and whether a prior first save preceded the refused write are not independently established",
        "model_selfreport_packet510": "no-final-newline claim contradicted by original byte hash and actual LF; no draft bytes changed",
        "original_byte_transport_relocations": [70, 333],
        "source_citation_verification_is_semantic_truth": False,
        "labels_read": False,
        "scores_created": False,
        "production_adoption_allowed": False,
    }
    with target.open("x") as output:
        json.dump(receipt, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(json.dumps({"path": target.relative_to(ROOT).as_posix(),
                      "file_count": len(inventory), **pin(target)}))


if __name__ == "__main__":
    main()
