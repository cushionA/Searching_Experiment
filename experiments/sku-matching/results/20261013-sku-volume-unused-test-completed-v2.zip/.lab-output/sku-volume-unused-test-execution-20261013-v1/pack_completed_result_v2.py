"""Export completed execution bytes and aggregate results, excluding private grade."""
from __future__ import annotations

import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

EX = Path(__file__).resolve().parent
ROOT = EX.parents[1]
RESULTS = ROOT / "experiments/sku-matching/results"


def pin(data: bytes) -> dict:
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main() -> None:
    summary_path = EX / "frozen-volume-grade-summary-v1.json"
    summary = json.loads(summary_path.read_text())
    if summary["selected_case_count"] != 569 or summary["selected_product_count"] != 46:
        raise ValueError("summary is not the entire fixed cohort")
    freeze = EX / "grading-freeze-v1.json"
    grade = EX / "postfreeze-private-grade-v1.json"
    if summary["pins"]["freeze"] != pin(freeze.read_bytes()) or summary["pins"]["grade"] != pin(grade.read_bytes()):
        raise ValueError("completed summary no longer matches its freeze/grade")
    state = json.loads((EX / "supervisor-v2-state.json").read_text())
    if set(state["terminal"]) != set(range(109, 966)) or state["active"]:
        raise ValueError("some original classifier tasks are not terminal")
    target = RESULTS / "20261013-sku-volume-unused-test-completed-v2.zip"
    receipt_path = target.with_suffix(".receipt.json")
    if target.exists() or receipt_path.exists():
        raise FileExistsError("completed export already exists")
    dependency_path = RESULTS / "20261013-sku-volume-unused-test-source-checkpoint.chunks.json"
    dependency = json.loads(dependency_path.read_text())
    duplicates = {EX / "sku-volume-unused-test-source-checkpoint-v1.zip":
                  {"bytes": dependency["archive_bytes"], "sha256": dependency["archive_sha256"]}}
    for part in dependency["parts"]:
        suffix = part["path"].split(".zip.", 1)[1]
        duplicates[EX / ("sku-volume-unused-test-source-checkpoint-v1.zip." + suffix)] = {
            "bytes": part["bytes"], "sha256": part["sha256"]}
        if pin((RESULTS / part["path"]).read_bytes()) != duplicates[EX / ("sku-volume-unused-test-source-checkpoint-v1.zip." + suffix)]:
            raise ValueError("source dependency part no longer matches its frozen pin")
    for original, expected in duplicates.items():
        if pin(original.read_bytes()) != expected:
            raise ValueError("source archive duplicate does not match the retained dependency")
    files = {}
    for path in sorted(EX.rglob("*")):
        if path in duplicates:
            continue
        relative = path.relative_to(EX)
        if relative.parts[0] in {"packet-index-v1", "pre-model-preflight-v2", "pre-model-preflight-v1", "__pycache__"}:
            continue
        if path == grade:
            continue
        if path.is_symlink():
            raise ValueError("symlink in completed export")
        if path.is_file():
            files[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    manifest = {
        "schema_version": "sku-volume-completed-checkpoint-v2",
        "omitted_exact_source_package_duplicates": {p.relative_to(ROOT).as_posix(): expected for p, expected in duplicates.items()},
        "source_dependency_manifest_pin": pin(dependency_path.read_bytes()),
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "selected_product_count": 46, "selected_case_count": 569,
        "packet_count": 965, "pair_count": 971,
        "source_checkpoint_dependency": "20261013-sku-volume-unused-test-source-checkpoint.chunks.json and restore supplement",
        "public_source_packets_and_preflight_retained_in_source_dependency": True,
        "private_reference_archives_included": False,
        "private_per_case_grade_included": False,
        "aggregate_summary_included": True,
        "original_firstpass_bytes_unchanged": True,
        "early_provenance_gaps_retained_and_disclosed": True,
        "no_semantic_retries_or_test_retuning": True,
        "files": {name: pin(data) for name, data in files.items()},
    }
    manifest_bytes = json.dumps(manifest, ensure_ascii=False, sort_keys=True,
                                separators=(",", ":")).encode() + bytes([10])
    with target.open("xb") as raw:
        with zipfile.ZipFile(raw, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, data in files.items():
                archive.writestr(name, data)
            archive.writestr("checkpoint-manifest.json", manifest_bytes)
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise ValueError("completed archive CRC failure")
        for name, data in files.items():
            if archive.read(name) != data:
                raise ValueError("completed archive differs from original bytes")
    if target.stat().st_size > 40 * 1024 * 1024:
        raise ValueError("completed archive exceeds 40MiB; retain it and split before git add")
    receipt = {"schema_version": "sku-volume-completed-checkpoint-receipt-v2",
               "archive": target.relative_to(ROOT).as_posix(), **pin(target.read_bytes()),
               "member_count": len(files), "manifest_sha256": pin(manifest_bytes)["sha256"],
               "crc_and_all_member_bytes_verified": True,
               "private_reference_archives_included": False,
               "private_per_case_grade_included": False, "partial_checkpoint": False}
    with receipt_path.open("x") as output:
        json.dump(receipt, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
