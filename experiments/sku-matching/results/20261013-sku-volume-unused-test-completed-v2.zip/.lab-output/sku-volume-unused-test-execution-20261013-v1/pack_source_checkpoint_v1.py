#!/usr/bin/env python3
"""Create the blind, source-only restore checkpoint from a root freeze pin map.

No labels, predictions, scores, gold/reference cases, or per-case grade files are read.
The archive member names are workspace-relative source paths; raw captures retain
those exact logical paths while being read from the frozen physical source root.
"""
from __future__ import annotations
import argparse, hashlib, json, os, zipfile
from pathlib import Path

ROOT = Path('/workspace/Searching_Experiment-model-gates-20261010')
BASE = ROOT / '.lab-output/sku-volume-unused-test-20261013-v1'
EXEC = ROOT / '.lab-output/sku-volume-unused-test-execution-20261013-v1'
IDENTITY = ROOT / '.lab-output/sku-volume-unused-test-identity-plan-20261013-v1'
SOURCE_ROOT = ROOT / '.lab-output/sku-full-evaluation-prepare-20261013-v1/source'
OUTPUT = EXEC / 'sku-volume-unused-test-source-checkpoint-v1.zip'
PACKER = Path(__file__).resolve()
POLICY = BASE / 'candidate-policy-freeze-v1.json'


def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def add_tree(pins: dict[str,dict], directory: Path, excluded_parts=()) -> None:
    for p in sorted(directory.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT).as_posix()
        if any(x in rel for x in excluded_parts): continue
        pins[rel]={'sha256':sha256(p),'bytes':p.stat().st_size}

def build_inventory() -> dict:
    pins: dict[str,dict]={}
    # All prepared-source-v1, literal-proofs-v1 and scoped-native-source-v3 files.
    for name in ('prepared-source-v1','literal-proofs-v1','scoped-native-source-v3'):
        add_tree(pins, BASE/name)
    # Root-level source receipts/configs and explicitly mapped history; exclude private failure traces.
    for p in sorted(BASE.iterdir()):
        if p.is_file():
            rel=p.relative_to(ROOT).as_posix(); pins[rel]={'sha256':sha256(p),'bytes':p.stat().st_size}
        elif p.name == 'source-preparation-logs': add_tree(pins,p)
    # Identity plan and the full pre-model packet/preflight evidence.
    add_tree(pins, IDENTITY)
    add_tree(pins, EXEC/'pre-model-preflight-v2')
    add_tree(pins, EXEC/'packet-index-v1')
    # Human and automated pre-inference QA/review evidence, plus the collector source.
    qa=ROOT/'.lab-output/sku-volume-preinference-qa-20261013-v1'
    for rel in (
        '.lab-output/sku-volume-preinference-qa-20261013-v1/focused-final.log',
        '.lab-output/sku-volume-preinference-qa-20261013-v1/focused.log',
        '.lab-output/sku-volume-preinference-qa-20261013-v1/qa-receipt-v1.json',
        '.lab-output/sku-volume-preinference-qa-20261013-v1/required.log',
        '.lab-output/sku-volume-unused-test-execution-20261013-v1/supervisor-instructions-v1.txt',
        '.lab-output/sku-volume-unused-test-execution-20261013-v1/collector-code-qa-receipt-v1.json',
        '.lab-output/sku-volume-unused-test-execution-20261013-v1/packet-index-v1/worker-instructions.txt',
        '.lab-output/sku-volume-unused-test-execution-20261013-v1/packet-index-v1/prepare-history.jsonl',
        '.lab-output/sku-volume-unused-test-execution-20261013-v1/packet-index-v1/ROOT-INSTRUCTIONS.txt',
        '.lab-output/sku-volume-unused-test-execution-20261013-v1/collect_volume_firstpass_v1.py',
        '.lab-output/sku-volume-unused-test-execution-20261013-v1/test_collect_volume_firstpass_v1.py',
    ):
        p=ROOT/rel
        if p.is_file(): pins[rel]={'sha256':sha256(p),'bytes':p.stat().st_size}
    # New volume-specific scripts and tests, plus all 24 candidate-policy exact code pins.
    policy=json.loads(POLICY.read_text(encoding='utf-8'))
    for rel, expected in policy['source_code_and_identity_pins'].items():
        p=ROOT/rel
        if not p.is_file() or p.stat().st_size != expected['bytes'] or sha256(p) != expected['sha256']:
            raise SystemExit(f'candidate-policy pinned source mismatch: {rel}')
        pins[rel]={'sha256':expected['sha256'],'bytes':expected['bytes']}
    for rel in (
        'experiments/sku-matching/prepare_body_indexed_volume_packets_v1.py',
        'experiments/sku-matching/prepare_indexed_volume_partial_source_v1.py',
        'experiments/sku-matching/prepare_indexed_volume_source_v1.py',
        'experiments/sku-matching/run_indexed_volume_test_v1.py',
        'tests/test_lab_sku_indexed_volume_runner_v1.py',
        'tests/test_lab_sku_indexed_volume_source_v1.py',
        'tests/test_lab_sku_volume_partial_source_v1.py',
    ):
        p=ROOT/rel
        if not p.is_file(): raise SystemExit(f'missing required code/test: {rel}')
        pins[rel]={'sha256':sha256(p),'bytes':p.stat().st_size}
    # Exact original raw capture list; preserve inventory's relative path in ZIP.
    inventory=BASE/'prepared-source-v1/raw-source-capture-inventory.json'
    captures=json.loads(inventory.read_text(encoding='utf-8'))['captures']
    if len(captures)!=91: raise SystemExit(f'expected verified 91 unique captures, got {len(captures)}')
    for item in captures:
        logical=item['path']; physical=SOURCE_ROOT/logical
        if not physical.is_file() or physical.stat().st_size!=item['bytes'] or sha256(physical)!=item['sha256']:
            raise SystemExit(f'raw capture pin mismatch: {logical}')
        pins[logical]={'sha256':item['sha256'],'bytes':item['bytes'],'physical_source':str(physical)}
    # This packer is part of the source provenance.
    pins[PACKER.relative_to(ROOT).as_posix()]={'sha256':sha256(PACKER),'bytes':PACKER.stat().st_size}
    return {'schema_version':'sku-volume-unused-test-source-checkpoint-inventory-v1',
            'labels_read':False,'predictions_read':False,'scores_created':False,
            'gold_or_reference_cases_included':False,'raw_capture_unique_count':len(captures),
            'document_count':92,'raw_captures_are_byte_exact':True,
            'source_code_and_identity_pin_count':len(policy['source_code_and_identity_pins']),
            'pins':dict(sorted(pins.items()))}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--write-inventory', action='store_true')
    ap.add_argument('--root-go', type=Path)
    ap.add_argument('--freeze', type=Path)
    args=ap.parse_args()
    inv=build_inventory()
    inventory_path=EXEC/'source-checkpoint-inventory-v1.json'
    if args.write_inventory:
        inventory_path.write_text(json.dumps(inv,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'inventory':str(inventory_path),'sha256':sha256(inventory_path),'members':len(inv['pins'])},ensure_ascii=False)); return
    if not args.root_go or not args.freeze: raise SystemExit('packing requires final freeze and root GO')
    go_path=args.root_go.resolve(); freeze_path=args.freeze.resolve()
    go=json.loads(go_path.read_text(encoding='utf-8')); freeze=json.loads(freeze_path.read_text(encoding='utf-8'))
    if go.get('root_go_for_source_checkpoint') is not True or go.get('freeze_sha256')!=sha256(freeze_path):
        raise SystemExit('root GO is missing or not bound to the supplied freeze')
    for p in (go_path,freeze_path):
        rel=p.relative_to(ROOT).as_posix(); inv['pins'][rel]={'sha256':sha256(p),'bytes':p.stat().st_size}
    # Final collector/QA/freeze receipts are added only through the supplied immutable pin map.
    for rel, entry in freeze.get('pins',{}).items():
        expected=entry.get('sha256') if isinstance(entry,dict) else entry
        f=ROOT/rel
        if not f.is_file() or sha256(f)!=expected: raise SystemExit(f'final freeze pin mismatch: {rel}')
        if any(x in rel.lower() for x in ('gold','reference-case','prediction','score','label')):
            raise SystemExit(f'prohibited final-freeze path: {rel}')
        inv['pins'][rel]={'sha256':expected,'bytes':f.stat().st_size}
    inv['pins'][PACKER.relative_to(ROOT).as_posix()]={'sha256':sha256(PACKER),'bytes':PACKER.stat().st_size}
    inv['root_go_sha256']=sha256(go_path); inv['freeze_sha256']=sha256(freeze_path)
    entries=sorted(inv['pins'].items())
    manifest={'schema_version':'sku-volume-unused-test-source-checkpoint-v1','archive':OUTPUT.name,
              'labels_read':False,'predictions_read':False,'scores_created':False,
              'gold_or_reference_cases_included':False,'raw_capture_unique_count':91,'document_count':92,
              'member_count':len(entries)+1,
              'members':[{'path':r,'sha256':v['sha256'],'bytes':v['bytes']} for r,v in entries]}
    manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
    with zipfile.ZipFile(OUTPUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for rel,v in entries:
            src=Path(v.get('physical_source',ROOT/rel))
            z.write(src,rel)
        z.writestr('MANIFEST.json',manifest_bytes)
    # Validate ZIP integrity and every uncompressed member hash.
    with zipfile.ZipFile(OUTPUT) as z:
        bad=z.testzip()
        if bad: raise SystemExit(f'CRC failure: {bad}')
        for rel,v in entries:
            h=hashlib.sha256()
            with z.open(rel) as f:
                for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
            if h.hexdigest()!=v['sha256']: raise SystemExit(f'archive content hash mismatch: {rel}')
    archive_sha=sha256(OUTPUT)
    sha_path=OUTPUT.with_suffix('.zip.sha256')
    sha_path.write_text(f'{archive_sha}  {OUTPUT.name}\n',encoding='ascii')
    parts=[]
    if OUTPUT.stat().st_size > 75*1024*1024:
        chunk_size=40*1024*1024
        with OUTPUT.open('rb') as src:
            n=0
            while True:
                block=src.read(chunk_size)
                if not block: break
                n+=1; part=OUTPUT.with_name(OUTPUT.name+f'.part-{n:03d}')
                part.write_bytes(block); parts.append({'path':part.name,'bytes':len(block),'sha256':sha256(part)})
    manifest_path=EXEC/'source-checkpoint-manifest-v1.json'
    manifest_path.write_bytes(manifest_bytes)
    print(json.dumps({'archive':str(OUTPUT),'archive_bytes':OUTPUT.stat().st_size,
      'archive_sha256':archive_sha,'sha256_sidecar':str(sha_path),
      'manifest':str(manifest_path),'manifest_sha256':sha256(manifest_path),
      'member_count':len(entries)+1,'crc':'passed','chunks':parts},ensure_ascii=False))
if __name__=='__main__': main()
