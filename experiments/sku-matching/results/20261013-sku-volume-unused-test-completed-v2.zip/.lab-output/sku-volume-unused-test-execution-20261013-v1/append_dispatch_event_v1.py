"""Append one actual tool event as JSONL without shell-escaped delimiters."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--event-file", type=Path, required=True)
args = parser.parse_args()
data = args.event_file.read_bytes()
event = json.loads(data)
if not isinstance(event, dict) or not isinstance(event.get("event"), str):
    raise ValueError("one complete event object is required")
line = json.dumps(event, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode() + bytes([10])
ledger = Path(__file__).resolve().parent / "supervisor-dispatch-ledger.jsonl"
with ledger.open("ab") as stream:
    stream.write(line)
print(json.dumps({"event": event["event"], "event_file_sha256": hashlib.sha256(data).hexdigest(),
                  "appended_line_bytes": len(line), "earlier_ledger_bytes_changed": False}))
