"""Append actual supervisory events; no classifier or source semantics."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

E = Path(__file__).resolve().parent
D = E / "supervisor-v2-events"
D.mkdir(exist_ok=True)
p = argparse.ArgumentParser()
p.add_argument("event", choices=["spawn_call", "worker_final", "worker_failure"])
p.add_argument("packet", type=int)
p.add_argument("--tool-result", type=json.loads)
p.add_argument("--final-message")
p.add_argument("--note")
a = p.parse_args()
n = a.packet
desc = E / "root-supervisor-prompts" / f"packet-{n}.spawn-input.json"
d = json.loads(desc.read_text())
ev = {"event": a.event, "utc_time": datetime.datetime.now(datetime.timezone.utc).isoformat(),
      "assigned_packet": d["packet"]}
if a.event == "spawn_call":
    assert a.tool_result and "task_name" in a.tool_result
    ev.update(requested_model=d["model"], fork_turns=d["fork_turns"], task_name=d["task_name"],
              returned_task_name=a.tool_result["task_name"], actual_tool_result=a.tool_result,
              actual_message=d["message"], descriptor_path=str(desc),
              descriptor_sha256=hashlib.sha256(desc.read_bytes()).hexdigest(),
              task_text_sha256=d["task_text_sha256"])
    suffix = "spawn"
else:
    sp = json.loads((D / f"packet-{n}-spawn.json").read_text())
    assert a.final_message is not None
    ev.update(task_name=sp["returned_task_name"], original_final_message=a.final_message)
    draft = E / "drafts" / f"packet-{n}.jsonl"
    ev["draft_exists"] = draft.exists()
    if draft.exists():
        data = draft.read_bytes()
        ev.update(draft_path=str(draft), draft_bytes=len(data), draft_sha256=hashlib.sha256(data).hexdigest())
    suffix = "terminal"
if a.note:
    ev["metadata_note"] = a.note
out = D / f"packet-{n}-{suffix}.json"
with out.open("x") as f:
    f.write(json.dumps(ev, ensure_ascii=False, indent=2) + "\n")
subprocess.run(["python3", "-B", str(E / "append_dispatch_event_v1.py"), "--event-file", str(out)], check=True)
events = [json.loads(x.read_text()) for x in D.glob("packet-*.json")]
spawned = sorted(int(x["assigned_packet"].split("-")[1].split(".")[0]) for x in events if x["event"] == "spawn_call")
terminal = sorted(int(x["assigned_packet"].split("-")[1].split(".")[0]) for x in events if x["event"] in ("worker_final", "worker_failure"))
state = {"last_updated_utc": ev["utc_time"], "assigned": spawned, "terminal": terminal,
         "active": sorted(set(spawned) - set(terminal)), "next_unassigned": max(spawned, default=108) + 1,
         "assigned_count": len(spawned), "terminal_count": len(terminal)}
(E / "supervisor-v2-state.json").write_text(json.dumps(state, indent=2) + "\n")
print(json.dumps({k: state[k] for k in ("active", "next_unassigned", "assigned_count", "terminal_count")}))
