"""Log explicitly supplied actual spawn receipts and received final messages."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path

EX = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--actual-spawns", nargs="*", default=[])
parser.add_argument("--received-finals", type=Path)
args = parser.parse_args()
events = []
at = datetime.datetime.now(datetime.timezone.utc).isoformat()
for receipt in args.actual_spawns:
    number, name = receipt.split(":", 1)
    stem = f"packet-{int(number):02d}"
    descriptor = json.loads((EX / "root-supervisor-prompts" / (stem + ".spawn-input.json")).read_text())
    if name != "/root/" + descriptor["task_name"]:
        raise ValueError("actual returned name differs from the prepared task")
    events.append({"event": "spawn_call", "utc_time": at,
                   "timestamp_kind": "recorded_after_actual_tool_return", "model": "gpt-6-luna",
                   "requested_model": "gpt-6-luna", "fork_turns": "none",
                   "task_name": descriptor["task_name"], "assigned_packet": stem + ".json",
                   "returned_task_name": name, "actual_tool_return": {"task_name": name},
                   "returned_status": "tool_returned_task_name_without_explicit_status",
                   "actual_tool_message": descriptor["message"],
                   "task_text_path": descriptor["task_text_path"],
                   "task_text_sha256": descriptor["task_text_sha256"], "dispatcher": "root_direct"})
if args.received_finals:
    received = json.loads(args.received_finals.read_text())
    for item in received:
        number, name = item["packet_number"], item["actual_sender"]
        if name != f"/root/volume_packet_{number:03d}":
            raise ValueError("original final sender differs from task name")
        path = EX / "drafts" / f"packet-{number:02d}.jsonl"
        event = {"event": item.get("event", "worker_final"), "utc_time": at,
                 "timestamp_kind": "recorded_after_original_final_received",
                 "task_name": name, "assigned_packet": f"packet-{number:02d}.json",
                 "final_message": item["final_message"], "dispatcher": "root_direct"}
        if path.exists():
            data = path.read_bytes()
            event.update({"draft_path": str(path), "draft_bytes": len(data),
                          "draft_sha256": hashlib.sha256(data).hexdigest()})
        events.append(event)
with (EX / "supervisor-dispatch-ledger.jsonl").open("ab") as output:
    for event in events:
        output.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")).encode() + bytes([10]))
print(json.dumps({"actual_spawn_receipts_recorded": len(args.actual_spawns),
                  "actual_received_final_messages_recorded": len(events) - len(args.actual_spawns)}))
