"""Offline development scoring of previous errors only; no overall accuracy."""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path


def read(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--reference-dir', type=Path, required=True)
    p.add_argument('--baseline', type=Path, required=True)
    p.add_argument('--run', type=Path, action='append', required=True)
    p.add_argument('--output-dir', type=Path, required=True)
    args = p.parse_args()
    refpath = args.reference_dir / 'reference.jsonl'
    manifest = json.loads((args.reference_dir / 'manifest.json').read_text())
    assert manifest['errors_only'] is True and manifest['development_only'] is True
    assert manifest['output_sha256']['reference.jsonl'] == sha(refpath)
    assert manifest['baseline_predictions_sha256'] == sha(args.baseline)
    refs = read(refpath)
    ids = {r['request_id'] for r in refs}
    assert len(ids) == len(refs)
    baseline = {r['request_id']: r for r in read(args.baseline)}
    binary = lambda state: 'accept' if state == 'support' else 'drop'
    for r in refs:
        assert r['expected_binary'] in {'accept', 'drop'}
        assert r['previous_state'] == baseline[r['request_id']]['state']
        assert r['previous_binary'] == binary(r['previous_state']) != r['expected_binary']
    scores, details = {}, []
    for run in args.run:
        summary = json.loads((run / 'summary.json').read_text())
        variant = summary.get('variant', {'scoped-condition-nli-v1': 'nli',
                      'scoped-condition-nli-veto-v1': 'gliner_nli_veto'}.get(summary['schema_version']))
        assert isinstance(variant, str) and variant not in scores
        for name, value in summary['output_sha256'].items():
            assert sha(run / name) == value, (run, name)
        preds = read(run / 'predictions.jsonl')
        assert len(preds) == len(ids) and {r['request_id'] for r in preds} == ids
        by_id = {r['request_id']: r for r in preds}
        counts = Counter()
        for ref in refs:
            pred = by_id[ref['request_id']]
            assert pred['production_adoption_allowed'] is False
            assert pred['state'] in {'support', 'conflict', 'unknown'}
            corrected = binary(pred['state']) == ref['expected_binary']
            counts[ref['previous_error_kind'] + ('_corrected' if corrected else '_remaining')] += 1
            details.append({**ref, 'variant': variant, 'new_state': pred['state'],
                            'new_binary': binary(pred['state']), 'corrected': corrected})
        scores[variant] = {
            'selected_previous_errors': len(refs), 'corrected_errors': sum(d['corrected'] for d in details if d['variant'] == variant),
            'counts': dict(counts), 'prediction_states': dict(Counter(r['state'] for r in preds)),
            'window_status_counts': summary.get('window_status_counts'), 'inference_seconds': summary.get('inference_seconds'),
            'nli_inference_reused': summary.get('nli_inference_reused', False),
            'prediction_sha256': sha(run / 'predictions.jsonl')}
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / 'score.json').open('x') as stream:
        json.dump({'errors_only': True, 'development_only': True, 'independent_test': False,
                   'reference_kind': 'machine_labels_not_human_gold', 'production_adoption_allowed': False,
                   'metric_scope': 'selected-error corrections only; no overall precision, recall or accuracy',
                   'reference_sha256': sha(refpath), 'baseline_sha256': sha(args.baseline), 'variants': scores}, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    with (args.output_dir / 'cases.csv').open('x', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(dict.fromkeys(key for row in details for key in row)))
        writer.writeheader()
        writer.writerows(details)
    print(json.dumps(scores, ensure_ascii=False))


if __name__ == '__main__':
    main()
