"""Label-free score fusion on the two remaining real development errors."""
from collections import Counter
import json
from pathlib import Path
import shutil
import sys

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / 'experiments/sku-matching'))
from trial_scoped_condition_gliner_v1 import load_sources, read, sha, write_json, write_rows
from trial_scoped_condition_nli_v1 import verified_ref

BASE = ROOT / '.lab-output'
INPUT = BASE / 'sku-scoped-condition-inputs-20261011-v4'
NLI = BASE / 'sku-scoped-condition-nli-title-choice-20261011-v1'
JEV = BASE / 'sku-scoped-condition-jev-title-choice-described-20261011-v1'
RANKING = BASE / 'sku-claude-pr26-integrated-models-20261011-v5-v2'
OUT = BASE / 'sku-scoped-condition-fused-remaining-20261011-v2'


def main():
    assert not OUT.exists()
    manifest = json.loads((INPUT / 'manifest.json').read_text())
    assert manifest['errors_only'] and manifest['development_only'] and not manifest['labels_in_model_inputs']
    requests, documents, bindings, _, names, _, _ = load_sources(INPUT, RANKING)
    source = {}
    for label, directory in [('nli', NLI), ('jev', JEV)]:
        summary = json.loads((directory / 'summary.json').read_text())
        assert sha(directory / 'predictions.jsonl') == summary['output_sha256']['predictions.jsonl']
        source[label] = {r['request_id']: r for r in read(directory / 'predictions.jsonl')}
    OUT.mkdir()
    for name in ['manifest.json', *names]:
        shutil.copyfile(INPUT / name, OUT / ('source-' + name))
    shutil.copyfile(Path(__file__), OUT / 'code.py')
    freeze = {'schema_version': 'scoped-condition-score-fusion-v1', 'variant': 'equal-score-fusion-remaining',
        'request_count': len(requests), 'labels_read': False, 'errors_only': True, 'development_only': True,
        'production_adoption_allowed': False, 'scope_status': 'unproved', 'new_inference': False,
        'independent_test': False, 'previously_correct_cases_not_scored': True,
        'policy': 'JEV unknown/error/tie remains unknown; otherwise mean of NLI relative entailment and JEV candidate scores; unique selected winner supports',
        'input_sha256': {name: sha(INPUT / name) for name in ['manifest.json', *names]},
        'code_sha256': sha(Path(__file__)),
        'model_prediction_sha256': {'nli': sha(NLI / 'predictions.jsonl'), 'jev': sha(JEV / 'predictions.jsonl')}}
    write_json(OUT / 'freeze.json', freeze)
    predictions = []
    for request in requests:
        nli, jev = (source[label][request['request_id']] for label in ['nli', 'jev'])
        for prediction in [nli, jev]:
            assert prediction['source_request'] == request
            assert prediction['production_adoption_allowed'] is False
        control = json.loads((JEV / 'freeze.json').read_text())['unknown_control_label']
        scores = None
        winner = None
        candidate = jev['candidate_record']
        valid = candidate['status'] == 'ok' and not jev['tie'] and jev['winning_value'] != control
        if valid and nli['relative_entailment_scores'] is not None:
            assert set(nli['relative_entailment_scores']) == set(request['option_values'])
            assert set(candidate['probabilities']) == set(request['option_values']) | {control}
            scores = {v: .5 * nli['relative_entailment_scores'][v] + .5 * candidate['probabilities'][v] for v in request['option_values']}
            leaders = [v for v, score in scores.items() if score == max(scores.values())]
            winner = leaders[0] if len(leaders) == 1 else None
        support = winner == request['selected_value']
        refs = nli['candidate_records'][0]['quote_refs'] if support else []
        assert not support or (refs and all(verified_ref(ref, request, documents) for ref in refs))
        predictions.append({'request_id': request['request_id'], 'request_sha256': request['request_sha256'],
            'selected_value': request['selected_value'], 'state': 'support' if support else 'unknown',
            'winning_value': winner, 'quote_refs': refs,
            'source_request': request, 'source_task_bindings': bindings[request['request_id']],
            'source_nli_prediction': nli, 'source_jev_prediction': jev, 'fused_scores': scores,
            'scope_status': 'unproved', 'production_adoption_allowed': False, 'variant': freeze['variant']})
    write_rows(OUT / 'predictions.jsonl', predictions)
    write_json(OUT / 'summary.json', {**freeze, 'inference_seconds': None,
        'prediction_states': dict(Counter(p['state'] for p in predictions)),
        'output_sha256': {p.name: sha(p) for p in OUT.iterdir() if p.is_file()}})
    print(Counter(p['state'] for p in predictions))


if __name__ == '__main__':
    main()
