"""Label-free CPU development probe of raw alternatives plus an unknown choice."""
import argparse
from collections import Counter
from pathlib import Path
import shutil
import sys

ROOT = Path.cwd()
HERE = ROOT / 'experiments/sku-matching'
sys.path.insert(0, str(HERE))
import trial_generic_model_jev_v1 as JEV
from trial_scoped_condition_gliner_v1 import load_sources, quote_ref, sha, write_json, write_rows

UNKNOWN = '記載から特定できない（診断用）'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input-dir', type=Path, required=True)
    p.add_argument('--ranking-dir', type=Path, required=True)
    p.add_argument('--output-dir', type=Path, required=True)
    args = p.parse_args()
    out = args.output_dir
    if out.exists():
        raise FileExistsError(out)
    requests, documents, bindings, _, names, ranknames, _ = load_sources(args.input_dir, args.ranking_dir)
    import json
    manifest = json.loads((args.input_dir / 'manifest.json').read_text())
    assert manifest['errors_only'] and manifest['development_only'] and not manifest['labels_in_model_inputs']
    choices = []
    for request in requests:
        assert UNKNOWN not in request['option_values']
        document = documents[request['target_document_id']]
        choices.append({'id': request['request_id'],
            'question': '現在の商品について、「' + request['axis_name'] + '」に該当する選択肢はどれですか。記載から特定できない場合は、その選択肢を選んでください。',
            'state': '現在の商品名：' + document['title']['text'] + '\n現在の選択行：\n' + request['target_selected_axes_text'],
            'choices': [{'label': value, 'description': ''} for value in request['option_values']] +
                       [{'label': UNKNOWN, 'description': '商品名と選択行から、この条件の該当する値を特定できない。'}]})
    out.mkdir(parents=True, exist_ok=False)
    for name in ['manifest.json', *names]:
        shutil.copyfile(args.input_dir / name, out / ('source-' + name))
    code = out / 'code'
    code.mkdir()
    for source in [Path(__file__), HERE / 'trial_generic_model_jev_v1.py', HERE / 'trial_scoped_condition_gliner_v1.py',
                   HERE / 'trial_generic_gliner_choice_v1.py', HERE / 'try_gliner.py']:
        shutil.copyfile(source, code / source.name)
    freeze = {'schema_version': 'scoped-condition-jev-choice-v1', 'variant': 'jev-title-choice',
        'labels_read': False, 'errors_only': True, 'development_only': True, 'independent_test': False,
        'production_adoption_allowed': False, 'synthetic_data': False, 'scope_status': 'unproved',
        'body_model_input': False, 'new_retrieval_run': False, 'request_count': len(requests),
        'candidate_pair_count': sum(len(c['choices']) for c in choices), 'unknown_control_label': UNKNOWN,
        'source_selected_value_in_question_or_state': False, 'all_original_options_preserved': True,
        'policy': 'unique highest scalar score; alternate/unknown/error/tie drops; uncalibrated candidate ranking',
        'threads': 4, 'batch_size': 16, 'model_pin': JEV._pins(),
        'input_sha256': {name: sha(args.input_dir / name) for name in ['manifest.json', *names]},
        'received_source_contract_sha256': {name: sha(args.ranking_dir / name) for name in ['summary.json', *ranknames]},
        'code_sha256': {source.name: sha(source) for source in code.iterdir()}}
    write_json(out / 'freeze.json', freeze)
    write_rows(out / 'model-requests.jsonl', choices)
    result = JEV.run_choices(choices, model_dir=ROOT / '.deps/sku-modernbert-jev-model', threads=4, batch_size=16,
        on_ready=lambda pins, runtime: write_json(out / 'model-ready.json', {'pins': pins, 'runtime': runtime}))
    records = result['records']
    assert [r['id'] for r in records] == [r['request_id'] for r in requests]
    write_rows(out / 'classification-options.jsonl', records)
    predictions = []
    for request, record in zip(requests, records, strict=True):
        winner = record['argmax_label']
        tie = record['status'] == 'ok' and sum(v == max(record['logits'].values()) for v in record['logits'].values()) != 1
        support = record['status'] == 'ok' and not tie and winner == request['selected_value']
        doc = documents[request['target_document_id']]
        refs = [quote_ref(doc, field, text) for field, text in [('title', doc['title']['text']),
                ('selected_axes', request['target_selected_axes_text'])] if text]
        predictions.append({'request_id': request['request_id'], 'request_sha256': request['request_sha256'],
            'selected_value': request['selected_value'], 'direction': request['direction'],
            'state': 'support' if support else 'unknown', 'winning_value': winner,
            'source_request': request, 'source_task_bindings': bindings[request['request_id']],
            'quote_refs': refs if support else [], 'scope_status': 'unproved', 'production_adoption_allowed': False,
            'candidate_record': record, 'tie': tie, 'variant': freeze['variant']})
    write_rows(out / 'predictions.jsonl', predictions)
    summary = {**freeze, 'model_pin': result['pins'], 'runtime': result['runtime'],
        'inference_seconds': result['runtime']['inference_seconds'],
        'prediction_states': dict(Counter(r['state'] for r in predictions)),
        'output_sha256': {source.name: sha(source) for source in out.iterdir() if source.is_file()}}
    write_json(out / 'summary.json', summary)
    print(summary['prediction_states'], summary['inference_seconds'])


if __name__ == '__main__':
    main()
