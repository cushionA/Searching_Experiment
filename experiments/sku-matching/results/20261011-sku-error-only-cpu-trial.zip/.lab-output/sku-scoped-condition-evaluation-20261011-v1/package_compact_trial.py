"""Package fixed real-error development inputs, outputs and integrity receipts."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path.cwd()
BASE = ROOT / '.lab-output'
EVAL = BASE / 'sku-scoped-condition-evaluation-20261011-v1'
PREFIX = ROOT / 'experiments/sku-matching/results/20261011-sku-error-only-cpu-trial'
RUNS = ['sku-scoped-condition-entailment-20261011-v1', 'sku-scoped-condition-ownership-20261011-v1',
        'sku-scoped-condition-nli-20261011-v1', 'sku-scoped-condition-nli-veto-20261011-v1',
        'sku-scoped-condition-nli-title-choice-20261011-v1', 'sku-scoped-condition-jev-title-choice-20261011-v1',
        'sku-scoped-condition-jev-title-choice-described-20261011-v1',
        'sku-scoped-condition-fused-remaining-20261011-v2']
REPORT = ROOT / 'experiments/sku-matching/sku-scoped-condition-error-trial-20261011.txt'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    targets = [Path(str(PREFIX) + suffix) for suffix in ('.zip', '.manifest.json', '.zip.sha256')]
    assert not any(path.exists() for path in targets)
    sources = {REPORT}
    for folder in ['sku-scoped-condition-inputs-20261011-v3', 'sku-scoped-condition-reference-20261011-v3',
                   'sku-scoped-condition-inputs-20261011-v4', 'sku-scoped-condition-reference-20261011-v4']:
        sources.update(p for p in (BASE / folder).iterdir() if p.is_file())
    for run in RUNS:
        directory = BASE / run
        summary = json.loads((directory / 'summary.json').read_text())
        for name, expected in summary['output_sha256'].items():
            assert sha((directory / name).read_bytes()) == expected
        sources.update(p for p in directory.iterdir() if p.is_file())
        if (directory / 'code').exists():
            sources.update((directory / 'code').iterdir())
    sources.update(p for p in EVAL.iterdir() if p.is_file())
    sources.update((EVAL / 'final-complete').iterdir())
    sources.update((EVAL / 'remaining-two').iterdir())
    for name in ['sku-scoped-condition-tests-20261011-v1.log',
                 'sku-scoped-condition-nli-contract-tests-20261011.log',
                 'sku-scoped-condition-nli-choice-contract-tests-final-20261011.log',
                 'sku-scoped-condition-full-tests-final2-20261011-v1.log']:
        sources.add(BASE / name)
    sources.update(BASE / (name + '.log') for name in RUNS if name not in {
        'sku-scoped-condition-nli-veto-20261011-v1', 'sku-scoped-condition-fused-remaining-20261011-v2'})
    sources.update((BASE / 'sku-scoped-condition-selector-review-20261011-v1').iterdir())
    sources.update(ROOT / 'tests' / name for name in [
        'test_lab_sku_scoped_condition_models.py', 'test_lab_sku_scoped_condition_nli.py', 'test_lab_sku_scoped_condition_nli_choice.py'])
    docs = [json.loads(line) for line in (BASE / 'sku-scoped-condition-inputs-20261011-v3/documents.jsonl').read_text().splitlines()]
    for doc in docs:
        for ref in doc['title']['source_refs']:
            path = ROOT / ref['raw_file']
            assert sha(path.read_bytes()) == ref['sha256']
            sources.add(path)
    dependency = ROOT / 'experiments/sku-matching/results/20261011-sku-pr26-v5-description-integration.zip'
    expected_dependency = '01e282a8d6519baf6adcba025afd5d1fc3e649899f446f49aee9bc91111c5b01'
    assert sha(dependency.read_bytes()) == expected_dependency
    payloads = []
    with zipfile.ZipFile(targets[0], 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source in sorted(sources):
            assert source.is_file() and not source.is_symlink()
            member = source.relative_to(ROOT).as_posix()
            assert not member.startswith('/') and '..' not in Path(member).parts
            data = source.read_bytes()
            archive.writestr(member, data)
            payloads.append({'path': member, 'size_bytes': len(data), 'sha256': sha(data)})
        checkpoint = {'schema_version': 'sku-error-only-cpu-checkpoint-v1', 'errors_only': True,
            'real_request_count': 17, 'machine_references_not_human_gold': True, 'independent_test': False,
            'subsequent_remaining_error_count': 2, 'previous_fifteen_cases_not_rescored_after_score_fusion': True,
            'production_adoption_allowed': False, 'all_case_scores_are_development_error_corrections': True,
            'normal_case_regressions_not_measured': True, 'claude_alignment_unchanged': True,
            'excluded_large_received_ranking_dependency': {'path': str(dependency.relative_to(ROOT)),
                'sha256': expected_dependency, 'reason': 'Frozen full ranking/source inputs required for rerun; selected passages included here.'},
            'weights_and_venvs_included': False, 'payloads': payloads}
        archive.writestr('SKU_ERROR_ONLY_CHECKPOINT.json', json.dumps(checkpoint, ensure_ascii=False, indent=2) + '\n')
    data = targets[0].read_bytes()
    external = {**checkpoint, 'archive': {'path': str(targets[0].relative_to(ROOT)), 'size_bytes': len(data), 'sha256': sha(data)}}
    targets[1].open('x').write(json.dumps(external, ensure_ascii=False, indent=2) + '\n')
    targets[2].open('x').write(sha(data) + '  ' + targets[0].name + '\n')
    print(json.dumps({'archive_bytes': len(data), 'archive_sha256': sha(data), 'payload_count': len(payloads)}))


if __name__ == '__main__':
    main()
