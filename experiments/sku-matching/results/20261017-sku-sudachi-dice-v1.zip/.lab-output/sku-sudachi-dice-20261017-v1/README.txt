Sudachi Core/Full + character bigram ranking experiment v1 (2026-10-17 JST)

Base repository: 21821f54e0f1a346723f5a1b5b0d2d7d540fd81e
Branch: codex-sku-generic-model-gates-20261010
Read experiments/sku-matching/results/20261017-sku-sudachi-dice-v1.txt first.
The external 80-case CSV and comparison ZIP were not supplied; their 60/60 and
11/6/3 counts are NOT reproduced. This is a separate diagnostic on the existing
historical grouped EVALtest cohort, not a fresh independent or human-gold test.

Data: 1332 cases /113 products /26996 candidate rows /120145 conditions.
Fixed rank variants: NFKC/lower/whitespace-only; Core/Full normalized forms A/B/C.
Core/Full both 20260723.1, SudachiPy0.7.0. Prices use the old frozen price-free view.
All original rows/conditions retained, same source-order ties. Ranking never
certifies matches or absence. Existing current+dictionary2 states stay immutable.
Extra normalization gate preserves numerical strings and ASCII identifiers.
PLAN -> predictions FREEZE -> selected historical reference GRADE; no post-grade
rule tuning. Production gate unchanged; zero model calls or weight downloads.

The ZIP stores observations, views, rankings, all gate predictions, plan, freeze,
grade, audit, tests/logs and result CSV. MANIFEST.json pins every other member.
Entry paths are repository-relative. Extract into a separate copy of the base
repository; old receipts should remain unchanged. Replaying all existing input
hash checks requires the base commit's volume/axis-domains/dictionary-half
workspace artifacts. Original source archives/binaries are not duplicated.

Install Full separately (does not modify the old dedicated venv):
.deps/sku-classical-venv/bin/python -m pip install --no-deps --target .deps/sku-sudachi-full-20261017-v1 SudachiDict-full==20260723.1
Core is the already-installed SudachiDict-core==20260723.1 in the same venv.
Do not substitute newest dictionaries. PLAN.json pins both binary files by SHA256
and size. No network or model download is needed after dictionary installation.
Dictionary files are 202219619 and330563683 bytes and are not included in this ZIP.

Commands (refuse to overwrite run-v1 or GRADE.json; rerun in a clean restored copy):
.deps/sku-classical-venv/bin/python -B experiments/sku-matching/run_sudachi_dice_v1.py run
.deps/sku-classical-venv/bin/python -B experiments/sku-matching/run_sudachi_dice_v1.py grade
.deps/sku-classical-venv/bin/python -B -m unittest tests/test_lab_sku_sudachi_dice.py -v

Absolute original workspace paths are /workspace/Searching_Experiment. Relocated
runs need new receipts; do not edit original freeze files to bypass checks.
Node24.19.0 parity test needs node on PATH. It compares901 observed/edge strings
and144 synthetic score pairs; this does not establish all-Unicode equivalence.
No npm dependencies or production TypeScript integration were added.

6 new focused tests pass. Required full suite1577 tests has the same prior
4 failures /66 errors /60 skips (all70 failure/error names unchanged).
