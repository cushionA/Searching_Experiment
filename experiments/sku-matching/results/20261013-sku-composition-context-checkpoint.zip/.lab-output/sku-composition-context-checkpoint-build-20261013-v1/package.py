from __future__ import annotations

import hashlib
import json
import os
import subprocess
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "experiments/sku-matching/results"
STEM = "20261013-sku-composition-context-checkpoint"
ARCHIVE = RESULTS / f"{STEM}.zip"
MANIFEST_PATH = RESULTS / f"{STEM}.manifest.json"

CONTEXT_ROOT = ".lab-output/sku-composition-context-20261013-v1"
RESUME_ROOT = ".lab-output/sku-composition-context-resume-20261013-v1"
DIAGNOSIS_ROOT = ".lab-output/sku-composition-remaining-diagnosis-20261013-v1"
REVIEW_ROOT = ".lab-output/sku-composition-context-review-20261013-v1"
RUN_ROOTS = (CONTEXT_ROOT, RESUME_ROOT, DIAGNOSIS_ROOT, REVIEW_ROOT)
EVALUATION_ROOT = f"{CONTEXT_ROOT}/evaluation"
POLICIES = ("complete-context-fallback", "context-replace")

EXACT_FILES = (
    "experiments/sku-matching/composition_context_v1.py",
    "experiments/sku-matching/composition_context_policy_v1.py",
    "experiments/sku-matching/trial_composition_context_v1.py",
    "tests/test_lab_sku_composition_context.py",
    "tests/test_lab_sku_composition_context_policy.py",
    "tests/test_lab_sku_composition_context_trial.py",
    "experiments/sku-matching/composition-context-result-20261013.txt",
    "experiments/sku-matching/session-result-20261012.txt",
    ".lab-output/sku-composition-context-checkpoint-build-20261013-v1/package.py",
)
DEPENDENCIES = (
    (
        "experiments/sku-matching/results/20261013-sku-composition-evidence-checkpoint.zip",
        "13de386a769383a2828fd6b78ef941d393810c282c415dc770dd14bcbd2aa139",
    ),
    (
        "experiments/sku-matching/results/20261012-sku-mixed-cpu-checkpoint.zip",
        "f55928415f5028f6b110e44e68f936b03adbad177da1be58da3d3ee58fc4a951",
    ),
    (
        "experiments/sku-matching/results/20261012-sku-mixed-gates-improvement-checkpoint.zip",
        "26ddd2289ea44072a37f7aa677bd078372644fbb7e59b063c84b18f9c182c11c",
    ),
    (
        "experiments/sku-matching/results/20261012-sku-followup-checkpoint.zip",
        "3d013ed382adc4467d97575ae3602d162e2a8a1ea84d3087a622bdcadf186cf5",
    ),
    (
        "experiments/sku-matching/results/20261012-sku-option-context-checkpoint.zip",
        "beeb336a455a32d324dec03c103ee412e06e236ff1aed92353d0a7ff389567a0",
    ),
    (
        "experiments/sku-matching/results/20261012-sku-value-equivalence-integration-checkpoint.zip",
        "a0579182143d6d496e1acb95af46e741b47f3f2e2a15f0986ad81ab2642fe747",
    ),
)
SKIP_PARTS = {
    "__pycache__", "models", ".deps", ".aws", ".codex", ".git",
    "secrets", "credentials", "cache", "caches", "weights", "model_weights",
    "venv", ".venv", "node_modules",
}
WEIGHT_SUFFIXES = (".safetensors", ".pt", ".pth", ".ckpt", ".bin")
REQUIRED_CONTEXT_ARTIFACTS = (
    f"{CONTEXT_ROOT}/freeze.json",
    f"{CONTEXT_ROOT}/assembly-freeze.json",
    f"{CONTEXT_ROOT}/dispatch-trace.json",
    f"{CONTEXT_ROOT}/evaluation/summary.json",
    f"{EVALUATION_ROOT}/execution-freeze.json",
    f"{EVALUATION_ROOT}/all-gates-frozen.json",
    f"{RESUME_ROOT}/code-history/runner-at-input-freeze.py",
    f"{RESUME_ROOT}/code-history/composition_context_policy_v1_initial_reconstructed.py",
    f"{RESUME_ROOT}/code-history/edit-trace.md",
    f"{RESUME_ROOT}/composition-tests.log",
    f"{RESUME_ROOT}/required-tests.log",
    f"{RESUME_ROOT}/composition-tests-final.log",
    f"{RESUME_ROOT}/required-tests-final.log",
    f"{RESUME_ROOT}/read-only-review.json",
    f"{RESUME_ROOT}/evaluation.log",
    f"{REVIEW_ROOT}/review.json",
    f"{DIAGNOSIS_ROOT}/diagnosis.json",
)
REQUIRED_OUTPUTS = tuple(
    f"{EVALUATION_ROOT}/{policy}/{relative}"
    for policy in POLICIES
    for relative in (
        "predictions.jsonl",
        "gates/decisions.jsonl",
        "gates/row_results.jsonl",
        "gates/condition_results.jsonl",
        "gates/manifest.json",
    )
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_value(*args: str) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=ROOT, text=True, stderr=subprocess.DEVNULL
    ).strip()


def safe_relative(name: str) -> Path:
    relative = Path(name)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"invalid archive path: {name}")
    return relative


def require_file(name: str) -> Path:
    path = ROOT / safe_relative(name)
    if not path.is_file() or path.is_symlink():
        raise FileNotFoundError(f"required file missing or unsafe: {name}")
    if any(part.lower() in SKIP_PARTS for part in Path(name).parts):
        raise ValueError(f"required file is under an excluded path: {name}")
    return path


def collect_paths() -> list[str]:
    names: set[str] = set()
    for root_name in RUN_ROOTS:
        root = ROOT / safe_relative(root_name)
        if not root.is_dir() or root.is_symlink():
            raise FileNotFoundError(f"required run directory missing or unsafe: {root_name}")
        for current, directories, filenames in os.walk(root, followlinks=False):
            current_path = Path(current)
            retained = []
            for dirname in directories:
                child = current_path / dirname
                if dirname.lower() in SKIP_PARTS:
                    continue
                if child.is_symlink():
                    raise ValueError(f"symlink in allowlisted source tree: {child.relative_to(ROOT)}")
                retained.append(dirname)
            directories[:] = retained
            for filename in filenames:
                path = current_path / filename
                relative_name = path.relative_to(ROOT).as_posix()
                if path.is_symlink():
                    raise ValueError(f"symlink in allowlisted source tree: {relative_name}")
                names.add(relative_name)

    names.update(EXACT_FILES)
    names.update(REQUIRED_CONTEXT_ARTIFACTS)
    names.update(REQUIRED_OUTPUTS)
    for name in names:
        require_file(name)
    if any(Path(name).suffix.lower() in WEIGHT_SUFFIXES for name in names):
        raise ValueError("model-weight file found in the allowlisted package")
    return sorted(names)


def verify_summary_outputs(summary_path: Path) -> dict:
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    output_hashes = summary.get("output_sha256")
    if not isinstance(output_hashes, dict) or not output_hashes:
        raise ValueError(f"summary has no valid output_sha256 map: {summary_path.relative_to(ROOT)}")
    for relative_name, expected_sha in output_hashes.items():
        relative = safe_relative(relative_name)
        path = summary_path.parent / relative
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f"summary output missing: {path.relative_to(ROOT)}")
        if digest(path.read_bytes()) != expected_sha:
            raise ValueError(f"summary output SHA256 mismatch: {path.relative_to(ROOT)}")
    return summary


def verify_context_claims(names: list[str]) -> None:
    freeze_path = ROOT / f"{CONTEXT_ROOT}/freeze.json"
    assembly_path = ROOT / f"{CONTEXT_ROOT}/assembly-freeze.json"
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    assembly = json.loads(assembly_path.read_text(encoding="utf-8"))
    dispatch = json.loads((ROOT / f"{CONTEXT_ROOT}/dispatch-trace.json").read_text(encoding="utf-8"))
    if freeze.get("unit_count") != 82 or freeze.get("classification_unit_count") != 72 or freeze.get("no_evidence_unit_count") != 10:
        raise ValueError("input freeze must record 82 units: 72 classification and 10 no-evidence")
    if assembly.get("schema_version") != "composition-context-assembly-reconciliation-v1":
        raise ValueError("assembly-only reconciliation receipt has unexpected schema")
    original_freeze_sha = digest(freeze_path.read_bytes())
    if assembly.get("original_inference_freeze_sha256") != original_freeze_sha:
        raise ValueError("assembly receipt does not bind the preserved original inference freeze")
    if assembly.get("original_inference_freeze_preserved") is not True:
        raise ValueError("assembly receipt does not affirm preservation of original inference freeze")
    required_receipt_flags = {
        "all_model_packets_payloads_protocol_and_source_pins_unchanged": True,
        "responses_inspected_for_policy_selection": False,
        "gates_or_new_scores_created": False,
        "new_inference_or_changed_model_answers": False,
    }
    for key, expected in required_receipt_flags.items():
        if assembly.get(key) is not expected:
            raise ValueError(f"assembly receipt {key} must equal {expected!r}")
    changed_paths = assembly.get("assembly_only_changed_paths")
    if not isinstance(changed_paths, list):
        raise ValueError("assembly receipt must enumerate assembly-only reconciled code changes")
    allowed_changed = {
        "experiments/sku-matching/trial_composition_context_v1.py",
        "experiments/sku-matching/composition_context_policy_v1.py",
    }
    changed_by_path = {}
    for changed in changed_paths:
        recorded = changed.get("path")
        if not isinstance(recorded, str):
            raise ValueError("malformed assembly reconciliation changed-path entry")
        rel = recorded[len(str(ROOT)) + 1:] if recorded.startswith(str(ROOT) + "/") else recorded
        if rel not in allowed_changed:
            raise ValueError(f"assembly receipt names a disallowed changed path: {rel}")
        if rel in changed_by_path:
            raise ValueError(f"duplicate assembly changed-path receipt: {rel}")
        changed_by_path[rel] = changed
    if set(changed_by_path) != allowed_changed:
        raise ValueError("assembly receipt must contain exactly the two declared code paths")

    original_snapshot = freeze.get("source_snapshot")
    assembly_snapshot = assembly.get("source_snapshot")
    if not isinstance(original_snapshot, dict) or not isinstance(assembly_snapshot, dict):
        raise ValueError("original and assembly source snapshots must both be mappings")

    def normalize_snapshot_path(recorded_path: str) -> str:
        if not isinstance(recorded_path, str):
            raise ValueError("malformed source snapshot path")
        return recorded_path[len(str(ROOT)) + 1:] if recorded_path.startswith(str(ROOT) + "/") else recorded_path

    original_by_path = {normalize_snapshot_path(k): v for k, v in original_snapshot.items()}
    assembly_by_path = {normalize_snapshot_path(k): v for k, v in assembly_snapshot.items()}
    if len(original_by_path) != len(original_snapshot) or len(assembly_by_path) != len(assembly_snapshot):
        raise ValueError("duplicate paths in source snapshot")
    if not set(original_by_path).issubset(assembly_by_path):
        raise ValueError("assembly snapshot omits one or more original inference snapshot pins")
    for rel, original_entry in original_by_path.items():
        original_sha = original_entry.get("sha256") if isinstance(original_entry, dict) else None
        assembly_entry = assembly_by_path[rel]
        assembly_sha = assembly_entry.get("sha256") if isinstance(assembly_entry, dict) else None
        receipt = changed_by_path.get(rel)
        if receipt is None:
            if assembly_sha != original_sha:
                raise ValueError(f"nonchanged original source pin differs in assembly snapshot: {rel}")
        elif receipt.get("before_sha256") != original_sha or receipt.get("after_sha256") != assembly_sha:
            raise ValueError(f"changed source receipt does not reconcile original and assembly pins: {rel}")

    # Verify every path/hash in the reconciled snapshot, including newly recorded
    # assembly artifacts; source change claims remain audit metadata, not a boundary.
    archived = set(names)
    for rel, entry in assembly_by_path.items():
        expected_sha = entry.get("sha256") if isinstance(entry, dict) else None
        source = require_file(rel)
        if rel in allowed_changed and rel not in archived:
            raise FileNotFoundError(f"reconciled assembly source not in package: {rel}")
        if digest(source.read_bytes()) != expected_sha:
            raise ValueError(f"assembly source snapshot SHA mismatch: {rel}")
    agents = dispatch.get("agents")
    if not isinstance(agents, list) or len(agents) != 4:
        raise ValueError("dispatch trace must cover four worker records")
    if dispatch.get("source_packet_count") != 72 or sum(a.get("assignment_count", 0) for a in agents) != 72:
        raise ValueError("dispatch trace must record coverage of 72/82 units")
    for agent in agents:
        for key in ("input_path", "output_path"):
            rel = agent.get(key)
            if not isinstance(rel, str) or rel not in names:
                raise FileNotFoundError(f"dispatch trace {key} is absent from checkpoint: {rel}")
            expected_sha = agent.get("input_sha256") if key == "input_path" else None
            if expected_sha and digest((ROOT / safe_relative(rel)).read_bytes()) != expected_sha:
                raise ValueError(f"worker input hash mismatch: {rel}")


def verify_evaluation(names: list[str]) -> None:
    summary_path = ROOT / f"{EVALUATION_ROOT}/summary.json"
    summary = verify_summary_outputs(summary_path)
    expected = {
        "model_input_unit_count": 72,
        "no_evidence_unit_count": 10,
        "all_case_count": 83,
        "experiment_status": "exploratory_dev_informed",
        "independent_test": False,
        "production_adoption_allowed": False,
    }
    for key, value in expected.items():
        if summary.get(key) != value:
            raise ValueError(f"evaluation summary {key} must equal {value!r}")
    if summary.get("labels_read_after_all_predictions_and_gates_frozen") is not True:
        raise ValueError("evaluation summary does not establish predictions/gates-before-labels ordering")
    identity = summary.get("model_identity", {})
    if identity.get("revision") != "hosted-alias-revision-unresolved/20261013" or identity.get("hosted_weights_revision_verified") is not False:
        raise ValueError("evaluation summary must disclose unresolved hosted model weights revision")
    expected_metrics = {
        "complete-context-fallback": (39, 1, 16, 17),
        "context-replace": (27, 0, 28, 18),
    }
    for policy, counts in expected_metrics.items():
        metrics = summary.get("policies", {}).get(policy, {}).get("scored_primary_reference_union", {})
        actual = tuple(metrics.get(key) for key in ("tp", "fp", "fn", "tn"))
        if actual != counts:
            raise ValueError(f"evaluation summary {policy} final metric counts mismatch: {actual}")
    for required in (f"{EVALUATION_ROOT}/execution-freeze.json", f"{EVALUATION_ROOT}/all-gates-frozen.json"):
        if required not in names:
            raise FileNotFoundError(f"required evaluation freeze missing: {required}")

    for policy in POLICIES:
        policy_root = ROOT / f"{EVALUATION_ROOT}/{policy}"
        prediction_path = policy_root / "predictions.jsonl"
        decisions_path = policy_root / "gates/decisions.jsonl"
        if sum(1 for _ in prediction_path.open(encoding="utf-8")) != 134:
            raise ValueError(f"{policy} must have 134 frozen predictions")
        if sum(1 for _ in decisions_path.open(encoding="utf-8")) != 83:
            raise ValueError(f"{policy} must have 83 frozen gate decisions")
        gate = json.loads((policy_root / "gates/manifest.json").read_text(encoding="utf-8"))
        if gate.get("case_count") != 83:
            raise ValueError(f"{policy} gate manifest must cover 83 cases")
        scope = gate.get("diagnostic_scope_policy", "")
        if "applicability is unproved" not in scope or gate.get("no_human_review_lane") is not True:
            raise ValueError(f"{policy} gate manifest must disclose unproved applicability and no human-review lane")
        if gate.get("production_adoption_allowed") is not False:
            raise ValueError(f"{policy} gate manifest must prohibit production adoption")


def main() -> None:
    if ARCHIVE.exists() or MANIFEST_PATH.exists():
        raise FileExistsError("refusing to overwrite an existing checkpoint or manifest")

    files = []
    payloads: dict[str, bytes] = {}
    for name in collect_paths():
        body = (ROOT / name).read_bytes()
        payloads[name] = body
        files.append({"path": name, "bytes": len(body), "sha256": digest(body)})

    names = [row["path"] for row in files]
    verify_context_claims(names)
    verify_evaluation(names)
    required_summaries = [Path(f"{EVALUATION_ROOT}/summary.json")]
    for name in names:
        if Path(name).name == "summary.json":
            required_summaries.append(Path(name))
    for summary_rel in sorted(set(required_summaries)):
        summary_path = ROOT / summary_rel
        verify_summary_outputs(summary_path)

    dependencies = []
    for name, expected_sha in DEPENDENCIES:
        path = require_file(name)
        actual_sha = digest(path.read_bytes())
        if actual_sha != expected_sha:
            raise ValueError(f"dependency SHA256 mismatch: {name}")
        dependencies.append({"path": name, "sha256": actual_sha})

    manifest = {
        "schema_version": "sku-composition-context-checkpoint-v1",
        "experiment_status": "exploratory_dev_informed",
        "branch": git_value("branch", "--show-current"),
        "head": git_value("rev-parse", "HEAD"),
        "independent_test_read": False,
        "model_weights_included": False,
        "production_adoption_allowed": False,
        "model_identity": {
            "alias": "gpt-6-luna",
            "revision": "hosted-alias-revision-unresolved/20261013",
            "revision_pinned": False,
        },
        "input_freeze_interpretation": "original inference input freeze preserved; assembly-only code revisions are disclosed and bound by assembly-freeze receipt; original code snapshot is not represented as entirely unchanged",
        "excluded_content": ["models", ".deps", "secrets", "credentials", "caches", "model weights"],
        "dependencies": dependencies,
        "file_count": len(files),
        "files": files,
        "restore_rule": "verify exact member names, CRC, byte counts and SHA256 before extraction; never overwrite a different existing source",
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()

    RESULTS.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for row in files:
            body = payloads[row["path"]]
            if len(body) != row["bytes"] or digest(body) != row["sha256"]:
                raise ValueError(f"source changed while packaging: {row['path']}")
            zipped.writestr(row["path"], body)
        zipped.writestr("CHECKPOINT_MANIFEST.json", manifest_bytes)

    with zipfile.ZipFile(ARCHIVE, "r") as zipped:
        expected_names = {row["path"] for row in files} | {"CHECKPOINT_MANIFEST.json"}
        names_in_archive = zipped.namelist()
        if (zipped.testzip() is not None or set(names_in_archive) != expected_names
                or len(names_in_archive) != len(expected_names)):
            raise ValueError("archive CRC or exact member-name verification failed")
        for row in files:
            body = zipped.read(row["path"])
            if len(body) != row["bytes"] or digest(body) != row["sha256"]:
                raise ValueError(f"archive member verification failed: {row['path']}")
        if zipped.read("CHECKPOINT_MANIFEST.json") != manifest_bytes:
            raise ValueError("embedded manifest verification failed")

    for row in files:
        current = (ROOT / row["path"]).read_bytes()
        if len(current) != row["bytes"] or digest(current) != row["sha256"]:
            raise ValueError(f"source changed during packaging: {row['path']}")

    archive_sha = digest(ARCHIVE.read_bytes())
    adjacent = dict(manifest)
    adjacent["archive"] = {
        "path": ARCHIVE.relative_to(ROOT).as_posix(),
        "bytes": ARCHIVE.stat().st_size,
        "sha256": archive_sha,
    }
    MANIFEST_PATH.write_text(
        json.dumps(adjacent, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "archive": str(ARCHIVE),
        "manifest": str(MANIFEST_PATH),
        "archive_bytes": ARCHIVE.stat().st_size,
        "archive_sha256": archive_sha,
        "verified_members": len(files),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
