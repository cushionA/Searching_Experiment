Composition context policy source history

- `composition_context_policy_v1_initial_reconstructed.py` reconstructs the initial helper from the implementation patch and subsequent recorded edits. Its SHA-256 is `34340e4e1d9031a3595d122d8b037e1a684dd987a79c61a3113be744d3e3b203`.
- The reported prepared/frozen helper SHA-256 `be2f67...` could not be matched to a recoverable local source version, so the reconstructed source is explicitly not represented as that frozen version.
- Current fix: collect every request ID bound to any case whose baseline decision is `accept`; do not add derived support for these requests when the baseline was not support; retain explicit nonselected whole-option abstention. Record any resulting support retraction in `reverted_request_ids`.
- Regression coverage: a newly supported competing row remains unknown in a previously accepted case; an explicit alternative still changes a previously accepted prediction to unknown.
- No evaluation output, worker response, or label was opened or examined semantically while making this fix. A read-only `rg -l` query for the frozen SHA across Python/JSON files in the named run directories returned no matching paths and may have traversed JSON files.
