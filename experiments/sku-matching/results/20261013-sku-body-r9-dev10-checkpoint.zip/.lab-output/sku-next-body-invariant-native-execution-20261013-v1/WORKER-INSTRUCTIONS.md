# SOURCEONLY R9 native whole-option review

These packets contain complete source-only public context from final source bundle R9-v3. It adds captured Rakuten `productDescription` passages only where the source adapter bound the field to the nearest `itemInfo.sku` object and verified exact source spans, including exact selector-value equality across native mirrors and the R8 inventory. Other records retain their complete body, family, row, and native SKU context. A missing native description remains unavailable; it is not a negative fact. No private validation binding, source-selected answer, task/request/case/row identity, score, prior prediction, grade, or label is supplied.

For each packet, author one complete JSONL response set in a **new** draft file, with exactly one compact JSON object on each physical line. Include one response per `pair_records` item in packet order and one decision per `candidate_vector` option in original order. Copy the exact pair `pair_id`, `cache_key`, option `whole_option`, and `option_evidence_id` from the packet. Use response protocol `sku-body-invariant-choice-v3`. Preserve the first-authored draft byte-for-byte; malformed or incomplete first output is a failed first pass and must not be semantically corrected or retried.

Assess every complete whole option independently. Author the state, scope, semantic relation, grounding route, target fact references, exclusivity assessment, and these three explanations for every option: `scope_and_coordinate_explanation`, `option_relation_explanation`, and `exclusivity_explanation`. Explain exclusivity even if uncertain. A different option winning, raw inequality, absent text, or assumed cross-source exclusivity does not establish conflict. Use `explicit_conflict` only for a directly assessed same-condition conflict with an explicit exclusivity basis. Unresolved scope, relation, or exclusivity requires `unknown`.

Ground positive claims through the applicable route:

- `selected_fact`: cite exact indices from `context.target_selected_facts`. Each selected fact exposes distinct native axis-name and value spans. This route does not require a body title.
- `selected_sku_body`: cite the target selected fact indices and exact target-body quotes; add one `body_condition_bindings` entry for each fact. Both body axis and value quotes must match that fact exactly.
- `body_invariant`: author every `body_invariant` field, cite `body_quote_refs` with exact quotes and offsets, assess positive target-product scope, and audit all target-native SKU family states in the exact supplied order. Body-only text does not prove a target match.
- `none`: if no route grounds the claim, use `state: "unknown"`, uncertain scope/relation where applicable, empty `target_fact_indices`, `body_quote_refs`, and `body_condition_bindings`, plus `body_invariant: null`.

For missing or ambiguous evidence, explicitly author unknown/uncertain values and empty arrays or `null`. Do not infer or generate states, winners, equality, categories, or default remainder from code, option index, order, or another option's judgment. Shared explanation wording is acceptable only when independently accurate for that whole option. Do not patch, normalize, fill, classify, or semantically retry any draft.

The canonical schema is `experiments/sku-matching/sku_body_invariant_choice_v3.schema.json`; the live validator, schema, and native wrapper hashes are checked by the CLI before persistence. The CLI checks structure, exact pair and option order, and supplied reference shape. It does not establish semantic truth or citation truth. Responses remain semantically unverified and sourceproof uncertified pending the separate full-source validator. No inference, labels, prior predictions, scores, grades, or production claims are authorized in this stage.

Synthetic-only shape illustration (not a judgment about any packet; this is not a complete response):

```json
{"protocol":"sku-body-invariant-choice-v3","pair_id":"SYNTHETIC_PAIR_ID","cache_key":"SYNTHETIC_CACHE_KEY","decisions":[{"option_index":0,"whole_option":"SYNTHETIC_WHOLE_OPTION","option_evidence_id":"SYNTHETIC_OPTION_EVIDENCE_ID","whole_value_assessed":true,"state":"unknown","scope_assessment":"uncertain","semantic_relation":"uncertain","scope_and_coordinate_explanation":"SYNTHETIC ONLY","option_relation_explanation":"SYNTHETIC ONLY","exclusivity_assessment":"uncertain","exclusivity_explanation":"SYNTHETIC ONLY","grounding_route":"none","target_fact_indices":[],"body_invariant":null,"body_quote_refs":[],"body_condition_bindings":[],"direct_contradiction_explanation":""}]}
```

After the new draft is first written, persist it without editing:

```sh
python3 -B experiments/sku-matching/sku_body_invariant_native_literal_cli_v1.py persist \
  --packet .lab-output/sku-next-body-invariant-native-execution-20261013-v1/packets/packet-NNN.json \
  --literal-json-file .lab-output/sku-next-body-invariant-native-execution-20261013-v1/drafts/packet-NNN.jsonl \
  --output .lab-output/sku-next-body-invariant-native-execution-20261013-v1/responses/packet-NNN.jsonl
```

The CLI rejects duplicate object keys, malformed arrays/JSONL, incomplete sets, packet SHA mismatches, and live source hash drift. It atomically creates a new output only after the full set validates. It never overwrites, appends to, repairs, or regenerates authored response text.
