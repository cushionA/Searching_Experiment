#!/usr/bin/env python3
"""Runtime adapter for grading selected DEV10 cases from one archival split."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
EXECUTION = ROOT / ".lab-output/sku-next-body-invariant-native-execution-20261013-v1"
GRADER_PATH = ROOT / "experiments/sku-matching/grade_next_body_invariant_dev10_r9_v1.py"
PARSER_PATH = ROOT / "experiments/sku-matching/grade_final_test_subset_v1.py"
EXPECTED_GRADER_SHA256 = "4dd4ffd40669bda49e8d1758f2414ab4729947883c6c09391a0f12a7a21339c6"
EXPECTED_PARSER_SHA256 = "4e4d41c0423ad6685a6c2ab4cbeef1b6bbe2dac165376ea9cf7db77410fdde11"
EXPECTED_FROZEN_RECEIPT_SHA256 = "e986645778ad2bf3c5b03bf7d255eadd96917bad4edc23d3dea281abc6c3ab1a"

sys.path.insert(0, str(ROOT / "experiments/sku-matching"))
import grade_final_test_subset_v1 as ORIGINAL_SCORE  # noqa: E402


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _build_adapted_parser():
    if sha_file(PARSER_PATH) != EXPECTED_PARSER_SHA256:
        raise ValueError("source reference parser changed from its reviewed frozen bytes")
    original_loader = inspect.getsource(ORIGINAL_SCORE.load_token_reference_shards)
    old = 'if not selected:\n            raise ValueError(f"frozen subset has no cases for required split {split}")'
    new = 'if not selected:\n            continue'
    if original_loader.count(old) != 1:
        raise ValueError("source parser empty-split guard differs from the one reviewed repair point")
    parser_globals = dict(vars(ORIGINAL_SCORE))
    parser_globals["__name__"] = "grade_final_test_subset_v1_runtime_adapter"
    adapted_source = original_loader.replace(old, new, 1)
    exec(compile(adapted_source, str(PARSER_PATH), "exec"), parser_globals)
    reader_source = inspect.getsource(ORIGINAL_SCORE.read_label_archives)
    exec(compile(reader_source, str(PARSER_PATH), "exec"), parser_globals)
    return parser_globals, adapted_source, reader_source


PARSER_GLOBALS, ADAPTED_LOADER_SOURCE, CLONED_ARCHIVE_READER_SOURCE = _build_adapted_parser()
ADAPTED_READ_LABEL_ARCHIVES = PARSER_GLOBALS["read_label_archives"]
SCORE_FACADE = SimpleNamespace(**vars(ORIGINAL_SCORE))
SCORE_FACADE.load_token_reference_shards = PARSER_GLOBALS["load_token_reference_shards"]
SCORE_FACADE.read_label_archives = ADAPTED_READ_LABEL_ARCHIVES


def _load_grader_alias():
    if sha_file(GRADER_PATH) != EXPECTED_GRADER_SHA256:
        raise ValueError("frozen R9 grader changed from the root-recorded bytes")
    spec = importlib.util.spec_from_file_location("grade_next_body_invariant_dev10_r9_runtime_alias", GRADER_PATH)
    if spec is None or spec.loader is None:
        raise ImportError("cannot load frozen R9 grader under runtime alias")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.SCORE = SCORE_FACADE
    return module


GRADE = _load_grader_alias()


def parser_adapter_receipt() -> dict:
    return {
        "schema_version": "body-dev10-r9-single-archival-split-adapter-v1",
        "behavior": "skip an archival split only when the frozen selected membership has zero cases in that split",
        "source_parser_sha256": sha_file(PARSER_PATH),
        "source_grader_sha256": sha_file(GRADER_PATH),
        "source_load_token_reference_shards_sha256": hashlib.sha256(
            inspect.getsource(ORIGINAL_SCORE.load_token_reference_shards).encode("utf-8")).hexdigest(),
        "adapted_load_token_reference_shards_sha256": hashlib.sha256(
            ADAPTED_LOADER_SOURCE.encode("utf-8")).hexdigest(),
        "read_label_archives_source_sha256": hashlib.sha256(
            CLONED_ARCHIVE_READER_SOURCE.encode("utf-8")).hexdigest(),
        "changed_source_lines": 1,
        "empty_selected_split_action": "continue_without_opening_or_hashing_that_archive",
        "nonempty_split_validation": "original_loader_logic_unchanged",
        "unsupported_source_versions": "original_read_label_archives_logic_unchanged",
        "freeze_receipt_sha256": EXPECTED_FROZEN_RECEIPT_SHA256,
        "labels_read_by_adapter_import": False,
        "scores_created_by_adapter_import": False,
        "predictions_or_gates_changed": False,
    }


def grade_with_adapter(root_go: Path, freeze: Path, output: Path,
                       membership: Path | None = None,
                       archive_v2: Path | None = None,
                       archive_v3: Path | None = None) -> dict:
    go = GRADE.read_json(root_go)
    receipt_path = Path(freeze)
    if sha_file(receipt_path) != EXPECTED_FROZEN_RECEIPT_SHA256:
        raise ValueError("all-predictions/all-gates freeze receipt SHA differs from the root-pinned freeze")
    if (go.get("root_go_for_body_dev10_grading") is not True
            or go.get("freeze_receipt_sha256") != sha_file(receipt_path)
            or go.get("grade_adapter_sha256") != sha_file(Path(__file__))
            or go.get("source_grader_sha256") != EXPECTED_GRADER_SHA256
            or go.get("source_reference_parser_sha256") != EXPECTED_PARSER_SHA256):
        raise PermissionError("grading requires root GO bound to this adapter, original code, and exact freeze")
    return GRADE.grade(root_go, receipt_path, membership or GRADE.COHORT / "membership.jsonl",
                       output, archive_v2 or ROOT / GRADE.SCORE.V2_LABEL_ARCHIVE,
                       archive_v3 or ROOT / GRADE.SCORE.V3_LABEL_ARCHIVE)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-go", type=Path, required=True)
    parser.add_argument("--freeze", type=Path, required=True)
    parser.add_argument("--membership", type=Path, default=GRADE.COHORT / "membership.jsonl")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--v2-label-archive", type=Path, default=ROOT / GRADE.SCORE.V2_LABEL_ARCHIVE)
    parser.add_argument("--v3-label-archive", type=Path, default=ROOT / GRADE.SCORE.V3_LABEL_ARCHIVE)
    args = parser.parse_args()
    result = grade_with_adapter(args.root_go, args.freeze, args.output, args.membership,
                                args.v2_label_archive, args.v3_label_archive)
    print(json.dumps({"phase": result["phase"], "labels_read_after_root_go": True,
                      "variant_names": sorted(result["variants"]),
                      "reference_parser_adapter_sha256": sha_file(Path(__file__))}, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
