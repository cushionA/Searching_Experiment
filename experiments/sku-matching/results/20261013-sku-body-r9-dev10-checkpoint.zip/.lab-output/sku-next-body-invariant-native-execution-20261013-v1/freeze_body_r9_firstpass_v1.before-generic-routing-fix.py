#!/usr/bin/env python3
"""Freeze the authorized immutable R9 first-pass response snapshot; never grade or repair."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
EXECUTION = ROOT / ".lab-output/sku-next-body-invariant-native-execution-20261013-v1"
PRE_ML = EXECUTION / "pre-ml-freeze.json"
ROOT_GO = EXECUTION / "root-classification-go.json"
PACKET_INDEX = EXECUTION / "packet-index.json"
EXPECTED_PRE_ML_SHA256 = "0a8d99e2e8f96be94b7a881be7fe73fa1ff56dbd6b0350abca44dcfcb91e9928"
EXPECTED_PRE_ML_PINS = 175
EXPECTED_PACKETS = 64
EXPECTED_DISPATCHED = 93
EXPECTED_PROTECTED = 48
PARTITION = ROOT / ".lab-output/sku-next-body-invariant-dev10-pair-partition-20261013-v5"
PREPARED = ROOT / ".lab-output/sku-next-body-invariant-v3-source-only-20261013-r9-v3"
PROOFS = ROOT / ".lab-output/sku-next-body-invariant-literal-proofs-20261013-v1"
DEFAULT_OUTPUT = EXECUTION / "firstpass-snapshot-v1"

sys.path.insert(0, str(ROOT / "experiments/sku-matching"))
import assemble_next_body_invariant_dev10_r9_v1 as ASSEMBLER  # noqa: E402


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def pin(path: Path) -> dict:
    return {"bytes": path.stat().st_size, "sha256": sha_file(path)}


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def verify_packet_index_authorization(index: dict, go: dict) -> None:
    """The immutable index records pre-inference state; root GO authorizes later calls."""
    if (index.get("inference_run") is not False
            or index.get("labels_read") is not False
            or index.get("scores_created") is not False
            or go.get("root_authorization") is not True
            or go.get("schema_version") != "sku-body-native-r9-root-classification-go-v1"):
        raise ValueError("packet index must remain pre-inference; actual calls require separate root GO")


def verify_tool_evidence(value: dict, go: dict) -> None:
    records = value.get("packet_records")
    if (value.get("schema_version") != "sku-body-native-r9-root-tool-execution-ledger-v1"
            or value.get("status") != "complete_root_tool_execution_ledger"
            or value.get("packet_count") != EXPECTED_PACKETS
            or not isinstance(records, list) or len(records) != EXPECTED_PACKETS):
        raise ValueError("root tool evidence must be the complete root-generated 64-packet ledger")
    expected_packets = {f"packet-{i:03d}" for i in range(1, EXPECTED_PACKETS + 1)}
    seen = set()
    for record in records:
        packet_id = record.get("packet_id")
        ordinal = int(packet_id.removeprefix("packet-")) if isinstance(packet_id, str) and packet_id.startswith("packet-") else 0
        expected_task_name = f"/root/body_r9_packet{ordinal:03d}" if ordinal else None
        common_ok = (packet_id not in seen and packet_id in expected_packets
            and record.get("requested_model_selector") == go.get("requested_model_selector")
            and record.get("trusted_selector_route") == go.get("trusted_selector_route"))
        if ordinal <= 39:
            call_ok = (record.get("tool_name") == "collaboration.spawn_agent"
                and record.get("fork_turns") == "none"
                and record.get("returned_task_name") == expected_task_name)
        else:
            target_name = record.get("target_task_name")
            expected_target = f"/root/body_r9_packet{ordinal - 39:03d}"
            call_ok = (record.get("tool_name") == "collaboration.followup_task"
                and record.get("origin_spawn_task_name") == target_name
                and target_name == expected_target
                and record.get("origin_requested_model_selector") == go.get("requested_model_selector")
                and record.get("worker_history_retained") is True
                and record.get("retained_history_disclosed_to_worker") is True
                and record.get("fork_turns") is None)
        if not common_ok or not call_ok:
            raise ValueError("root tool ledger has incomplete or mismatched returned task/selector evidence")
        seen.add(packet_id)
    if seen != expected_packets:
        raise ValueError("root tool ledger does not cover each of the 64 packet spawns exactly once")


def rows_from_bytes(data: bytes, source: str) -> list[dict]:
    rows = []
    for n, line in enumerate(data.splitlines(), 1):
        if not line.strip():
            raise ValueError(f"blank JSONL line {n} in {source}")
        item = json.loads(line)
        if not isinstance(item, dict):
            raise ValueError(f"non-object JSONL line {n} in {source}")
        rows.append(item)
    return rows


def make_failure_ledger(dispatch_ids: set[str], accepted_ids: set[str],
                        unaccepted_draft_records: list[dict]) -> list[dict]:
    if not accepted_ids <= dispatch_ids:
        raise ValueError("accepted response includes a non-dispatched pair")
    missing = dispatch_ids - accepted_ids
    by_id = {row.get("pair_id"): row for row in unaccepted_draft_records}
    if len(by_id) != len(unaccepted_draft_records) or set(by_id) != missing:
        raise ValueError("unaccepted drafts must account for every and only missing dispatched pair")
    failures = []
    for pair_id in sorted(missing):
        draft_row = by_id[pair_id]
        failures.append({"pair_id": pair_id,
            "status": "missing_firstpass_response_unknown",
            "failure_reason": "no registered byte-identical complete response file for first-pass draft",
            "model_judgment_recorded": False,
            "registered_complete_response_recorded": False,
            "unaccepted_firstpass_literal_present": True,
            "model_semantic_judgments_present_in_unaccepted_draft": draft_row["model_semantic_judgments_present_in_unaccepted_draft"],
            "draft_path": draft_row["draft_path"], "draft_sha256": draft_row["draft_sha256"],
            "draft_parse_error": draft_row.get("draft_parse_error"),
            "semantic_retry_performed": False})
    return failures


def verify_pre_ml(root_go_sha256: str) -> tuple[dict, dict, dict]:
    if sha_file(PRE_ML) != EXPECTED_PRE_ML_SHA256:
        raise ValueError("pre-ML freeze differs from the root-pinned SHA")
    pre = read_json(PRE_ML)
    if (pre.get("schema_version") != "sku-body-native-r9-pre-ml-freeze-v1"
            or pre.get("status") != "frozen_before_first_model_inference"
            or pre.get("packet_count") != EXPECTED_PACKETS
            or pre.get("dispatched_pair_count") != EXPECTED_DISPATCHED
            or pre.get("literal_protected_pair_count") != EXPECTED_PROTECTED
            or pre.get("model_inference_started") is not False
            or pre.get("labels_read") is not False or pre.get("test_labels_read") is not False
            or pre.get("scores_created") is not False):
        raise ValueError("pre-ML freeze fields do not authorize this snapshot")
    pins = pre.get("pins")
    if not isinstance(pins, list) or len(pins) != EXPECTED_PRE_ML_PINS:
        raise ValueError("pre-ML freeze does not contain exactly 175 input pins")
    seen = set()
    for item in pins:
        rel = item.get("path")
        if not isinstance(rel, str) or rel.startswith("/") or ".." in Path(rel).parts:
            raise ValueError("unsafe path in pre-ML frozen pin list")
        path = ROOT / rel
        if rel in seen or not path.is_file() or path.is_symlink() or pin(path) != {
                "bytes": item.get("bytes"), "sha256": item.get("sha256")}:
            raise ValueError(f"pre-ML pin mismatch: {rel}")
        seen.add(rel)
    if sha_file(ROOT_GO) != root_go_sha256:
        raise ValueError("root GO SHA does not match the caller-supplied frozen authorization pin")
    go = read_json(ROOT_GO)
    if (go.get("schema_version") != "sku-body-native-r9-root-classification-go-v1"
            or go.get("root_authorization") is not True
            or go.get("pre_ml_freeze_sha256") != EXPECTED_PRE_ML_SHA256
            or go.get("pre_ml_pin_count") != EXPECTED_PRE_ML_PINS
            or go.get("packet_count") != EXPECTED_PACKETS
            or go.get("pair_count") != EXPECTED_DISPATCHED
            or go.get("option_count") != pre.get("dispatched_whole_option_count")
            or go.get("labels_read") is not False or go.get("scores_created") is not False
            or go.get("semantic_retry_allowed") is not False
            or go.get("semantic_code_generation_allowed") is not False):
        raise ValueError("root GO does not match the frozen pre-ML packet authorization")
    return pre, go, {"pre_ml_freeze_sha256": sha_file(PRE_ML), "root_go_sha256": sha_file(ROOT_GO)}


def load_partition() -> tuple[dict, list[str], list[str]]:
    receipt, _ = ASSEMBLER.validate_partition(PARTITION, PREPARED, PROOFS)
    dispatch = [r["pair_id"] for r in ASSEMBLER.read_rows(PARTITION / "dispatch-pair-ids.jsonl")]
    protected = [r["pair_id"] for r in ASSEMBLER.read_rows(PARTITION / "literal-protected-pair-ids.jsonl")]
    if (len(dispatch) != EXPECTED_DISPATCHED or len(protected) != EXPECTED_PROTECTED
            or len(set(dispatch)) != len(dispatch) or len(set(protected)) != len(protected)):
        raise ValueError("source-derived R9 partition does not have exact 93/48 pair membership")
    return receipt, dispatch, protected


def collect_outputs(go: dict) -> tuple[list[dict], dict[str, Path], dict[str, Path]]:
    index = read_json(PACKET_INDEX)
    verify_packet_index_authorization(index, go)
    if (index.get("packet_count") != EXPECTED_PACKETS
            or index.get("dispatch_pair_count") != EXPECTED_DISPATCHED
            or index.get("literal_protected_pair_count") != EXPECTED_PROTECTED
            or index.get("labels_read") is not False or index.get("scores_created") is not False):
        raise ValueError("frozen pre-inference packet index differs from the authorized packet set")
    packet_rows = index.get("packets")
    if not isinstance(packet_rows, list) or len(packet_rows) != EXPECTED_PACKETS:
        raise ValueError("packet index must enumerate all 64 frozen packets")
    expected_ids: list[str] = []
    packet_paths: dict[str, Path] = {}
    for row in packet_rows:
        name = row.get("file")
        packet_id = Path(name).stem if isinstance(name, str) else ""
        if packet_id in packet_paths or not packet_id.startswith("packet-"):
            raise ValueError("packet index has duplicate or malformed packet filenames")
        path = EXECUTION / name
        if not path.is_file() or path.is_symlink() or pin(path) != {
                "bytes": row.get("bytes"), "sha256": row.get("sha256")}:
            raise ValueError(f"frozen packet file differs from packet index: {name}")
        packet_paths[packet_id] = path
        pair_ids = row.get("pair_ids")
        if not isinstance(pair_ids, list) or not pair_ids:
            raise ValueError(f"empty packet pair membership: {name}")
        expected_ids.extend(pair_ids)
    if len(expected_ids) != EXPECTED_DISPATCHED or len(set(expected_ids)) != len(expected_ids):
        raise ValueError("packets do not partition all 93 dispatched pair IDs uniquely")
    draft_dir, response_dir = EXECUTION / "drafts", EXECUTION / "responses"
    draft_paths = list(draft_dir.glob("packet-*.jsonl"))
    response_paths = list(response_dir.glob("packet-*.jsonl"))
    if any(not p.is_file() or p.is_symlink() for p in draft_paths + response_paths):
        raise ValueError("draft and response files must be regular nonsymlink files")
    drafts = {p.stem: p for p in draft_paths}
    responses = {p.stem: p for p in response_paths}
    expected_names = set(packet_paths)
    if set(drafts) != expected_names:
        raise ValueError("all 64 immutable first-draft files are required before freezing")
    if not set(responses) <= expected_names:
        raise ValueError("response files contain a foreign packet")
    return packet_rows, drafts, responses


def freeze(root_go_sha256: str, tool_records_path: Path, output_dir: Path) -> dict:
    pre, go, auth_pins = verify_pre_ml(root_go_sha256)
    tool_records_path = Path(tool_records_path).resolve()
    if (tool_records_path.is_symlink() or not tool_records_path.is_relative_to(ROOT / ".lab-output")
            or not tool_records_path.is_file()):
        raise ValueError("root-side tool execution evidence must be a regular file under .lab-output")
    verify_tool_evidence(read_json(tool_records_path), go)
    partition_receipt, dispatch, protected = load_partition()
    packet_rows, drafts, responses = collect_outputs(go)
    expected_by_packet = {Path(row["file"]).stem: row["pair_ids"] for row in packet_rows}
    dispatch_set, protected_set = set(dispatch), set(protected)
    if set().union(*(set(ids) for ids in expected_by_packet.values())) != dispatch_set:
        raise ValueError("packet-index pair IDs differ from the source-derived dispatch set")
    output_dir = output_dir.resolve()
    if (output_dir.exists() or output_dir.is_symlink()
            or not output_dir.is_relative_to(ROOT / ".lab-output")):
        raise FileExistsError("snapshot output must be a new regular directory under .lab-output")

    accepted_payloads: list[bytes] = []
    response_inventory: dict[str, dict] = {}
    draft_inventory: dict[str, dict] = {}
    accepted_pair_ids: list[str] = []
    unaccepted_draft_records: list[dict] = []
    for packet_id in sorted(drafts):
        draft = drafts[packet_id]
        draft_bytes = draft.read_bytes()
        draft_inventory[draft.name] = pin(draft)
        draft_parse_error = None
        try:
            rows = rows_from_bytes(draft_bytes, str(draft))
        except (ValueError, json.JSONDecodeError) as exc:
            rows = []
            draft_parse_error = f"{type(exc).__name__}: {exc}"
        draft_ids = [r.get("pair_id") for r in rows]
        response = responses.get(packet_id)
        if response is None:
            rows_by_id = {r.get("pair_id"): r for r in rows}
            for pair_id in expected_by_packet[packet_id]:
                row = rows_by_id.get(pair_id, {})
                if pair_id not in dispatch_set:
                    raise ValueError("packet index contains a protected or foreign pair")
                unaccepted_draft_records.append({
                    "packet_id": packet_id, "pair_id": pair_id,
                    "draft_path": f"drafts/{draft.name}", "draft_sha256": sha_bytes(draft_bytes),
                    "draft_parse_error": draft_parse_error,
                    "unaccepted_firstpass_literal_present": True,
                    "model_semantic_judgments_present_in_unaccepted_draft": bool(
                        isinstance(row.get("decisions"), list) and row.get("decisions")),
                    "registered_complete_response_recorded": False,
                    "model_judgment_recorded": False,
                })
            continue
        response_bytes = response.read_bytes()
        if response_bytes != draft_bytes:
            raise ValueError(f"registered response bytes differ from original draft: {packet_id}")
        if response_bytes and not response_bytes.endswith(b"\n"):
            raise ValueError(f"registered response lacks terminal JSONL newline; refusing byte alteration: {packet_id}")
        parsed = rows_from_bytes(response_bytes, str(response))
        ids = [r.get("pair_id") for r in parsed]
        if ids != expected_by_packet[packet_id]:
            raise ValueError(f"registered packet response does not contain the exact packet pair order: {packet_id}")
        if set(ids) & protected_set or not set(ids) <= dispatch_set:
            raise ValueError(f"registered response contains protected or foreign pair: {packet_id}")
        accepted_pair_ids.extend(ids)
        accepted_payloads.append(response_bytes)
        response_inventory[response.name] = pin(response)
    if len(accepted_pair_ids) != len(set(accepted_pair_ids)):
        raise ValueError("registered responses duplicate a dispatched pair ID")
    if set(accepted_pair_ids) & {r["pair_id"] for r in unaccepted_draft_records}:
        raise ValueError("a pair appears in both accepted response and unaccepted draft")
    missing = dispatch_set - set(accepted_pair_ids)
    drafted = {r["pair_id"] for r in unaccepted_draft_records}
    if missing != drafted:
        raise ValueError("every missing dispatch must have an exact preserved unaccepted draft record")
    if not go.get("hosted_weights_independently_attested") is False:
        raise ValueError("unexpected hosted-weight attestation state")

    # Preserve exact source bytes as per-file copies plus byte-for-byte concatenated JSONL.
    output_dir.mkdir(parents=True)
    try:
        shutil.copytree(EXECUTION / "drafts", output_dir / "drafts", dirs_exist_ok=True)
        shutil.copytree(EXECUTION / "responses", output_dir / "responses", dirs_exist_ok=True)
        raw_bytes = b"".join(accepted_payloads)
        raw_path = output_dir / "raw-responses.jsonl"
        raw_path.write_bytes(raw_bytes)
        failures = make_failure_ledger(dispatch_set, set(accepted_pair_ids), unaccepted_draft_records)
        fail_path = output_dir / "failure-ledger.jsonl"
        with fail_path.open("xb") as stream:
            for failure in failures:
                stream.write(json.dumps(failure, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8") + b"\n")
        response_ids_sorted = sorted(accepted_pair_ids)
        receipt = {
            "schema_version": "sku-next-body-invariant-dev10-r9-literal-snapshot-v1",
            "status": "complete_firstpass_snapshot_frozen",
            "snapshot_path": ASSEMBLER.relpath(raw_path),
            "snapshot_bytes": len(raw_bytes), "snapshot_sha256": sha_bytes(raw_bytes),
            "draft_count": len(drafts), "draft_inventory": draft_inventory,
            "response_file_count": len(responses), "response_inventory": response_inventory,
            "responses_are_byte_identical_to_first_drafts": True,
            "response_count": len(accepted_pair_ids),
            "response_pair_ids_sha256": ASSEMBLER.BODY.sha_bytes(ASSEMBLER.BODY.canon(response_ids_sorted)),
            "expected_dispatched_pair_count": len(dispatch),
            "expected_dispatched_pair_ids_sha256": ASSEMBLER.BODY.sha_bytes(ASSEMBLER.BODY.canon(sorted(dispatch))),
            "literal_protected_pair_count": len(protected),
            "literal_protected_pair_ids_sha256": ASSEMBLER.BODY.sha_bytes(ASSEMBLER.BODY.canon(sorted(protected))),
            "prepared_pair_count": len(dispatch) + len(protected),
            "pair_partition_receipt_sha256": sha_file(PARTITION / "pair-partition-receipt.json"),
            "failure_ledger_path": ASSEMBLER.relpath(fail_path),
            "failure_ledger_bytes": fail_path.stat().st_size, "failure_ledger_sha256": sha_file(fail_path),
            "failure_count": len(failures),
            "unaccepted_firstpass_literal_count": len(unaccepted_draft_records),
            "unaccepted_draft_pair_records": unaccepted_draft_records,
            "registered_complete_response_recorded": bool(accepted_pair_ids),
            "all_predictions_frozen": True,
            "labels_read": False, "test_labels_read": False, "scores_created": False,
            "production_adoption_allowed": False,
            "pre_ml_freeze_sha256": auth_pins["pre_ml_freeze_sha256"],
            "root_classification_go_sha256": auth_pins["root_go_sha256"],
            "root_tool_execution_evidence_path": ASSEMBLER.relpath(tool_records_path),
            "root_tool_execution_evidence_bytes": tool_records_path.stat().st_size,
            "root_tool_execution_evidence_sha256": sha_file(tool_records_path),
            "root_requested_model_selector": go.get("requested_model_selector"),
            "hosted_weights_independently_attested": False,
            "model_self_report_is_attestation": False,
            "inference_claim_source": "root-side tool execution record only; worker/model self-report is not attestation",
            "partition_receipt_sha256": sha_file(PARTITION / "pair-partition-receipt.json"),
            "packet_index_sha256": sha_file(PACKET_INDEX),
            "pre_ml_pin_count_verified": EXPECTED_PRE_ML_PINS,
            "packet_count": EXPECTED_PACKETS,
            "model_judgment_recorded_semantics": "true means an accepted, registered complete first-pass response; false means no accepted response was registered, even where preserved unaccepted draft bytes contain judgments",
            "semantic_retry_performed": False,
        }
        receipt_path = output_dir / "snapshot-receipt.json"
        receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        inventory = {"schema_version": "body-dev10-r9-snapshot-inventory-v1",
            "files": {p.relative_to(output_dir).as_posix(): pin(p)
                for p in sorted(output_dir.rglob("*")) if p.is_file() and p.name != "snapshot-inventory.json"},
            "labels_read": False, "scores_created": False, "semantic_retry_performed": False}
        (output_dir / "snapshot-inventory.json").write_text(json.dumps(inventory, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        # Run the frozen downstream contract against the copied raw snapshot and ledger.
        ASSEMBLER.validate_snapshot(raw_path, receipt_path,
            set(dispatch), set(protected), sha_file(PARTITION / "pair-partition-receipt.json"))
        return {"snapshot_dir": str(output_dir), "response_count": len(accepted_pair_ids),
                "failure_count": len(failures), "unaccepted_draft_count": len(unaccepted_draft_records),
                "raw_snapshot_sha256": sha_file(raw_path), "receipt_sha256": sha_file(receipt_path)}
    except Exception as exc:
        (output_dir / "freeze-failure.json").write_text(json.dumps({"error_type": type(exc).__name__,
            "error": str(exc), "labels_read": False, "scores_created": False,
            "source_drafts_preserved": True}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-go-sha256", required=True,
        help="full SHA-256 of the root-owned root-classification-go.json authorization")
    parser.add_argument("--tool-records-file", type=Path, required=True,
        help="root-side tool execution evidence under .lab-output; model self-report is not evidence")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    result = freeze(args.root_go_sha256, args.tool_records_file, args.output_dir)
    print(json.dumps(result, sort_keys=True))

if __name__ == "__main__":
    main()
