#!/usr/bin/env python3
"""Identity-only deterministic TEST subset plan; never reads test evidence fields."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
TEST_ROOT = ROOT / ".lab-output/sku-full-condition-adapter-20261013-v2/test"
FULL_MANIFEST = TEST_ROOT / "manifest.json"
FULL_CASE_PLANS = TEST_ROOT / "case-plans.jsonl"
FINAL_FREEZE = ROOT / ".lab-output/sku-final-test-execution-20261013-v1/experiment-freeze.json"
HOLDOUT_FREEZE = ROOT / ".lab-output/sku-unused-holdout-choice-execution-20261013-v1/experiment-freeze.json"
FINAL_SUBSET_MEMBERSHIP = ROOT / ".lab-output/sku-final-composition-subset-20261013-v1/plan/subset-membership.jsonl"
HOLDOUT_MEMBERSHIP = ROOT / ".lab-output/sku-unused-holdout-choice-20261013-v1/selection-membership.jsonl"
SALT = "sku-body-final-test-identity-plan-v1|hash-rank|2026-10-13"
PRODUCT_SAMPLE_N = 20
CASES_PER_PRODUCT = 2


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canon(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def rows(path: Path, allowed_keys: set[str]) -> list[dict[str, Any]]:
    """Read identity fields only; reject files whose records include evidence fields."""
    result = []
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            if not line.strip():
                continue
            item = json.loads(line)
            if not isinstance(item, dict) or not set(item).issubset(allowed_keys):
                extra = sorted(set(item) - allowed_keys) if isinstance(item, dict) else ["not_object"]
                raise ValueError(f"non-identity field present in identity input: {path.name}: {extra}")
            result.append(item)
    return result


def rank(kind: str, value: Any) -> str:
    text = str(value)
    return hashlib.sha256((SALT + "\0" + kind + "\0" + text).encode("utf-8")).hexdigest()


def write_json(path: Path, value: Any) -> bytes:
    raw = canon(value) + b"\n"
    path.write_bytes(raw)
    return raw


def write_jsonl(path: Path, values: list[dict[str, Any]]) -> bytes:
    raw = b"".join(canon(value) + b"\n" for value in values)
    path.write_bytes(raw)
    return raw


def main() -> None:
    if not OUT.exists():
        OUT.mkdir(parents=True)
    if any(path.name != "build_identity_plan.py" for path in OUT.iterdir()):
        raise FileExistsError("identity plan output directory must be empty")

    # Load only frozen checkpoint metadata to resolve the canonical excluded membership paths.
    final_freeze = json.loads(FINAL_FREEZE.read_text(encoding="utf-8"))
    holdout_freeze = json.loads(HOLDOUT_FREEZE.read_text(encoding="utf-8"))
    final_snapshot = final_freeze["source_snapshot"]
    final_key = str(FINAL_SUBSET_MEMBERSHIP)
    holdout_key = str(HOLDOUT_MEMBERSHIP.relative_to(ROOT))
    final_ref = final_snapshot.get(final_key)
    holdout_ref = holdout_freeze["frozen_files"].get(holdout_key)
    if not isinstance(final_ref, dict) or not isinstance(holdout_ref, dict):
        raise ValueError("frozen checkpoint does not name the expected identity membership files")

    full_manifest = json.loads(FULL_MANIFEST.read_text(encoding="utf-8"))
    full_case_sha = full_manifest.get("outputs_sha256", {}).get("case-plans.jsonl")
    if not isinstance(full_case_sha, str) or sha(FULL_CASE_PLANS) != full_case_sha:
        raise ValueError("TEST identity case-plan SHA does not match frozen TEST manifest")
    if sha(FINAL_SUBSET_MEMBERSHIP) != final_ref.get("sha256"):
        raise ValueError("first TEST20 membership SHA differs from its frozen checkpoint")
    if sha(HOLDOUT_MEMBERSHIP) != holdout_ref.get("sha256"):
        raise ValueError("unused-holdout20 membership SHA differs from its frozen checkpoint")

    case_rows = rows(FULL_CASE_PLANS, {"au_product_id", "case_id", "dossier_id", "variant_id",
        "source_sku_key", "sku_record_key", "source_version", "split", "total_au_rows",
        "total_task_bindings", "rakuten_axis_count", "all_original_au_rows_covered",
        "all_original_rakuten_axes_covered", "strict_core_residual_proof_used", "typed_proof_used",
        "raw_selected_sku_source_sha256", "row_keys"})
    # Exclusion membership files are restricted to ID fields only.
    first_rows = rows(FINAL_SUBSET_MEMBERSHIP, {"au_product_id", "case_id", "dossier_id",
        "source_version", "selection_hash", "metadata_condition_count", "metadata_unique_request_count"})
    second_rows = rows(HOLDOUT_MEMBERSHIP, {"au_product_id", "case_id", "dossier_id", "source_version", "selection_hash"})

    product_cases: dict[str, dict[str, Any]] = {}
    case_ids: set[str] = set()
    for item in case_rows:
        product, case = str(item["au_product_id"]), str(item["case_id"])
        if item.get("split") != "test" or case in case_ids:
            raise ValueError("TEST case identity is duplicated or outside the frozen test split")
        case_ids.add(case)
        entry = product_cases.setdefault(product, {"au_product_id": item["au_product_id"], "case_ids": []})
        entry["case_ids"].append(item["case_id"])
    if len(product_cases) != 106 or len(case_rows) != 1292:
        raise ValueError("TEST identity population does not match frozen 106-product/1292-case manifest")

    def membership_ids(items: list[dict[str, Any]], label: str) -> tuple[set[str], set[str]]:
        products, cases = set(), set()
        for item in items:
            products.add(str(item["au_product_id"]))
            case = str(item["case_id"])
            if case in cases:
                raise ValueError(f"duplicate case ID in {label} frozen membership")
            cases.add(case)
        return products, cases

    first_products, first_cases = membership_ids(first_rows, "first TEST20")
    second_products, second_cases = membership_ids(second_rows, "unused holdout20")
    if len(first_products) != 20 or len(second_products) != 20 or first_products & second_products:
        raise ValueError("frozen 20-product exclusion sets are malformed or overlap")
    excluded_products = first_products | second_products
    if not excluded_products.issubset(product_cases):
        raise ValueError("frozen exclusion membership references a product outside TEST")
    if not first_cases.issubset(case_ids) or not second_cases.issubset(case_ids):
        raise ValueError("frozen exclusion membership references a case outside TEST")

    unused_products = [p for p in product_cases if p not in excluded_products]
    if len(unused_products) != 66:
        raise ValueError("expected 66 unused TEST products after whole-product exclusions")
    unused_cases_by_product = {
        p: sorted(product_cases[p]["case_ids"], key=lambda c: (rank("case", c), c))
        for p in unused_products
    }
    eligible_products = [p for p in unused_products
                         if len(unused_cases_by_product[p]) >= CASES_PER_PRODUCT]
    undersized_products = [p for p in unused_products
                           if len(unused_cases_by_product[p]) < CASES_PER_PRODUCT]
    if len(eligible_products) < PRODUCT_SAMPLE_N:
        raise ValueError("fewer than 20 unused products have at least two identity-only test cases")

    ranked_products = sorted(eligible_products, key=lambda p: (rank("product", p), p))
    selected_products = ranked_products[:PRODUCT_SAMPLE_N]
    subset_rows = []
    for product_rank, product in enumerate(selected_products, start=1):
        ordered_cases = unused_cases_by_product[product]
        for case_rank, case_id in enumerate(ordered_cases[:CASES_PER_PRODUCT], start=1):
            subset_rows.append({"au_product_id": product_cases[product]["au_product_id"],
                "case_id": case_id, "product_rank": product_rank, "case_rank": case_rank,
                "product_rank_sha256": rank("product", product), "case_rank_sha256": rank("case", case_id)})

    all_unused_product_rows = []
    all_unused_case_rows = []
    for product in sorted(unused_products):
        cases = sorted(product_cases[product]["case_ids"], key=str)
        all_unused_product_rows.append({"au_product_id": product_cases[product]["au_product_id"],
            "test_case_count": len(cases)})
        all_unused_case_rows.extend({"au_product_id": product_cases[product]["au_product_id"], "case_id": case}
                                    for case in cases)
    excluded_rows = []
    for product in sorted(first_products):
        excluded_rows.append({"au_product_id": product_cases[product]["au_product_id"], "exclusion_set": "first_test20"})
    for product in sorted(second_products):
        excluded_rows.append({"au_product_id": product_cases[product]["au_product_id"], "exclusion_set": "unused_holdout20"})
    undersized_rows = [{"au_product_id": product_cases[p]["au_product_id"],
        "test_case_count": len(unused_cases_by_product[p]), "sample_eligibility": "fewer_than_two_cases"}
        for p in sorted(undersized_products)]

    files = {}
    files["selected-membership.jsonl"] = write_jsonl(OUT / "selected-membership.jsonl", subset_rows)
    files["unused-product-identities.jsonl"] = write_jsonl(OUT / "unused-product-identities.jsonl", all_unused_product_rows)
    files["unused-case-identities.jsonl"] = write_jsonl(OUT / "unused-case-identities.jsonl", all_unused_case_rows)
    files["excluded-products.jsonl"] = write_jsonl(OUT / "excluded-products.jsonl", excluded_rows)
    files["undersized-unused-products.jsonl"] = write_jsonl(OUT / "undersized-unused-products.jsonl", undersized_rows)
    manifest = {
        "schema_version": "sku-body-final-test-identity-plan-v1",
        "status": "identity_only_subset_plan_no_test_evidence_read",
        "test_source_manifest_sha256": sha(FULL_MANIFEST),
        "test_case_plans_sha256": sha(FULL_CASE_PLANS),
        "test_case_plans_path": str(FULL_CASE_PLANS.relative_to(ROOT)),
        "test_product_count": len(product_cases), "test_case_count": len(case_rows),
        "first_test20_freeze_path": str(FINAL_FREEZE.relative_to(ROOT)),
        "first_test20_membership_path": str(FINAL_SUBSET_MEMBERSHIP.relative_to(ROOT)),
        "first_test20_membership_sha256": sha(FINAL_SUBSET_MEMBERSHIP),
        "unused_holdout20_freeze_path": str(HOLDOUT_FREEZE.relative_to(ROOT)),
        "unused_holdout20_membership_path": str(HOLDOUT_MEMBERSHIP.relative_to(ROOT)),
        "unused_holdout20_membership_sha256": sha(HOLDOUT_MEMBERSHIP),
        "excluded_product_count": len(excluded_products),
        "checkpoint_membership_case_count": len(first_cases | second_cases),
        "excluded_test_case_population_count": sum(len(product_cases[p]["case_ids"])
                                                    for p in excluded_products),
        "unused_product_count": len(unused_products),
        "unused_case_count": len(all_unused_case_rows),
        "sample_eligible_unused_product_count": len(eligible_products),
        "undersized_unused_product_count": len(undersized_products),
        "selection_salt": SALT, "selection_rank": "sha256(salt || NUL || kind || NUL || string(identity)); then identity lexical tie-break",
        "selected_product_count": PRODUCT_SAMPLE_N, "cases_per_selected_product": CASES_PER_PRODUCT,
        "selected_case_count": len(subset_rows),
        "selected_product_ids": [product_cases[p]["au_product_id"] for p in selected_products],
        "selected_case_ids": [row["case_id"] for row in subset_rows],
        "selected_products_disjoint_from_exclusions": not (set(map(str, selected_products)) & excluded_products),
        "selection_based_only_on_identity_fields": True,
        "test_condition_text_body_labels_gold_predictions_read": False,
        "model_inference_or_grading_run": False,
        "production_adoption_allowed": False,
        "outputs_sha256": {name: hashlib.sha256(raw).hexdigest() for name, raw in files.items()},
        "outputs_bytes": {name: len(raw) for name, raw in files.items()},
    }
    write_json(OUT / "manifest.json", manifest)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
