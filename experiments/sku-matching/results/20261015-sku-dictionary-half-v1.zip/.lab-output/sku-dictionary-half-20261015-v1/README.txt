SKU dictionary grouped half split, final v1

Base repository checkpoint: 40ab9b24b8e2fae3ca7f85b1465603cd0b0f834b
Branch: codex-sku-generic-model-gates-20261010

This ZIP stores the new split, dictionaries, all eight frozen EVAL predictions,
selected TRAIN/EVAL machine references, grades, independent audit, code and logs.
MANIFEST.json lists SHA256/size of every other archived member. Entry paths are
repository-relative. Extract into a separate copy of the base repository;
do not overwrite older experiments. Existing corpus archives are not duplicated.
The .lab-output directory is ignored by Git, so its files are explicitly archived.

Read experiments/sku-matching/results/20261015-sku-dictionary-half-v1.txt first.
No human gold or fresh independent-test accuracy is claimed. 56 primary automatic
decisions have unknown machine reference; errors reported as zero apply only to
known machine references. Extra two correct decisions are from one product.
The fixed dictionary is an experiment; production gate remains unchanged.

Full source verification / replay requires the base checkpoint's existing
20261015-sku-library-volume-v1.zip and 20261015-sku-library-axis-domains-v2.zip
workspaces and the original v2/v3 private machine reference archives for regrading.
The selected references in this ZIP allow score inspection without those archives.
Absolute input-pin paths describe the original /workspace/Searching_Experiment
workspace. Keep original receipts unchanged; relocated runs need new receipts.

Python >=3.12; use the existing sku-classical venv / requirements-axis-domains-v1.txt.
NetworkX 3.5. The original split ran under NetworkX 3.7; a separate 3.5 rerun gave
identical SHA256 for every split artifact (split-replay-verification.json).

CLI (new output directories required; replace OUTPUT names):
.deps/sku-classical-venv/bin/python -B experiments/sku-matching/run_dictionary_half_v1.py --phase build --split-dir .lab-output/sku-dictionary-half-20261015-v1/split-v1 --corpus-manifest .lab-output/sku-dictionary-half-20261015-v1/CORPUS_MANIFEST.json --train-refs .lab-output/sku-dictionary-half-20261015-v1/train-reference-v1.json --plan .lab-output/sku-dictionary-half-20261015-v1/EXPERIMENT_PLAN.json --output OUTPUT_DICT
.deps/sku-classical-venv/bin/python -B experiments/sku-matching/run_dictionary_half_v1.py --phase predict --split-dir .lab-output/sku-dictionary-half-20261015-v1/split-v1 --corpus-manifest .lab-output/sku-dictionary-half-20261015-v1/CORPUS_MANIFEST.json --plan .lab-output/sku-dictionary-half-20261015-v1/EXPERIMENT_PLAN.json --dictionaries OUTPUT_DICT --output OUTPUT_EVAL
.deps/sku-classical-venv/bin/python -B experiments/sku-matching/grade_dictionary_half_v1.py --run OUTPUT_EVAL --split-dir .lab-output/sku-dictionary-half-20261015-v1/split-v1 --plan .lab-output/sku-dictionary-half-20261015-v1/EXPERIMENT_PLAN.json --dictionaries OUTPUT_DICT --output OUTPUT_GRADE

13 focused tests pass. Required full suite: 1571 tests, failures4/errors66/skips60;
failure/error names match the previous baseline. Logs are included. No model
inference, model download, Kaggle job, or scheduled dictionary updater was used.
