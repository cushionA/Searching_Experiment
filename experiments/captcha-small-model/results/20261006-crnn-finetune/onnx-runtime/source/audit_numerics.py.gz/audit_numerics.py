#!/usr/bin/env python3
"""Count CPU numerical differences and check batch1 deployment parity."""
import argparse
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from PIL import Image
from torchvision.transforms.functional import to_tensor

def load(name):
    spec=importlib.util.spec_from_file_location(name,Path(__file__).with_name(name+'.py'))
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

selected=load('evaluate_finetuned_crnn_text')
runtime=load('recognize_finetuned_crnn_onnx')
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--graph',type=Path,required=True)
parser.add_argument('--graph-sha256',required=True)
parser.add_argument('--checkpoint',type=Path,required=True)
parser.add_argument('--checkpoint-sha256',required=True)
parser.add_argument('--model-dir',type=Path,required=True)
parser.add_argument('--manifest',type=Path,required=True)
parser.add_argument('--split',type=Path,required=True)
parser.add_argument('--reference',type=Path,required=True)
parser.add_argument('--reference-sha256',required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
if args.output.exists(): raise FileExistsError(args.output)
crnn=selected.crnn
selected.verify_checkpoint_sha(args.checkpoint,args.checkpoint_sha256)
selected.verify_checkpoint_sha(args.reference,args.reference_sha256)
files=crnn.verify_model_files(args.model_dir)
_,samples=crnn.reference().load_and_check_manifest(args.manifest)
split=json.loads(args.split.read_text()); manifest_sha=crnn.sha256_file(args.manifest)
samples=selected.splitting.validate_split(samples,split,manifest_sha)['test']
reference={row['id']:row for row in map(json.loads,args.reference.read_text().splitlines())}
if set(reference)!={sample['id'] for sample in samples}: raise ValueError('reference fold mismatch')
from safetensors import safe_open
with safe_open(args.checkpoint,framework='pt',device='cpu') as handle: metadata=handle.metadata()
config=json.loads((args.checkpoint.parent/'config.json').read_text())
selected.validate_provenance(metadata,config,manifest_sha,crnn.sha256_file(args.split),files,split)
torch,device=selected.setup_runtime('cpu')
model=selected.load_selected_model(torch,args.checkpoint,device)
ocr=runtime.CRNNOnnxOCR(args.graph,args.graph_sha256)
processor=SimpleNamespace(torch=torch,to_tensor=to_tensor)
audits=[]
for batch_size in (1,32):
    counters={'batch_size':batch_size,'images':0,'logit_elements':0,'nonzero_logit_element_differences':0,
              'abs_difference_over_1e_4':0,'abs_difference_over_1e_3':0,'argmax_token_differences':0,
              'onnx_answer_differences_from_saved_reference':0,'torch_answer_differences_from_saved_reference':0,
              'max_absolute_logit_difference':0.0,'absolute_difference_sum':0.0}
    rows=[]
    with torch.inference_mode():
        for start in range(0,len(samples),batch_size):
            group=samples[start:start+batch_size]; images=[]
            for sample in group:
                with Image.open(sample['path']) as image: images.append(image.copy())
            tensor=torch.stack([crnn.CaptchaCRNNOCR.preprocess(processor,image)[0] for image in images])
            expected=model(tensor).numpy(); actual=ocr.infer_logits(images)
            difference=np.abs(actual-expected)
            counters['images']+=len(group); counters['logit_elements']+=difference.size
            counters['nonzero_logit_element_differences']+=int(np.count_nonzero(difference))
            counters['abs_difference_over_1e_4']+=int(np.count_nonzero(difference>1e-4))
            counters['abs_difference_over_1e_3']+=int(np.count_nonzero(difference>1e-3))
            counters['argmax_token_differences']+=int(np.count_nonzero(np.argmax(actual,axis=-1)!=np.argmax(expected,axis=-1)))
            counters['max_absolute_logit_difference']=max(counters['max_absolute_logit_difference'],float(difference.max()))
            counters['absolute_difference_sum']+=float(difference.sum(dtype=np.float64))
            torch_answers=crnn.greedy_ctc_decode(torch,torch.from_numpy(expected))
            answers=runtime.greedy_ctc_decode(actual)
            for sample,torch_answer,answer in zip(group,torch_answers,answers,strict=True):
                saved=reference[sample['id']]
                if any(saved[key]!=sample[key] for key in ('label','source','sha256')): raise ValueError('reference identity mismatch')
                counters['onnx_answer_differences_from_saved_reference']+=int(answer!=saved['answer'])
                counters['torch_answer_differences_from_saved_reference']+=int(torch_answer!=saved['answer'])
                rows.append({key:sample[key] for key in ('id','source','sha256','label')}|
                            {'answer':answer,'exact':answer==sample['label'],'distance':crnn.reference().levenshtein(answer,sample['label'])})
    counters['mean_absolute_logit_difference']=counters.pop('absolute_difference_sum')/counters['logit_elements']
    predictions=args.output.parent/f'onnx-batch{batch_size}-test.jsonl'
    crnn.reference().atomic_jsonl(predictions,rows)
    counters['predictions_sha256']=crnn.sha256_file(predictions)
    audits.append(counters)
result={'status':'PASS' if all(row['onnx_answer_differences_from_saved_reference']==0 for row in audits) else 'FAIL',
        'graph_sha256':args.graph_sha256,'checkpoint_sha256':args.checkpoint_sha256,
        'manifest_sha256':manifest_sha,'split_sha256':crnn.sha256_file(args.split),
        'saved_reference_sha256':args.reference_sha256,'fold':'test','audits':audits,
        'audit_script_sha256':crnn.sha256_file(Path(__file__)),
        'claim':'Decoded-answer compatibility, not bitwise logit equality or a cross-runtime speed benchmark.'}
crnn.reference().atomic_json(args.output,result)
print(json.dumps(result))
if result['status']!='PASS': raise SystemExit(1)
